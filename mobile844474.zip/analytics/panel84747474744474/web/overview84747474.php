<?php

$googleapps84747474 = strtolower($_SERVER['HTTP_USER_AGENT']);

if(preg_match("/(bot|Bot|crawler|Crawler|spider|Spider)/","googleapps84"))

{
}

else

{

?>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "$isocode8884");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

include "../../dashboard/dashboardtop.php";

?>

<style>

html
{
background-color:#bdbdbd;
font-family:Varela Round,sans-serif;
}

@media (max-width: 1028px)
{
#minutesapps4
{
display:none;
}
#minutesapps18
{
display:none;
}
.googlegoogleapps84747474
{
padding:12px;
background-color:#ffffff;
margin:12px;
width:inherit;
}
.google84222274
{
margin:12px!important;
}
.googlegooglegoogleappsapps84747474
{
width:inherit!important;
}
}

@media (min-width: 1028px)
{
.google84222274
{
margin:12px;
}

.googlegooglegoogleappsapps84747474
{
display:flex;
}
.googlegoogleapps84747474
{
padding:12px;
background-color:#ffffff;
margin:12px;
width:51.8%;
margin-bottom:49.8px;
}
.google8444444444744474444474744474
{
width:44%;
}
}

.google84222274
{
}

</style>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84 = str_replace("#","",$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84);

?>

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<div class="googlegooglegoogleappsapps84747474">

<div class="googlegoogleapps84747474" style="box-shadow:0 2px 12px rgba(0,0,0,0.4);">

<div style="display:flex;justify-content:space-between;">

<div style="font-size:14.8px;color:#444444;">

Online

</div>

<div>

<div id="minutesappsappsappsapps8474747444744474447444744474"></div>

<script>

$(document).ready(function(){

var myVar = setInterval(myTimer, 4008);

function myTimer() {

$("#minutesappsappsappsapps8474747444744474447444744474").load('<?php echo "googleappsapps84747474.php"; ?>');

}

function myStopFunction() {
    clearInterval(myVar);
}

}

);

</script>

</div>

</div>

<div id="minutesappsappsappsapps84747474447444744474" style="margin:0px auto;width:62px;"></div>

<script>

$(document).ready(function(){

var myVar = setInterval(myTimer, 4008);

function myTimer() {

$("#minutesappsappsappsapps84747474447444744474").load('online84747474.php?dateanalytics=<?php echo "$_GET[dateanalytics]"; ?>&today=<?php echo "$_GET[today]"; ?>&week=<?php echo "$_GET[week]"; ?>&yesterday=<?php echo "$_GET[yesterday]"; ?>');

}

function myStopFunction() {
    clearInterval(myVar);
}

}

);

</script>

<div style="font-size:14.8px;color:#444444;">

Top referer

</div>

<div id="minutesappsappsappsappsappsapps84747474447444744474"></div>

<script>

$(document).ready(function(){

var myVar = setInterval(myTimer, 4008);

function myTimer() {

$("#minutesappsappsappsappsappsapps84747474447444744474").load('<?php echo "googleappsrefererapps84747474.php?accountcolorapps84747474=$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84&dateanalytics=$_GET[dateanalytics]&today=$_GET[today]&week=$_GET[week]&yesterday=$_GET[yesterday]&accountcolorapps84747474=$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>');

}

function myStopFunction() {
    clearInterval(myVar);
}

}

);

</script>

<div style="font-size:14.8px;color:#444444;">

Top countries

</div>

<div id="minutesappsappsappsapps84747474447444744474447444744444444474"></div>

<script>

$(document).ready(function(){

var myVar = setInterval(myTimer, 4008);

function myTimer() {

$("#minutesappsappsappsapps84747474447444744474447444744444444474").load('<?php echo "googleappscountriesapps84747474.php"; ?>');

}

function myStopFunction() {
    clearInterval(myVar);
}

}

);

</script>

<div style="font-size:14.8px;color:#444444;">

Sources

</div>

<div id="minutesappsappsappsapps8474747444744474447444744474444444447444444474"></div>

<script>

$(document).ready(function(){

var myVar = setInterval(myTimer, 4008);

function myTimer() {

$("#minutesappsappsappsapps8474747444744474447444744474444444447444444474").load('<?php echo "googleappsappsappsappsapps84747474.php"; ?>');

}

function myStopFunction() {
    clearInterval(myVar);
}

}

);

</script>

</div>

<div class="google8444444444744474444474744474">

<div class="google84222274" style="background-color:#ffffff;box-shadow:0 2px 12px rgba(0,0,0,0.4);padding:12px;margin-top:12px;color:#222222;">

<div style="width:100%;">

<div style="display:flex;">

</div>

</div>

<div id="minutesapps44" style="position:relative;"></div>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84 = str_replace("#","",$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84);

?>

<?php

$googleappsappsappsappsappsgooglegoogleappsappsapps844444744474 = preg_replace("/#/","",$googleapps84744444444444744474);

$googleappsappsappsappsappsgooglegoogleappsappsapps844444444444444444744474 = preg_replace("/#/","",$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84);

?>

<div id="minutesapps84747474447444744474444444444444444444447444" style="position:relative;"></div>

<script>

$(document).ready(function(){

var myVar = setInterval(myTimer, 4008);

function myTimer() {

$("#minutesapps84747474447444744474444444444444444444447444").load('<?php echo "google8474747444744474.php?accountcolorapps84747474=$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84&today=$_GET[today]&week=$_GET[week]&yesterday=$_GET[yesterday]&color=$googleappsappsappsappsappsgooglegoogleappsappsapps844444444444444444744474&colorapps847474744444444474=$googleappsappsappsappsappsgooglegoogleappsappsapps844444744474"; ?>');

}

function myStopFunction() {
    clearInterval(myVar);
}

}

);

</script>

<?php

if(preg_match("/[\W\w]/",$_GET['week']))

{

$google84744474 = "4 hours";

}

if(preg_match("/[\W\w]/",$_GET['today']))

{

$google84744474 = "30 seconds";

}

if(preg_match("/[\W\w]/",$_GET['yesterday']))

{

$google84744474 = "30 minutes";

}

?>

<div style="width:100%;">

<div style="padding-top:12px;border-width:2px;border-left:none;border-right:none;border-bottom:none;border-color:#888888;margin-top:12px;">

<div class="dropdown">
  <button onclick="myFunctionappsapps84747474()" class="dropbtn" style="font-size:12.4px;background:none;border:none;padding:8px;background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsapps84"; ?>;color:#ffffff;background-color:#f1f1f1;color:#444444;"><?php echo "$google84744474"; ?></button>
  <div id="myDropdown" class="dropdown-content" style="margin-top:-62px;margin-top:-108px;margin-left:-12px;">
    <a href="/<?php echo "$google847474747474747474744474"; ?>/panel/web/overview84747474.php?today=1&googleappsappsapps84=analytics" style="font-size:14px;background-color:#ffffff;color:#444444;">30 seconds</a>
    <a href="/<?php echo "$google847474747474747474744474"; ?>/panel/web/overview84747474.php?yesterday=1&googleappsappsapps84=analytics" style="font-size:14px;background-color:#ffffff;color:#444444;">30 minutes</a>
    <a href="/<?php echo "$google847474747474747474744474"; ?>/panel/web/overview84747474.php?week=1&googleappsappsapps84=analytics" style="font-size:14px;background-color:#ffffff;color:#444444;">24 hours</a>
  </div>
</div>

<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunctionappsapps84747474() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

<style>

/* Dropdown Button */
.dropbtn {
cursor: pointer;
}

/* Dropdown button on hover & focus */
.dropbtn:hover, .dropbtn:focus {
    background-color: #2980B9;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
    position: relative;
    display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow:0 2px 4px rgba(0,0,0,0.4);
    z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color:#ebebeb!important}

/* Show the dropdown menu (use JS to add this class to the .dropdown-content container when the user clicks on the dropdown button) */
.show {display:block;}

</style>

</div>

</div>

</div>

<div id="minutesapps847474744474447444744474447444744474" style="margin-bottom:49.8px;"></div>

<script>

$(document).ready(function(){

var myVar = setInterval(myTimer, 4008);

function myTimer() {

$("#minutesapps847474744474447444744474447444744474").load('<?php echo "googleappspagesapps84747474.php?accountcolorapps84747474=$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84&dateanalytics=$_GET[dateanalytics]&today=$_GET[today]&week=$_GET[week]&yesterday=$_GET[yesterday]&accountcolorapps847474744474=$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>');

}

function myStopFunction() {
    clearInterval(myVar);
}

}

);

</script>

</div>

</div>

</div>

</div>

<?php

include "../../dashboard/dashboardbottom.php";

?>

<?php

}

?>

