<?php

error_reporting(0);

?>

<?php

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

?>

<script src="/dashboard/jquery.js"></script>

<div id="minutesappsgoogleappsappsappsappsapps1"></div>

<script>

$(document).ready(function(){

$("#minutesappsgoogleappsappsappsappsapps1").load('/dashboard/dashboardtop.php');

});

</script>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<div style="margin-top:10px;">

<style>

@media screen and (min-width: 1884px)
{
html
{
zoom:1.4;
}
}

@media screen and (min-width: 2560px)
{
html
{
zoom:2;
}
}

</style>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../usermailsgoogleapps84747474";

}

else

{

$dataurl8884 = "../people/usermailsgoogleapps84747474";

}

?>

<?php

$decryptedstring = $_COOKIE['username'];

$decryptedstring8884 = $_COOKIE['password'];

$file84 = file_get_contents("$dataurl8884");

?>

<?php

$file84 = array();

$query = "SELECT * FROM mailapps84747474 order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$file84[] = "<div class='" . $row['email'] . "' id='na'><div class='" . $row['toemail'] . "'><div class='" . $row['emailtext'] . "'><div class='" . $row['frommail'] . "'><div class='" . $row['date'] . "'>1</div></div></div></div></div>";

}

$file84 = implode("\n",$file84);

?>

<?php

preg_match_all("/<div class='$decryptedstring' id='(.*?)'><div class='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div><\/div>/s", $file84, $googleapps84);
$emailtext = $googleapps84[3];

$emailtext = implode("<br>",$emailtext);

$emailtext = explode("<br>",$emailtext);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl888874 = "../userregistrations";

}

else

{

$dataurl888874 = "../register/userregistrations";

}

?>

<?php

$file847474 = file_get_contents("$dataurl888874");

?>

<?php

$file847474 = array();

$query = "SELECT * FROM email order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$file847474[] = "<div class='" . $row['email'] . "' id='na'>\n<div class='na' id='na'>1</div>\n</div>";

}

$file847474 = implode("\n",$file847474);

?>

<?php

$file84 = file_get_contents("$dataurl8884");

?>

<?php

$file84 = array();

$query = "SELECT * FROM mailapps84747474 order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$file84[] = "<div class='" . $row['email'] . "' id='na'><div class='" . $row['toemail'] . "'><div class='" . $row['emailtext'] . "'><div class='" . $row['frommail'] . "'><div class='" . $row['date'] . "'>1</div></div></div></div></div>";

}

$file84 = implode("\n",$file84);

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlapps84 = "../accountcolor88842274";

}

else

{

$dataurlurlapps84 = "../register/accountcolor88842274";

}

?>

<?php

$googleappsgoogleappsappsgoogleapps8884 = file_get_contents($dataurlurlapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../accountcolor8884";

}

else

{

$dataurlurlgoogleapps84 = "../register/accountcolor8884";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleapps84);
$accountcolor84742274 = $googleapps84[3][0];

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolor847474"))

{

$accountcolor1 = "$accountcolor847474";

$accountcolor2 = "$accountcolor847474";

$accountcolor4 = "$accountcolor847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<div class="google84767674" style="position:relative">

<div class="google84767474" style="background-color:#ffffff;padding:12px;box-shadow:0 2px 4px rgba(0,0,0,0.2);">

<div style="background-color:#ffffff;background-color:<?php echo "$accountcolor1"; ?>;display:inline-block;color:#ffffff;padding:8px;border-radius:2px;cursor:pointer;box-shadow:0 2px 4px rgba(0,0,0,0.2);" onclick="window.open('/people/usermailapps8884.php','_self')">

Create message

</div>

<div style="background-color:#ffffff;padding:12px;padding-bottom:0px;padding-top:8px;cursor:pointer;" onclick="window.open('/people/pagemail.php?googleapps84=0&googleapps8474=8&googleappsappsappsapps84=mail','_self')">

Inbox

</div>

<div style="background-color:#ffffff;padding:12px;padding-bottom:0px;padding-top:8px;cursor:pointer;" onclick="window.open('/people/pagemail84747474.php?googleapps84=0&googleapps8474=8&googleappsappsappsapps84=mail','_self')">

Sent

</div>

</div>

<?php

$google84742244 = array();

$emailtext8884 = "-1";

foreach($emailtext as $emailtext888874)

{

$emailtext8884++;

?>

<?php

if(preg_match("/[\W\w]/","$emailtext888874"))

{

?>

<?php

preg_match_all("/<div class='$decryptedstring' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $file84, $googleapps84);
$emailtext84747444 = $googleapps84[1][$emailtext8884];

?>

<?php

$stringtoencrypt = "$emailtext84747474";

$decryptedstring888474 = rawurldecode($stringtoencrypt);

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext84747474 = openssl_decrypt($decryptedstring888474,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$decryptedstring' id='(.*?)'><div class='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div><\/div>/s", $file84, $googleapps84);
$emailtext84747474 = $googleapps84[2][$emailtext8884];

?>

<?php

preg_match_all("/<div class='$decryptedstring' id='(.*?)'><div class='(.*?)'><div class='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div><\/div><\/div>/s", $file84, $googleapps84);
$emailtextgoogleapps84747474 = $googleapps84[5][$emailtext8884];

?>

<?php

$stringtoencrypt = "$emailtext84747474";

$decryptedstring888474 = rawurldecode($stringtoencrypt);

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext8474 = openssl_decrypt($decryptedstring888474,"AES-128-ECB",$password);

?>

<?php

$google84727474 = "$emailtext84747474";

?>

<?php

$stringtoencrypt = "$google84727474";

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext84727474 = openssl_encrypt($stringtoencrypt,"AES-128-ECB",$password);

$decryptedstringemailtext84727474 = rawurlencode($decryptedstringemailtext84727474);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../firstnameapps84747474";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../people/firstnameapps84747474";

}

?>

<?php

$googleappsuserappsgoogleappsappsapps888474 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = "../lastnameapps84747474";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = "../people/lastnameapps84747474";

}

?>

<?php

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484 = "../usernameapps84747474";

}

else

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484 = "../people/usernameapps84747474";

}

?>

<?php

$googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474 = file_get_contents($dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484);

?>

<?php

$googleappsuserappsgoogleappsappsapps888474 = array();

$query = "SELECT * FROM user1 order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$googleappsuserappsgoogleappsappsapps888474[] = "<div class='" . $row['email'] . "' id='na'>\n<div class='" . $row['firstname'] . "' id='na'>1</div>\n</div>";

}

$googleappsuserappsgoogleappsappsapps888474 = implode("\n",$googleappsuserappsgoogleappsappsapps888474);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = "../lastnameapps84747474";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = "../people/lastnameapps84747474";

}

?>

<?php

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484);

?>

<?php

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = array();

$query = "SELECT * FROM user2 order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484[] = "<div class='" . $row['email'] . "' id='na'>\n<div class='" . $row['lastname'] . "' id='na'>1</div>\n</div>";

}

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = implode("\n",$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484 = "../usernameapps84747474";

}

else

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484 = "../people/usernameapps84747474";

}

?>

<?php

$googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474 = file_get_contents($dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484);

?>

<?php

$googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474 = array();

$query = "SELECT * FROM username order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474[] = "<div class='" . $row['email'] . "' id='na'>\n<div class='" . $row['username'] . "' id='na'>1</div>\n</div>";

}

$googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474 = implode("\n",$googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474);

?>

<?php

preg_match_all("/<div class='$decryptedstring' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsgoogleappsappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$decryptedstring' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$decryptedstring' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$decryptedstringemailtextappsapps84727474 = "$gosearchimagesappsapps84747674 $gosearchimagesappsappsappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$decryptedstringemailtextappsapps84727474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84447422 = "../accountcolor8884";

}

else

{

$dataurl84447422 = "../register/accountcolor8884";

}

?>

<?php

$googleapps84747444 = file_get_contents($dataurl84447422);

?>

<?php

preg_match_all("/<div class='$decryptedstringemailtext84727474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleapps84747444, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor847474))

{
}

else

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

?>

<?php

if(preg_match("/blue/",$accountcolor847474))

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/orange/",$accountcolor847474))

{

$accountcolor84747474 = "#EF6C00";

$accountcolor1 = "#EF6C00";

$accountcolor2 = "#FB8C00";

$accountcolor4 = "#FFA726";

}

if(preg_match("/yellow/",$accountcolor847474))

{

$accountcolor84747474 = "#F9A825";

$accountcolor1 = "#F9A825";

$accountcolor2 = "#FDD835";

$accountcolor4 = "#FFEE58";

}

if(preg_match("/purple/",$accountcolor847474))

{

$accountcolor84747474 = "#6A1B9A";

$accountcolor1 = "#6A1B9A";

$accountcolor2 = "#8E24AA";

$accountcolor4 = "#AB47BC";

}

if(preg_match("/pink/",$accountcolor847474))

{

$accountcolor84747474 = "#AD1457";

$accountcolor1 = "#AD1457";

$accountcolor2 = "#D81B60";

$accountcolor4 = "#EC407A";

}

?>

<?php

$stringtoencrypt842274 = "$decryptedstringemailtext8474";

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext84727444 = openssl_encrypt($stringtoencrypt842274,"AES-128-ECB",$password);

$decryptedstringemailtextappsappsapps84727444 = rawurlencode($decryptedstringemailtext84727444);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../firstnameapps84747474";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../people/firstnameapps84747474";

}

?>

<?php

$googleappsuserappsgoogleappsappsapps888474 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = "../lastnameapps84747474";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = "../people/lastnameapps84747474";

}

?>

<?php

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484 = "../usernameapps84747474";

}

else

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484 = "../people/usernameapps84747474";

}

?>

<?php

$googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474 = file_get_contents($dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484);

?>

<?php

$googleappsuserappsgoogleappsappsapps888474 = array();

$query = "SELECT * FROM user1 order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$googleappsuserappsgoogleappsappsapps888474[] = "<div class='" . $row['email'] . "' id='na'>\n<div class='" . $row['firstname'] . "' id='na'>1</div>\n</div>";

}

$googleappsuserappsgoogleappsappsapps888474 = implode("\n",$googleappsuserappsgoogleappsappsapps888474);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = "../lastnameapps84747474";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = "../people/lastnameapps84747474";

}

?>

<?php

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484);

?>

<?php

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = array();

$query = "SELECT * FROM user2 order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484[] = "<div class='" . $row['email'] . "' id='na'>\n<div class='" . $row['lastname'] . "' id='na'>1</div>\n</div>";

}

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = implode("\n",$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484 = "../usernameapps84747474";

}

else

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484 = "../people/usernameapps84747474";

}

?>

<?php

$googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474 = file_get_contents($dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484);

?>

<?php

$googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474 = array();

$query = "SELECT * FROM username order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474[] = "<div class='" . $row['email'] . "' id='na'>\n<div class='" . $row['username'] . "' id='na'>1</div>\n</div>";

}

$googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474 = implode("\n",$googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474);

?>

<?php

preg_match_all("/<div class='$decryptedstringemailtextappsappsapps84727444' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsgoogleappsappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$decryptedstringemailtextappsappsapps84727444' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$decryptedstringemailtextappsappsapps84727444' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$decryptedstringemailtextgoogleapps84727444 = "$gosearchimagesappsapps84747674 $gosearchimagesappsappsappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$decryptedstringemailtextgoogleapps84727444 = "$gosearchimages84747674";

?>

<?php

}

?>

<script>

$(document).ready(function(){

$('#googleapps84222274').click(function() {
  $('#google8474').style.display = "inline-block";

  });

});

</script>

<div class="googleappsappsapps8474" id="google<?php echo "$emailtext8884"; ?>" style="display:none;" onclick="$(this).hide();">

<div>

<div style="position:fixed;background-color:#bdbdbd;z-index:44;height:100%;top:0px;width:100%;left:0px;background:rgba(0, 0, 0, 0.4);">

<div align="center" style="margin:12px;margin-top:62px;background-color:#ffffff;padding:12px;">

<?php echo "$decryptedstringemailtextgoogleapps84727444"; ?>

<?php echo "$emailtext888874"; ?>

</div>

</div>

</div>

</div>

<div style="width:100%;">

<div class="googleappsmobileapps84 googleapps4474" onclick="$('#google<?php echo "$emailtext8884"; ?>').show();" style="margin-bottom:0px;margin-bottom:0px;background-color:#ffffff;padding:12px;margin-top:0px;border-style:solid;border-color:#dddddd;border-width:1px;border-top:none;border-right:none;border-left:none;margin-bottom:0px;background-color:#ffffff;padding:12px;">
<div class="googleappsmobileapps8884">

<div style="position:relative;display:flex;">

<div style="color:#888888;font-size:12.8px;"><divapps8884></divapps8884> <divapps8474 style="font-weight:bold;color:#222222;"><?php echo "$decryptedstringemailtextgoogleapps84727444"; ?></divapps8474></div>

<div style="color:#888888;font-size:13.4px;padding-top:12px;padding-left:12px;font-weight:bold;color:<?php echo "$accountcolor1"; ?>"></div>

<div class="googleappsappsapps84747474" style="color:#888888;font-size:12.8px;padding-top:0px;"><?php echo "$emailtext888874"; ?></div>

<div style="font-size:12.8px;padding-top:0px;position:absolute;right:0px;font-weight:bold;">

<?php

$google84747474 = date("M d", strtotime("$emailtextgoogleapps84747474"));

?>

<?php

echo "$google84747474";

?>

</div>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../gosearchimages8884";

}

else

{

$dataurl84 = "../gosearchimages8884/gosearchimages8884";

}

?>

<?php

$googleapps8884 = file_get_contents($dataurl84);

?>

<?php

$stringtoencrypt842274 = "$emailtext84747474";

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext84727444 = openssl_encrypt($stringtoencrypt842274,"AES-128-ECB",$password);

$decryptedstringemailtext84727444 = rawurlencode($decryptedstringemailtext84727444);

?>

<?php

preg_match_all("/<div class='$decryptedstringemailtext84727444' id='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$gosearchimages8474 = $googleapps84[4][0];

?>

<?php

if(preg_match("/[\W\w]/",$gosearchimages8474))

{

?>

<?php

echo "<div style='position:absolute;right:-8px;top:-8px;'><img src='$gosearchimages8474' width='38' height='38' style='border-radius:24px;border-radius: 24px;border-color:$accountcolor4;border-style:solid;border-width:2px;box-shadow:0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);'></img></div>";

?>

<?php

}

else

{
}

?>

</div>

</div>
</div>

<?php

$google84742244[] = $emailtext84747474;

?>

<?php

}

?>

<?php

}

?>

<div style="display:flex;position:absolute;right:96px;bottom:-37.4px;background-color:#ffffff;padding:4px;">

<div>

<?php

echo $_GET['googleapps84'] . "-";

?>

</div>

<div>

<?php

echo $_GET['googleapps8474'];

?>

</div>

</div>

<div style="padding:4px;background-color:#444444;position:absolute;right:0px;display:inline-block;bottom:-41.8px;right:48px;color:#ffffff;cursor:pointer;" onclick="window.open('/people/pagemail.php?googleapps84=<?php echo $_GET[googleapps84] - 8; ?>&googleapps8474=<?php echo $_GET[googleapps8474] - 8; ?>&googleappsappsappsapps84=ads&today=1','_self')">

<i class="material-icons">keyboard_arrow_left</i>

</div>

<div style="padding:4px;background-color:#444444;position:absolute;right:0px;display:inline-block;bottom:-41.8px;right:12px;color:#ffffff;cursor:pointer;" onclick="window.open('/people/pagemail.php?googleapps84=<?php echo $_GET[googleapps84] + 8; ?>&googleapps8474=<?php echo $_GET[googleapps8474] + 8; ?>&googleappsappsappsapps84=mail','_self')">

<i class="material-icons">keyboard_arrow_right</i>

</div>

<?php

$google84742222 = $google84742244[0];

?>

<style>

@media screen and (max-width:770px)
{
#google84227474
{
display:flex;
position:fixed;
bottom:0px;
width:100%;
left:0px;
}
.google84767674
{
display:inline;
}
.google84767474
{
display:flex;
justify-content:space-between;
}
}

@media screen and (min-width:770px)
{
.google84767474
{
width:196px;
}
.google84767674
{
display:flex;
}
.googleappsmobileapps84.googleapps4474
{
margin-left:12px;
}
}

</style>

</div>

</div>

</div>

<?php

include "../dashboard/dashboardbottom.php";

?>

<?php

$conn->close();

?>

