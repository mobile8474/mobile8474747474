<?php

error_reporting(0);

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

$countryapps8884 = $_COOKIE['country'];

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../adsclicksapps84747474.sh";

}

else

{

$dataurlappsappsapps84 = "adsclicksapps84747474.sh";

}

?>

<?php

$googleapps8474 = $_GET['userapps84747474'];

$googleapps8474 = rawurlencode($googleapps8474);

?>

<?php

$googleapps8474 = $_GET['coworkers84747474'];

$googleapps84444474 = rawurlencode($googleapps8474);

?>

<?php

$googleapps8474 = $_GET['coworkersnameapps84747474'];

$googleapps84442274 = rawurlencode($googleapps8474);

$googleapps84747474 = $_GET['adsusernameappsappsapps84747474'];

$googleapps84442274444474 = rawurlencode("$googleapps84747474");

?>

<?php

$date84747474 = date("Y-m-d");

?>

<?php

$date8474747444744474 = date("H");

?>

<?php

if(preg_match("/[\W\w]/","googleapps84"))

{

?>

<?php

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip847474 = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip847474 = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip847474 = $_SERVER['REMOTE_ADDR'];
}

?>

<?php

$userip84747474 = $ip847474;

?>

<?php

$googleapps847474744474 = $_GET['adsusername84442274'];

$googleapps847474744474 = rawurlencode($googleapps847474744474);

$googleapps84747474447444744474 = $_GET['adsurl84747474'];

$googleapps84747474447444744474 = rawurlencode($googleapps84747474447444744474);



$googleapps8474747444744474447444744474 = $_GET['adsusername84747474'];

$googleapps8474747444744474447444744474 = rawurlencode($googleapps8474747444744474447444744474);

?>

<?php

$googleapps8884 = "<div class='$googleapps8474747444744474447444744474' id='$userip84747474'>" . "\n" . "<div class='$date84747474-$date8474747444744474'>" . "\n" . "<div class='$googleapps847474744474'>" . "\n" . "<div class='$googleapps84747474447444744474'>1</div>" . "\n" . "</div>" . "\n" . "</div>" . "\n" . "</div>";

?>

<?php

$user84747474 = $_GET['adsusername84747474'];

$date84747474 = "$date84747474-$date8474747444744474";

$username84747474 = $_GET['adsusername84442274'];

$url84747474 = $_GET['adsurl84747474'];

$filedata = "$googleapps8884";
$filedata .= file_get_contents("$dataurlappsappsapps84");
$googleapps888844 = file_put_contents("$dataurlappsappsapps84", $filedata);

if(preg_match("/[\W\w]/","$googleapps847474744474"))

{

$googleapps847474744474 = "$googleapps847474744474";

}

else

{

$googleapps847474744474 = "0.01";

}

$sql = "INSERT INTO adsclicksapps844444444474 (adsusername,date,adsusername84747474,adsurl,userip)
VALUES ('$googleapps8474747444744474447444744474','$date84747474','$googleapps847474744474','$googleapps84747474447444744474','$userip84747474')";

echo "<div style='display:none;'>$googleapps888844</div>";

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_GET['adsusername84747474']))

{
}

else

{

?>

<?php

$googleapps8884 = "<div class='$googleapps84442274444474' id='ads'>" . "\n" . "<div class='$_GET[adsusername84222274]'>1</div>" . "\n" . "</div>";

?>

<?php

$filedata = "$googleapps8884";
$filedata .= file_get_contents("$dataurlappsappsapps84");
$googleapps888844 = file_put_contents("$dataurlappsappsapps84", $filedata);

$sql12 = "INSERT INTO adsclicksapps847474744474 (adsusername,adsusername84747474)
VALUES ('$googleapps84442274444474','$_GET[adsusername84222274]')";

echo "<div style='display:none;'>$googleapps888844</div>";

?>

<?php

}

?>

<?php

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

if ($conn->query($sql12) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql12 . "<br>" . $conn->error;
}

?>

<?php

$conn->close();

?>

