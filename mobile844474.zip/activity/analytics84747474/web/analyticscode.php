<?php

error_reporting(0);

?>

<?php

include "../../dashboard/dashboardtop.php";

?>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

$google888844 = "

<script>

var googleappsappsappsapps847474744474 = location.protocol

var url84747474 = document.referrer;

var google84747474 = location.href;

var google84444474 = location.search.split('q=')[1]

var url84747474 = encodeURIComponent(url84747474);

var google84444474 = encodeURIComponent(google84444474);

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//$_SERVER[HTTP_HOST]/analytics/web/analytics/analytics.php?username=$_COOKIE[username]&password=$_COOKIE[password]&country=$isocode8884&referer=' + url84747474 + '&keywordsapps8474=' + google84444474 + '';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

var time,timeSite;

time=new Date();

window.onbeforeunload=function(){
timeSite=new Date()-time;
window.localStorage['timeSite']=timeSite;

var url84747474 = document.referrer;

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//$_SERVER[HTTP_HOST]/analytics/web/analytics/analytics.php?username=$_COOKIE[username]&password=$_COOKIE[password]&country=$isocode8884&timeonsite=' + timeSite + '';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

}

var list84747474 = document.getElementsByTagName('html')[0];

window.addEventListener('backbutton', function(){

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//$_SERVER[HTTP_HOST]/analytics/web/analytics/analytics.php?username=$_COOKIE[username]&password=$_COOKIE[password]&useractions8884=googleapps84&country=ZA';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

});

window.addEventListener('scroll', function(){

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//$_SERVER[HTTP_HOST]/analytics/web/analytics/analytics.php?username=$_COOKIE[username]&password=$_COOKIE[password]&useractions8884=googleapps84&country=ZA';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

});

</script>

";

$googleapps8884 = htmlentities($google888844);

?>

<style>

@media (min-width: 770px)
{
.google84747474
{
margin-left:96px;
margin-right:96px;
}
}

</style>

<div class="google84747474" style="padding:8px;box-shadow:0 2px 4px rgba(0,0,0,0.2);background-color:#ffffff;margin:12px;margin-bottom:51.8px;">

<textarea rows="4" cols="24" readonly style="font-size:13.8px;height:396px;width:100%;border:none;resize:none;"><?php echo "$googleapps8884"; ?></textarea>

</div>

<?php

include "../../dashboard/dashboardbottom.php";

?>

