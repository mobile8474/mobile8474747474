<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

$file84 = array();

$query = "SELECT * FROM email order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$file84[] = $row['email'];

}

$file84747474 = $file84[array_rand($file84)];

$google8422747444444474 = "$file84747474";

$password = "googleappsmobileapps888888884444";

$google8422747444444474 = rawurldecode($google8422747444444474);

$google8422747444444474 = openssl_decrypt($google8422747444444474,"AES-128-ECB",$password);

echo "$google8422747444444474";

?>

<?php

$google8474 = "noreply@gcloud.pw";

$google847474 = "mobileapps84";

?>

<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPDebug = 0;
$mail->SMTPAuth = true;
$mail->SMTPSecure = 'tls';
$mail->Host = "smtp.yandex.com";
$mail->Port = 465;
$mail->IsHTML(true);

$mail->Username = "$google8474";
$mail->Password = "$google847474";

?>

<?php

$mail->CharSet = "UTF-8";
$mail->Subject = "We have changed to ads company";
$mail->Body = '

<head>
<title></title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no">
</head>

<html>

<body style="background-color:#f8f8f8;">

<div class="googleapps888844" style="left:0px;right:0px;width:574px;background-color:#ffffff;font-family: Varela Round, sans-serif;width:100%;border-style:solid;border-left:none;border-bottom:none;border-top:none;border-color:#bdbdbd;position:relative;">

<div style="position:absolute;padding:12px;right:12px;bottom:12px;border-style:solid;border-left:none;border-top:none;border-color:#bdbdbd;display:none;">
</div>

<div style="background-color:#ffffff;width:100%;height:62px;">

<div style="color:#ffffff;padding:18px;font-size:22px;">

<center>

<span style="padding-left:8px;padding-right:8px;border-width:2px;padding-top:4px;padding-bottom:4px;font-weight:bold;"></span> <span style="color:#ffffff!important;font-weight:bold;"><span>

</center>

</div>

</div>

<div class="googleapps8884" style="font-family: Varela Round, sans-serif;">

<div class="google888874" style="font-family: Varela Round, sans-serif;"></div>

<div class="google8474" style="font-family: Varela Round, sans-serif;"></div>

<div style="padding:12px;color:#5d636f;font-size:12.8px;">

<div style="text-align:center;font-size:44px;">Getit&#153;</div><br>

<div class="google88884474" style="font-family:Varela Round, sans-serif;"><div><div style="font-size:13.8px;color:#222222;"><div style="text-align:center;">googleapps84</div><br><div style="text-align:center;margin:0 auto;"></div><div style="color:#222222;font-size:13.8px;"></div><br><div><div style="color:#222222;font-size:13.8px;"></div><br><div style="font-size:12.8px;">Getit&#153;</div><div style="font-weight:bold;color:#222222;font-size:12.8px;">company@gcloud.pw<br><a href="https://www.gcloud.pw/" style="color:#222222;">https://www.gcloud.pw/</a></div></div><mobileapps84></mobileapps84><mobileapps84></mobileapps84><br><mobileapps84></mobileapps84><mobileapps84></mobileapps84></div>

<div>

</div>

</div>

</body>

</html>

';

?>

<?php

if(preg_match("/(gosearch.website|charlotteclark09@gmail.com|cindybeaton696@gmail.com|Dartaniandegoede@hotmail.com|heisgreat3@gmail.com|eleneh58@gmail.com|riaan.cockrell@gmail.com)/",$googleapps84441274))

{

$googleapps84441274 = "";

}

else

{

$googleapps84441274 = "$googleapps84441274";

}

$mail->AddBCC("mobileappslinuxapps84@gmail.com");

echo "$googleapps84441274";

$mail->setFrom("$google8474", 'gcloud');
$mail->addReplyTo("$google8474", 'gcloud');

$mail->Send();

$mail->ClearAllRecipients();

?>

