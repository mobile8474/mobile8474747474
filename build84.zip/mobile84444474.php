<?php

$servername = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

?>

<?php

$username = "mobileapps84";

$date84442274444474447444744474 = date("Y-m-d");

$date844422744444744474447444744474 = date("H");

$sql12 = "INSERT INTO googleapps84 (email,date84,hour,valid)
VALUES ('$username','$date84442274444474447444744474','$date844422744444744474447444744474','1')";

?>

<?php

$googleapps84747474 = mysqli_query($conn,$sql12);

echo "$googleapps84747474";

?>

<?php

$conn->close();

?>

