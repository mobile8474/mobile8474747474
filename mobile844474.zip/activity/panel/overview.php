<?php

$googleapps84747474 = strtolower($_SERVER['HTTP_USER_AGENT']);

if(preg_match("/(bot|Bot|crawler|Crawler|spider|Spider)/","googleapps84"))

{
}

else

{

?>

<?php

$countryapps8884 = $_COOKIE['country'];

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn8444444444744444444474 = new mysqli($servername, $username, $password, $dbname);

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "$isocode8884");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

include "../dashboard/dashboardtop.php";

?>

<?php

$query = "SELECT * FROM userpageapps84747474 order by date desc";

$google84747474 = array();

$result = mysqli_query($conn8444444444744444444474,$query);

foreach($result as $row)

{

$google84747474[] = $row['id'];

}

?>

<div align="center">

<div style="margin:12px;">

<form action="/activity/people/userpageapps84747474.php" method="post" id="googleappsapps8474744444444474" style="">

<input type="text" name="userpageapps84747474" placeholder="activity update" class="google84747474847474748474747484747474" style="box-shadow:0 1px 4px rgba(0,0,0,0.4);border:none;padding:10px;font-size:17.6px;outline:none;width:700px;font-weight:bold;"></input>

<input type="hidden" name="userpageapps847474744474" value="<?php echo $_COOKIE['username']; ?>" style="display:none;"></input>

<input type="submit" style="display:none;"></input>

</form>

</div>

<style>

@media (max-width: 770px)
{
.google84747474847474748474747484747474
{
width:100%!important;
}
.google847474748474747484747474847474744474
{
width:100%!important;
}
}

</style>

<div class="google84747474847474748474747484747474" style="width:724px;">

<div>

<?php

foreach($google84747474 as $google847474744474)

{

?>

<?php

$query = "SELECT * FROM userpageapps84747474 WHERE id='$google847474744474'";

$google84747474 = array();

$result = mysqli_query($conn8444444444744444444474,$query);

foreach($result as $row)

{

$googleappsappsappsapps8474 = $row['userpageapps84747474'];

$password = "googleappsmobileapps888888884444";

$googleappsappsappsapps8474 = rawurldecode($googleappsappsappsapps8474);

$googleappsappsappsapps8474 = openssl_decrypt($googleappsappsappsapps8474,"AES-128-ECB",$password);

$google84747474[] = "$googleappsappsappsapps8474";

$googleappsappsappsapps847444444444444474 = $row['email'];

}

$google84747474 = reset($google84747474);

?>

<?php

$query = "SELECT * FROM user1 WHERE email='$googleappsappsappsapps847444444444444474' limit 1";

$result = mysqli_query($conn8444444444744444444474,$query);

foreach($result as $row)

{

$googleappsappsappsapps8474444444444474 = $row['firstname'];

$password = "googleappsmobileapps888888884444";

$googleappsappsappsapps8474444444444474 = rawurldecode($googleappsappsappsapps8474444444444474);

$googleappsappsappsapps8474444444444474 = openssl_decrypt($googleappsappsappsapps8474444444444474,"AES-128-ECB",$password);

}

?>

<?php

$query84747474 = "SELECT * FROM user2 WHERE email='$googleappsappsappsapps847444444444444474' limit 1";

$result84747474 = mysqli_query($conn8444444444744444444474,$query84747474);

foreach($result84747474 as $row84747474)

{

$googleappsappsappsapps84744444444444744474 = $row84747474['lastname'];

$password = "googleappsmobileapps888888884444";

$googleappsappsappsapps84744444444444744474 = rawurldecode($googleappsappsappsapps84744444444444744474);

$googleappsappsappsapps84744444444444744474 = openssl_decrypt($googleappsappsappsapps84744444444444744474,"AES-128-ECB",$password);

}

?>

<?php

$query84747474 = "SELECT * FROM userpageapps84747474 WHERE id='$google847474744474' limit 1";

$result84747474 = mysqli_query($conn8444444444744444444474,$query84747474);

foreach($result84747474 as $row84747474)

{

$googleappsappsappsapps8474444444444474447444444444444474 = $row84747474['date'];

}

?>

<div style="padding:12px;background-color:#ffffff;text-align:left;border-bottom-style:solid;border-color:#bdbdbd;border-width:1px;box-shadow:0 1px 4px rgba(0,0,0,0.4);margin-left:12px;margin-right:12px;">

<div style="display:flex;font-weight:bold;style="margin-top:12px;"">

<div>

<?php

echo "$googleappsappsappsapps8474444444444474";

?>

</div>

<div style="padding-left:4px;word-wrap:break-word;">

<?php

echo "$googleappsappsappsapps84744444444444744474";

?>

</div>

</div>

<?php

$googleappsappsappsapps847444444444447444744444444444447444744474 = preg_replace("/(.*?)-(.*?)-(.*?)-(.*?)-(.*?)-(.*?)/","$1-$2-$3",$googleappsappsappsapps8474444444444474447444444444444474);

?>

<?php

$google8474747444444444444474 = date("Y-m-d");

if(preg_match("/$google8474747444444444444474/",$googleappsappsappsapps847444444444447444744444444444447444744474))

{

$googleappsappsappsapps8474444444444474447444444444444474 = preg_replace("/(.*?)-(.*?)-(.*?)-(.*?)-(.*?)-(.*?)/","$4:$5:$6",$googleappsappsappsapps8474444444444474447444444444444474);

}

else

{

$googleappsappsappsapps8474444444444474447444444444444474 = preg_replace("/(.*?)-(.*?)-(.*?)-(.*?)-(.*?)-(.*?)/","$1-$2-$3 $4:$5:$6",$googleappsappsappsapps8474444444444474447444444444444474);

}

?>

<div style="word-wrap:break-word;">

<?php

echo "$googleappsappsappsapps8474444444444474447444444444444474";

?>

</div>

<div style="word-wrap:break-word;">

<?php

echo "$google84747474";

?>

</div>

<style>

.google84747474747474747474444444447444744474:hover
{
background-color:#90CAF9;
}

</style>

<div style="display:flex;margin-top:12px;">

<div class="google84747474747474747474444444447444744474" style="display:flex;cursor:pointer;">

<div>

<i class="material-icons" id="namemobileappsgoogleapps844444744474<?php echo $google847474744474; ?>" style="color:#bdbdbd;padding:12px;cursor:pointer;color:#42A5F5;">thumb_up</i>

</div>

<script>

$(document).ready(function() {

$('#namemobileappsgoogleapps844444744474<?php echo $google847474744474; ?>').click(function(){

var googlemobileapps844444744474 = $('#namemobileapps847474744474').val();

$.ajax({
    data: 'promotesappsuser84747474=<?php echo "$_COOKIE[username]"; ?>&promotesapps84747474=<?php echo $google847474744474; ?>',
    url: '/<?php echo "$google847474747474747474744474"; ?>/panel/promotes84747474.php',
    method: 'POST',
    success: function(msg) {
    }
});

});

});

</script>

<?php

$googleappsappsappsapps8474444444444474447444444474 = array();

$query84747474 = "SELECT * FROM promotes84747474 WHERE promotes='$google847474744474'";

$result84747474 = mysqli_query($conn8444444444744444444474,$query84747474);

foreach($result84747474 as $row84747474)

{

$googleappsappsappsapps84744444444444744474 = $row84747474['promote'];

$googleappsappsappsapps8474444444444474447444444474[] = "$googleappsappsappsapps84744444444444744474";

}

$googleappsappsappsapps8474444444444474447444444474 = count($googleappsappsappsapps8474444444444474447444444474);

?>

<div style="padding:12px;font-weight:bold;">

<?php

echo "$googleappsappsappsapps8474444444444474447444444474";

?>

</div>

</div>

<div style="cursor:pointer;">

<div>
</div>

<div>

<i class="material-icons" style="color:#bdbdbd;padding:12px;cursor:pointer;color:#EF5350;">share</i>

</div>

</div>

<?php

$googleappsappsappsapps8474444444444474447444444474444444447444744474 = array();

$query84747474444444447444744474 = "SELECT * FROM commentapps84747474 WHERE commentsapps84747474='$google847474744474' order by id desc";

$result84747474444444447444744474 = mysqli_query($conn8444444444744444444474,$query84747474444444447444744474);

foreach($result84747474444444447444744474 as $row84747474444444447444744474)

{

$googleappsappsappsapps84744444444444744474444444447444744474 = $row84747474444444447444744474['comments'];

$googleappsappsappsapps8474444444444474447444444474444444447444744474[] = "$googleappsappsappsapps84744444444444744474444444447444744474";

}

?>

<style>

.google8474747474747474747444444444744474:hover
{
background-color:#A5D6A7;
}

</style>

<style>

.main847474747474747474
{
display:block!important;
}

</style>

<div class="google8474747474747474747444444444744474" style="display:flex;cursor:pointer;" onclick="$('.googleapps8474747474747474747474747474744474447444744474<?php echo $google847474744474; ?>').toggleClass('main847474747474747474');">

<div>

<i class="material-icons" style="color:#bdbdbd;padding:12px;cursor:pointer;color:#66BB6A;">comment</i>

</div>

<div style="padding:12px;font-weight:bold;">

<?php

$google8474747444444444744474 = count($googleappsappsappsapps8474444444444474447444444474444444447444744474);

echo "$google8474747444444444744474";

?>

</div>

</div>

</div>



</div>

<div style="margin:12px;">

<form action="/activity/panel/commentapps84747474.php" method="post" id="googleappsapps8474744444444474" style="">

<input type="text" name="commentapps84747474" placeholder="comment" class="google84747474847474748474747484747474" style="box-shadow:0 1px 4px rgba(0,0,0,0.4);border:none;padding:10px;font-size:17.6px;outline:none;width:700px;font-weight:bold;"></input>

<input type="hidden" name="commentappsuser84747474" value="<?php echo $_COOKIE['username']; ?>" style="display:none;"></input>

<input type="hidden" name="commentappsuserapps84747474" value="<?php echo $google847474744474; ?>" style="display:none;"></input>

<input type="submit" style="display:none;"></input>

</form>

</div>

<?php

$googleappsappsappsapps847444444444447444744444447444444444744474 = array();

$query8474747444444444744474 = "SELECT * FROM commentapps84747474 WHERE commentsapps84747474='$google847474744474'";

$result8474747444444444744474 = mysqli_query($conn8444444444744444444474,$query8474747444444444744474);

foreach($result8474747444444444744474 as $row8474747444444444744474)

{

$googleappsappsappsapps8474444444444474447444444444744474 = $row8474747444444444744474['commentsapps84747474'];

$googleappsappsappsapps847444444444447444744444447444444444744474[] = "$googleappsappsappsapps8474444444444474447444444444744474";

}

?>

<div class="googleapps8474747474747474747474747474744474447444744474<?php echo "$google847474744474"; ?>" style="box-shadow:0 0px 0px rgba(0,0,0,0.4);margin-left:12px;margin-right:12px;margin-bottom:12px;display:none;">

<?php

$google847474744474 = "-1";

?>

<?php

foreach($googleappsappsappsapps847444444444447444744444447444444444744474 as $google84747474)

{

?>

<?php

$google847474744474++;

?>

<?php

$googleappsappsappsapps8474444444444474447444444474444444447444744474 = array();

$query84747474444444447444744474 = "SELECT * FROM commentapps84747474 WHERE commentsapps84747474='$google84747474' order by id desc";

$result84747474444444447444744474 = mysqli_query($conn8444444444744444444474,$query84747474444444447444744474);

foreach($result84747474444444447444744474 as $row84747474444444447444744474)

{

$googleappsappsappsapps84744444444444744474444444447444744474 = $row84747474444444447444744474['comments'];

$googleappsappsappsapps8474444444444474447444444474444444447444744474[] = "$googleappsappsappsapps84744444444444744474444444447444744474";

}

?>

<?php

$googleappsappsappsapps847444444444447444744474 = $googleappsappsappsapps8474444444444474447444444474444444447444744474[$google847474744474];

$password = "googleappsmobileapps888888884444";

$googleappsappsappsapps847444444444447444744474 = rawurldecode($googleappsappsappsapps847444444444447444744474);

$googleappsappsappsapps847444444444447444744474 = openssl_decrypt($googleappsappsappsapps847444444444447444744474,"AES-128-ECB",$password);

?>

<div style="padding:12px;font-weight:bold;background-color:#ffffff;word-wrap:break-word;">

<?php

echo "$googleappsappsappsapps847444444444447444744474";

?>

</div>

<?php

}

?>

</div>

<?php

}

?>



</div>

</div>

</div>

<?php

include "../dashboard/dashboardbottom.php";

?>

<?php

$conn8444444444744444444474->close();

?>

<?php

}

?>

