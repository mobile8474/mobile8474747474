<?php

error_reporting(0);

$cookiename = "analytics";

$cookievalue = "analytics";

setcookie("$cookiename", "$cookievalue", time()+30*24*60*60, "/");

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

$dateapps847474 = date("Y-m-d");

?>

<script>

setTimeout(function()

{

window.location = '<?php echo "https://$_SERVER[HTTP_HOST]/analytics/web/overview.php?today=1&googleappsappsapps84=analytics"; ?>';

}, 884);

</script>

<?php

if(preg_match("/[\W\w]/",$_GET['analytics']))

{

?>

<script>

setTimeout(function()

{

window.location = '<?php echo "https://$_SERVER[HTTP_HOST]/analytics/web/index84747474.php?dateanalytics=$dateapps847474"; ?>';

}, 884);

</script>

<?php

}

?>

