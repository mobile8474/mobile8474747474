<?php

$cookievalue84747474 = $_POST['email'];

$passwordname8884 = "googleappsmobileapps888888884444";

$cookievalue84747474 = openssl_encrypt($cookievalue84747474,"AES-128-ECB",$passwordname8884);

$cookievalue84747474 = rawurlencode($cookievalue84747474);

$servername84747474444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username84747474444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password84747474444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname84747474444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn84444474 = new mysqli($servername84747474444444744474, $username84747474444444744474, $password84747474444444744474, $dbname84747474444444744474);



$string_to_encrypt = $_POST['email'];

$decrypted_string = "$string_to_encrypt";

$passwordname = "googleappsmobileapps888888884444";

$decrypted_string = openssl_encrypt($decrypted_string,"AES-128-ECB",$passwordname);

$decryptedstring84227474 = rawurlencode($decrypted_string);

$decryptedstring84447474 = $_POST['username84747474'];

$string_to_encrypt = $_POST['pword'];

$decrypted_string = "$string_to_encrypt";

$passwordname = "googleappsmobileapps888888884444";

$decrypted_string = openssl_encrypt($decrypted_string,"AES-128-ECB",$passwordname);

$decryptedstring84187474 = rawurlencode($decrypted_string);



$query = "SELECT * FROM countryapps84747474 WHERE email='$cookievalue84747474' order by date desc limit 1";
$result = $conn84444474->query($query);

$googleappsgooglegoogleapps888444744474 = array();

while($row = $result->fetch_array())

{

$googleappsgooglegoogleapps888444744474[] = $row['country'];

}

$googleappsgooglegoogleapps8884447444744474 = reset($googleappsgooglegoogleapps888444744474);

$passwordname = "googleappsmobileapps888888884444";

$googleappsgooglegoogleapps8884447444744474 = rawurldecode($googleappsgooglegoogleapps8884447444744474);

$googleappsgooglegoogleapps8884447444744474 = openssl_decrypt($googleappsgooglegoogleapps8884447444744474,"AES-128-ECB",$passwordname);

$query = "SELECT * FROM user4 WHERE email='$decryptedstring84227474' and password='$decryptedstring84187474' order by date desc limit 1";
$result = $conn84444474->query($query);

$googleappsgooglegoogleapps8884 = array();

while($row = $result->fetch_array())

{

$googleappsgooglegoogleapps8884[] = $row['date'];

}

$googleappsgooglegoogleapps88844474447444744474 = implode("\n",$googleappsgooglegoogleapps8884);

if(preg_match("/[\W\w]/","$googleappsgooglegoogleapps88844474447444744474"))

{

if(preg_match("/[\W\w]/",$_POST['email']))

{

setcookie("username", "$cookievalue84747474", time()+30*24*60*60 , "/");

setcookie("country", "$googleappsgooglegoogleapps8884447444744474", time()+30*24*60*60 , "/");

setcookie("google84444474", "googleapps84", time()+30*24*60*60 , "/");

}

if(preg_match("/[\W\w]/",$_GET['logout8474']))

{

setcookie("username", "", time()+30*24*60*60 , "/");

setcookie("google84444474", "", time()+30*24*60*60 , "/");

}

}

?>

<?php

$query = "SELECT * FROM user4 WHERE email='$decryptedstring84227474' and password='$decryptedstring84187474' order by date desc limit 1";
$result = $conn84444474->query($query);

$googleappsgooglegoogleapps8884 = array();

while($row = $result->fetch_array())

{

$googleappsgooglegoogleapps8884[] = $row['date'];

}

?>

<?php

$googleappsgooglegoogleapps88844474447444744474 = implode("\n",$googleappsgooglegoogleapps8884);

?>

<script src="/dashboard/jquery.js" type="text/javascript"></script>

<?php

if(preg_match("/[\W\w]/",$_POST['email']))

{

?>

<?php

if(preg_match("/[\W\w]/","$googleappsgooglegoogleapps88844474447444744474"))

{

?>

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<script>

setTimeout(function()

{

window.location = '<?php echo "/$google847474747474747474744474/panel/overview.php?today=1&query=0"; ?>';

}, 104);

</script>

<?php

}

else

{

?>

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<script>

setTimeout(function()

{

window.location = '/<?php echo "$google847474747474747474744474"; ?>/';

}, 884);

</script>

<?php

}

?>

<?php

}

?>

<?php

$conn84444474->close();

?>

