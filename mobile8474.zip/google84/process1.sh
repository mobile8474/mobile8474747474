#!/bin/bash  

touch pid1.sh

startme() {

google84=$(cat pid1.sh)
   
if [[ $google84 == "" ]];

then

cd /var/www/html/mobile8474/
php ./googleapps84.php google1 &> /dev/null &

mypid=$!

echo $mypid > pid1.sh 

else

echo "google84"

fi

}

stopme() {
    kill -9 $(cat pid1.sh)

echo "" > pid1.sh

}

case "$1" in 
    start)   startme ;;
    stop)    stopme ;;
    restart) stopme; startme ;;
    *) echo "usage: $0 start|stop|restart" >&2
       exit 1
       ;;
esac

