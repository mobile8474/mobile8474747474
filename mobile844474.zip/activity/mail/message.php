<?php

error_reporting(0);

?>

<?php

include "../dashboard/dashboardtop.php";

?>

<?php

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

$conn847474744474 = new mysqli($servername, $username, $password, $dbname);

?>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

$stringtoencrypt = $_GET['toemail'];

$decryptedstringemailtext84727474 = rawurlencode($stringtoencrypt);

?>

<?php

$stringtoencrypt84747474 = $_GET['text'];

$decryptedstringemailtext847274744474447444744474747474 = rawurlencode($stringtoencrypt84747474);

?>

<?php

$stringtoencrypt847474744474 = $_GET['date'];

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext8472747444744474447444747474744474 = rawurldecode($stringtoencrypt847474744474);

$decryptedstringemailtext8472747444744474447444747474744474 = openssl_decrypt($decryptedstringemailtext8472747444744474447444747474744474,"AES-128-ECB",$password);

?>

<?php

$emailtextgoogleapps84747474 = array();

$emailtextgoogleapps847474744474 = array();

$emailtextgoogleapps8474747444744474 = array();

$query84747474744474 = "SELECT * FROM mailapps84747474 WHERE email='$_COOKIE[username]' and toemail='$decryptedstringemailtext84727474' and emailtext='$decryptedstringemailtext847274744474447444744474747474' and date='$decryptedstringemailtext8472747444744474447444747474744474' order by date desc";

$result84747474744474 = mysqli_query($conn847474744474,$query84747474744474);

foreach($result84747474744474 as $row84747474744474)

{

$emailtextgoogleapps84747474[] = $row84747474744474['toemail'];

$emailtextgoogleapps847474744474[] = $row84747474744474['emailtext'];

$emailtextgoogleapps8474747444744474[] = $row84747474744474['date'];

}

?>

<div style="padding:12px;background-color:#ffffff;box-shadow:0 2px 12px rgba(0,0,0,0.4);margin:12px;cursor:pointer;">

<div>

<?php

$stringtoencrypt847474744474 = $emailtextgoogleapps84747474[0];

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext8472747444744474447444747474744474 = rawurldecode($stringtoencrypt847474744474);

$decryptedstringemailtext8472747444744474447444747474744474 = openssl_decrypt($decryptedstringemailtext8472747444744474447444747474744474,"AES-128-ECB",$password);

echo "$decryptedstringemailtext8472747444744474447444747474744474";

?>

</div>

<div>

<?php

$stringtoencrypt847474744474 = $emailtextgoogleapps847474744474[0];

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext8472747444744474447444747474744474 = rawurldecode($stringtoencrypt847474744474);

$decryptedstringemailtext8472747444744474447444747474744474 = openssl_decrypt($decryptedstringemailtext8472747444744474447444747474744474,"AES-128-ECB",$password);

echo "$decryptedstringemailtext8472747444744474447444747474744474";

?>

</div>

<div>

<?php

$google84747474 = date("M d", strtotime($emailtextgoogleapps8474747444744474[0]));

echo "$google84747474";

?>

</div>

</div>

<?php

include "../dashboard/dashboardbottom.php";

?>

<?php

$conn847474744474->close();

?>

