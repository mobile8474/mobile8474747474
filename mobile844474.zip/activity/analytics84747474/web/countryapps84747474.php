<!-- Styles -->
<style>
#chartdiv {
  width: 100%;
  height: 500px;
}																		
</style>

<?php

$servername8474747444444474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps84.sh"));
$username8474747444444474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps1.sh"));
$password8474747444444474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps2.sh"));
$dbname8474747444444474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername8474747444444474, $username8474747444444474, $password8474747444444474, $dbname8474747444444474);

?>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

$google847474744474 = date("Y-m-d");

?>

<?php

$google847474744474447444744474 = $_COOKIE['username'];

$google8884 = array();

$query = "SELECT email,date,country FROM countryusersapps84747474 WHERE email='$google847474744474447444744474' and date REGEXP '$google847474744474.*' order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$google8884[] = $row['country'];

}

$googleapps1 = array_count_values($google8884);
$googleapps2 = array_count_values($google8884);
$googleapps3 = array_count_values($google8884);
$googleapps4 = array_count_values($google8884);
$googleapps5 = array_count_values($google8884);
$googleapps6 = array_count_values($google8884);
$googleapps7 = array_count_values($google8884);
$googleapps8 = array_count_values($google8884);
$googleapps9 = array_count_values($google8884);
$googleapps10 = array_count_values($google8884);
$googleapps11 = array_count_values($google8884);
$googleapps12 = array_count_values($google8884);
$googleapps13 = array_count_values($google8884);
$googleapps14 = array_count_values($google8884);
$googleapps15 = array_count_values($google8884);
$googleapps16 = array_count_values($google8884);
$googleapps17 = array_count_values($google8884);
$googleapps18 = array_count_values($google8884);
$googleapps19 = array_count_values($google8884);
$googleapps20 = array_count_values($google8884);
$googleapps21 = array_count_values($google8884);
$googleapps22 = array_count_values($google8884);
$googleapps23 = array_count_values($google8884);
$googleapps24 = array_count_values($google8884);
$googleapps25 = array_count_values($google8884);
$googleapps26 = array_count_values($google8884);
$googleapps27 = array_count_values($google8884);
$googleapps28 = array_count_values($google8884);
$googleapps29 = array_count_values($google8884);
$googleapps30 = array_count_values($google8884);
$googleapps31 = array_count_values($google8884);
$googleapps32 = array_count_values($google8884);
$googleapps33 = array_count_values($google8884);
$googleapps34 = array_count_values($google8884);
$googleapps35 = array_count_values($google8884);
$googleapps36 = array_count_values($google8884);
$googleapps37 = array_count_values($google8884);
$googleapps38 = array_count_values($google8884);
$googleapps39 = array_count_values($google8884);
$googleapps40 = array_count_values($google8884);
$googleapps41 = array_count_values($google8884);
$googleapps42 = array_count_values($google8884);
$googleapps43 = array_count_values($google8884);
$googleapps44 = array_count_values($google8884);
$googleapps45 = array_count_values($google8884);
$googleapps46 = array_count_values($google8884);
$googleapps47 = array_count_values($google8884);
$googleapps48 = array_count_values($google8884);
$googleapps49 = array_count_values($google8884);
$googleapps50 = array_count_values($google8884);
$googleapps51 = array_count_values($google8884);
$googleapps52 = array_count_values($google8884);
$googleapps53 = array_count_values($google8884);
$googleapps54 = array_count_values($google8884);
$googleapps55 = array_count_values($google8884);
$googleapps56 = array_count_values($google8884);
$googleapps57 = array_count_values($google8884);
$googleapps58 = array_count_values($google8884);
$googleapps59 = array_count_values($google8884);
$googleapps60 = array_count_values($google8884);
$googleapps61 = array_count_values($google8884);
$googleapps62 = array_count_values($google8884);
$googleapps63 = array_count_values($google8884);
$googleapps64 = array_count_values($google8884);
$googleapps65 = array_count_values($google8884);
$googleapps66 = array_count_values($google8884);
$googleapps67 = array_count_values($google8884);
$googleapps68 = array_count_values($google8884);
$googleapps69 = array_count_values($google8884);
$googleapps70 = array_count_values($google8884);
$googleapps71 = array_count_values($google8884);
$googleapps72 = array_count_values($google8884);
$googleapps73 = array_count_values($google8884);
$googleapps74 = array_count_values($google8884);
$googleapps75 = array_count_values($google8884);
$googleapps76 = array_count_values($google8884);
$googleapps77 = array_count_values($google8884);
$googleapps78 = array_count_values($google8884);
$googleapps79 = array_count_values($google8884);
$googleapps80 = array_count_values($google8884);
$googleapps81 = array_count_values($google8884);
$googleapps82 = array_count_values($google8884);
$googleapps83 = array_count_values($google8884);
$googleapps84 = array_count_values($google8884);
$googleapps85 = array_count_values($google8884);
$googleapps86 = array_count_values($google8884);
$googleapps87 = array_count_values($google8884);
$googleapps88 = array_count_values($google8884);
$googleapps89 = array_count_values($google8884);
$googleapps90 = array_count_values($google8884);
$googleapps91 = array_count_values($google8884);
$googleapps92 = array_count_values($google8884);
$googleapps93 = array_count_values($google8884);
$googleapps94 = array_count_values($google8884);
$googleapps95 = array_count_values($google8884);
$googleapps96 = array_count_values($google8884);
$googleapps97 = array_count_values($google8884);
$googleapps98 = array_count_values($google8884);
$googleapps99 = array_count_values($google8884);
$googleapps100 = array_count_values($google8884);
$googleapps101 = array_count_values($google8884);
$googleapps102 = array_count_values($google8884);
$googleapps103 = array_count_values($google8884);
$googleapps104 = array_count_values($google8884);
$googleapps105 = array_count_values($google8884);
$googleapps106 = array_count_values($google8884);
$googleapps107 = array_count_values($google8884);
$googleapps108 = array_count_values($google8884);
$googleapps109 = array_count_values($google8884);
$googleapps110 = array_count_values($google8884);
$googleapps111 = array_count_values($google8884);
$googleapps112 = array_count_values($google8884);
$googleapps113 = array_count_values($google8884);
$googleapps114 = array_count_values($google8884);
$googleapps115 = array_count_values($google8884);
$googleapps116 = array_count_values($google8884);
$googleapps117 = array_count_values($google8884);
$googleapps118 = array_count_values($google8884);
$googleapps119 = array_count_values($google8884);
$googleapps120 = array_count_values($google8884);
$googleapps121 = array_count_values($google8884);
$googleapps122 = array_count_values($google8884);
$googleapps123 = array_count_values($google8884);
$googleapps124 = array_count_values($google8884);
$googleapps125 = array_count_values($google8884);
$googleapps126 = array_count_values($google8884);
$googleapps127 = array_count_values($google8884);
$googleapps128 = array_count_values($google8884);
$googleapps129 = array_count_values($google8884);
$googleapps130 = array_count_values($google8884);
$googleapps131 = array_count_values($google8884);
$googleapps132 = array_count_values($google8884);
$googleapps133 = array_count_values($google8884);
$googleapps134 = array_count_values($google8884);
$googleapps135 = array_count_values($google8884);
$googleapps136 = array_count_values($google8884);
$googleapps137 = array_count_values($google8884);
$googleapps138 = array_count_values($google8884);
$googleapps139 = array_count_values($google8884);
$googleapps140 = array_count_values($google8884);
$googleapps141 = array_count_values($google8884);
$googleapps142 = array_count_values($google8884);
$googleapps143 = array_count_values($google8884);
$googleapps144 = array_count_values($google8884);
$googleapps145 = array_count_values($google8884);
$googleapps146 = array_count_values($google8884);
$googleapps147 = array_count_values($google8884);
$googleapps148 = array_count_values($google8884);
$googleapps149 = array_count_values($google8884);
$googleapps150 = array_count_values($google8884);
$googleapps151 = array_count_values($google8884);
$googleapps152 = array_count_values($google8884);
$googleapps153 = array_count_values($google8884);
$googleapps154 = array_count_values($google8884);
$googleapps155 = array_count_values($google8884);
$googleapps156 = array_count_values($google8884);
$googleapps157 = array_count_values($google8884);
$googleapps158 = array_count_values($google8884);
$googleapps159 = array_count_values($google8884);
$googleapps160 = array_count_values($google8884);
$googleapps161 = array_count_values($google8884);
$googleapps162 = array_count_values($google8884);
$googleapps163 = array_count_values($google8884);
$googleapps164 = array_count_values($google8884);
$googleapps165 = array_count_values($google8884);
$googleapps166 = array_count_values($google8884);
$googleapps167 = array_count_values($google8884);
$googleapps168 = array_count_values($google8884);
$googleapps169 = array_count_values($google8884);

$googleapps1 = $googleapps1['Afghanistan'];
$googleapps2 = $googleapps2['Albania'];
$googleapps3 = $googleapps3['Algeria'];
$googleapps4 = $googleapps4['Angola'];
$googleapps5 = $googleapps5['Argentina'];
$googleapps6 = $googleapps6['Armenia'];
$googleapps7 = $googleapps7['Australia'];
$googleapps8 = $googleapps8['Austria'];
$googleapps9 = $googleapps9['Azerbaijan'];
$googleapps10 = $googleapps10['Bahrain'];
$googleapps11 = $googleapps11['Bangladesh'];
$googleapps12 = $googleapps12['Belarus'];
$googleapps13 = $googleapps13['Belgium'];
$googleapps14 = $googleapps14['Benin'];
$googleapps15 = $googleapps15['Bhutan'];
$googleapps16 = $googleapps16['Bolivia'];
$googleapps17 = $googleapps17['Bosnia and Herzegovina'];
$googleapps18 = $googleapps18['Botswana'];
$googleapps19 = $googleapps19['Brazil'];
$googleapps20 = $googleapps20['Brunei'];
$googleapps21 = $googleapps21['Bulgaria'];
$googleapps22 = $googleapps22['Burkina Faso'];
$googleapps23 = $googleapps23['Burundi'];
$googleapps24 = $googleapps24['Cambodia'];
$googleapps25 = $googleapps25['Cameroon'];
$googleapps26 = $googleapps26['Canada'];
$googleapps27 = $googleapps27['Cape Verde'];
$googleapps28 = $googleapps28['Central African Rep.'];
$googleapps29 = $googleapps29['Chad'];
$googleapps30 = $googleapps30['Chile'];
$googleapps31 = $googleapps31['China'];
$googleapps32 = $googleapps32['Colombia'];
$googleapps33 = $googleapps33['Comoros'];
$googleapps34 = $googleapps34['Congo, Dem. Rep.'];
$googleapps35 = $googleapps35['Congo, Rep.'];
$googleapps36 = $googleapps36['Costa Rica'];
$googleapps37 = $googleapps37['Cote d\'Ivoire'];
$googleapps38 = $googleapps38['Croatia'];
$googleapps39 = $googleapps39['Cuba'];
$googleapps40 = $googleapps40['Cyprus'];
$googleapps41 = $googleapps41['Czech Rep.'];
$googleapps42 = $googleapps42['Denmark'];
$googleapps43 = $googleapps43['Djibouti'];
$googleapps44 = $googleapps44['Dominican Rep.'];
$googleapps45 = $googleapps45['Ecuador'];
$googleapps46 = $googleapps46['Egypt'];
$googleapps47 = $googleapps47['El Salvador'];
$googleapps48 = $googleapps48['Equatorial Guinea'];
$googleapps49 = $googleapps49['Eritrea'];
$googleapps50 = $googleapps50['Estonia'];
$googleapps51 = $googleapps51['Ethiopia'];
$googleapps52 = $googleapps52['Fiji'];
$googleapps53 = $googleapps53['Finland'];
$googleapps54 = $googleapps54['France'];
$googleapps55 = $googleapps55['Gabon'];
$googleapps56 = $googleapps56['Gambia'];
$googleapps57 = $googleapps57['Georgia'];
$googleapps58 = $googleapps58['Germany'];
$googleapps59 = $googleapps59['Ghana'];
$googleapps60 = $googleapps60['Greece'];
$googleapps61 = $googleapps61['Guatemala'];
$googleapps62 = $googleapps62['Guinea'];
$googleapps63 = $googleapps63['Guinea-Bissau'];
$googleapps64 = $googleapps64['Guyana'];
$googleapps65 = $googleapps65['Haiti'];
$googleapps66 = $googleapps66['Honduras'];
$googleapps67 = $googleapps67['Hong Kong, China'];
$googleapps68 = $googleapps68['Hungary'];
$googleapps69 = $googleapps69['Iceland'];
$googleapps70 = $googleapps70['India'];
$googleapps71 = $googleapps71['Indonesia'];
$googleapps72 = $googleapps72['Iran'];
$googleapps73 = $googleapps73['Iraq'];
$googleapps74 = $googleapps74['Ireland'];
$googleapps75 = $googleapps75['Israel'];
$googleapps76 = $googleapps76['Italy'];
$googleapps77 = $googleapps77['Jamaica'];
$googleapps78 = $googleapps78['Japan'];
$googleapps79 = $googleapps79['Jordan'];
$googleapps80 = $googleapps80['Kazakhstan'];
$googleapps81 = $googleapps81['Kenya'];
$googleapps82 = $googleapps82['Korea, Dem. Rep.'];
$googleapps83 = $googleapps83['Korea, Rep.'];
$googleapps84 = $googleapps84['Kuwait'];
$googleapps85 = $googleapps85['Kyrgyzstan'];
$googleapps86 = $googleapps86['Laos'];
$googleapps87 = $googleapps87['Latvia'];
$googleapps88 = $googleapps88['Lebanon'];
$googleapps89 = $googleapps89['Lesotho'];
$googleapps90 = $googleapps90['Liberia'];
$googleapps91 = $googleapps91['Libya'];
$googleapps92 = $googleapps92['Lithuania'];
$googleapps93 = $googleapps93['Luxembourg'];
$googleapps94 = $googleapps94['Macedonia, FYR'];
$googleapps95 = $googleapps95['Madagascar'];
$googleapps96 = $googleapps96['Malawi'];
$googleapps97 = $googleapps97['Malaysia'];
$googleapps98 = $googleapps98['Mali'];
$googleapps99 = $googleapps99['Mauritania'];
$googleapps100 = $googleapps100['Mauritius'];
$googleapps101 = $googleapps101['Mexico'];
$googleapps102 = $googleapps102['Moldova'];
$googleapps103 = $googleapps103['Mongolia'];
$googleapps104 = $googleapps104['Montenegro'];
$googleapps105 = $googleapps105['Morocco'];
$googleapps106 = $googleapps106['Mozambique'];
$googleapps107 = $googleapps107['Myanmar'];
$googleapps108 = $googleapps108['Namibia'];
$googleapps109 = $googleapps109['Nepal'];
$googleapps110 = $googleapps110['Netherlands'];
$googleapps111 = $googleapps111['New Zealand'];
$googleapps112 = $googleapps112['Nicaragua'];
$googleapps113 = $googleapps113['Niger'];
$googleapps114 = $googleapps114['Nigeria'];
$googleapps115 = $googleapps115['Norway'];
$googleapps116 = $googleapps116['Oman'];
$googleapps117 = $googleapps117['Pakistan'];
$googleapps118 = $googleapps118['Panama'];
$googleapps119 = $googleapps119['Papua New Guinea'];
$googleapps120 = $googleapps120['Paraguay'];
$googleapps121 = $googleapps121['Peru'];
$googleapps122 = $googleapps122['Philippines'];
$googleapps123 = $googleapps123['Poland'];
$googleapps124 = $googleapps124['Portugal'];
$googleapps125 = $googleapps125['Puerto Rico'];
$googleapps126 = $googleapps126['Qatar'];
$googleapps127 = $googleapps127['Romania'];
$googleapps128 = $googleapps128['Russia'];
$googleapps129 = $googleapps129['Rwanda'];
$googleapps130 = $googleapps130['Saudi Arabia'];
$googleapps131 = $googleapps131['Senegal'];
$googleapps132 = $googleapps132['Serbia'];
$googleapps133 = $googleapps133['Sierra Leone'];
$googleapps134 = $googleapps134['Singapore'];
$googleapps135 = $googleapps135['Slovak Republic'];
$googleapps136 = $googleapps136['Slovenia'];
$googleapps137 = $googleapps137['Solomon Islands'];
$googleapps138 = $googleapps138['Somalia'];
$googleapps139 = $googleapps139['South Africa'];
$googleapps140 = $googleapps140['Spain'];
$googleapps141 = $googleapps141['Sri Lanka'];
$googleapps142 = $googleapps142['Sudan'];
$googleapps143 = $googleapps143['Suriname'];
$googleapps144 = $googleapps144['Swaziland'];
$googleapps145 = $googleapps145['Sweden'];
$googleapps146 = $googleapps146['Switzerland'];
$googleapps147 = $googleapps147['Syria'];
$googleapps148 = $googleapps148['Taiwan'];
$googleapps149 = $googleapps149['Tajikistan'];
$googleapps150 = $googleapps150['Tanzania'];
$googleapps151 = $googleapps151['Thailand'];
$googleapps152 = $googleapps152['Togo'];
$googleapps153 = $googleapps153['Trinidad and Tobago'];
$googleapps154 = $googleapps154['Tunisia'];
$googleapps155 = $googleapps155['Turkey'];
$googleapps156 = $googleapps156['Turkmenistan'];
$googleapps157 = $googleapps157['Uganda'];
$googleapps158 = $googleapps158['Ukraine'];
$googleapps159 = $googleapps159['United Arab Emirates'];
$googleapps160 = $googleapps160['United Kingdom'];
$googleapps161 = $googleapps161['United States'];
$googleapps162 = $googleapps162['Uruguay'];
$googleapps163 = $googleapps163['Uzbekistan'];
$googleapps164 = $googleapps164['Venezuela'];
$googleapps165 = $googleapps165['West Bank and Gaza'];
$googleapps166 = $googleapps166['Vietnam'];
$googleapps167 = $googleapps167['Yemen, Rep.'];
$googleapps168 = $googleapps168['Zambia'];
$googleapps169 = $googleapps169['Zimbabwe'];

echo "$googleapps1";

?>

<!-- Chart code -->
<script>
/*
  Although amMap has methods like getAreaCenterLatitude and getAreaCenterLongitude,
  they are not suitable in quite a lot of cases as the center of some countries
  is even outside the country itself (like US, because of Alaska and Hawaii)
  That's why wehave the coordinates stored here
*/

var latlong = {};
latlong["AD"] = {"latitude":42.5, "longitude":1.5};
latlong["AE"] = {"latitude":24, "longitude":54};
latlong["AF"] = {"latitude":33, "longitude":65};
latlong["AG"] = {"latitude":17.05, "longitude":-61.8};
latlong["AI"] = {"latitude":18.25, "longitude":-63.1667};
latlong["AL"] = {"latitude":41, "longitude":20};
latlong["AM"] = {"latitude":40, "longitude":45};
latlong["AN"] = {"latitude":12.25, "longitude":-68.75};
latlong["AO"] = {"latitude":-12.5, "longitude":18.5};
latlong["AP"] = {"latitude":35, "longitude":105};
latlong["AQ"] = {"latitude":-90, "longitude":0};
latlong["AR"] = {"latitude":-34, "longitude":-64};
latlong["AS"] = {"latitude":-14.3333, "longitude":-170};
latlong["AT"] = {"latitude":47.3333, "longitude":13.3333};
latlong["AU"] = {"latitude":-27, "longitude":133};
latlong["AW"] = {"latitude":12.5, "longitude":-69.9667};
latlong["AZ"] = {"latitude":40.5, "longitude":47.5};
latlong["BA"] = {"latitude":44, "longitude":18};
latlong["BB"] = {"latitude":13.1667, "longitude":-59.5333};
latlong["BD"] = {"latitude":24, "longitude":90};
latlong["BE"] = {"latitude":50.8333, "longitude":4};
latlong["BF"] = {"latitude":13, "longitude":-2};
latlong["BG"] = {"latitude":43, "longitude":25};
latlong["BH"] = {"latitude":26, "longitude":50.55};
latlong["BI"] = {"latitude":-3.5, "longitude":30};
latlong["BJ"] = {"latitude":9.5, "longitude":2.25};
latlong["BM"] = {"latitude":32.3333, "longitude":-64.75};
latlong["BN"] = {"latitude":4.5, "longitude":114.6667};
latlong["BO"] = {"latitude":-17, "longitude":-65};
latlong["BR"] = {"latitude":-10, "longitude":-55};
latlong["BS"] = {"latitude":24.25, "longitude":-76};
latlong["BT"] = {"latitude":27.5, "longitude":90.5};
latlong["BV"] = {"latitude":-54.4333, "longitude":3.4};
latlong["BW"] = {"latitude":-22, "longitude":24};
latlong["BY"] = {"latitude":53, "longitude":28};
latlong["BZ"] = {"latitude":17.25, "longitude":-88.75};
latlong["CA"] = {"latitude":54, "longitude":-100};
latlong["CC"] = {"latitude":-12.5, "longitude":96.8333};
latlong["CD"] = {"latitude":0, "longitude":25};
latlong["CF"] = {"latitude":7, "longitude":21};
latlong["CG"] = {"latitude":-1, "longitude":15};
latlong["CH"] = {"latitude":47, "longitude":8};
latlong["CI"] = {"latitude":8, "longitude":-5};
latlong["CK"] = {"latitude":-21.2333, "longitude":-159.7667};
latlong["CL"] = {"latitude":-30, "longitude":-71};
latlong["CM"] = {"latitude":6, "longitude":12};
latlong["CN"] = {"latitude":35, "longitude":105};
latlong["CO"] = {"latitude":4, "longitude":-72};
latlong["CR"] = {"latitude":10, "longitude":-84};
latlong["CU"] = {"latitude":21.5, "longitude":-80};
latlong["CV"] = {"latitude":16, "longitude":-24};
latlong["CX"] = {"latitude":-10.5, "longitude":105.6667};
latlong["CY"] = {"latitude":35, "longitude":33};
latlong["CZ"] = {"latitude":49.75, "longitude":15.5};
latlong["DE"] = {"latitude":51, "longitude":9};
latlong["DJ"] = {"latitude":11.5, "longitude":43};
latlong["DK"] = {"latitude":56, "longitude":10};
latlong["DM"] = {"latitude":15.4167, "longitude":-61.3333};
latlong["DO"] = {"latitude":19, "longitude":-70.6667};
latlong["DZ"] = {"latitude":28, "longitude":3};
latlong["EC"] = {"latitude":-2, "longitude":-77.5};
latlong["EE"] = {"latitude":59, "longitude":26};
latlong["EG"] = {"latitude":27, "longitude":30};
latlong["EH"] = {"latitude":24.5, "longitude":-13};
latlong["ER"] = {"latitude":15, "longitude":39};
latlong["ES"] = {"latitude":40, "longitude":-4};
latlong["ET"] = {"latitude":8, "longitude":38};
latlong["EU"] = {"latitude":47, "longitude":8};
latlong["FI"] = {"latitude":62, "longitude":26};
latlong["FJ"] = {"latitude":-18, "longitude":175};
latlong["FK"] = {"latitude":-51.75, "longitude":-59};
latlong["FM"] = {"latitude":6.9167, "longitude":158.25};
latlong["FO"] = {"latitude":62, "longitude":-7};
latlong["FR"] = {"latitude":46, "longitude":2};
latlong["GA"] = {"latitude":-1, "longitude":11.75};
latlong["GB"] = {"latitude":54, "longitude":-2};
latlong["GD"] = {"latitude":12.1167, "longitude":-61.6667};
latlong["GE"] = {"latitude":42, "longitude":43.5};
latlong["GF"] = {"latitude":4, "longitude":-53};
latlong["GH"] = {"latitude":8, "longitude":-2};
latlong["GI"] = {"latitude":36.1833, "longitude":-5.3667};
latlong["GL"] = {"latitude":72, "longitude":-40};
latlong["GM"] = {"latitude":13.4667, "longitude":-16.5667};
latlong["GN"] = {"latitude":11, "longitude":-10};
latlong["GP"] = {"latitude":16.25, "longitude":-61.5833};
latlong["GQ"] = {"latitude":2, "longitude":10};
latlong["GR"] = {"latitude":39, "longitude":22};
latlong["GS"] = {"latitude":-54.5, "longitude":-37};
latlong["GT"] = {"latitude":15.5, "longitude":-90.25};
latlong["GU"] = {"latitude":13.4667, "longitude":144.7833};
latlong["GW"] = {"latitude":12, "longitude":-15};
latlong["GY"] = {"latitude":5, "longitude":-59};
latlong["HK"] = {"latitude":22.25, "longitude":114.1667};
latlong["HM"] = {"latitude":-53.1, "longitude":72.5167};
latlong["HN"] = {"latitude":15, "longitude":-86.5};
latlong["HR"] = {"latitude":45.1667, "longitude":15.5};
latlong["HT"] = {"latitude":19, "longitude":-72.4167};
latlong["HU"] = {"latitude":47, "longitude":20};
latlong["ID"] = {"latitude":-5, "longitude":120};
latlong["IE"] = {"latitude":53, "longitude":-8};
latlong["IL"] = {"latitude":31.5, "longitude":34.75};
latlong["IN"] = {"latitude":20, "longitude":77};
latlong["IO"] = {"latitude":-6, "longitude":71.5};
latlong["IQ"] = {"latitude":33, "longitude":44};
latlong["IR"] = {"latitude":32, "longitude":53};
latlong["IS"] = {"latitude":65, "longitude":-18};
latlong["IT"] = {"latitude":42.8333, "longitude":12.8333};
latlong["JM"] = {"latitude":18.25, "longitude":-77.5};
latlong["JO"] = {"latitude":31, "longitude":36};
latlong["JP"] = {"latitude":36, "longitude":138};
latlong["KE"] = {"latitude":1, "longitude":38};
latlong["KG"] = {"latitude":41, "longitude":75};
latlong["KH"] = {"latitude":13, "longitude":105};
latlong["KI"] = {"latitude":1.4167, "longitude":173};
latlong["KM"] = {"latitude":-12.1667, "longitude":44.25};
latlong["KN"] = {"latitude":17.3333, "longitude":-62.75};
latlong["KP"] = {"latitude":40, "longitude":127};
latlong["KR"] = {"latitude":37, "longitude":127.5};
latlong["KW"] = {"latitude":29.3375, "longitude":47.6581};
latlong["KY"] = {"latitude":19.5, "longitude":-80.5};
latlong["KZ"] = {"latitude":48, "longitude":68};
latlong["LA"] = {"latitude":18, "longitude":105};
latlong["LB"] = {"latitude":33.8333, "longitude":35.8333};
latlong["LC"] = {"latitude":13.8833, "longitude":-61.1333};
latlong["LI"] = {"latitude":47.1667, "longitude":9.5333};
latlong["LK"] = {"latitude":7, "longitude":81};
latlong["LR"] = {"latitude":6.5, "longitude":-9.5};
latlong["LS"] = {"latitude":-29.5, "longitude":28.5};
latlong["LT"] = {"latitude":55, "longitude":24};
latlong["LU"] = {"latitude":49.75, "longitude":6};
latlong["LV"] = {"latitude":57, "longitude":25};
latlong["LY"] = {"latitude":25, "longitude":17};
latlong["MA"] = {"latitude":32, "longitude":-5};
latlong["MC"] = {"latitude":43.7333, "longitude":7.4};
latlong["MD"] = {"latitude":47, "longitude":29};
latlong["ME"] = {"latitude":42.5, "longitude":19.4};
latlong["MG"] = {"latitude":-20, "longitude":47};
latlong["MH"] = {"latitude":9, "longitude":168};
latlong["MK"] = {"latitude":41.8333, "longitude":22};
latlong["ML"] = {"latitude":17, "longitude":-4};
latlong["MM"] = {"latitude":22, "longitude":98};
latlong["MN"] = {"latitude":46, "longitude":105};
latlong["MO"] = {"latitude":22.1667, "longitude":113.55};
latlong["MP"] = {"latitude":15.2, "longitude":145.75};
latlong["MQ"] = {"latitude":14.6667, "longitude":-61};
latlong["MR"] = {"latitude":20, "longitude":-12};
latlong["MS"] = {"latitude":16.75, "longitude":-62.2};
latlong["MT"] = {"latitude":35.8333, "longitude":14.5833};
latlong["MU"] = {"latitude":-20.2833, "longitude":57.55};
latlong["MV"] = {"latitude":3.25, "longitude":73};
latlong["MW"] = {"latitude":-13.5, "longitude":34};
latlong["MX"] = {"latitude":23, "longitude":-102};
latlong["MY"] = {"latitude":2.5, "longitude":112.5};
latlong["MZ"] = {"latitude":-18.25, "longitude":35};
latlong["NA"] = {"latitude":-22, "longitude":17};
latlong["NC"] = {"latitude":-21.5, "longitude":165.5};
latlong["NE"] = {"latitude":16, "longitude":8};
latlong["NF"] = {"latitude":-29.0333, "longitude":167.95};
latlong["NG"] = {"latitude":10, "longitude":8};
latlong["NI"] = {"latitude":13, "longitude":-85};
latlong["NL"] = {"latitude":52.5, "longitude":5.75};
latlong["NO"] = {"latitude":62, "longitude":10};
latlong["NP"] = {"latitude":28, "longitude":84};
latlong["NR"] = {"latitude":-0.5333, "longitude":166.9167};
latlong["NU"] = {"latitude":-19.0333, "longitude":-169.8667};
latlong["NZ"] = {"latitude":-41, "longitude":174};
latlong["OM"] = {"latitude":21, "longitude":57};
latlong["PA"] = {"latitude":9, "longitude":-80};
latlong["PE"] = {"latitude":-10, "longitude":-76};
latlong["PF"] = {"latitude":-15, "longitude":-140};
latlong["PG"] = {"latitude":-6, "longitude":147};
latlong["PH"] = {"latitude":13, "longitude":122};
latlong["PK"] = {"latitude":30, "longitude":70};
latlong["PL"] = {"latitude":52, "longitude":20};
latlong["PM"] = {"latitude":46.8333, "longitude":-56.3333};
latlong["PR"] = {"latitude":18.25, "longitude":-66.5};
latlong["PS"] = {"latitude":32, "longitude":35.25};
latlong["PT"] = {"latitude":39.5, "longitude":-8};
latlong["PW"] = {"latitude":7.5, "longitude":134.5};
latlong["PY"] = {"latitude":-23, "longitude":-58};
latlong["QA"] = {"latitude":25.5, "longitude":51.25};
latlong["RE"] = {"latitude":-21.1, "longitude":55.6};
latlong["RO"] = {"latitude":46, "longitude":25};
latlong["RS"] = {"latitude":44, "longitude":21};
latlong["RU"] = {"latitude":60, "longitude":100};
latlong["RW"] = {"latitude":-2, "longitude":30};
latlong["SA"] = {"latitude":25, "longitude":45};
latlong["SB"] = {"latitude":-8, "longitude":159};
latlong["SC"] = {"latitude":-4.5833, "longitude":55.6667};
latlong["SD"] = {"latitude":15, "longitude":30};
latlong["SE"] = {"latitude":62, "longitude":15};
latlong["SG"] = {"latitude":1.3667, "longitude":103.8};
latlong["SH"] = {"latitude":-15.9333, "longitude":-5.7};
latlong["SI"] = {"latitude":46, "longitude":15};
latlong["SJ"] = {"latitude":78, "longitude":20};
latlong["SK"] = {"latitude":48.6667, "longitude":19.5};
latlong["SL"] = {"latitude":8.5, "longitude":-11.5};
latlong["SM"] = {"latitude":43.7667, "longitude":12.4167};
latlong["SN"] = {"latitude":14, "longitude":-14};
latlong["SO"] = {"latitude":10, "longitude":49};
latlong["SR"] = {"latitude":4, "longitude":-56};
latlong["ST"] = {"latitude":1, "longitude":7};
latlong["SV"] = {"latitude":13.8333, "longitude":-88.9167};
latlong["SY"] = {"latitude":35, "longitude":38};
latlong["SZ"] = {"latitude":-26.5, "longitude":31.5};
latlong["TC"] = {"latitude":21.75, "longitude":-71.5833};
latlong["TD"] = {"latitude":15, "longitude":19};
latlong["TF"] = {"latitude":-43, "longitude":67};
latlong["TG"] = {"latitude":8, "longitude":1.1667};
latlong["TH"] = {"latitude":15, "longitude":100};
latlong["TJ"] = {"latitude":39, "longitude":71};
latlong["TK"] = {"latitude":-9, "longitude":-172};
latlong["TM"] = {"latitude":40, "longitude":60};
latlong["TN"] = {"latitude":34, "longitude":9};
latlong["TO"] = {"latitude":-20, "longitude":-175};
latlong["TR"] = {"latitude":39, "longitude":35};
latlong["TT"] = {"latitude":11, "longitude":-61};
latlong["TV"] = {"latitude":-8, "longitude":178};
latlong["TW"] = {"latitude":23.5, "longitude":121};
latlong["TZ"] = {"latitude":-6, "longitude":35};
latlong["UA"] = {"latitude":49, "longitude":32};
latlong["UG"] = {"latitude":1, "longitude":32};
latlong["UM"] = {"latitude":19.2833, "longitude":166.6};
latlong["US"] = {"latitude":38, "longitude":-97};
latlong["UY"] = {"latitude":-33, "longitude":-56};
latlong["UZ"] = {"latitude":41, "longitude":64};
latlong["VA"] = {"latitude":41.9, "longitude":12.45};
latlong["VC"] = {"latitude":13.25, "longitude":-61.2};
latlong["VE"] = {"latitude":8, "longitude":-66};
latlong["VG"] = {"latitude":18.5, "longitude":-64.5};
latlong["VI"] = {"latitude":18.3333, "longitude":-64.8333};
latlong["VN"] = {"latitude":16, "longitude":106};
latlong["VU"] = {"latitude":-16, "longitude":167};
latlong["WF"] = {"latitude":-13.3, "longitude":-176.2};
latlong["WS"] = {"latitude":-13.5833, "longitude":-172.3333};
latlong["YE"] = {"latitude":15, "longitude":48};
latlong["YT"] = {"latitude":-12.8333, "longitude":45.1667};
latlong["ZA"] = {"latitude":-29, "longitude":24};
latlong["ZM"] = {"latitude":-15, "longitude":30};
latlong["ZW"] = {"latitude":-20, "longitude":30};

var mapData = [
{"code":"AF" , "name":"Afghanistan", "value":'<?php echo $googleapps1 * 1;; ?>', "color":"#eea638"},
{"code":"AL" , "name":"Albania", "value":'<?php echo $googleapps2 * 1;; ?>', "color":"#d8854f"},
{"code":"DZ" , "name":"Algeria", "value":'<?php echo $googleapps3 * 1;; ?>', "color":"#de4c4f"},
{"code":"AO" , "name":"Angola", "value":'<?php echo $googleapps4 * 1;; ?>', "color":"#de4c4f"},
{"code":"AR" , "name":"Argentina", "value":'<?php echo $googleapps5 * 1;; ?>', "color":"#86a965"},
{"code":"AM" , "name":"Armenia", "value":'<?php echo $googleapps6 * 1;; ?>', "color":"#d8854f"},
{"code":"AU" , "name":"Australia", "value":'<?php echo $googleapps7 * 1;; ?>', "color":"#8aabb0"},
{"code":"AT" , "name":"Austria", "value":'<?php echo $googleapps8 * 1;; ?>', "color":"#d8854f"},
{"code":"AZ" , "name":"Azerbaijan", "value":'<?php echo $googleapps9 * 1;; ?>', "color":"#d8854f"},
{"code":"BH" , "name":"Bahrain", "value":'<?php echo $googleapps10 * 1;; ?>', "color":"#eea638"},
{"code":"BD" , "name":"Bangladesh", "value":'<?php echo $googleapps11 * 1;; ?>', "color":"#eea638"},
{"code":"BY" , "name":"Belarus", "value":'<?php echo $googleapps12 * 1;; ?>', "color":"#d8854f"},
{"code":"BE" , "name":"Belgium", "value":'<?php echo $googleapps13 * 1;; ?>', "color":"#d8854f"},
{"code":"BJ" , "name":"Benin", "value":'<?php echo $googleapps14 * 1;; ?>', "color":"#de4c4f"},
{"code":"BT" , "name":"Bhutan", "value":'<?php echo $googleapps15 * 1;; ?>', "color":"#eea638"},
{"code":"BO" , "name":"Bolivia", "value":'<?php echo $googleapps16 * 1;; ?>', "color":"#86a965"},
{"code":"BA" , "name":"Bosnia and Herzegovina", "value":'<?php echo $googleapps17 * 1;; ?>', "color":"#d8854f"},
{"code":"BW" , "name":"Botswana", "value":'<?php echo $googleapps18 * 1;; ?>', "color":"#de4c4f"},
{"code":"BR" , "name":"Brazil", "value":'<?php echo $googleapps19 * 1;; ?>', "color":"#86a965"},
{"code":"BN" , "name":"Brunei", "value":'<?php echo $googleapps20 * 1;; ?>', "color":"#eea638"},
{"code":"BG" , "name":"Bulgaria", "value":'<?php echo $googleapps21 * 1;; ?>', "color":"#d8854f"},
{"code":"BF" , "name":"Burkina Faso", "value":'<?php echo $googleapps22 * 1;; ?>', "color":"#de4c4f"},
{"code":"BI" , "name":"Burundi", "value":'<?php echo $googleapps23 * 1;; ?>', "color":"#de4c4f"},
{"code":"KH" , "name":"Cambodia", "value":'<?php echo $googleapps24 * 1;; ?>', "color":"#eea638"},
{"code":"CM" , "name":"Cameroon", "value":'<?php echo $googleapps25 * 1;; ?>', "color":"#de4c4f"},
{"code":"CA" , "name":"Canada", "value":'<?php echo $googleapps26 * 1;; ?>', "color":"#a7a737"},
{"code":"CV" , "name":"Cape Verde", "value":'<?php echo $googleapps27 * 1;; ?>', "color":"#de4c4f"},
{"code":"CF" , "name":"Central African Rep.", "value":'<?php echo $googleapps28 * 1;; ?>', "color":"#de4c4f"},
{"code":"TD" , "name":"Chad", "value":'<?php echo $googleapps29 * 1;; ?>', "color":"#de4c4f"},
{"code":"CL" , "name":"Chile", "value":'<?php echo $googleapps30 * 1;; ?>', "color":"#86a965"},
{"code":"CN" , "name":"China", "value":'<?php echo $googleapps31 * 1;; ?>', "color":"#eea638"},
{"code":"CO" , "name":"Colombia", "value":'<?php echo $googleapps32 * 1;; ?>', "color":"#86a965"},
{"code":"KM" , "name":"Comoros", "value":'<?php echo $googleapps33 * 1;; ?>', "color":"#de4c4f"},
{"code":"CD" , "name":"Congo, Dem. Rep.", "value":'<?php echo $googleapps34 * 1;; ?>', "color":"#de4c4f"},
{"code":"CG" , "name":"Congo, Rep.", "value":'<?php echo $googleapps35 * 1;; ?>', "color":"#de4c4f"},
{"code":"CR" , "name":"Costa Rica", "value":'<?php echo $googleapps36 * 1;; ?>', "color":"#a7a737"},
{"code":"CI" , "name":"Cote d'Ivoire", "value":'<?php echo $googleapps37 * 1;; ?>', "color":"#de4c4f"},
{"code":"HR" , "name":"Croatia", "value":'<?php echo $googleapps38 * 1;; ?>', "color":"#d8854f"},
{"code":"CU" , "name":"Cuba", "value":'<?php echo $googleapps39 * 1;; ?>', "color":"#a7a737"},
{"code":"CY" , "name":"Cyprus", "value":'<?php echo $googleapps40 * 1;; ?>', "color":"#d8854f"},
{"code":"CZ" , "name":"Czech Rep.", "value":'<?php echo $googleapps41 * 1;; ?>', "color":"#d8854f"},
{"code":"DK" , "name":"Denmark", "value":'<?php echo $googleapps42 * 1;; ?>', "color":"#d8854f"},
{"code":"DJ" , "name":"Djibouti", "value":'<?php echo $googleapps43 * 1;; ?>', "color":"#de4c4f"},
{"code":"DO" , "name":"Dominican Rep.", "value":'<?php echo $googleapps44 * 1;; ?>', "color":"#a7a737"},
{"code":"EC" , "name":"Ecuador", "value":'<?php echo $googleapps45 * 1;; ?>', "color":"#86a965"},
{"code":"EG" , "name":"Egypt", "value":'<?php echo $googleapps46 * 1;; ?>', "color":"#de4c4f"},
{"code":"SV" , "name":"El Salvador", "value":'<?php echo $googleapps47 * 1;; ?>', "color":"#a7a737"},
{"code":"GQ" , "name":"Equatorial Guinea", "value":'<?php echo $googleapps48 * 1;; ?>', "color":"#de4c4f"},
{"code":"ER" , "name":"Eritrea", "value":'<?php echo $googleapps49 * 1;; ?>', "color":"#de4c4f"},
{"code":"EE" , "name":"Estonia", "value":'<?php echo $googleapps50 * 1;; ?>', "color":"#d8854f"},
{"code":"ET" , "name":"Ethiopia", "value":'<?php echo $googleapps51 * 1;; ?>', "color":"#de4c4f"},
{"code":"FJ" , "name":"Fiji", "value":'<?php echo $googleapps52 * 1;; ?>', "color":"#8aabb0"},
{"code":"FI" , "name":"Finland", "value":'<?php echo $googleapps53 * 1;; ?>', "color":"#d8854f"},
{"code":"FR" , "name":"France", "value":'<?php echo $googleapps54 * 1;; ?>', "color":"#d8854f"},
{"code":"GA" , "name":"Gabon", "value":'<?php echo $googleapps55 * 1;; ?>', "color":"#de4c4f"},
{"code":"GM" , "name":"Gambia", "value":'<?php echo $googleapps56 * 1;; ?>', "color":"#de4c4f"},
{"code":"GE" , "name":"Georgia", "value":'<?php echo $googleapps57 * 1;; ?>', "color":"#d8854f"},
{"code":"DE" , "name":"Germany", "value":'<?php echo $googleapps58 * 1;; ?>', "color":"#d8854f"},
{"code":"GH" , "name":"Ghana", "value":'<?php echo $googleapps59 * 1;; ?>', "color":"#de4c4f"},
{"code":"GR" , "name":"Greece", "value":'<?php echo $googleapps60 * 1;; ?>', "color":"#d8854f"},
{"code":"GT" , "name":"Guatemala", "value":'<?php echo $googleapps61 * 1;; ?>', "color":"#a7a737"},
{"code":"GN" , "name":"Guinea", "value":'<?php echo $googleapps62 * 1;; ?>', "color":"#de4c4f"},
{"code":"GW" , "name":"Guinea-Bissau", "value":'<?php echo $googleapps63 * 1;; ?>', "color":"#de4c4f"},
{"code":"GY" , "name":"Guyana", "value":'<?php echo $googleapps64 * 1;; ?>', "color":"#86a965"},
{"code":"HT" , "name":"Haiti", "value":'<?php echo $googleapps65 * 1;; ?>', "color":"#a7a737"},
{"code":"HN" , "name":"Honduras", "value":'<?php echo $googleapps66 * 1;; ?>', "color":"#a7a737"},
{"code":"HK" , "name":"Hong Kong, China", "value":'<?php echo $googleapps67 * 1;; ?>', "color":"#eea638"},
{"code":"HU" , "name":"Hungary", "value":'<?php echo $googleapps68 * 1;; ?>', "color":"#d8854f"},
{"code":"IS" , "name":"Iceland", "value":'<?php echo $googleapps69 * 1;; ?>', "color":"#d8854f"},
{"code":"IN" , "name":"India", "value":'<?php echo $googleapps70 * 1;; ?>', "color":"#eea638"},
{"code":"ID" , "name":"Indonesia", "value":'<?php echo $googleapps71 * 1;; ?>', "color":"#eea638"},
{"code":"IR" , "name":"Iran", "value":'<?php echo $googleapps72 * 1;; ?>', "color":"#eea638"},
{"code":"IQ" , "name":"Iraq", "value":'<?php echo $googleapps73 * 1;; ?>', "color":"#eea638"},
{"code":"IE" , "name":"Ireland", "value":'<?php echo $googleapps74 * 1;; ?>', "color":"#d8854f"},
{"code":"IL" , "name":"Israel", "value":'<?php echo $googleapps75 * 1;; ?>', "color":"#eea638"},
{"code":"IT" , "name":"Italy", "value":'<?php echo $googleapps76 * 1;; ?>', "color":"#d8854f"},
{"code":"JM" , "name":"Jamaica", "value":'<?php echo $googleapps77 * 1;; ?>', "color":"#a7a737"},
{"code":"JP" , "name":"Japan", "value":'<?php echo $googleapps78 * 1;; ?>', "color":"#eea638"},
{"code":"JO" , "name":"Jordan", "value":'<?php echo $googleapps79 * 1;; ?>', "color":"#eea638"},
{"code":"KZ" , "name":"Kazakhstan", "value":'<?php echo $googleapps80 * 1;; ?>', "color":"#eea638"},
{"code":"KE" , "name":"Kenya", "value":'<?php echo $googleapps81 * 1;; ?>', "color":"#de4c4f"},
{"code":"KP" , "name":"Korea, Dem. Rep.", "value":'<?php echo $googleapps82 * 1;; ?>', "color":"#eea638"},
{"code":"KR" , "name":"Korea, Rep.", "value":'<?php echo $googleapps83 * 1;; ?>', "color":"#eea638"},
{"code":"KW" , "name":"Kuwait", "value":'<?php echo $googleapps84 * 1;; ?>', "color":"#eea638"},
{"code":"KG" , "name":"Kyrgyzstan", "value":'<?php echo $googleapps85 * 1;; ?>', "color":"#eea638"},
{"code":"LA" , "name":"Laos", "value":'<?php echo $googleapps86 * 1;; ?>', "color":"#eea638"},
{"code":"LV" , "name":"Latvia", "value":'<?php echo $googleapps87 * 1;; ?>', "color":"#d8854f"},
{"code":"LB" , "name":"Lebanon", "value":'<?php echo $googleapps88 * 1;; ?>', "color":"#eea638"},
{"code":"LS" , "name":"Lesotho", "value":'<?php echo $googleapps89 * 1;; ?>', "color":"#de4c4f"},
{"code":"LR" , "name":"Liberia", "value":'<?php echo $googleapps90 * 1;; ?>', "color":"#de4c4f"},
{"code":"LY" , "name":"Libya", "value":'<?php echo $googleapps91 * 1;; ?>', "color":"#de4c4f"},
{"code":"LT" , "name":"Lithuania", "value":'<?php echo $googleapps92 * 1;; ?>', "color":"#d8854f"},
{"code":"LU" , "name":"Luxembourg", "value":'<?php echo $googleapps93 * 1;; ?>', "color":"#d8854f"},
{"code":"MK" , "name":"Macedonia, FYR", "value":'<?php echo $googleapps94 * 1;; ?>', "color":"#d8854f"},
{"code":"MG" , "name":"Madagascar", "value":'<?php echo $googleapps95 * 1;; ?>', "color":"#de4c4f"},
{"code":"MW" , "name":"Malawi", "value":'<?php echo $googleapps96 * 1;; ?>', "color":"#de4c4f"},
{"code":"MY" , "name":"Malaysia", "value":'<?php echo $googleapps97 * 1;; ?>', "color":"#eea638"},
{"code":"ML" , "name":"Mali", "value":'<?php echo $googleapps98 * 1;; ?>', "color":"#de4c4f"},
{"code":"MR" , "name":"Mauritania", "value":'<?php echo $googleapps99 * 1;; ?>', "color":"#de4c4f"},
{"code":"MU" , "name":"Mauritius", "value":'<?php echo $googleapps100 * 1;; ?>', "color":"#de4c4f"},
{"code":"MX" , "name":"Mexico", "value":'<?php echo $googleapps101 * 1;; ?>', "color":"#a7a737"},
{"code":"MD" , "name":"Moldova", "value":'<?php echo $googleapps102 * 1;; ?>', "color":"#d8854f"},
{"code":"MN" , "name":"Mongolia", "value":'<?php echo $googleapps103 * 1;; ?>', "color":"#eea638"},
{"code":"ME" , "name":"Montenegro", "value":'<?php echo $googleapps104 * 1;; ?>', "color":"#d8854f"},
{"code":"MA" , "name":"Morocco", "value":'<?php echo $googleapps105 * 1;; ?>', "color":"#de4c4f"},
{"code":"MZ" , "name":"Mozambique", "value":'<?php echo $googleapps106 * 1;; ?>', "color":"#de4c4f"},
{"code":"MM" , "name":"Myanmar", "value":'<?php echo $googleapps107 * 1;; ?>', "color":"#eea638"},
{"code":"NA" , "name":"Namibia", "value":'<?php echo $googleapps108 * 1;; ?>', "color":"#de4c4f"},
{"code":"NP" , "name":"Nepal", "value":'<?php echo $googleapps109 * 1;; ?>', "color":"#eea638"},
{"code":"NL" , "name":"Netherlands", "value":'<?php echo $googleapps110 * 1;; ?>', "color":"#d8854f"},
{"code":"NZ" , "name":"New Zealand", "value":'<?php echo $googleapps111 * 1;; ?>', "color":"#8aabb0"},
{"code":"NI" , "name":"Nicaragua", "value":'<?php echo $googleapps112 * 1;; ?>', "color":"#a7a737"},
{"code":"NE" , "name":"Niger", "value":'<?php echo $googleapps113 * 1;; ?>', "color":"#de4c4f"},
{"code":"NG" , "name":"Nigeria", "value":'<?php echo $googleapps114 * 1;; ?>', "color":"#de4c4f"},
{"code":"NO" , "name":"Norway", "value":'<?php echo $googleapps115 * 1;; ?>', "color":"#d8854f"},
{"code":"OM" , "name":"Oman", "value":'<?php echo $googleapps116 * 1;; ?>', "color":"#eea638"},
{"code":"PK" , "name":"Pakistan", "value":'<?php echo $googleapps117 * 1;; ?>', "color":"#eea638"},
{"code":"PA" , "name":"Panama", "value":'<?php echo $googleapps118 * 1;; ?>', "color":"#a7a737"},
{"code":"PG" , "name":"Papua New Guinea", "value":'<?php echo $googleapps119 * 1;; ?>', "color":"#8aabb0"},
{"code":"PY" , "name":"Paraguay", "value":'<?php echo $googleapps120 * 1;; ?>', "color":"#86a965"},
{"code":"PE" , "name":"Peru", "value":'<?php echo $googleapps121 * 1;; ?>', "color":"#86a965"},
{"code":"PH" , "name":"Philippines", "value":'<?php echo $googleapps122 * 1;; ?>', "color":"#eea638"},
{"code":"PL" , "name":"Poland", "value":'<?php echo $googleapps123 * 1;; ?>', "color":"#d8854f"},
{"code":"PT" , "name":"Portugal", "value":'<?php echo $googleapps124 * 1;; ?>', "color":"#d8854f"},
{"code":"PR" , "name":"Puerto Rico", "value":'<?php echo $googleapps125 * 1;; ?>', "color":"#a7a737"},
{"code":"QA" , "name":"Qatar", "value":'<?php echo $googleapps126 * 1;; ?>', "color":"#eea638"},
{"code":"RO" , "name":"Romania", "value":'<?php echo $googleapps127 * 1;; ?>', "color":"#d8854f"},
{"code":"RU" , "name":"Russia", "value":'<?php echo $googleapps128 * 1;; ?>', "color":"#d8854f"},
{"code":"RW" , "name":"Rwanda", "value":'<?php echo $googleapps129 * 1;; ?>', "color":"#de4c4f"},
{"code":"SA" , "name":"Saudi Arabia", "value":'<?php echo $googleapps130 * 1;; ?>', "color":"#eea638"},
{"code":"SN" , "name":"Senegal", "value":'<?php echo $googleapps131 * 1;; ?>', "color":"#de4c4f"},
{"code":"RS" , "name":"Serbia", "value":'<?php echo $googleapps132 * 1;; ?>', "color":"#d8854f"},
{"code":"SL" , "name":"Sierra Leone", "value":'<?php echo $googleapps133 * 1;; ?>', "color":"#de4c4f"},
{"code":"SG" , "name":"Singapore", "value":'<?php echo $googleapps134 * 1;; ?>', "color":"#eea638"},
{"code":"SK" , "name":"Slovak Republic", "value":'<?php echo $googleapps135 * 1;; ?>', "color":"#d8854f"},
{"code":"SI" , "name":"Slovenia", "value":'<?php echo $googleapps136 * 1;; ?>', "color":"#d8854f"},
{"code":"SB" , "name":"Solomon Islands", "value":'<?php echo $googleapps137 * 1;; ?>', "color":"#8aabb0"},
{"code":"SO" , "name":"Somalia", "value":'<?php echo $googleapps138 * 1;; ?>', "color":"#de4c4f"},
{"code":"ZA" , "name":"South Africa", "value":'<?php echo $googleapps139 * 1;; ?>', "color":"#de4c4f"},
{"code":"ES" , "name":"Spain", "value":'<?php echo $googleapps140 * 1;; ?>', "color":"#d8854f"},
{"code":"LK" , "name":"Sri Lanka", "value":'<?php echo $googleapps141 * 1;; ?>', "color":"#eea638"},
{"code":"SD" , "name":"Sudan", "value":'<?php echo $googleapps142 * 1;; ?>', "color":"#de4c4f"},
{"code":"SR" , "name":"Suriname", "value":'<?php echo $googleapps143 * 1;; ?>', "color":"#86a965"},
{"code":"SZ" , "name":"Swaziland", "value":'<?php echo $googleapps144 * 1;; ?>', "color":"#de4c4f"},
{"code":"SE" , "name":"Sweden", "value":'<?php echo $googleapps145 * 1;; ?>', "color":"#d8854f"},
{"code":"CH" , "name":"Switzerland", "value":'<?php echo $googleapps146 * 1;; ?>', "color":"#d8854f"},
{"code":"SY" , "name":"Syria", "value":'<?php echo $googleapps147 * 1;; ?>', "color":"#eea638"},
{"code":"TW" , "name":"Taiwan", "value":'<?php echo $googleapps148 * 1;; ?>', "color":"#eea638"},
{"code":"TJ" , "name":"Tajikistan", "value":'<?php echo $googleapps149 * 1;; ?>', "color":"#eea638"},
{"code":"TZ" , "name":"Tanzania", "value":'<?php echo $googleapps150 * 1;; ?>', "color":"#de4c4f"},
{"code":"TH" , "name":"Thailand", "value":'<?php echo $googleapps151 * 1;; ?>', "color":"#eea638"},
{"code":"TG" , "name":"Togo", "value":'<?php echo $googleapps152 * 1;; ?>', "color":"#de4c4f"},
{"code":"TT" , "name":"Trinidad and Tobago", "value":'<?php echo $googleapps153 * 1;; ?>', "color":"#a7a737"},
{"code":"TN" , "name":"Tunisia", "value":'<?php echo $googleapps154 * 1;; ?>', "color":"#de4c4f"},
{"code":"TR" , "name":"Turkey", "value":'<?php echo $googleapps155 * 1;; ?>', "color":"#d8854f"},
{"code":"TM" , "name":"Turkmenistan", "value":'<?php echo $googleapps156 * 1;; ?>', "color":"#eea638"},
{"code":"UG" , "name":"Uganda", "value":'<?php echo $googleapps157 * 1;; ?>', "color":"#de4c4f"},
{"code":"UA" , "name":"Ukraine", "value":'<?php echo $googleapps158 * 1;; ?>', "color":"#d8854f"},
{"code":"AE" , "name":"United Arab Emirates", "value":'<?php echo $googleapps159 * 1;; ?>', "color":"#eea638"},
{"code":"GB" , "name":"United Kingdom", "value":'<?php echo $googleapps160 * 1;; ?>', "color":"#d8854f"},
{"code":"US" , "name":"United States", "value":'<?php echo $googleapps161 * 1;; ?>', "color":"#a7a737"},
{"code":"UY" , "name":"Uruguay", "value":'<?php echo $googleapps162 * 1;; ?>', "color":"#86a965"},
{"code":"UZ" , "name":"Uzbekistan", "value":'<?php echo $googleapps163 * 1;; ?>', "color":"#eea638"},
{"code":"VE" , "name":"Venezuela", "value":'<?php echo $googleapps164 * 1;; ?>', "color":"#86a965"},
{"code":"PS" , "name":"West Bank and Gaza", "value":'<?php echo $googleapps165 * 1;; ?>', "color":"#eea638"},
{"code":"VN" , "name":"Vietnam", "value":'<?php echo $googleapps166 * 1;; ?>', "color":"#eea638"},
{"code":"YE" , "name":"Yemen, Rep.", "value":'<?php echo $googleapps167 * 1;; ?>', "color":"#eea638"},
{"code":"ZM" , "name":"Zambia", "value":'<?php echo $googleapps168 * 1;; ?>', "color":"#de4c4f"},
{"code":"ZW" , "name":"Zimbabwe", "value":'<?php echo $googleapps169 * 1;; ?>', "color":"#de4c4f"}];


// get min and max values
var minBulletSize = 0;
var maxBulletSize = 12;
var min = Infinity;
var max = -Infinity;
for ( var i = 0; i < mapData.length; i++ ) {
  var value = mapData[ i ].value;
  if ( value < min ) {
    min = value;
  }
  if ( value > max ) {
    max = value;
  }
}

// it's better to use circle square to show difference between values, not a radius
var maxSquare = maxBulletSize * maxBulletSize * 4 * Math.PI;
var minSquare = minBulletSize * minBulletSize * 4 * Math.PI;

// create circle for each country
var images = [];
for ( var i = 0; i < mapData.length; i++ ) {
  var dataItem = mapData[ i ];
  var value = dataItem.value;
  // calculate size of a bubble
  var square = ( value - min ) / ( max - min ) * ( maxSquare - minSquare ) + minSquare;
  if ( square < minSquare ) {
    square = minSquare;
  }
  var size = Math.sqrt( square / ( Math.PI * 4 ) );
  var id = dataItem.code;

  images.push( {
    "type": "circle",
"theme": "light",

    "width": size,
    "height": size,
    "color": dataItem.color,
    "longitude": latlong[ id ].longitude,
    "latitude": latlong[ id ].latitude,
    "title": dataItem.name,
    "value": value
  } );
}

// build map
var map = AmCharts.makeChart( "chartdiv", {
  "type": "map",
  "projection": "eckert6",
  "titles": [ {
    "text": "Users country",
    "size": 14
  }, {
    "text": "Today",
    "size": 11
  } ],
  "areasSettings": {
    //"unlistedAreasColor": "#000000",
    //"unlistedAreasAlpha": 0.1
  },
  "dataProvider": {
    "map": "worldLow",
    "images": images
  },
  "export": {
    "enabled": true
  }
} );
</script>

<!-- HTML -->
<div id="chartdiv"></div>

<?php

$conn->close();

?>

