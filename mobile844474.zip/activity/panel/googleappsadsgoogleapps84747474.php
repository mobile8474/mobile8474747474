<?php

error_reporting(0);

?>

<style>

@media (min-width: 770px)
{
.googleappsappsappsappsapps84747474747474744474
{
width:396px;
}
}

</style>

<head>
<title><?php echo "GCLOUD Create ads"; ?></title>
<meta name='description' content='<?php echo "$googleapps847474744474"; ?>'>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="/<?php echo "$google847474747474747474744474"; ?>/dashboard/jquery.js"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>

<?php

include "../dashboard/dashboardtop.php";

?>

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<div style="padding:8px;box-shadow: 0 2px 4px rgba(0,0,0,0.2);margin-bottom:18px;background-color:#ffffff;box-shadow:0 1px 4px rgba(0,0,0,0.4);z-index:8888888844;border-radius:4px;margin:12px;box-sizing:border-box;">

<style>

@media screen and (min-width: 1884px)
{
html
{
zoom:1.4;
}
}

@media screen and (min-width: 2560px)
{
html
{
zoom:2;
}
}

</style>

<?php

$string_to_encrypt="$_COOKIE[username]";

$decrypted_string = "$string_to_encrypt";

?>

<?php

$string_to_encrypt8884="$_COOKIE[password]";

$decrypted_string8884 = "$string_to_encrypt8884";

?>

<?php

$string_to_encrypt="$_COOKIE[username]";

$decrypted_string = "$string_to_encrypt";

?>

<?php

$string_to_encrypt="$decrypted_string";

$decrypted_string888474 = rawurldecode($string_to_encrypt);

$password="googleappsmobileapps888888884444";

$decrypted_string8474=openssl_decrypt($decrypted_string888474,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../userregistrations.sh";

}

else

{

$dataurl8884 = "../register/userregistrations.sh";

}

?>

<?php

$decryptedstring = $_COOKIE['username'];

$file84 = file_get_contents("$dataurl8884");

preg_match_all("/<div class=\'$decryptedstring\' id=\'(.*?)\'><div class=\'(.*?)\' id=\'(.*?)\'><div class=\'(.*?)\'><div class=\'(.*?)\'>(.*?)<\/div><\/div><\/div><\/div>/s", $file84, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

$googleapps8884 = strtoupper("$name");

$googleapps888844 = "$name";

?>

<?php

if(!preg_match("/[\W\w]/",$_COOKIE['username']))

{

?>

<?php

}

?>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>

<?php

$hours = date("H");

$minutes = date("i");

$seconds = date("s");

?>

<?php

$date = date("Y-m-d");

?>

<?php

$userpagesbrowsed = $_SERVER['REQUEST_URI'];

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../userpagesbrowsed.sh";

}

else

{

$dataurl8884 = "../registrations/userpagesbrowsed.sh";

}

?>

<?php

$googleapps88888844 = "$dataurl8884";

$file_data = "<div class='$googlecookieapps8884' id='$googlecookieapps888844'><div class='$date-$hours-$minutes-$seconds'><div class='$userpagesbrowsed'>1</div></div></div>\n";
$file_data .= file_get_contents("$dataurl8884");
file_put_contents("$dataurl8884", $file_data);

echo "<div style='display:none;'>$googleapps8884</div>";

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../accountcolor8884.sh";

}

else

{

$dataurl84 = "../register/accountcolor8884.sh";

}

?>

<?php

$googleapps8884 = file_get_contents($dataurl84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleapps8884, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlapps84 = "../accountcolor88842274.sh";

}

else

{

$dataurlurlapps84 = "../register/accountcolor88842274.sh";

}

?>

<?php

$googleappsgoogleappsappsgoogleapps8884 = file_get_contents($dataurlurlapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../accountcolor8884.sh";

}

else

{

$dataurlurlgoogleapps84 = "../register/accountcolor8884.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsapps84);
$accountcolor84742274 = $googleappsappsapps84[3][0];

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsapps84);
$accountcolor847474 = $googleappsappsapps84[3][0];

?>

<div class="googleappsappsapps8474" id="google8444447474">

<div>

<div style="position:fixed;background-color:#bdbdbd;width:100%;z-index:44;height:100%;top:0px;left:0px;background:rgba(0, 0, 0, 0.4);">

<div align="center" style="margin:12px;margin-top:62px;background-color:#f1f1f1;padding:12px;box-sizing:border-box;box-shadow:0 2px 4px rgba(0,0,0,0.4);">

<div align="center" style="margin:12px;margin-top:12px;">

<form action="/<?php echo "$google847474747474747474744474"; ?>/people/adsgoogleapps84747474.php" method="post" style="margin-bottom:0px;">

<div style="position:relative;">

<input type="text" class="input8474" placeholder="Ad title" name="adsusername84747474" autocomplete="off" style="margin-bottom:8px;letter-spacing:0.4px;width:100%;box-sizing:border-box;padding:12px;border:none;font-size:14.8px;" required autofocus></input>

</div>

<input type="hidden" class="input84744474" placeholder="" value="<?php echo $countryfromip; ?>" name="countryapps8884" autocomplete="off" style="margin-bottom:8px;letter-spacing:0.4px;border:none;font-size:14.8px;"></input>

<div style="position:relative;">

<input type="text" class="inputapps1" placeholder="Ad description" name="adsusername84444474" autocomplete="off" style="margin-bottom:8px;letter-spacing:0.4px;width:100%;box-sizing:border-box;padding:12px;border:none;font-size:14.8px;" required><div style="position:absolute;top:14.8px;right:54px;font-size:13.8px;color:#424242;border:none;font-size:14.8px;"></div></input>

</div>

<div style="position:relative;">

<input type="text" class="inputapps1" placeholder="Ad url" name="adsusername84442274" autocomplete="off" style="margin-bottom:8px;letter-spacing:0.4px;width:100%;box-sizing:border-box;padding:12px;border:none;font-size:14.8px;" required><div style="position:absolute;top:14.8px;right:54px;font-size:13.8px;color:#424242;border:none;font-size:14.8px;"></div></input>

</div>

<input type="submit" class="inputapps1" placeholder="" value="CREATE" id="emailmobileapps84742274" name="adsusername84442274" autocomplete="off" style="margin-bottom:8px;letter-spacing:0.4px;width:100%;box-sizing:border-box;padding:12px;border:none;font-size:14.8px;background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;color:#ffffff;" required><div style="position:absolute;top:14.8px;right:54px;font-size:13.8px;color:#424242;border:none;font-size:14.8px;"></div></input>

</form>

<div align="left">

<div id="namemobileapps84444474" style="border:none;padding:12px;display:inline-block;padding-left:0px;cursor:pointer;" onclick="$('#google8444447474').hide();location = '/<?php echo "$google847474747474747474744474"; ?>/ads/overview.php?today=1&googleappsappsappsapps84=ads&googleapps84=0&googleapps8474=8';">

<div>

</div>

</div>



</div>



</div>

</div>

</div>

</div>

</div>

</div>

</div>

</div>

<?php

include "../dashboard/dashboardbottom.php";

?>

