<?php

error_reporting(0);

?>

<?php

$servername = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

if(preg_match("/[\W\w]/",$_GET['week']))

{

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../daysapps84747474";

}

else

{

$dataurl = "../daysapps84747474";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl");

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = $_GET['dateanalytics'];

}

?>

<?php

$googlemobileapps1 = date('Y-m-d', strtotime('today'));
$googlemobileapps2 = date('Y-m-d', strtotime('-1 day'));
$googlemobileapps3 = date('Y-m-d', strtotime('-2 day'));
$googlemobileapps4 = date('Y-m-d', strtotime('-3 day'));
$googlemobileapps5 = date('Y-m-d', strtotime('-4 day'));
$googlemobileapps6 = date('Y-m-d', strtotime('-5 day'));
$googlemobileapps7 = date('Y-m-d', strtotime('-6 day'));

$googlemobileappsapps1 = date("M d", strtotime('today'));
$googlemobileappsapps2 = date("M d", strtotime('-1 day'));
$googlemobileappsapps3 = date("M d", strtotime('-2 day'));
$googlemobileappsapps4 = date("M d", strtotime('-3 day'));
$googlemobileappsapps5 = date("M d", strtotime('-4 day'));
$googlemobileappsapps6 = date("M d", strtotime('-5 day'));
$googlemobileappsapps7 = date("M d", strtotime('-6 day'));

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps1'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$google1 = $googleapps84[2];

$query = "SELECT email,date,userip FROM daysapps84747474 WHERE email='$decrypted_string' and date='$googlemobileapps1'";
$result = $conn->query($query);

$google1 = array();

while($row = $result->fetch_array())

{

$google1[] = $row['userip'];

}

$google1 = count($google1);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps2'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$google2 = $googleapps84[2];

$query = "SELECT email,date,userip FROM daysapps84747474 WHERE email='$decrypted_string' and date='$googlemobileapps2'";
$result = $conn->query($query);

$google2 = array();

while($row = $result->fetch_array())

{

$google2[] = $row['userip'];

}

$google2 = count($google2);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps3'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$google3 = $googleapps84[2];

$query = "SELECT email,date,userip FROM daysapps84747474 WHERE email='$decrypted_string' and date='$googlemobileapps3'";
$result = $conn->query($query);

$google3 = array();

while($row = $result->fetch_array())

{

$google3[] = $row['userip'];

}

$google3 = count($google3);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps4'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$google4 = $googleapps84[2];

$query = "SELECT email,date,userip FROM daysapps84747474 WHERE email='$decrypted_string' and date='$googlemobileapps4'";
$result = $conn->query($query);

$google4 = array();

while($row = $result->fetch_array())

{

$google4[] = $row['userip'];

}

$google4 = count($google4);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps5'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$google5 = $googleapps84[2];

$query = "SELECT email,date,userip FROM daysapps84747474 WHERE email='$decrypted_string' and date='$googlemobileapps5'";
$result = $conn->query($query);

$google5 = array();

while($row = $result->fetch_array())

{

$google5[] = $row['userip'];

}

$google5 = count($google5);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps6'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$google6 = $googleapps84[2];

$query = "SELECT email,date,userip FROM daysapps84747474 WHERE email='$decrypted_string' and date='$googlemobileapps6'";
$result = $conn->query($query);

$google6 = array();

while($row = $result->fetch_array())

{

$google6[] = $row['userip'];

}

$google6 = count($google6);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps7'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$google7 = $googleapps84[2];

$query = "SELECT email,date,userip FROM daysapps84747474 WHERE email='$decrypted_string' and date='$googlemobileapps7'";
$result = $conn->query($query);

$google7 = array();

while($row = $result->fetch_array())

{

$google7[] = $row['userip'];

}

$google7 = count($google7);

$googleappsappsapps84747474 = array($google1,$google2,$google3,$google4,$google5,$google6,$google7);

$googleappsappsapps84747474 = array_sum($googleappsappsapps84747474);

?>

<?php

$googleapps84222274 = array_sum($google88888872);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../analyticschartsrealtime84";

}

else

{

$dataurl = "../analyticschartsrealtime84";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl");

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = $_GET['dateanalytics'];

}

?>

<?php

$days84744474447444744474 = date("Y-m-d");

?>

<?php

$googleapps847474 = "18";

for ($google74 = 0; $google74 <= 18; $google74++)

{

$googleapps847474--;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hours = date("H");

$unixtime = strtotime("-$googleapps847474 seconds");

$minutes = date("i",$unixtime);

$unixtime = strtotime("-$googleapps847474 seconds");

$seconds = date("s",$unixtime);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$_GET[dateanalytics]-$hours-$minutes-$seconds'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$google8884 = $googleapps84[1];

$query = "SELECT email,date,userip FROM charts84747474 WHERE email='$decrypted_string' and date REGEXP '$days84744474447444744474.*'";
$result = $conn->query($query);

$google8884 = array();

while($row = $result->fetch_array())

{

$google8884[] = $row['userip'];

}

$googleappsmobileapps8884 = array_unique($google8884);

$googleappsmobileapps8884 = count($googleappsmobileapps8884);

$google88888872[] = $googleappsmobileapps8884;

}

?>

<?php

$google847444 = $google88888872[0];

$google1 = $google88888872[1];

$google2 = $google88888872[2];

$google3 = $google88888872[3];

$google4 = $google88888872[4];

$google5 = $google88888872[5];

$google6 = $google88888872[6];

$google7 = $google88888872[7];

$google8 = $google88888872[8];

$google9 = $google88888872[9];

$google10 = $google88888872[10];

$google11 = $google88888872[11];

$google12 = $google88888872[12];

$google13 = $google88888872[13];

$google14 = $google88888872[14];

$google15 = $google88888872[15];

$google16 = $google88888872[16];

$google17 = $google88888872[17];

$google18 = $google88888872[18];

$google19 = $google88888872[19];

$google20 = $google88888872[20];

$google21 = $google88888872[21];

$google22 = $google88888872[22];

$google23 = $google88888872[23];

$google24 = $google88888872[24];

?>

<?php

$google88888872 = implode("<br>",$google88888872);

$google88888872 = explode("<br>",$google88888872);

?>

<?php

$google847444 = "-19";

?>

<style>

@media screen and (max-width: 1022px)
{
.googleapps8884
{
margin-bottom:18px;
}
}

</style>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../accountcolor8884";

}

else

{

$dataurl84 = "../register/accountcolor8884";

}

?>

<?php

$googleapps8884 = file_get_contents($dataurl84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleapps8884, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor847474))

{
}

else

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

?>

<?php

if(preg_match("/blue/",$accountcolor847474))

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/orange/",$accountcolor847474))

{

$accountcolor84747474 = "#EF6C00";

$accountcolor1 = "#EF6C00";

$accountcolor2 = "#FB8C00";

$accountcolor4 = "#FFA726";

}

if(preg_match("/yellow/",$accountcolor847474))

{

$accountcolor84747474 = "#F9A825";

$accountcolor1 = "#F9A825";

$accountcolor2 = "#FDD835";

$accountcolor4 = "#FFEE58";

}

if(preg_match("/purple/",$accountcolor847474))

{

$accountcolor84747474 = "#6A1B9A";

$accountcolor1 = "#6A1B9A";

$accountcolor2 = "#8E24AA";

$accountcolor4 = "#AB47BC";

}

if(preg_match("/pink/",$accountcolor847474))

{

$accountcolor84747474 = "#AD1457";

$accountcolor1 = "#AD1457";

$accountcolor2 = "#D81B60";

$accountcolor4 = "#EC407A";

}

?>

<?php

$prev8884 = array();

?>

<style>

.tooltip {
}

.tooltip .tooltiptext {
    visibility: hidden;
    width: 104px;
    background-color:#ffffff;
    color: #888888;
    text-align: center;
    padding: 4px 0;
    border-radius: 2px;
    position: absolute;
    z-index: 1;
top:18px;
right:18px;
}

.tooltip:hover .tooltiptext {
    visibility: visible;
}

</style>

<?php

foreach($google88888872 as $google888844)

{

$google847444++;

?>

<?php

$prev8884[] = $google888844;

?>

<?php

$hours8884 = date("s");

?>

<?php

$google847444 = str_pad($google847444, 2, "0", STR_PAD_LEFT);

?>

<?php

}

?>

<?php

if(preg_match("/0/",$prev8884[17]))

{

if(preg_match("/0/",$prev8884[16]))

{

$googleapps84747474 = "color:#bdbdbd!important";

$googleapps8474747422 = "border-color:#ebebeb!important";

}

else

{

$googleapps84747474 = "color:$accountcolor2!important";

$googleapps8474747422 = "border-color:$accountcolor1!important";

}

}

?>

<?php

$google8474 = $googleapps84222274;

?>

<style>

.googleapps84747474
{
color:#bdbdbd!important;
}

</style>

<div>

<div style="color:#bdbdbd;">

Pageviews

</div>

<div style="font-size:34px;width:100%;">

<div>

<?php echo "$googleappsappsapps84747474"; ?>

</div>

</div>

</div>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_GET['today']))

{

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../analyticscharts84";

}

else

{

$dataurl = "../analyticscharts84";

}

?>

<?php

$googleapps8884 = file_get_contents($dataurl);

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = "$_GET[dateanalytics]";

}

?>

<?php

$google84747474 = date("Y-m-d");

?>

<?php

$googleapps847474 = "-1";

$googleapps847474++;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hours = $googleapps847474;

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$google84747474-(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$google8884 = $googleapps84[2];

$googleappsmobileapps8884 = count($google8884);

$google88888872[] = $googleappsmobileapps8884;

?>

<?php

$googleapps84222274 = array_sum($google88888872);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../analyticschartsrealtime84";

}

else

{

$dataurl = "../analyticschartsrealtime84";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl");

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = $_GET['dateanalytics'];

}

?>

<?php

$days84744474447444744474 = date("Y-m-d");

?>

<?php

$googleapps847474 = "18";

$googleapps847474--;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hours = date("H");

$unixtime = strtotime("-$googleapps847474 seconds");

$minutes = date("i",$unixtime);

$unixtime = strtotime("-$googleapps847474 seconds");

$seconds = date("s",$unixtime);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$_GET[dateanalytics]-$hours-$minutes-$seconds'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$google8884 = $googleapps84[1];

$query = "SELECT email,date,userip FROM charts84747474 WHERE email='$decrypted_string' and date REGEXP '$days84744474447444744474.*'";
$result = $conn->query($query);

$google8884 = array();

while($row = $result->fetch_array())

{

$google8884[] = $row['userip'];

}

$googleappsmobileapps8884 = count($google8884);

$google88888872[] = $googleappsmobileapps8884;

?>

<?php

$google847444 = $google88888872[0];

$google1 = $google88888872[1];

$google2 = $google88888872[2];

$google3 = $google88888872[3];

$google4 = $google88888872[4];

$google5 = $google88888872[5];

$google6 = $google88888872[6];

$google7 = $google88888872[7];

$google8 = $google88888872[8];

$google9 = $google88888872[9];

$google10 = $google88888872[10];

$google11 = $google88888872[11];

$google12 = $google88888872[12];

$google13 = $google88888872[13];

$google14 = $google88888872[14];

$google15 = $google88888872[15];

$google16 = $google88888872[16];

$google17 = $google88888872[17];

$google18 = $google88888872[18];

$google19 = $google88888872[19];

$google20 = $google88888872[20];

$google21 = $google88888872[21];

$google22 = $google88888872[22];

$google23 = $google88888872[23];

$google24 = $google88888872[24];

?>

<?php

$google88888872 = implode("<br>",$google88888872);

$google88888872 = explode("<br>",$google88888872);

?>

<?php

$google847444 = "-19";

?>

<style>

@media screen and (max-width: 1022px)
{
.googleapps8884
{
margin-bottom:18px;
}
}

</style>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../accountcolor8884";

}

else

{

$dataurl84 = "../register/accountcolor8884";

}

?>

<?php

$googleapps8884 = file_get_contents($dataurl84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleapps8884, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor847474))

{
}

else

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

?>

<?php

if(preg_match("/blue/",$accountcolor847474))

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/orange/",$accountcolor847474))

{

$accountcolor84747474 = "#EF6C00";

$accountcolor1 = "#EF6C00";

$accountcolor2 = "#FB8C00";

$accountcolor4 = "#FFA726";

}

if(preg_match("/yellow/",$accountcolor847474))

{

$accountcolor84747474 = "#F9A825";

$accountcolor1 = "#F9A825";

$accountcolor2 = "#FDD835";

$accountcolor4 = "#FFEE58";

}

if(preg_match("/purple/",$accountcolor847474))

{

$accountcolor84747474 = "#6A1B9A";

$accountcolor1 = "#6A1B9A";

$accountcolor2 = "#8E24AA";

$accountcolor4 = "#AB47BC";

}

if(preg_match("/pink/",$accountcolor847474))

{

$accountcolor84747474 = "#AD1457";

$accountcolor1 = "#AD1457";

$accountcolor2 = "#D81B60";

$accountcolor4 = "#EC407A";

}

?>

<?php

$prev8884 = array();

?>

<style>

.tooltip {
}

.tooltip .tooltiptext {
    visibility: hidden;
    width: 104px;
    background-color:#ffffff;
    color: #888888;
    text-align: center;
    padding: 4px 0;
    border-radius: 2px;
    position: absolute;
    z-index: 1;
top:18px;
right:18px;
}

.tooltip:hover .tooltiptext {
    visibility: visible;
}

</style>

<?php

foreach($google88888872 as $google888844)

{

$google847444++;

?>

<?php

$prev8884[] = $google888844;

?>

<?php

$hours8884 = date("s");

?>

<?php

$google847444 = str_pad($google847444, 2, "0", STR_PAD_LEFT);

?>

<?php

}

?>

<?php

if(preg_match("/0/",$prev8884[17]))

{

if(preg_match("/0/",$prev8884[16]))

{

$googleapps84747474 = "color:#bdbdbd!important";

$googleapps8474747422 = "border-color:#ebebeb!important";

}

else

{

$googleapps84747474 = "color:$accountcolor2!important";

$googleapps8474747422 = "border-color:$accountcolor1!important";

}

}

?>

<?php

$google8474 = $googleapps84222274;

?>

<style>

.googleapps84747474
{
color:#bdbdbd!important;
}

</style>

<div>

<div style="color:#bdbdbd;">

Pageviews

</div>

<div style="font-size:34px;width:100%;">

<div>

<?php echo "$googleappsmobileapps8884"; ?>

</div>

</div>

</div>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_GET['yesterday']))

{

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../analyticscharts84";

}

else

{

$dataurl = "../analyticscharts84";

}

?>

<?php

$googleapps8884 = file_get_contents($dataurl);

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = "$_GET[dateanalytics]";

}

?>

<?php

$google84747474 = date("Y-m-d");

?>

<?php

$googleappsapps84747474 = date('Y-m-d', strtotime('-1 day'));

?>

<?php

$googleapps847474 = "-1";

$googleapps847474++;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hours = $googleapps847474;

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googleappsapps84747474-(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$google8884 = $googleapps84[2];

$query = "SELECT email,date,userip FROM charts84747474 WHERE email='$decrypted_string' and date REGEXP '$googleappsapps84747474.*'";
$result = $conn->query($query);

$google8474 = array();

while($row = $result->fetch_array())

{

$google8474[] = $row['userip'];

}

$googleappsmobileapps8884447422444474744474 = count($google8474);

$google88888872[] = $googleappsmobileapps8884;

?>

<?php

$googleapps84222274 = array_sum($google88888872);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../analyticschartsrealtime84";

}

else

{

$dataurl = "../analyticschartsrealtime84";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl");

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = $_GET['dateanalytics'];

}

?>

<?php

$googleapps847474 = "18";

for ($google74 = 0; $google74 <= 18; $google74++)

{

$googleapps847474--;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hours = date("H");

$unixtime = strtotime("-$googleapps847474 seconds");

$minutes = date("i",$unixtime);

$unixtime = strtotime("-$googleapps847474 seconds");

$seconds = date("s",$unixtime);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$_GET[dateanalytics]-$hours-$minutes-$seconds'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$google8884 = $googleapps84[1];

$googleappsmobileapps8884 = array_unique($google8884);

$googleappsmobileapps8884 = count($googleappsmobileapps8884);

$google88888872[] = $googleappsmobileapps8884;

}

?>

<?php

$google847444 = $google88888872[0];

$google1 = $google88888872[1];

$google2 = $google88888872[2];

$google3 = $google88888872[3];

$google4 = $google88888872[4];

$google5 = $google88888872[5];

$google6 = $google88888872[6];

$google7 = $google88888872[7];

$google8 = $google88888872[8];

$google9 = $google88888872[9];

$google10 = $google88888872[10];

$google11 = $google88888872[11];

$google12 = $google88888872[12];

$google13 = $google88888872[13];

$google14 = $google88888872[14];

$google15 = $google88888872[15];

$google16 = $google88888872[16];

$google17 = $google88888872[17];

$google18 = $google88888872[18];

$google19 = $google88888872[19];

$google20 = $google88888872[20];

$google21 = $google88888872[21];

$google22 = $google88888872[22];

$google23 = $google88888872[23];

$google24 = $google88888872[24];

?>

<?php

$google88888872 = implode("<br>",$google88888872);

$google88888872 = explode("<br>",$google88888872);

?>

<?php

$google847444 = "-19";

?>

<style>

@media screen and (max-width: 1022px)
{
.googleapps8884
{
margin-bottom:18px;
}
}

</style>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../accountcolor8884";

}

else

{

$dataurl84 = "../register/accountcolor8884";

}

?>

<?php

$googleapps8884 = file_get_contents($dataurl84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleapps8884, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor847474))

{
}

else

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

?>

<?php

if(preg_match("/blue/",$accountcolor847474))

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/orange/",$accountcolor847474))

{

$accountcolor84747474 = "#EF6C00";

$accountcolor1 = "#EF6C00";

$accountcolor2 = "#FB8C00";

$accountcolor4 = "#FFA726";

}

if(preg_match("/yellow/",$accountcolor847474))

{

$accountcolor84747474 = "#F9A825";

$accountcolor1 = "#F9A825";

$accountcolor2 = "#FDD835";

$accountcolor4 = "#FFEE58";

}

if(preg_match("/purple/",$accountcolor847474))

{

$accountcolor84747474 = "#6A1B9A";

$accountcolor1 = "#6A1B9A";

$accountcolor2 = "#8E24AA";

$accountcolor4 = "#AB47BC";

}

if(preg_match("/pink/",$accountcolor847474))

{

$accountcolor84747474 = "#AD1457";

$accountcolor1 = "#AD1457";

$accountcolor2 = "#D81B60";

$accountcolor4 = "#EC407A";

}

?>

<?php

$prev8884 = array();

?>

<style>

.tooltip {
}

.tooltip .tooltiptext {
    visibility: hidden;
    width: 104px;
    background-color:#ffffff;
    color: #888888;
    text-align: center;
    padding: 4px 0;
    border-radius: 2px;
    position: absolute;
    z-index: 1;
top:18px;
right:18px;
}

.tooltip:hover .tooltiptext {
    visibility: visible;
}

</style>

<?php

foreach($google88888872 as $google888844)

{

$google847444++;

?>

<?php

$prev8884[] = $google888844;

?>

<?php

$hours8884 = date("s");

?>

<?php

$google847444 = str_pad($google847444, 2, "0", STR_PAD_LEFT);

?>

<?php

}

?>

<?php

if(preg_match("/0/",$prev8884[17]))

{

if(preg_match("/0/",$prev8884[16]))

{

$googleapps84747474 = "color:#bdbdbd!important";

$googleapps8474747422 = "border-color:#ebebeb!important";

}

else

{

$googleapps84747474 = "color:$accountcolor2!important";

$googleapps8474747422 = "border-color:$accountcolor1!important";

}

}

?>

<?php

$google8474 = $googleapps84222274;

?>

<style>

.googleapps84747474
{
color:#bdbdbd!important;
}

</style>

<div>

<div style="color:#bdbdbd;">

Pageviews

</div>

<div style="font-size:34px;width:100%;">

<div>

<?php echo "$googleappsmobileapps8884447422444474744474"; ?>

</div>

</div>

</div>

<?php

}

?>

<?php

$conn->close();

?>

