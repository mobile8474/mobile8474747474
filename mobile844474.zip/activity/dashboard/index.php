<head>
<title><?php echo "$google84747474 $googleappsappsapps84747474"; ?></title>
<meta name='description' content='<?php echo "$google8884 $googleappsappsapps84747474"; ?>'>
<meta name='robots' content='index,follow'>
<meta name='keywords' content=''>
<meta name='viewport' content='width=device-width, initial-scale=1.0'/>
<script src="/dashboard/jquery.js"></script>
<link href="https://fonts.googleapis.com/css?family=Roboto:400" rel="stylesheet">
<script src="/dashboard/chart.js"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>

<style>

html,body
{
margin:0px;
padding:0px;
}

</style>

<style>

*
{
font-family:'Roboto',sans-serif;
}

</style>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "$isocode8884");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

$servername8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn84747474 = new mysqli($servername8474747444444474, $username8474747444444474, $password8474747444444474, $dbname8474747444444474);

?>

<div style="padding:12px;background-color:#42A5F5;">

<div style="display:flex;">

<div>

<i class="material-icons" style="color:#ffffff;cursor:pointer;" onclick="window.open('/','_self');">arrow_back</i>

</div>

<div style="position:absolute;right:12px;">

<i class="material-icons" style="color:#ffffff;">more_vert</i>

</div>

</div>

</div>

<div>
</div>

<div style="display:flex;justify-content:space-between;">

<div id="minutesappsgoogleappsappsappsapps1" style="position:relative;display:inline-block;margin:12px;padding:12px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.4);border-radius:4px;width:100%;"></div>

<script>

$(document).ready(function(){

$("#minutesappsgoogleappsappsappsapps1").load('pageviews.php?today=<?php echo "1"; ?>');

}

);

</script>

<div id="minutesappsgoogleappsappsappsapps84747474" style="position:relative;display:inline-block;margin:12px;padding:12px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.4);border-radius:4px;width:100%;"></div>

<script>

$(document).ready(function(){

$("#minutesappsgoogleappsappsappsapps84747474").load('bouncerate.php?today=<?php echo "1"; ?>');

}

);

</script>

</div>

<div style="display:flex;justify-content:space-between;">

<div id="minutesappsgoogleappsappsappsapps847474744474" style="position:relative;display:inline-block;margin:12px;padding:12px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.4);border-radius:4px;width:100%;"></div>

<script>

$(document).ready(function(){

$("#minutesappsgoogleappsappsappsapps847474744474").load('timeonsite.php?today=<?php echo "1"; ?>');

}

);

</script>

</div>
