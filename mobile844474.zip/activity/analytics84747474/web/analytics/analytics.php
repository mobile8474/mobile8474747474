<?php

header('Content-type: application/javascript');

?>

<?php

$google8444444444744474447444744474 = strtolower($_SERVER['HTTP_USER_AGENT']);

if(preg_match("/bot|spider|crawler|appengine/","$google8444444444744474447444744474"))

{
}

else

{

?>

<?php

if(preg_match("/[\W\w]/",$_GET['country']))

{

?>

<?php

$servername = preg_replace("/\s+/","",file_get_contents("../../../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../../../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../../../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../../../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

if(preg_match("/[\W\w]/","googleapps84"))

{

?>

<?php

$googlemobileapps84747474 = "user";

?>

<?php

if(preg_match("/[\W\w]/",$_COOKIE['analytics']))

{
}

else

{

?>

<?php

if(strpos($_SERVER['HTTP_USER_AGENT'], 'Firefox') !== FALSE)
   $googleapps84224474 = 'Mozilla Firefox';
elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'Opera') !== FALSE)
   $googleapps84224474 = "Opera";
elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'OPR') !== FALSE)
   $googleapps84224474 = "Opera";
elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'Chrome') !== FALSE)
   $googleapps84224474 = 'Google Chrome';
 elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mini') !== FALSE)
   $googleapps84224474 = "Opera Mini";
 elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'Safari') !== FALSE)
   $googleapps84224474 = "Safari";

?>

<?php

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $google84747474 = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $google84747474 = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $google84747474 = $_SERVER['REMOTE_ADDR'];
}

?>

<?php

$ip = "$google84747474";

?>

<?php

$ip84747474 = $ip;

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $_GET['country']);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

$hours = date("H");

$minutes = date("i");

$seconds = date("s");

?>

<?php

$date = date("Y-m-d");

$datehoursapps84747474 = date("Y-m-d-H");

?>

<?php

$username = $_GET['username'];

$username = rawurlencode($username);

?>

<?php

$password = $_GET['password'];

$password = rawurlencode($password);

?>

<?php

$requesturl = $_SERVER['HTTP_REFERER'];

?>

<?php

$requesturl84747474 = $_GET['referer'];

$googlemobileappsapps84747474 = $_GET['referer'];

$googlemobileappsapps84747474 = rawurldecode($googlemobileappsapps84747474);

$googlemobileappsappsapps84747474 = $_SERVER['HTTP_USER_AGENT'];

?>

<?php

$countryapps8884 = "$countryfromip";

?>

<?php

$time8884 = $_GET['timeonsite'];

if(preg_match("/[\W\w]/",$time8884))

{

?>

<?php

$sql = "INSERT INTO timeonsiteapps84747474 (email,date,timeonsite,userip)
VALUES ('$username','$date','$time8884','$ip84747474')";

?>

<?php

}

else

{

?>

<?php

$userip8884 = $ip;

?>

<?php

$sql2 = "INSERT INTO analyticscharts84 (email,date,userip)
VALUES ('$username','$date-$hours','$userip8884')";

?>

<?php

$sql4 = "INSERT INTO analyticschartsgoogle84747474 (email,date,referer,userip)
VALUES ('$username','$datehoursapps84747474','$googlemobileappsapps84747474','$userip8884')";

?>

<?php

$googleappsappsapps84747474 = $_GET['keywordsapps8474'];

$googleappsappsapps84747474 = str_replace("-"," ",$googleappsappsapps84747474);

$googleappsappsapps84747474 = str_replace("+"," ",$googleappsappsapps84747474);

$googleappsappsapps84747474 = str_replace("?","",$googleappsappsapps84747474);

$googleappsappsapps84747474 = rawurldecode($googleappsappsapps84747474);

?>

<?php

$userip8884 = $ip;

?>

<?php

$sql12 = "INSERT INTO charts84747474 (email,date,userip,browser,referer,user,page,keywords)
VALUES ('$username','$date-$hours-$minutes-$seconds','$userip8884','$googleapps84224474','$googlemobileappsapps84747474','$googlemobileappsappsapps84747474','$requesturl','$googleappsappsapps84747474')";

?>

<?php

$userip8884 = $ip;

?>

<?php

if(preg_match("/[\W\w]/",$_GET['useractions8884']))

{

?>

<?php

$sql24 = "INSERT INTO analyticschartsapps84 (email,date,userip,browser,referer,user,page,keywords)
VALUES ('$username','$date-$hours-$minutes-$seconds','$userip8884','$googleapps84224474','$googlemobileappsapps84747474','$googlemobileappsappsapps84747474','$requesturl','$googleappsappsapps84747474')";

?>

<?php

}

?>

<?php

$date84747474 = date("Y-m-d");
$nameOfDay = date('D', strtotime($date));

$date84442274 = date("Y-m-d");

?>

<?php

$sql28 = "INSERT INTO monthsapps84747474 (email,date,day,userip)
VALUES ('$username','$date84442274','$nameOfDay','$userip8884')";

?>

<?php

$date84747474 = date("Y-m-d");
$nameOfDay84747474 = date('M', strtotime($date));

?>

<?php

$sql34 = "INSERT INTO daysapps84747474 (email,date,day,userip)
VALUES ('$username','$date84442274','$nameOfDay84747474','$userip8884')";

?>

<?php

$json_string = "http://www.geoplugin.net/json.gp?ip=$userip8884";

$jsondata = file_get_contents($json_string);

$jsondata = json_decode($jsondata, true);

$jsondata84747474 = $jsondata['geoplugin_countryName'];

?>

<?php

$date84442274444474447444744474 = date("Y-m-d-H-i-s");

$sql84744474447444744474 = "INSERT INTO countryusersapps84747474 (email,date,country,userip)
VALUES ('$username','$date84442274444474447444744474','$jsondata84747474','$userip8884')";

?>

<?php

}

?>

<?php

$googleapps84747474 = mysqli_query($conn,$sql84744474447444744474);

echo "$googleapps84747474";

$googleapps84747474 = mysqli_query($conn,$sql);

echo "$googleapps84747474";

$googleapps84747474 = mysqli_query($conn,$sql1);

echo "$googleapps84747474";

$googleapps84747474 = mysqli_query($conn,$sql2);

echo "$googleapps84747474";

$googleapps84747474 = mysqli_query($conn,$sql4);

echo "$googleapps84747474";

$googleapps84747474 = mysqli_query($conn,$sql12);

echo "$googleapps84747474";

$googleapps84747474 = mysqli_query($conn,$sql24);

echo "$googleapps84747474";

$googleapps84747474 = mysqli_query($conn,$sql28);

echo "$googleapps84747474";

$googleapps84747474 = mysqli_query($conn,$sql34);

echo "$googleapps84747474";

?>

<?php

}

?>

<?php

}

?>

<?php

$conn->close();

?>

<?php

if(preg_match("/(bot|Bot|crawler|Crawler|spider|Spider)/","$googleapps84747474"))

{
}

else

{

?>

<?php

if(preg_match("/www48|www12/",$_SERVER['HTTP_REFERER']))

{
}

else

{

?>

<?php

}

?>

<?php

}

?>

<?php

}

?>

<?php

}

?>

