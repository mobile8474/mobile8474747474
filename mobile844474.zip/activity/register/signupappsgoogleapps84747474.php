<head>
<title>Bluecloud</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<meta name="description" content='<?php echo ""; ?>'>

<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<script type="text/javascript" src="/dashboard/jquery.js"></script>

<link rel="icon" type="image/png" href="/people/googleapps84.png">

</head>

<style>

html,body
{
margin:0px;
padding:0px;
font-family:Varela Round, sans-serif;
background-color:#ECEFF1!important;
}

</style>

<div align="center">

<div style="padding:14px;background-color:#1565C0;color:#ffffff;box-sizing:border-box;cursor:pointer;font-weight:bold;" onclick="window.open('/','_self');">

Bluecloud

</div>

<div style="padding-top:44px;font-size:14.8px;font-weight:bold;">

Enter email

</div>

<div>
</div>

<div class="googleappsmobileappsinstallapps8444" style="box-sizing:border-box;margin-top:12px;margin:12px;">

<div class="googleapps1">

<form action="/people/pageupdates84447474.php" method="post" enctype="multipart/form-data" id="googleapps84744474" style="margin-bottom:0px;">

<input type="hidden" name="q" value="<?php echo "$googleapps84"; ?>"></input>

<input type="email" class="inputapps1" placeholder="Email" value="" id="email" style="padding:8.6px;width:100%;box-sizing:border-box;font-size:14.6px;border-radius:4px;border-style:solid;border-width:1px;border-color:#bdbdbd;outline-style:none;padding:10px;" name="email" autocomplete="off"></div></input>

<div class="googleappsappsapps84747474" style="padding-top:12px;font-size:14.8px;font-weight:bold;display:none;">

Enter password

</div>

<input type="password" class="googleappsappsapps84747474" placeholder="Password" value="" id="password" name="pword" autocomplete="off" style="padding:8.6px;width:100%;box-sizing:border-box;margin-top:12px;display:none;font-size:14.6px;border-radius:4px;border-style:solid;border-width:1px;border-color:#bdbdbd;outline-style:none;padding:10px;"></input>

</form>

</div>

</div>

<div style="padding:12px;background-color:#1565C0;color:#ffffff;text-align:center;margin:12px;border-radius:4px;font-weight:bold;cursor:pointer;" onclick="$('.googleappsappsapps84747474').show();$(this).hide();$('.loginapps84747474').show();">

LOGIN

</div>

<div class="loginapps84747474" style="padding:12px;background-color:#1565C0;color:#ffffff;text-align:center;margin:12px;display:none;border-radius:4px;font-weight:bold;cursor:pointer;" onclick="$('.googleappsappsapps84747474').show();$('#googleapps84744474').submit();">

LOGIN

</div>

<div style="color:#444444;text-align:center;margin:12px;">

or

</div>

<div align="center">

<div style="padding:12px;background-color:#444444;color:#ffffff;text-align:center;margin:12px;cursor:pointer;border-radius:4px;font-weight:bold;display:inline-block;padding-left:44px;padding-right:44px;margin-top:0px;" onclick="window.open('/register/signupapps84747474.php','_self');">

CREATE

</div>

</div>

</div>

<?php

if(preg_match("/[\W\w]/",$_COOKIE['username']))

{

?>

<?php

$string_to_encrypt = $_COOKIE['username'];

$decrypted_string888474 = rawurldecode($string_to_encrypt);

$password = "googleappsmobileapps888888884444";

$decrypted_string8474 = openssl_decrypt($decrypted_string888474,"AES-128-ECB",$password);

?>

<script>

setTimeout(function()

{

window.location = '/people/usermail.php?useremail=<?php echo "$decrypted_string8474"; ?>';

}, 884);

</script>

<?php

}

?>

<footer8474 id="footer84747474">

<div class="mui-container-fluid">

<div style="color:#222222!important;font-size:12.8px;z-index:44;left:12px;bottom:12px;position:fixed;width:100%;padding:12px;background-color:#ffffff;bottom:0px;left:0px;box-sizing:border-box;z-index:88888844;">

&copy; <?php echo date('Y',time()); ?> Bluecloud

<div style="position:absolute;right:12px;padding:12px;bottom:56px;background-color:#ffffff;width:156px;box-shadow:0 2px 4px rgba(0,0,0,0.4);">Find any malware or think this website is a phishing website, or any thing else report it</div>

<div style="float:right;cursor:pointer;" onclick="$('.googleappsapps847474744474447444744474').show();">Report this Website</div>

<center>

<div class="googleappsapps847474744474447444744474" style="position:fixed;padding:12px;top:12%;display:none;background-color:#ffffff;margin:0 auto;width:146px;left:12px;right:12px;box-shadow:0 2px 4px rgba(0,0,0,0.4);" onclick="$('.googleappsapps847474744474447444744474').hide();">Thank you, this website has been reported</div>

</center>

</div>

</div>

</footer8474>

<script>

var googleappsapps84747474 = location.protocol

var url84747474 = document.referrer;

var google84747474 = location.href;
var google84444474 = google84747474.substring(google84747474.indexOf('?')+1);

var script = document.createElement('script');
script.src = '' + googleappsapps84747474 + '//mobileapps847444744474.eu-gb.mybluemix.net/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&country=ZA&referer=' + url84747474 + '&keywordsapps8474=' + google84444474 + '';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

var time,timeSite;

time=new Date();

window.onbeforeunload=function(){
timeSite=new Date()-time;
window.localStorage['timeSite']=timeSite;

var url84747474 = document.referrer;

var script = document.createElement('script');
script.src = '' + googleappsapps84747474 + '//mobileapps847444744474.eu-gb.mybluemix.net/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&country=ZA&timeonsite=' + timeSite + '';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

}

var list84747474 = document.getElementsByTagName('html')[0];

window.addEventListener('backbutton', function(){

var script = document.createElement('script');
script.src = '' + googleappsapps84747474 + '//mobileapps847444744474.eu-gb.mybluemix.net/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&useractions8884=googleapps84&country=ZA';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

});

window.addEventListener('scroll', function(){

var script = document.createElement('script');
script.src = '' + googleappsapps84747474 + '//mobileapps847444744474.eu-gb.mybluemix.net/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&useractions8884=googleapps84&country=ZA';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

});

</script>

