<!DOCTYPE html>

<head>
<title>Bluecloud ads</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="/dashboard/jquery.js" type="text/javascript"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>

<div align="center">

<div style="padding:14px;background-color:#1565C0;color:#ffffff;box-sizing:border-box;cursor:pointer;font-weight:bold;" onclick="window.open('/','_self');">

Bluecloud ads

</div>

<div>
</div>

</div>

<style>

html,body
{
margin:0px;
padding:0px;
font-family:Varela Round, sans-serif;
background-color:#ECEFF1!important;
}

</style>

<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<title>Getit register</title>
<style>
* {
  box-sizing: border-box;
}

body {
}

#regForm {
  padding:12px;
}

h1 {
  text-align: center;  
}

input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
}

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
}

button {
  background-color: #1565C0;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  font-size: 17px;
  font-family: Raleway;
  cursor: pointer;
}

button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #bbbbbb;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;  
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #1565C0;
}

.googleapps84747474
{
display:flex;
}

</style>
<body>

<form id="regForm" action="/people/pageupdates84747474.php" enctype="multipart/form-data" method="post">
<!-- One "tab" for each step in the form: -->

<div class="tab">

<div class="googleapps84747474">

</div>

</div>  

<div class="tab">

<div style="text-align:center;font-weight:bold;padding-bottom:12px;">What is your email</div>

<div style="text-align:center;font-size:12.8px;color:#444444;padding-bottom:12px;">Enter your email</div>

<div class="googleapps84747474">

<input type="email" placeholder="E-mail..." oninput="this.className = ''" name="email" required>

</div>

</div>

<div class="tab">

<div class="googleapps84747474">

</div>

</div>
<div class="tab">

<div style="text-align:center;font-weight:bold;padding-bottom:12px;padding-top:12px;">Choose a username</div>

<div style="text-align:center;font-size:12.8px;color:#444444;padding-bottom:12px;">Enter a username and password</div>

<div class="googleapps84747474">

<?php

if(preg_match("/[\W\w]/",$_GET['googleapps84']))

{

?>

<input type="hidden" name="googleapps84" value="googleapps84">

<?php

}

?>

<input placeholder="Username..." oninput="this.className = ''" name="uname" required>
<input placeholder="Password..." oninput="this.className = ''" name="pword" type="password" style="margin-left:12px;" required>

<input type="file" name="image" id="googleimageappsmobileappsappsappsappsappsapps84" style="display:none;" required>

</div>

</div>

<div>

<div class="googleappsappsappsappsapps84222274" style="font-size:12.8px;">

<div style="display:flex;">

<div id="googleappsappsappsappsappsappsapps844444444474" onclick="document.getElementById('googleimageappsmobileappsappsappsappsappsapps84').click();" style="padding:12px;background-color:#444444;display:inline-block;margin-top:12px;color:#ffffff;cursor:pointer;">

Set account image

</div>

<div>

<div class='googleappsappsappsappsapps8474447444744474' style="color:#ffffff;font-size:14.6px;color:#444444;padding:12px;">required</div>

</div>

</div>

</div>

</div>

</div>

<input type="submit" value="REGISTER" style="padding:12px;background-color:#444444;color:#ffffff;margin-top:12px;"></input>

</div>

</form>

</body>
</html>

<script>

$(document).ready(function(){

$('#googleimageappsmobileappsappsappsappsappsapps84').on('change', function() {

var google8474447444744474 = $('#googleimageappsmobileappsappsappsappsappsapps84').val();

$(".googleappsappsappsappsapps8474447444744474").text('success');

});

});

</script>

