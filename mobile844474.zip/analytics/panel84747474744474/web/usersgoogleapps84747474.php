<?php

$countryapps8884 = $_COOKIE['country'];

$servername84747474444444744474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps84.sh"));
$username84747474444444744474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps1.sh"));
$password84747474444444744474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps2.sh"));
$dbname84747474444444744474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps4.sh"));

$conn84747474 = new mysqli($servername84747474444444744474, $username84747474444444744474, $password84747474444444744474, $dbname84747474444444744474);

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "$isocode8884");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../analyticschartsrealtime84";

}

else

{

$dataurl = "../analyticschartsrealtime84";

}

?>

<?php

$googleapps8884 = file_get_contents($dataurl);

?>

<?php

$google847474744474 = date("Y-m-d");

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>1<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google8884 = $googleapps84[11];

$google847474744474447444744474 = $_COOKIE['username'];

$google8884 = array();

$query = "SELECT email,date,referer FROM charts84747474 WHERE email='$google847474744474447444744474' and date REGEXP '$google847474744474.*' order by date desc";

$result = mysqli_query($conn84747474,$query);

foreach($result as $row)

{

$google8884[] = $row['referer'];

}

$google8884 = array_filter($google8884);

$google8884 = implode("<br>",$google8884);

$google8884 = explode("<br>",$google8884);

?>

<?php

?>

<?php

$googleapps847474744474 = array();

$googleappsgoogleapps847474744474 = array();

foreach($google8884 as $googleappsapps84747474)

{

$url = "$googleappsapps84747474";
$parse = parse_url($url);

$googleapps847474744474[] = $googleappsapps84747474;

$googleappsgoogleapps847474744474[] = $googleappsapps84747474;

}

?>

<?php

$googleapps847474744474 = array_filter($googleapps847474744474);

$googleapps847474744474  = preg_grep('/^https:\/\/(.*?)yandex.(.*?)\/$|^https:\/\/(.*?)yandex.com.tr\/(.*?)|^http:\/\/(.*?)yandex.(.*?)\/$|^http:\/\/(.*?)yandex.com.tr\/(.*?)|^https:\/\/(.*?)google.(.*?)\/(.*?)|^http:\/\/(.*?)google.(.*?)\/(.*?)|^https:\/\/(.*?)duckduckgo.(.*?)\/(.*?)|^http:\/\/(.*?)duckduckgo.(.*?)\/(.*?)|^https:\/\/(.*?)yahoo.(.*?)\/(.*?)|^http:\/\/(.*?)yahoo.(.*?)\/(.*?)|^http:\/\/(.*?)boomle.(.*?)\/(.*?)|^https:\/\/(.*?)boomle.(.*?)\/(.*?)|^https:\/\/(.*?)mail.ru\/(.*?)|^http:\/\/(.*?)mail.ru\/(.*?)|^https:\/\/(.*?)yandex.ru\/$|^http:\/\/(.*?)yandex.ru\/$|^android-app:\/\/|^https:\/\/(.*?)aol.(.*?)\/(.*?)|^http:\/\/(.*?)aol.(.*?)\/(.*?)|mail.(.*?)|^http:\/\/(.*?)yaani.(.*?)\/(.*?)|^https:\/\/(.*?)yaani.(.*?)\/(.*?)|^http:\/\/(.*?)text.(.*?)\/(.*?)|^https:\/\/(.*?)text.(.*?)\/(.*?)|^http:\/\/(.*?)monstercrawler.(.*?)\/(.*?)|^https:\/\/(.*?)monstercrawler.(.*?)\/(.*?)/', $googleapps847474744474);

$googleapps847474744474 = array_count_values($googleapps847474744474);

$googleappsgooglegooglegooglegoogleapps847474744474 = array_filter($googleappsgooglegooglegooglegoogleapps847474744474);

$googleappsgooglegooglegooglegoogleapps847474744474  = preg_grep('/^https:\/\/(.*?)yandex.(.*?)\/$|^https:\/\/(.*?)yandex.com.tr\/(.*?)|^http:\/\/(.*?)yandex.(.*?)\/$|^http:\/\/(.*?)yandex.com.tr\/(.*?)|^https:\/\/(.*?)google.(.*?)\/(.*?)|^http:\/\/(.*?)google.(.*?)\/(.*?)|^https:\/\/(.*?)duckduckgo.(.*?)\/(.*?)|^http:\/\/(.*?)duckduckgo.(.*?)\/(.*?)|^https:\/\/(.*?)yahoo.(.*?)\/(.*?)|^http:\/\/(.*?)yahoo.(.*?)\/(.*?)|^http:\/\/(.*?)boomle.(.*?)\/(.*?)|^https:\/\/(.*?)boomle.(.*?)\/(.*?)|^https:\/\/(.*?)mail.ru\/(.*?)|^http:\/\/(.*?)mail.ru\/(.*?)|^https:\/\/(.*?)yandex.ru\/$|^http:\/\/(.*?)yandex.ru\/$|^android-app:\/\/|^https:\/\/(.*?)aol.(.*?)\/(.*?)|^http:\/\/(.*?)aol.(.*?)\/(.*?)|mail.(.*?)|^http:\/\/(.*?)yaani.(.*?)\/(.*?)|^https:\/\/(.*?)yaani.(.*?)\/(.*?)|^http:\/\/(.*?)text.(.*?)\/(.*?)|^https:\/\/(.*?)text.(.*?)\/(.*?)|^http:\/\/(.*?)monstercrawler.(.*?)\/(.*?)|^https:\/\/(.*?)monstercrawler.(.*?)\/(.*?)/', $googleappsgoogleapps847474744474);

$googleappsgooglegooglegooglegoogleapps847474744474 = array_count_values($googleappsgooglegooglegooglegoogleapps847474744474);

$googleapps847474744474 = implode("<br>",$googleapps847474744474);

$googleapps847474744474 = explode("<br>",$googleapps847474744474);

$googleappsgoogleapps847474744474 = implode("<br>",$googleappsgoogleapps847474744474);

$googleappsgoogleapps847474744474 = explode("<br>",$googleappsgoogleapps847474744474);

$google847474444444444474 = array_keys($googleappsgooglegooglegooglegoogleapps847474744474);

?>

<?php

$google8474747444744474 = "0";

$googleappsappsappsapps8474747444744474 = "-1";

$googleappsappsappsappsappsapps8474747444744474 = array();

$googleappsapps84747474 = array();

foreach($googleapps847474744474 as $googleapps84222274 => $google84747474)

{

$googleappsappsappsappsappsapps8474747444744474[] = "$google84747474";

}

?>

<?php

foreach($googleapps847474744474 as $googleapps84222274 => $google84747474)

{

$google8474747444744474++;

$googleappsappsappsapps8474747444744474++;

$googleappsgooglegoogleapps84747474 = $googleappsgoogleapps847474744474[$googleapps84222274];

$googleappsappsappsapps84744474447444744474 = rawurldecode($google847474444444444474[$googleappsappsappsapps8474747444744474]);

if(preg_match("/[\W\w]/","$googleappsappsappsapps84744474447444744474"))

{

$googleappsapps84747474[] = "$google84747474";

}

}

?>

<?php

$googleapps84 = array_sum($googleappsapps84747474);

$googleapps84 = number_format($googleapps84, 2,'.', ',');

echo "<div style='padding:4px;color:#ffffff;background-color:#$_GET[accountcolorapps84747474];border-radius:4px;display:inline-block;margin-bottom:8px;position:absolute;right:12px;margin-top:14px;box-shadow:0 1px 4px rgba(0,0,0,0.4);'>" . "$" . $googleapps84 . "</div>";

?>

<?php

$conn84747474->close();

?>
