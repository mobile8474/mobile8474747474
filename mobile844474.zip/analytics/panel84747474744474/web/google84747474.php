<?php

$servername = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

?>

<?php

$google8474224474747474 = $_GET['accountcolorapps84747474'];

$google847422447474747444744474 = $_GET['accountcolorapps847474744474'];

?>

<?php

if(preg_match("/[\W\w]/",$_GET['today']))

{

?>

<?php

$google847474744474 = date("Y-m-d-H-i");

?>

<?php

$google847474744474447444744474 = $_COOKIE['username'];

$google8884 = array();

$query = "SELECT email,date,page,userip FROM charts84747474 WHERE email='$google847474744474447444744474' and date '$google847474744474.*' order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$google8884[] = $row['date'];

}

$google8884 = array_filter($google8884);

$google8884 = implode("<br>",$google8884);

$google8884 = explode("<br>",$google8884);

?>

<?php

?>

<?php

$googleapps847474744474 = array();

$googleappsgoogleapps847474744474 = array();

foreach($google8884 as $googleappsapps84747474)

{

$url = "$googleappsapps84747474";
$parse = parse_url($url);

$googleapps847474744474[] = $googleappsapps84747474;

$googleappsgoogleapps847474744474[] = $googleappsapps84747474;

}

?>

<?php

$googleapps847474744474 = array_filter($googleapps847474744474);

$googleapps847474744474 = array_count_values($googleapps847474744474);

$googleappsgooglegooglegooglegoogleapps847474744474 = array_filter($googleappsgooglegooglegooglegoogleapps847474744474);

$googleappsgooglegooglegooglegoogleapps847474744474 = array_count_values($googleappsgoogleapps847474744474);

$googleapps847474744474 = implode("<br>",$googleapps847474744474);

$googleapps847474744474 = explode("<br>",$googleapps847474744474);

$googleappsgoogleapps847474744474 = implode("<br>",$googleappsgoogleapps847474744474);

$googleappsgoogleapps847474744474 = explode("<br>",$googleappsgoogleapps847474744474);

$google847474444444444474 = array_keys($googleappsgooglegooglegooglegoogleapps847474744474);

?>

<?php

$google84747474747444744474 = array();

$google8474747474744474 = array();

$google8474747444744474 = "0";

$googleappsappsappsapps8474747444744474 = "-1";

$googleappsappsappsappsappsapps8474747444744474 = array();

foreach($googleapps847474744474 as $googleapps84222274 => $google84747474)

{

$googleappsappsappsappsappsapps8474747444744474[] = "$google84747474";

}

?>

<?php

foreach($googleapps847474744474 as $googleapps84222274 => $google84747474)

{

$google8474747444744474++;

$googleappsappsappsapps8474747444744474++;

$googleappsgooglegoogleapps84747474 = $googleappsgoogleapps847474744474[$googleapps84222274];

$googleappsappsappsapps84744474447444744474 = rawurldecode($google847474444444444474[$googleappsappsappsapps8474747444744474]);

if(preg_match("/[\W\w]/","googleapps84"))

{

?>

<?php

}

$google8474747474744474[] = "$google8474747444744474";

$google84747474747444744474[] = "$google84747474";

}

?>

<?php

$google847474744444444444447444744444444474 = array_reverse($google8474747474744474);

$google84747474444444444444744474 = array_reverse($google84747474747444744474);

$google847474744444444444447444744444444474 = implode(",",$google847474744444444444447444744444444474);

$google847474744444444444447444744444444474 = preg_replace("/\s+/","",$google847474744444444444447444744444444474);

$google84747474444444444444744474 = implode(",",$google84747474444444444444744474);

?>

<div>

<canvas id="canvas" width="600" height="300" style="background-color:#fff"></canvas>

</div>

<script>

var draw = Chart.controllers.line.prototype.draw;
Chart.controllers.line = Chart.controllers.line.extend({
    draw: function() {
        draw.apply(this, arguments);
        var ctx = this.chart.chart.ctx;
        var _stroke = ctx.stroke;
        ctx.stroke = function() {
            ctx.save();
            ctx.shadowColor = '#bdbdbd';
            ctx.shadowBlur = 8;
            ctx.shadowOffsetX = 0;
            ctx.shadowOffsetY = 12;
            _stroke.apply(this, arguments)
            ctx.restore();
        }
    }
});

var ctx = document.getElementById("canvas").getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: [<?php echo "$google847474744444444444447444744444444474"; ?>],
        datasets: [{
            label: "USERS",
            data: [<?php echo "$google84747474444444444444744474"; ?>],
            borderColor: '<?php echo "#" . $google8474224474747474; ?>',
            pointBackgroundColor: "#fff",
            pointBorderColor: '<?php echo "#" . $google8474224474747474; ?>',
            pointHoverBackgroundColor: '<?php echo "#" . $google8474224474747474; ?>',
            pointHoverBorderColor: "#fff",
            pointRadius: 4,
            pointHoverRadius: 4,
            fill: true,
            fillColor: '<?php echo "#" . $google8474224474747474; ?>',
            backgroundColor: '<?php echo "#" . $google8474224474747474; ?>',
}],
    },

options: {

animation: false,

scales: {
      yAxes: [{
       ticks: {
                    beginAtZero: true,

},

}],

},

},

});

</script>

<?php

}

?>

<?php

$conn->close();

?>

