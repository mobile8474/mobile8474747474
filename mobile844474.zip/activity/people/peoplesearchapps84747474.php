<?php

error_reporting(0);

?>

<head>
<title><?php echo "$title8884"; ?></title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="/dashboard/jquery.js" type="text/javascript"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>

<div style="width:100%;">

<form action="/people/peoplesearchapps84747474.php" method="get" enctype="multipart/form-data" id="googlegooglegooglegoogleappsappsappsapps84747474" style="display:inline-grid;width:100%;">

<div class="googleuserappsappsapps84747474 googleappsappsappsapps84747474" style="display:none;z-index:88888844;">

<input type="text" name="q" id="googleappsappsappsappsapps847474744474" class="googleuserappsappsapps84747474 googleapps84747474 googleappsapps84444444447444224474" value="" autocomplete="off" placeholder="search for people..." style="width:100%;padding:17.6px;font-size:17.6px;border:none;z-index:10884;outline-style:none;padding-top:16.8px;padding-bottom:16.8px;padding-left:58px;" onclick="$('.google88884444444444447474').show();$('.googleappsappsapps844444224474').css('z-index', '34');$('.google84224422444474').css('z-index', '34');$('.googleappsappsappsgooglegoogleappsappsapps84444474').css('z-index', '34');$('.googleappsapps8422442244224474').css('z-index', '34');" onkeyup="doDelayedSearch(this.value);"></input>

<i class='material-icons googleappsappsappsapps8444444444447474' style='font-size:28px;position:absolute;top:12.8px;left:12px;z-index:884;color:#bdbdbd;'>search</i>

<i class='material-icons googleappsappsappsapps8444444444447474' style='font-size:34px;position:absolute;top:10px;right:12px;z-index:884;color:#bdbdbd;' onclick="$('.googleuserappsappsapps84747474.googleappsappsappsapps84747474').hide();$('#pageviewsappsappsapps84747474').hide();$('.google88884444444444447474').hide();">keyboard_arrow_left</i>

</div>

<div style="position:relative;z-index:88884">

<input type="text" name="q" id="googleappsappsappsappsapps847474744474" class="googleuserappsappsapps84747474 googleappsapps84747474 googleappsapps844444444474442244744474" value="" autocomplete="off" placeholder="search for people..." style="width:100%;padding:17.6px;font-size:17.6px;border:none;z-index:10884;outline-style:none;background-color:#ffffff;border-radius:4px;" onclick="$('.google8888444444444474').show();$('.googleappsappsapps844444224474').css('z-index', '34');$('.google84224422444474').css('z-index', '34');$('.googleappsappsappsgooglegoogleappsappsapps84444474').css('z-index', '34');$('.googleappsapps8422442244224474').css('z-index', '34');$('#googleappsappsappsgoogleapps84444474').css('z-index', '8884');$('#googleappsappsappsappsapps84444474').css('z-index', '8884');$('#googleappsappsappsappsappsappsappsappsapps84444474').css('z-index', '8884');$(this).css('z-index', '88884');$('.googleappsappsdivapps84747474').css('z-index', '88884');$('.googledivapps84').css('z-index', '88884');" onkeyup="doDelayedSearch(this.value);$('.googleappsapps84444444447444224474').show();$('.userappsappsappsappsgooglegooglegoogleappsappsappsapps84747474').show();">

<i class='material-icons googleappsapps84442244444444744474' style='font-size:24px;position:absolute;top:14.6px;right:12px;z-index:884;color:#bdbdbd;'>search</i>

</div>

</input>

<input type="submit" value="update" style="border:none;background-color:<?php echo "$accountcolor4"; ?>;padding:12px;color:#ffffff;font-weight:bold;margin:12px;font-size:13.8px;display:none;" id="googlegooglegooglegoogleappsappsappsapps84444474"></input>

</form>

</div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../accountcolor8884.sh";

}

else

{

$dataurlurlgoogleapps84 = "../accountcolor8884.sh";

}

?>

<?php

$googleappsgooglegoogleappsappsappsappsappsapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

if(preg_match("/[\W\w]/","googleapps84"))

{

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<style>

@media screen and (min-width:770px)
{
.googledivapps84
{
z-index:10884;
}
.googleappsmobileappsapps84
{
width:100%!important;
}
}

@media screen and (max-width:770px)
{
.googledivapps84
{
margin-left:0px!important;
z-index:2474;
width:100%!important;
box-sizing:border-box;
}
.googleappsmobileappsapps84
{
}
}

.googledivapps84
{
margin-left:0px!important;
width:100%!important;
box-sizing:border-box;
}

.googledivapps84:hover
{
background-color:#f1f1f1!important;
cursor:pointer;
}

</style>

<div>

<div>

</div>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../usersearchesapps84747474.sh";

}

else

{

$dataurl84 = "../people/usersearchesapps84747474.sh";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl84");

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='(.*?)' id='na'>1<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$gosearchimages84747674 = $googleapps84[1];

$gosearchimages84742274 = array_unique($gosearchimages84747674);

$gosearchimages84742274 = implode("<br>",$gosearchimages84742274);

$gosearchimages84742274 = explode("<br>",$gosearchimages84742274);

?>

<?php

$googleappsappsgooglegoogleapps84747474 = "0";

?>

<div class="googleappsappsdivapps84747474">

<?php

foreach($gosearchimages84742274 as $googleappsappsappsapps847474744474)

{

?>

<?php

$googleappsappsgooglegoogleapps84747474++;

?>

<?php

$namegooglegoogleappsappsappsapps84747474 = "$googleappsappsappsapps847474744474";

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps84747474 = rawurldecode($namegooglegoogleappsappsappsapps84747474);

$namegooglegoogleappsappsappsapps84747474 = openssl_decrypt($namegooglegoogleappsappsappsapps84747474,"AES-128-ECB",$password);

?>

<div onclick="window.open('/people/peoplesearchapps84747474.php?q=<?php echo "$namegooglegoogleappsappsappsapps84747474"; ?>','_self');">

<div class="googledivapps84" style="padding:12px;box-shadow:0 2px 4px 0 rgba(0, 0, 0, 0.1);background-color:#ffffff;width:396px;display:flex;position:relative;overflow:hidden;">

<div style="display:flex;">

<div>

<i class="material-icons" style="font-size:17.6px;color:#444444;margin-top:2px;margin-right:4px;">access_time</i>

</div>

<div>

<?php

echo "$namegooglegoogleappsappsappsapps84747474";

?>

</div>

</div>



</div>

</div>

<?php

if($googleappsappsgooglegoogleapps84747474 == "4")

{

break;

}

?>

<?php

}

?>

</div>

<?php

$googleappsappsapps844444444474 = $_GET['q'];

?>

<?php

if(preg_match("/^[a-z]/","$googleappsappsapps844444444474"))

{

$googleappsapps844422444474 = $_GET['q'];

$googleappsappsapps844444444474 = "$googleappsappsapps844444444474";

}

if(preg_match("/^[A-Z]/","$googleappsapps844422444474"))

{

$googleappsapps844422444474 = strtolower($_GET['q']);

$googleappsappsapps844444444474 = "$googleappsappsapps844444444474";

}

if(preg_match("/^[A-Z]/","$googleappsappsapps844444444474"))

{

$googleappsapps844422444474 = ucfirst($_GET['q']);

$googleappsappsapps844444444474 = ucfirst($googleappsappsapps844444444474);

}

?>


<?php

$namegooglegoogleappsappsappsapps84747474 = $_COOKIE['username'];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps84747474 = rawurldecode($namegooglegoogleappsappsappsapps84747474);

$namegooglegoogleappsappsappsapps84747474 = openssl_decrypt($namegooglegoogleappsappsappsapps84747474,"AES-128-ECB",$password);

$namegooglegoogleappsappsappsappsgooglegoogleappsappsapps84747474 = $_COOKIE['username'];

?>

<script>

$(document).ready(function() {

$('.googleappsmobileappsapps84').click(function(){

$.ajax({
    data: 'usersearchesapps84747474=<?php echo "$namegooglegoogleappsappsappsappsgooglegoogleappsappsapps84747474"; ?>&usersearchesappsapps84747474=<?php echo "$googleappsappsapps844444444474"; ?>',
    url: '/people/usersearchesapps84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

});

});

</script>

<?php echo "$_GET[useremail]"; ?>

<div class="googleappsmobileappsapps84" style="padding:12px;background-color:#ffffff;box-sizing:border-box;cursor:pointer;" onclick="window.open('/people/peoplesearchapps84747474.php?q=<?php echo "$googleappsappsapps844444444474"; ?>','_self');">

<divappsapps844444444474>

<div style="display:flex;">

<div>

<i class="material-icons" style="font-size:17.6px;color:#444444;margin-top:2px;margin-right:4px;">search</i>

</div>

<div style="margin-right:4px;">

<?php

echo "search for";

?>

</div>

<divappsapps844444444474 style="font-weight:bold;">

<?php echo "$googleappsapps844422444474"; ?>

</divappsapps844444444474>

</div>

</divappsapps844444444474>

</div>



<div style="width:100%;">

</div>

<div style="width:100%;">

</div>

<style>

html,body
{
margin:0px;
padding:0px;
font-family:Varela Round,sans-serif;
background-color:#ECEFF1!important;
}

</style>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlapps84 = "../accountcolor88842274.sh";

}

else

{

$dataurlurlapps84 = "../accountcolor88842274.sh";

}

?>

<?php

$googleappsgoogleappsappsgoogleapps8884 = file_get_contents($dataurlurlapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../accountcolor8884.sh";

}

else

{

$dataurlurlgoogleapps84 = "../accountcolor8884.sh";

}

?>

<?php

$googleappsgooglegoogleappsgoogleapps84747474 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../userregistrations.sh";

}

else

{

$dataurluserapps84 = "../userregistrations.sh";

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleappsgoogleappsapps84 = "../coworkers84747474.sh";

}

else

{

$dataurlurlgoogleappsgoogleappsapps84 = "coworkers84747474.sh";

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../coworkersappsappsapps84747474.sh";

}

else

{

$dataurlurlgoogleapps84 = "coworkersappsappsapps84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1][0];

if(preg_match("/1/","$accountcolorappsappsappsappsapps84742274"))

{

$googleappsuserapps888474 = file_get_contents("$dataurlurlgoogleappsgoogleappsapps84");

}

else

{

$googleappsuserapps888474 = file_get_contents("$dataurluserapps84");

}

?>

<?php

$googleapps88884474 = "-1";

?>

<?php

$usernameapps8884 = $_GET['username8884'];

$usernameapps8884 = rawurlencode($usernameapps8884);

?>

<?php

if(preg_match("/1/","$accountcolorappsappsappsappsapps84742274"))

{

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[0];

}

else

{

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[0];

}

$gosearchimages84742274 = array_unique($gosearchimages84747674);

$gosearchimages84742274 = implode("<br>",$gosearchimages84742274);

$gosearchimages84742274 = explode("<br>",$gosearchimages84742274);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84447422 = "../accountcolor8884.sh";

}

else

{

$dataurl84447422 = "../accountcolor8884.sh";

}

?>

<?php

$googleapps84747444 = file_get_contents($dataurl84447422);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../gosearchmages8884/gosearchimages8884.sh";

}

else

{

$dataurl84 = "../gosearchimages8884/gosearchimages8884.sh";

}

?>

<?php

$googleapps8884 = file_get_contents($dataurl84);

?>

<?php

$google84227474 = array();

$googleapps84181874 = array();

?>

<style>

pre {
  margin: 44px 0;
  padding: 20px;
  background: #fafafa;
}

.round { border-radius: 50%; }

</style>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../firstnameapps84747474.sh";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../people/firstnameapps84747474.sh";

}

?>

<?php

$googleappsuserappsgoogleappsappsapps888474 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = "../lastnameapps84747474.sh";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = "../people/lastnameapps84747474.sh";

}

?>

<?php

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484 = "../usernameapps84747474.sh";

}

else

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484 = "../people/usernameapps84747474.sh";

}

?>

<?php

$googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474 = file_get_contents($dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484);

?>

<?php

foreach($gosearchimages84742274 as $google8884)

{

?>

<?php

if(preg_match("/1/","$accountcolorappsappsappsappsapps84742274"))

{

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $google8884, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

}

else

{

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>/", $google8884, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

}

?>

<?php

$password="googleappsmobileapps888888884444";

$name84747474 = rawurldecode($gosearchimages84747674);

$name84747474 = openssl_decrypt($name84747474,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/1/","$accountcolorappsappsappsappsapps84742274"))

{

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $google8884, $googleapps84);
$gosearchimages84747674 = $googleapps84[1][0];

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='$gosearchimages84747674' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesapps84744474 = $googleapps84[2][0];

}

else

{

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>/", $google8884, $googleapps84);
$gosearchimages84747674 = $googleapps84[1][0];

?>

<?php

preg_match_all("/<div class='$gosearchimages84747674' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsgoogleappsappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$gosearchimages84747674' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$gosearchimages84747674' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674 $gosearchimagesappsappsappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

}

?>



<?php

$nameappsapps88847474 = "$googleappsappsapps844444444474";

?>

<?php

$nameappsapps8884 = $name84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

if(preg_match("/$nameappsapps8884/",$gosearchimagesapps84744474))

{

?>

<?php

$name84747474 = "$name84747474";

?>

<?php

}

else

{

?>

<?php

$name84747474 = "$nameappsapps88847474";

?>

<?php

}

?>

<?php

if(preg_match("/1/","$accountcolorappsappsappsappsapps84742274"))

{

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $google8884, $googleapps84);
$gosearchimages84747674 = $googleapps84[1][0];

}

else

{

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>/", $google8884, $googleapps84);
$gosearchimages84747674 = $googleapps84[1][0];

}

?>

<?php

$decryptedstringemailtext84727444 = "$gosearchimages84222274";

?>

<?php

$name84747474 = strtolower("$name84747474");

?>

<?php

$googleapps84747474 = $_GET['q'];

?>

<?php

if(preg_match("/[A-Z]/",$googleapps84747474[0]))

{

$google8474 = strtolower("$googleapps84747474");

}

else

{

$google8474 = "$googleapps84747474";

}

?>

<?php

if(preg_match("/^$google8474/",$name84747474))

{

?>

<?php

$google84227474[] = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

}

?>

<?php

$google84227474 = array_unique($google84227474);

$google84227474 = array_filter($google84227474);

$google84227474 = implode("<br>",$google84227474);

$google84227474 = explode("<br>",$google84227474);

?>

<div>

<div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../firstnameapps84747474.sh";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../people/firstnameapps84747474.sh";

}

?>

<?php

$googleappsuserappsgoogleappsappsapps888474 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = "../lastnameapps84747474.sh";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = "../people/lastnameapps84747474.sh";

}

?>

<?php

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484 = "../usernameapps84747474.sh";

}

else

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484 = "../people/usernameapps84747474.sh";

}

?>

<?php

$googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474 = file_get_contents($dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484);

?>

<?php

$google84444474 = "0";

foreach($google84227474 as $google8884)

{

?>

<?php

$password="googleappsmobileapps888888884444";

$nameappsappsappsappsapps84741822 = rawurldecode($google8884);

$nameappsappsappsappsapps84741822 = openssl_decrypt($nameappsappsappsappsapps84741822,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$nameappsappsappsappsapps84741822"))

{

?>

<div class="googleappsappsdivapps84747474">

<div>

<?php

$google84444474++;

?>

<?php

if($google84444474 == "8") {

break 1;

}

?>

<?php

preg_match_all("/<div class='$google8884' id='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$gosearchimages8474 = $googleapps84[2][0];

?>

<?php

if(preg_match("/1/","$accountcolorappsappsappsappsapps84742274"))

{

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='$google8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

}

else

{

?>

<?php

preg_match_all("/<div class='$google8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsgoogleappsappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$google8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$google8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674 $gosearchimagesappsappsappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

$name84747474 = "$googleappsappsapps844444444474";

?>

<?php

$name = $name84747474;
$passwordname = "googleappsmobileapps888888884444";

$name = openssl_encrypt($name,"AES-128-ECB",$passwordname);

$name8884 = rawurlencode($name);

?>

<?php

if(preg_match("/[\W\w]/","$name84747474"))

{

?>

<?php

if(preg_match("/1/","$accountcolorappsappsappsappsapps84742274"))

{

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='$google8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='$google8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesapps84744474 = $googleapps84[2][0];

}

else

{

preg_match_all("/<div class='$google8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesapps84744474 = $googleapps84[2][0];

}

?>

<?php

$nameappsapps88847474 = $gosearchimagesapps84744474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps88847474 = rawurldecode($nameappsapps88847474);

$nameappsapps88847474 = openssl_decrypt($nameappsapps88847474,"AES-128-ECB",$passwordname8884);

?>

<?php

$nameappsapps8884 = $name84747474;
$passwordname = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

if(preg_match("/1/","$accountcolorappsappsappsappsapps84742274"))

{

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='$google8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$name84444474 = $googleapps84[3][0];

}

else

{

preg_match_all("/<div class='$google8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$name84444474 = $googleapps84[3][0];

}

?>

<?php

$password="googleappsmobileapps888888884444";

$name84444474 = rawurldecode($name84444474);

$name84444474 = openssl_decrypt($name84444474,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/1/","$accountcolorappsappsappsappsapps84742274"))

{

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='$google8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$googleapps44 = $googleapps84[3][0];

}

else

{

preg_match_all("/<div class='$google8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$googleapps44 = $googleapps84[3][0];

}

?>

<?php

$passwordname8884 = "googleappsmobileapps888888884444";

$googleapps44 = rawurldecode($googleapps44);

$googleapps44 = openssl_decrypt($googleapps44,"AES-128-ECB",$passwordname8884);

?>

<?php

preg_match_all("/<div class='$google8884' id='(.*?)'><div class='(.*?)' id='(.*?)'><div class='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div><\/div><\/div>/", $googleappsuserapps888474, $googleapps84);
$googleapps84747474 = $googleapps84[6][0];

?>

<style>
.card {
box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
}

.title {
  color: grey;
  font-size: 18px;
}

button {
  border: none;
  outline: 0;
  padding: 8px;
  color: white;
  background-color: #000;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
background-color:<?php echo "$accountcolor4"; ?>!important;
}

a {
  text-decoration: none;
  font-size: 22px;
}

</style>

<style>

@media screen and (max-width:446px)
{
.googleurlapps84
{
white-space:nowrap;
overflow:hidden;
text-overflow:ellipsis;
max-width:226px;
}
}

@media screen and (max-width:770px)
{
.googleappsappsdivapps84747474
{
}
.googleappsmobileappsapps84
{
}
}

</style>

<?php

$password="googleappsmobileapps888888884444";

$name84741822 = rawurldecode($google8884);

$name84741822 = openssl_decrypt($name84741822,"AES-128-ECB",$password);

?>

<?php

$name84747474 = strtolower("$name84747474");

$googleapps44 = strtolower("$googleapps44");

$name84741822 = "$name84741822";

?>

<?php

$nameappsappsgooglegooglegooglegoogleapps88847474 = "$googleappsappsapps844444444474";
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsappsgooglegooglegooglegoogleapps88847474 = rawurldecode($nameappsappsgooglegooglegooglegoogleapps88847474);

$nameappsappsgooglegooglegooglegoogleapps88847474 = openssl_decrypt($nameappsappsgooglegooglegooglegoogleapps88847474,"AES-128-ECB",$passwordname8884);

?>

<div class="googledivapps84" style="padding:12px;box-shadow:0 2px 4px 0 rgba(0, 0, 0, 0.1);background-color:#ffffff;width:396px;display:flex;position:relative;overflow:hidden;padding-bottom:21.4px;" onclick="window.open('<?php echo "$googleprotocolapps8884"; ?>://<?php echo "$_SERVER[HTTP_HOST]"; ?>/people/usermail.php?useremail=<?php echo "$name84741822"; ?>','_self');">

<?php

preg_match_all("/<div class='$google8884' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleappsgoogleapps84747474, $googleappsappsapps84);
$accountcolor84742274 = $googleappsappsapps84[3][0];

?>

<?php

preg_match_all("/<div class='$google8884' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleappsgoogleapps84747474, $googleappsappsapps84);
$accountcolor847474 = $googleappsappsapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolor847474"))

{

$accountcolor1 = "$accountcolor847474";

$accountcolor2 = "$accountcolor847474";

$accountcolor4 = "$accountcolor847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<?php

if(preg_match("/[\W\w]/",$gosearchimages8474))

{

?>

<div>

<?php

echo "<div style='right:12px;top:7.4px;margin-top:-4px;'><img src='$gosearchimages8474' width='37.4' height='37.4' style='box-shadow:0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);'></img></div>";

?>

</div>

<?php

}

else

{

?>

<div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../userregistrations.sh";

}

else

{

$dataurl8884 = "../userregistrations.sh";

}

?>

<?php

$decryptedstring = $_COOKIE['username'];

$file84 = file_get_contents("$dataurl8884");

preg_match_all("/<div class='$google8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $file84, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

$nameappsapps8884 = "$name";

?>

<?php

$googleappsappsappsappsapps844444444474 = preg_replace("/(.*?) (.*?)/","$1",$googleappsappsapps844444444474);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsappsappsappsappsappsapps84 = "../googleappsapps84747474.sh";

}

else

{

$dataurluserappsappsappsappsappsappsapps84 = "../people/googleappsapps84747474.sh";

}

?>

<?php

$googleappsuserappsappsappsappsappsapps888474 = file_get_contents($dataurluserappsappsappsappsappsappsapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$google8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsappsappsapps888474, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$google8884' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/", $googleappsgooglegoogleappsappsappsappsappsapps8884, $googleappsappsappsappsappsappsappsapps84);
$accountcolorappsappsappsappsappsgoogleappsapps84742274 = $googleappsappsappsappsappsappsappsapps84[3][0];

$accountcolorappsappsappsappsappsgoogleappsapps84742274 = preg_replace("/#/","",$accountcolorappsappsappsappsappsgoogleappsapps84742274);

?>

<?php

$googleappsappsapps844474447444744474 = file_get_contents("/people/accountcolorappsapps84747474.php?accountcolorapps844474447444744474=$accountcolorappsappsappsappsappsgoogleappsapps84742274");

?>

<?php

$googleappsappsappsappsapps844474447444744474 = file_get_contents("/people/accountcolorappsapps847474744474.php?accountcolorapps844474447444744474=$accountcolorappsappsappsappsappsgoogleappsapps84742274");

?>

<?php

if(preg_match("/[\W\w]/",$accountcolorappsappsappsappsappsgoogleappsapps84742274))

{

$googleappsappsapps844474447444744474 = "$googleappsappsapps844474447444744474";

}

else

{

$googleappsappsapps844474447444744474 = "#2062b4";

}

?>

<?php

if(preg_match("/[\W\w]/",$accountcolorappsappsappsappsappsgoogleappsapps84742274))

{

$googleappsappsappsappsapps844474447444744474 = "$googleappsappsappsappsapps844474447444744474";

}

else

{

$googleappsappsappsappsapps844474447444744474 = "#6badff";

}

?>

<?php

if(preg_match("/(^Male$|^male$)/","$gosearchimages84747674"))

{

?>

<div style='position:relative;left:17.6px;top:14px;bottom:-28px;height:12px;width:56px;margin-left:-12px;margin-top:-26.8px;'>

<div class="googleappsappsgoogle844444224474" style="display:inline-block;">

<div style="border-radius:4px;">

<div class="inline">

<div class="textavatar googleapps84744422224474" style="width:112px;height:112px;color:#ffffff;border-style:solid;border-color:#f1f1f1;border-width:4px;background-color:<?php echo "$googleappsappsappsappsapps844474447444744474"; ?>;overflow:hidden;margin-left:-5.8px;border-radius:4px;z-index:888888884;position:relative;transform:scale(0.30);border-radius:4px!important;margin-left:-48px;margin-top:-31.8px!important;">

<div style="border-radius:196px;">

<div style="height:41px;width:41px;background-color:<?php echo "$googleappsappsapps844474447444744474"; ?>;border-radius:196px;margin-left:14px;margin-top:24px;margin-left:35.8px;margin-top:24px;top:0px;margin-bottom:17.4px;">
</div>

<div style="height:62px;width:80px;background-color:<?php echo "$googleappsappsapps844474447444744474"; ?>;border-radius:24px;margin-left:16.2px;margin-top:-12px;border-bottom-left-radius:0px;border-bottom-right-radius:0px;">
</div>

</div>

</div>

</div>

</div>

</div>

</div>

<?php

}

else

{

?>

<div style='position:relative;left:17.6px;top:14px;bottom:-28px;height:12px;width:56px;margin-left:-12px;margin-top:-26.8px;'>

<div class="googleappsappsgoogle844444224474" style="display:inline-block;">

<div style="border-radius:4px;">

<div class="inline">

<div class="textavatar googleapps84744422224474" style="width:112px;height:112px;color:#ffffff;border-style:solid;border-color:#f1f1f1;border-width:4px;background-color:<?php echo "$googleappsappsappsappsapps844474447444744474"; ?>;overflow:hidden;margin-left:-5.8px;border-radius:4px;z-index:888888884;position:relative;transform:scale(0.30);border-radius:4px!important;margin-left:-48px;margin-top:-31.8px!important;">

<div style="border-radius:196px;">

<div style="height:41px;width:41px;background-color:<?php echo "$googleappsappsapps844474447444744474"; ?>;border-radius:196px;margin-left:14px;margin-top:24px;margin-left:35.8px;margin-top:24px;top:0px;margin-bottom:17.4px;">
</div>

<div style="height:62px;width:80px;background-color:<?php echo "$googleappsappsapps844474447444744474"; ?>;border-radius:24px;margin-left:16.2px;margin-top:-12px;border-bottom-left-radius:0px;border-bottom-right-radius:0px;">
</div>

</div>

</div>

</div>

</div>

</div>

</div>

<?php

}

?>



</div>

<?php

}

?>

<?php

$password="googleappsmobileapps888888884444";

$name84741822 = rawurldecode($google8884);

$name84741822 = openssl_decrypt($name84741822,"AES-128-ECB",$password);

?>

<?php

$name84747474 = strtolower("$name84747474");

$googleapps44 = strtolower("$googleapps44");

$name84741822 = "$name84741822";

?>

<?php

if(preg_match("/^[a-z]/","$googleappsappsapps844444444474"))

{

$googleappsapps844422444474 = $_GET['q'];

$googleappsappsapps844444444474 = "$googleappsappsapps844444444474";

}

if(preg_match("/^[A-Z]/","$googleappsapps844422444474"))

{

$googleappsapps844422444474 = strtolower($_GET['q']);

$googleappsappsapps844444444474 = "$googleappsappsapps844444444474";

}

if(preg_match("/^[A-Z]/","$googleappsappsapps844444444474"))

{

$googleappsapps844422444474 = ucfirst($_GET['q']);

$googleappsappsapps844444444474 = ucfirst($googleappsappsapps844444444474);

}

$googleappsappsapps844444444474 = preg_replace("/^$googleappsapps844422444474/","",$googleappsappsapps844444444474);

?>

<?php

if(preg_match("/[\W\w]/","$googleappsappsapps844444444474"))

{

?>

<?php

if(strlen($googleappsappsapps844444444474) >= 24)

{

$googleappsappsapps844444444474 = substr($googleappsappsapps844444444474,0,24)."...";

}

else

{

$googleappsappsapps844444444474 = $googleappsappsapps844444444474;

}

?>

<?php

if(preg_match("/[\W\w]/","$googleappsappsapps844444444474"))

{

$googleappsappsapps844444444474 = "$googleappsappsapps844444444474";

}

else

{

$googleappsappsapps844444444474 = "User";

}

?>

<div style="padding-top:4px;margin:0px;"><a href="<?php echo "$googleprotocolapps8884"; ?>://<?php echo "$_SERVER[HTTP_HOST]"; ?>/people/usermail.php?useremail=<?php echo "$name84741822"; ?>" style="color:#444444;font-size:14.8px;margin-left:12px;"><divappsapps844444444474 style="font-weight:bold;"><?php echo "$googleappsapps844422444474"; ?></divappsapps844444444474><divappsapps844444444474><?php echo "$googleappsappsapps844444444474"; ?></divappsapps844444444474></a></div>

<?php

}

else

{

?>

<?php

}

?>

<?php

$google84747474 = "$name84741822";

?>

<?php

$googleapps84747474 = strtolower("$googleapps84747474");

?>

<div style="position:absolute;right:12px;">

<?php

echo "<i class='material-icons googleapps84742274' style='color:#bdbdbd;border-radius:44px;font-size:26px;'>keyboard_arrow_right</i>";

?>

</div>

<?php

$name = $name84747474;
$passwordname = "googleappsmobileapps888888884444";

$name = openssl_encrypt($name,"AES-128-ECB",$passwordname);

$name8884 = rawurlencode($name);

?>

</div>

<?php

}

else

{

?>

<style>
.card {
box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
}

.title {
  color: grey;
  font-size: 18px;
}

button {
  border: none;
  outline: 0;
  padding: 8px;
  color: white;
  background-color: #000;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

a {
  text-decoration: none;
  font-size: 22px;
}

</style>

<style>

@media screen and (max-width:446px)
{
.googleurlapps84
{
white-space:nowrap;
overflow:hidden;
text-overflow:ellipsis;
max-width:226px;
}
}

</style>

<div class="googledivapps84" style="padding:12px;box-shadow:0 2px 4px 0 rgba(0, 0, 0, 0.1);background-color:#ffffff;width:396px;display:flex;position:relative;overflow:hidden;padding-bottom:21.4px;">

<?php

preg_match_all("/<div class='$google8884' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleappsgoogleapps84747474, $googleappsappsapps84);
$accountcolor84742274 = $googleappsappsapps84[3][0];

?>

<?php

preg_match_all("/<div class='$google8884' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleappsgoogleapps84747474, $googleappsappsapps84);
$accountcolor847474 = $googleappsappsapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolor847474"))

{

$accountcolor1 = "$accountcolor847474";

$accountcolor2 = "$accountcolor847474";

$accountcolor4 = "$accountcolor847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<?php

if(preg_match("/[\W\w]/",$gosearchimages8474))

{

?>

<div>

<?php

echo "<div style='right:12px;top:7.4px;margin-top:-4px;'><img src='$gosearchimages8474' width='37.4' height='37.4' style='box-shadow:0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);'></img></div>";

?>

</div>

<?php

}

else

{

?>

<div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../userregistrations.sh";

}

else

{

$dataurl8884 = "../userregistrations.sh";

}

?>

<?php

$decryptedstring = $_COOKIE['username'];

$file84 = file_get_contents("$dataurl8884");

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $file84, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

$nameappsapps8884 = "$name";

?>

<?php

$googleappsappsappsappsapps844444444474 = preg_replace("/(.*?) (.*?)/","$1",$googleappsappsapps844444444474);

?>

<div style='left:18px;bottom:-22px;'>

<div onclick="document.getElementById('<?php echo "$googleapps847444444444444474"; ?>').click();">

<div class='inline'>
<div class='textavatar' style='width:28px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;' data-name='<?php echo "$googleappsappsappsappsapps844444444474"; ?>'>
</div>
</div>

</div>

</div>



</div>

<?php

$nameappsapps88847474 = strtolower("$nameappsapps88847474");

$googleapps44 = strtolower("$googleapps44");

?>

<?php

if(preg_match("/[\W\w]/","$googleappsappsapps844444444474"))

{

$googleappsappsapps844444444474 = "$googleappsappsapps844444444474";

}

else

{

$googleappsappsapps844444444474 = "User";

}

?>

<div style="padding-top:4px;margin:0px;"><a href="<?php echo "../people/usermail.php?useremail=$name84741822"; ?>" style="color:#444444;font-size:14.8px;margin-left:12px;"><?php echo "$googleappsappsapps844444444474"; ?></a></div>

<?php

$password="googleappsmobileapps888888884444";

$name84741822 = rawurldecode($google8884);

$name84741822 = openssl_decrypt($name84741822,"AES-128-ECB",$password);

?>

<?php

$google84747474 = "$name84741822";

?>

<div style="position:absolute;right:12px;">

<?php

echo "<i class='material-icons googleapps84742274' style='color:#bdbdbd;border-radius:44px;font-size:26px;'>keyboard_arrow_right</i>";

?>

</div>

<?php

$name = $name84747474;
$passwordname = "googleappsmobileapps888888884444";

$name = openssl_encrypt($name,"AES-128-ECB",$passwordname);

$name8884 = rawurlencode($name);

?>

</div>

<?php

}

?>

<?php

}

?>

<?php

}

?>



</div>

</div>

<?php

}

?>

<link rel="stylesheet" href="textavatar.css">
<script src="jquery.textavatar.js"></script>

<style>

.inline
{
display: inline-block;
margin-top:0px!important;
margin-right:0px!important;
}

</style>

<script>

$('.textavatar').textAvatar();

var name = $('#name').val();

var size = $('#size').val();

$('#test').textAvatar({

name: name,

width: size

});
		
</script>

</div>



</div>

<?php

}

?>

<script>

var googleappsapps84747474 = location.protocol

var script = document.createElement('script');
script.src = '' + googleappsapps84747474 + '//www.googletagmanager.com/gtag/js?id=UA-119997762-1';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

</script>

<script>

window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-119997762-1');

</script>

