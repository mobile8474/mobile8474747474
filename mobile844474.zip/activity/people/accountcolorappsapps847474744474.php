<?php

class ColorPalette84747474{
	public $color;
	
	public function __construct($color){
		$this->color = $color;
	}
	public function color_mod($hex, $diff) {
		$rgb = str_split(trim($hex, '# '), 2);
		 
		foreach ($rgb as &$hex) {
		$dec = hexdec($hex);
		if ($diff >= 0) {
		$dec += $diff;
		}
		else {
		$dec -= abs($diff);	
		}
		$dec = max(0, min(255, $dec));
		$hex = str_pad(dechex($dec), 2, '0', STR_PAD_LEFT);
	}
	return '#'.implode($rgb);
	}
	public function createPalette($colorCount=4){
		$colorPalette = array();
		for($i=1; $i<=$colorCount; $i++){
			if($i == 1){
				$color = $this->color;
				$colorVariation = -(($i-7.2) * 15);
			}
			if($i == 2){
				$color = $newColor;
				$colorVariation = -($i * 15);
			}
			if($i == 3){
				$color = $newColor;
				$colorVariation = -($i * 15);
			}
			if($i == 4){
				$color = $newColor;
				$colorVariation = -($i * 15);
			}
			
			$newColor = $this->color_mod($color, $colorVariation);
			array_push($colorPalette, $newColor);
		}
		return $colorPalette;
	}
}

$google8474 = "#" . $_GET['accountcolorapps844474447444744474'];

$color = new ColorPalette84747474($google8474);
$colorPalette = $color->createPalette();

$googleappsappsappsgoogleappsappsappsappsappsgooglegoogleappsappsapps84 = array();

foreach($colorPalette as $color84747474)

{

?>

<?php

$googleappsappsappsgoogleappsappsappsappsappsgooglegoogleappsappsapps84[] = "$color84747474";

?>

<?php

}

?>

<?php

$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84 = $googleappsappsappsgoogleappsappsappsappsappsgooglegoogleappsappsapps84[0];

echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84";

?>

