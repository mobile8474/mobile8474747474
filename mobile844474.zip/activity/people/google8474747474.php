<?php

$servername = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps4.sh"));

echo "$dbname";

$conn847474744474 = new mysqli($servername, $username, $password, $dbname);

?>

<?php

$sql = "DELETE FROM mailapps84747474 WHERE email='bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D' emailtext='googleapps84'";

if ($conn847474744474->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . $conn847474744474->error;
}

?>

<?php

$conn847474744474->close();

?>

