<center>

<div id="load84747474" style="width:100%;height:100%;position:fixed;left:0px;top:0px;background-color:#ffffff;z-index:88888844;margin:0 auto;z-index:88888844;opacity:0.8;">

<div id="load" align="center" style="z-index:88888844;margin-top:12%;"></div>

</div>

</center>

<script>

document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'interactive') {
  } else if (state == 'complete') {
      setTimeout(function(){
         document.getElementById('load').style.visibility="hidden";
         document.getElementById('load84747474').style.visibility="hidden";
      },1000);
  }
}

</script>

