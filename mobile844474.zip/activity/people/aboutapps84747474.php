<?php

error_reporting(0);

?>

<?php

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

$countryapps8884 = $_COOKIE['country'];

$date84747474 = date("Y-m-d-H-i-s");

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../aboutapps84747474.sh";

}

else

{

$dataurlappsappsapps84 = "aboutapps84747474.sh";

}

?>

<?php

$googleappsappsappsapps8474 = $_POST['aboutapps84747474'];

$password = "googleappsmobileapps888888884444";

$googleappsappsappsapps8474 = openssl_encrypt($googleappsappsappsapps8474,"AES-128-ECB",$password);

$googleappsappsappsapps8474 = rawurlencode($googleappsappsappsapps8474);

?>

<?php

$googleapps8474 = $_GET['coworkers84747474'];

$googleapps84444474 = rawurlencode($googleapps8474);

?>

<?php

$googleapps84442274 = $_POST['aboutappsuser84747474'];

?>

<?php

$googleapps8884 = "<div class='$googleapps84442274' id='na'>" . "\n" . "<div class='$googleappsappsappsapps8474' id='na'>1</div>" . "\n" . "</div>";

?>

<?php

$filedata = "$googleapps8884";
$filedata .= file_get_contents("$dataurlappsappsapps84");
$googleapps888844 = file_put_contents("$dataurlappsappsapps84", $filedata);

$sql84747474 = "INSERT INTO aboutapps84747474 (email,about,date)
VALUES ('$googleapps84442274','$googleappsappsappsapps8474','$date84747474')";

echo "<div style='display:none;'>$googleapps888844</div>";

?>

<?php

if ($conn->query($sql84747474) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql84747474 . "<br>" . $conn->error;
}

?>

<?php

$conn->close();

?>

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<script>

setTimeout(function()

{

window.location = '<?php echo "/$google847474747474747474744474/settings/account.php"; ?>';

}, 104);

</script>

