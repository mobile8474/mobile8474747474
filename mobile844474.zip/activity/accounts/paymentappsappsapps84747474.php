<?php

error_reporting(0);

?>

<?php

$googleapps84747474 = strtolower($_SERVER['HTTP_USER_AGENT']);

if(preg_match("/(bot|Bot|crawler|Crawler|spider|Spider)/","googleapps84"))

{
}

else

{

?>

<?php

include "../dashboard/dashboardtop.php";

?>

<?php

$servername847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn84744474447444744474 = new mysqli($servername847444444444744474, $username847444444444744474, $password847444444444744474, $dbname847444444444744474);

?>

<style>

@media (max-width: 770px)
{
.googleappsappsappsapps84747474
{
display:grid!important;
}
}

@media (min-width: 770px)
{
.googlegooglegoogleappsapps847474744474
{
width:296px;
}
}

</style>

<div style="background-color:#ffffff;">

<div style="padding:44px;">

<div style="font-size:58px;color:#444444;">

Your payment

</div>

</div>

</div>

</div>

<div class="googleappsappsappsapps84747474" style="display:flex;background-color:#ffffff;">

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:44px;">attach_money</i>

</div>

<h3 style="font-size:24px;color:#444444;font-weight:bold;">

<?php

if(preg_match("/[\W\w]/",$_POST['googleappsappsappsapps847474744474']))

{

$google84747474 = $_POST['googleappsappsappsapps847474744474'];

}

else

{

$google84747474 = $_GET['amountappsapps84747474'];

}

?>

<?php echo "$" . $google84747474; ?> to gcloud

<div>

<div>

<form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="business" value="<?php echo "mobileappsmobileapps8@gmail.com"; ?>">
<input type="hidden" name="amount" value='<?php echo $google84747474; ?>'>
<input type="hidden" name="return" value='https://<?php echo "$_SERVER[HTTP_HOST]"; ?>/accounts/payments84747474.php?googleappsapps84747474447444744474=<?php echo $_POST['googleappsappsappsapps847474744474']; ?>'>
<input name="item_name" type="hidden" value="Bluecloud ads" />
<input type="submit" value="Pay" name="submit" title="" class="paypal_btn" id="google84747474" formtarget="_self" style="background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:14.8px;padding:12px;color:#ffffff;border:none;margin-top:12px;box-shadow:0 2px 4px rgba(0,0,0,0.4);">
</form>

</div>

</div>

</h3>

<h4 style="font-weight:bold;">

<?php

$googleapps8884 = array();

$query = "SELECT * FROM email WHERE email='$_COOKIE[username]' order by date desc limit 1";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$googleapps8884[] = $row['email'];

}

$password="googleappsmobileapps888888884444";

$googleapps8884 = rawurldecode($googleapps8884[0]);

$googleapps8884 = openssl_decrypt($googleapps8884,"AES-128-ECB",$password);

?>

</h4>

<div style="font-size:14.8px;"></div>

<?php

$accountcolorappsappsappsappsapps84742274 = array();

$query = "SELECT * FROM paymentsapps84747474 WHERE email='$_COOKIE[username]'";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$accountcolorappsappsappsappsapps84742274[] = $row['payments'];

}

$accountcolorappsappsappsappsapps8474227444744474447444744474 = array_sum($accountcolorappsappsappsappsapps84742274);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1];

?>

<?php

$accountcolorappsappsappsappsapps84742274 = array();

$query = "SELECT * FROM adsclicksapps844444444474 WHERE adsusername='$_COOKIE[username]'";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$accountcolorappsappsappsappsapps84742274[] = $row['userip'];

}

?>

<?php

$accountcolorappsappsappsappsapps84742274 = count($accountcolorappsappsappsappsapps84742274);

$accountcolorappsappsappsappsapps84742274 = $accountcolorappsappsappsappsapps84742274 / 100;

$accountcolorappsappsappsappsapps84742274 = "$accountcolorappsappsappsappsapps8474227444744474447444744474" - $accountcolorappsappsappsappsapps84742274;

$accountcolorappsappsappsappsapps84742274 =  str_replace("/-/","",$accountcolorappsappsappsappsapps84742274);

$accountcolorappsappsappsappsapps84742274 = $accountcolorappsappsappsappsapps84742274 + $google84747474;

$accountcolorappsappsappsappsapps84742274 = number_format($accountcolorappsappsappsappsapps84742274, 2,'.', ',');

echo "<div style='font-size:14.8px;margin-top:4px;'>" . "Available balance after payment" . " $" . "$accountcolorappsappsappsappsapps84742274" . "</div>";

?>

</div>

<?php

$conn84744474447444744474->close();

?>

<?php

}

?>

