<?php

error_reporting(0);

?>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../chatapps84747474.sh";

}

else

{

$dataurlappsappsapps84 = "chatapps84747474.sh";

}

?>

<?php

$name84747474 = $_GET['googlebetween1'];

$password="googleappsmobileapps888888884444";

$namegoogleapps84747474 = "$name84747474";

$name84747474 = $_GET['googlebetween74'];

$password="googleappsmobileapps888888884444";

$namegoogleapps84444474 = "$name84747474";

$googleappsappsappsappsgoogleapps84747474 = "$namegoogleapps84747474$namegoogleapps84444474";

$password="googleappsmobileapps888888884444";

$googleappsappsappsappsgoogleapps84747474 = openssl_encrypt($googleappsappsappsappsgoogleapps84747474,"AES-128-ECB",$password);

$googleappsappsappsappsgoogleappsappsgoogleapps84747474 = rawurlencode($googleappsappsappsappsgoogleapps84747474);

?>

<?php

$dateapps84747474 = date("Y-m-d H:i:s");

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../chatapps84747474.sh";

}

else

{

$dataurl8884 = "../people/chatapps84747474.sh";

}

?>

<?php

$decryptedstring = $_GET['googlebetween1'];

$decryptedstring84444474 = "$decryptedstring";

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../userregistrations.sh";

}

else

{

$dataurl84 = "../register/userregistrations.sh";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl84");

?>

<?php

preg_match_all("/<div class='$decryptedstring84444474' id='(.*?)'><div class='(.*?)' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div><\/div>/", $googleapps8884, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name84747474 = openssl_decrypt($name,"AES-128-ECB",$password);

?>

<?php

$password="googleappsmobileapps888888884444";

$decryptedstring = rawurldecode($decryptedstring84444474);

$decryptedstring = openssl_decrypt($decryptedstring,"AES-128-ECB",$password);

$decryptedstring8884 = $_GET['googlebetween74'];

$decryptedstring88847474 = "$decryptedstring8884";

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../userregistrations.sh";

}

else

{

$dataurl84 = "../register/userregistrations.sh";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl84");

?>

<?php

preg_match_all("/<div class='$decryptedstring88847474' id='(.*?)'><div class='(.*?)' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div><\/div>/", $googleapps8884, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$namegoogleappsappsapps84747474 = openssl_decrypt($name,"AES-128-ECB",$password);

?>

<?php

$password="googleappsmobileapps888888884444";

$decryptedstring8884 = rawurldecode($decryptedstring88847474);

$decryptedstring8884 = openssl_decrypt($decryptedstring8884,"AES-128-ECB",$password);

$file84 = file_get_contents("$dataurl8884");

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='$decryptedstring84444474'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $file84, $googleapps84);
$emailtext = $googleapps84[3];

$googleappsappsappsappsgoogleapps84747474 = "$decryptedstring84444474$decryptedstring88847474";

$password="googleappsmobileapps888888884444";

$googleappsappsappsappsgoogleapps84747474 = openssl_encrypt($googleappsappsappsappsgoogleapps84747474,"AES-128-ECB",$password);

$googleappsappsappsappsgoogleapps84747474 = rawurlencode($googleappsappsappsappsgoogleapps84747474);

$googleappsappsappsappsgoogleappsgoogleappsapps84747474 = "$decryptedstring88847474$decryptedstring84444474";

$password="googleappsmobileapps888888884444";

$googleappsappsappsappsgoogleappsgoogleappsapps84747474 = openssl_encrypt($googleappsappsappsappsgoogleappsgoogleappsapps84747474,"AES-128-ECB",$password);

$googleappsappsappsappsgoogleappsgoogleappsapps84747474 = rawurlencode($googleappsappsappsappsgoogleappsgoogleappsapps84747474);

preg_match_all("/<div class='$googleappsappsappsappsgoogleapps84747474'>\n<div class='na' id='na'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>1<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $file84, $googleapps84);
$emailtextappsapps84747474 = $googleapps84[2];

preg_match_all("/<div class='$googleappsappsappsappsgoogleappsgoogleappsapps84747474'>\n<div class='na' id='na'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>1<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $file84, $googleapps84);
$emailtextappsappsappsapps84747474 = $googleapps84[2];

$googleappsappsapps84444474 = array_merge($emailtextappsapps84747474,$emailtextappsappsappsapps84747474);

$google84744474 = implode("<br>",$googleappsappsapps84444474);

$emailtext84747474 = explode("<br>",$google84744474);

?>

<?php

$googleapps84 = array();

foreach($emailtext84747474 as $googleapps84747474)

{

$googleapps84[] = "$googleapps84747474";

}

$data = trim(implode('',$googleapps84));
if (strlen($data) === 0)

{

$googleapps84224474 = "1";

}

else

{

$googleapps84224474 = count($googleapps84) + 1;

}

?>

<?php

$googleapps8884 = "<div class='$googleappsappsappsappsgoogleappsappsgoogleapps84747474'>" . "\n" . "<div class='na' id='na'>" . "\n" . "<div class='$googleapps84224474'>" . "\n" . "<div class='$_GET[message84747474]'>" . "\n" . "<div class='$dateapps84747474'>1</div>" . "\n" . "</div>" . "\n" . "</div>" . "\n" . "</div>" . "\n" . "</div>";

?>

<?php

$filedata = "$googleapps8884";
$filedata .= file_get_contents("$dataurlappsappsapps84");
$googleapps888844 = file_put_contents("$dataurlappsappsapps84", $filedata);

echo "<div style='display:none;'>$googleapps888844</div>";

?>

<script>

setTimeout(function()

{

window.location = '<?php echo "/people/chatupdates8884.php"; ?>';

}, 104);

</script>

