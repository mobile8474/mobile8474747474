<?php

$countryapps8884 = $_COOKIE['country'];

$servername84747474444444744474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps84.sh"));
$username84747474444444744474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps1.sh"));
$password84747474444444744474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps2.sh"));
$dbname84747474444444744474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps4.sh"));

$conn84747474 = new mysqli($servername84747474444444744474, $username84747474444444744474, $password84747474444444744474, $dbname84747474444444744474);

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "$isocode8884");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

$google847474744474 = date("Y-m-d-H-i");

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>1<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google8884 = $googleapps84[11];

$google847474744474447444744474 = $_COOKIE['username'];

$google8884 = array();

$query = "SELECT email,date,referer FROM charts84747474 WHERE email='$google847474744474447444744474' and date REGEXP '$google847474744474.*' order by date desc";

$result = mysqli_query($conn84747474,$query);

foreach($result as $row)

{

$google8884[] = $row['referer'];

}

$google8884 = array_filter($google8884);

$google8884 = implode("<br>",$google8884);

$google8884 = explode("<br>",$google8884);

?>

<?php

?>

<?php

$googleapps847474744474 = array();

$googleappsgoogleapps847474744474 = array();

foreach($google8884 as $googleappsapps84747474)

{

$url = "$googleappsapps84747474";
$parse = parse_url($url);

$googleapps847474744474[] = $googleappsapps84747474;

$googleappsgoogleapps847474744474[] = $googleappsapps84747474;

}

?>

<?php

$googleapps847474744474 = array_filter($googleapps847474744474);

$googleapps847474744474 = array_count_values($googleapps847474744474);

$googleappsgooglegooglegooglegoogleapps847474744474 = array_filter($googleappsgooglegooglegooglegoogleapps847474744474);

$googleappsgooglegooglegooglegoogleapps847474744474 = array_count_values($googleappsgoogleapps847474744474);

$googleapps847474744474 = implode("<br>",$googleapps847474744474);

$googleapps847474744474 = explode("<br>",$googleapps847474744474);

$googleappsgoogleapps847474744474 = implode("<br>",$googleappsgoogleapps847474744474);

$googleappsgoogleapps847474744474 = explode("<br>",$googleappsgoogleapps847474744474);

$google847474444444444474 = array_keys($googleappsgooglegooglegooglegoogleapps847474744474);

?>

<div style="position:relative;">

<div>

<div style="margin-top:12px;background-color:#ffffff;margin:12px;word-wrap:break-word;">

<?php

$google8474747444744474 = "0";

$googleappsappsappsapps8474747444744474 = "-1";

$googleappsappsappsappsappsapps8474747444744474 = array();

foreach($googleapps847474744474 as $googleapps84222274 => $google84747474)

{

$googleappsappsappsappsappsapps8474747444744474[] = "$google84747474";

}

?>

<?php

foreach($googleapps847474744474 as $googleapps84222274 => $google84747474)

{

$google8474747444744474++;

$googleappsappsappsapps8474747444744474++;

$googleappsgooglegoogleapps84747474 = $googleappsgoogleapps847474744474[$googleapps84222274];

$googleappsappsappsapps84744474447444744474 = rawurldecode($google847474444444444474[$googleappsappsappsapps8474747444744474]);

if(preg_match("/[\W\w]/","$googleappsappsappsapps84744474447444744474"))

{

echo "<div style='display:flex;display:flex;border-style:solid;border-width:1px;border-color:#bdbdbd;border-top:none;border-left:none;border-right:none;font-size:12.8px;word-wrap:break-word;'><div style='padding:12px;padding:12px;border-style:solid;border-left:none;border-top:none;border-bottom:none;border-width:1px;border-color:#bdbdbd;word-wrap:break-word;'>$google8474747444744474</div>" . "<div style='padding:12px;word-wrap:break-word;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%;'>" . $googleappsappsappsapps84744474447444744474 . "</div>" . "<div style='margin-left:4px;padding:12px;font-weight:bold;word-wrap:break-word;'>$google84747474</div></div>";

}

if ($google8474747444744474 == "12") break;

}

?>

</div>

</div>

</div>



</div>

</div>

<?php

$conn84747474->close();

?>

