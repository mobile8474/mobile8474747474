<?php

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

?>

<?php
print_r($_FILES); //this will print out the received name, temp name, type, size, etc.


$size = $_FILES['audio_data']['size']; //the size in bytes
$input = $_FILES['audio_data']['tmp_name']; //temporary name that PHP gave to the uploaded file
$output = $_FILES['audio_data']['name'].".wav"; //letting the client control the filename is a rather bad idea

//move the file from temp name to local folder using $output name
move_uploaded_file($input, $output)
?>

<?php

$date84747474 = date("Y-m-d-H-i-s");



if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}



$googleappsapps84747474 = "$ip";



$image = addslashes(file_get_contents($_FILES['audio_data']['tmp_name']));
$sql8474747444744474 = "INSERT INTO googleappsappsappsapps84747474 (email,date,google84747474,userip) VALUES('$cookievalue84747474','$date84747474','$image','$googleappsapps84747474')";

?>

<?php

$googleapps84747474 = mysqli_query($conn,$sql8474747444744474);

echo "$googleapps84747474";

?>

<?php

$conn->close();

?>

