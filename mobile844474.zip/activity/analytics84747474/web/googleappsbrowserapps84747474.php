<?php

$countryapps8884 = $_COOKIE['country'];

$servername = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "ZA");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

include "../../dashboard/dashboardtop.php";

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../analyticschartsrealtime84";

}

else

{

$dataurl = "../analyticschartsrealtime84";

}

?>

<?php

$googleapps8884 = file_get_contents($dataurl);

?>

<?php

$google847474744474 = date("Y-m-d");

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>1<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google8884 = $googleapps84[7];

$query = "SELECT email,date,browser FROM charts84747474 WHERE email='$_COOKIE[username]' and date REGEXP '$google847474744474.*'";
$result = $conn->query($query);

$google8884 = array();

while($row = $result->fetch_array())

{

$google8884[] = $row['browser'];

}

$google8884 = array_filter($google8884);

$google8884 = implode("<br>",$google8884);

$google8884 = explode("<br>",$google8884);

?>

<?php

?>

<?php

$googleapps847474744474 = array();

$googleappsgoogleapps847474744474 = array();

foreach($google8884 as $googleappsapps84747474)

{

$url = "$googleappsapps84747474";
$parse = parse_url($url);

$googleapps847474744474[] = "$googleappsapps84747474";

$googleappsgoogleapps847474744474[] = "$googleappsapps84747474";

}

?>

<?php

$googleapps847474744474 = array_count_values($googleapps847474744474);

$googleappsgooglegooglegooglegoogleapps847474744474 = array_count_values($googleappsgoogleapps847474744474);

$googleapps847474744474 = implode("<br>",$googleapps847474744474);

$googleapps847474744474 = explode("<br>",$googleapps847474744474);

$googleappsgoogleapps847474744474 = implode("<br>",$googleappsgoogleapps847474744474);

$googleappsgoogleapps847474744474 = explode("<br>",$googleappsgoogleapps847474744474);

?>

<div style="position:relative;">

<div>

<div style="margin-top:12px;background-color:#ffffff;margin:12px;word-wrap:break-word;">

<?php

$google8474747444744474 = "0";

foreach($googleapps847474744474 as $googleapps84222274 => $google84747474)

{

$google8474747444744474++;

if ($googleapps84222274 < $_GET['googleapps84']) continue;

$googleappsgooglegoogleapps84747474 = $googleappsgoogleapps847474744474[$googleapps84222274];

$googleappsgooglegoogleapps84747474 = array_search("$google84747474", $googleappsgooglegooglegooglegoogleapps847474744474);

echo "<div style='display:flex;display:flex;border-style:solid;border-width:1px;border-color:#bdbdbd;border-top:none;border-left:none;border-right:none;font-size:12.8px;'><div style='padding:12px;padding:12px;border-style:solid;border-left:none;border-top:none;border-bottom:none;border-width:1px;border-color:#bdbdbd;
'>$google8474747444744474</div>" . "<div style='padding:12px;'>$googleappsgooglegoogleapps84747474</div>" . "<div style='margin-left:4px;padding:12px;font-weight:bold;'>$google84747474</div></div>";

if ($googleapps84222274 > $_GET['googleapps8474']) break;

}

?>

<div style="padding:12px;background-color:#444444;position:absolute;right:0px;display:inline-block;bottom:-41.8px;right:12px;" onclick="window.open('/analytics/web/googleappsbrowserapps84747474.php?googleapps84=<?php echo $_GET[googleapps84] + 8; ?>&googleapps8474=<?php echo $_GET[googleapps8474] + 8; ?>&googleappsappsapps84=analytics','_self')">

next

</div>

</div>

</div>

</div>



</div>

</div>

<?php

include "../../dashboard/dashboardbottom.php";

?>

<?php

$conn->close();

?>

