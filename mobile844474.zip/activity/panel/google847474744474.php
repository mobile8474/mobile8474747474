<?php

$countryapps8884 = $_COOKIE['country'];

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn8444444444744444444474 = new mysqli($servername, $username, $password, $dbname);

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "$isocode8884");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

$accountcolorappsappsappsappsapps847422744474447444744474 = array();

$query = "SELECT * FROM adsbudgetapps84747474 order by date desc";

$result = mysqli_query($conn8444444444744444444474,$query);

foreach($result as $row)

{

$accountcolorappsappsappsappsapps847422744474447444744474[] = $row['budget'];

}

$accountcolorappsappsappsappsapps847422744474447444744474 = reset($accountcolorappsappsappsappsapps847422744474447444744474);

$accountcolorappsappsappsappsapps847422744474447444744474 = number_format($accountcolorappsappsappsappsapps847422744474447444744474, 2,'.', ',');

?>

<?php echo "$" . "$accountcolorappsappsappsappsapps847422744474447444744474"; ?>

<?php

$conn8444444444744444444474->close();

?>

