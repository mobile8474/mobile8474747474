<?php
$servername = "localhost";
$username = "w32zfjmq_mobile8";
$password = "mobileapps84";
$dbname = "w32zfjmq_mobileapps84";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to create table
$sql = "CREATE TABLE coworkersapps847474744474 (
email VARCHAR(884) NOT NULL,
coworkers VARCHAR(884) NOT NULL,
date VARCHAR(884) NOT NULL,
userip VARCHAR(884) NOT NULL,
reg_date TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "Table MyGuests created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();

?>

