<?php

error_reporting(0);

?>

<?php

$googleapps84747474 = strtolower($_SERVER['HTTP_USER_AGENT']);

if(preg_match("/(bot|Bot|crawler|Crawler|spider|Spider)/","googleapps84"))

{
}

else

{

?>

<?php

include "../dashboard/dashboardtop.php";

?>

<?php

$servername847474744444447444447474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username847474744444447444447474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password847474744444447444447474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname847474744444447444447474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn84444444447474 = new mysqli($servername847474744444447444447474, $username847474744444447444447474, $password847474744444447444447474, $dbname847474744444447444447474);

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

$googleapps847474744474 = $_GET['useremail'];

$password847474744474="googleappsmobileapps888888884444";

$nameappsapps847474744474 = openssl_encrypt($googleapps847474744474,"AES-128-ECB",$password847474744474);

$nameappsapps847474744474 = rawurlencode($nameappsapps847474744474);

$result84747474 = array();

$query = "SELECT * FROM imagesappsapps84747474 WHERE email='$nameappsapps847474744474' order by date desc";

$result = mysqli_query($conn84444444447474,$query);

foreach($result as $row)

{

$result84747474[] = $row['imagesapps84747474'];

}

$result84747474 = reset($result84747474);

?>

<div style="background-color:#ffffff;padding:12px;box-shadow:0 2px 4px rgba(0,0,0,0.4);margin:12px;">

<div style="padding:12px;color:#444444;">

Account

</div>

<div id="div84747474" style=""><?php echo '<img src="data:image/jpeg;base64,'.base64_encode($result84747474).'" width="119.6" height="119.6" style="border-color:#1565C0;color:#ffffff;border-radius:4px;font-size:86px;box-shadow:0 2px 4px rgba(0,0,0,0.4);object-fit:cover;" onclick="document.getElementById(' . "$googleapps847444444444444474" . ').click();"></img>'; ?></div>

</div>

<?php

$googleapps847474744474 = $_GET['useremail'];

$password847474744474="googleappsmobileapps888888884444";

$nameappsapps847474744474 = openssl_encrypt($googleapps847474744474,"AES-128-ECB",$password847474744474);

$nameappsapps847474744474 = rawurlencode($nameappsapps847474744474);

$result8474747444444444744474 = array();

$query84747474 = "SELECT * FROM imagesappsgoogle84747474 WHERE email='$nameappsapps847474744474' order by date desc";

$result847474744444444474 = mysqli_query($conn84444444447474,$query84747474);

foreach($result847474744444444474 as $row8474747444444444744474)

{

$result8474747444444444744474[] = $row8474747444444444744474['imagesapps84747474'];

}

?>

<?php

$result8474747444444444744474 = implode("<br>",$result8474747444444444744474);

$result8474747444444444744474 = explode("<br>",$result8474747444444444744474);

?>

<style>

@media (max-width: 770px)
{
.googleapps847444744474447444744474447444744474
{
justify-content:center;
}
}

</style>

<div style="padding:12px;color:#444444;padding-left:24px;">

Images

</div>

<div class="googleapps847444744474447444744474447444744474" style="background-color:#ffffff;padding:12px;box-shadow:0 2px 4px rgba(0,0,0,0.4);margin:12px;display:flex;display:-webkit-flex;-webkit-flex-wrap:wrap;display:flex;flex-wrap:wrap;">

<?php

foreach($result8474747444444444744474 as $googleapps847474744474)

{

?>

<?php

if(preg_match("/[\W\w]/","$googleapps847474744474"))

{

?>

<div>

<?php echo '<img src="data:image/jpeg;base64,'.base64_encode($googleapps847474744474).'" width="119.6" height="119.6" style="border-color:#1565C0;color:#ffffff;border-radius:4px;font-size:86px;box-shadow:0 2px 4px rgba(0,0,0,0.4);object-fit:cover;" onclick="document.getElementById(' . "$googleapps847444444444444474" . ').click();"></img>'; ?>

</div>

<?php

}

else

{

?>

<div>No images</div>

<?php

}

?>

<?php

}

?>

<script>

$(document).ready(function() {

$('.googleapps8444447474744474447444744474447444744474').onchange();

});

</script>

<div>

<form id="regForm" action="/imagesappsapps84747474/googleapps84.php" enctype="multipart/form-data" method="post">

<div class="tab" style="margin-top:12px;">

<div class="googleapps84747474">

</div>

</div>

<div class="tab">

<div class="googleapps84747474">

<input type="file" name="image" id="googleimageappsmobileappsappsappsappsappsapps84" onchange="$('.googleimageappsmobileappsappsappsappsappsapps844474447444744474').click();" style="display:none;" required>

</div>

</div>

<div>

<div class="googleappsappsappsappsapps84222274" style="font-size:12.8px;">

<input type="submit" value="REGISTER" class="googleimageappsmobileappsappsappsappsappsapps844474447444744474" style="padding:12px;background-color:#4285f4;color:#ffffff;margin-top:12px;box-shadow:0 2px 4px rgba(0,0,0,0.4);cursor:pointer;display:none;"></input>

</div>

</form>

</div>

</div>

<?php

}

?>

</div>

</div>

<?php

$googleapps847474744474 = $_GET['useremail'];

$password847474744474="googleappsmobileapps888888884444";

$nameappsapps847474744474 = openssl_encrypt($googleapps847474744474,"AES-128-ECB",$password847474744474);

$nameappsapps847474744474 = rawurlencode($nameappsapps847474744474);

if(preg_match("/$_COOKIE[username]/","$nameappsapps847474744474"))

{

?>

<div style="margin:12px;margin-left:24px;">

<div style="background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;padding:12px;display:inline-block;cursor:pointer;color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.4);" onclick="$('#googleimageappsmobileappsappsappsappsappsapps84').click();">

Add image

</div>

</div>

<?php

}

else

{
}

?>

<?php

$googleapps847474744474 = $_GET['useremail'];

$password847474744474="googleappsmobileapps888888884444";

$nameappsapps847474744474 = openssl_encrypt($googleapps847474744474,"AES-128-ECB",$password847474744474);

$nameappsapps847474744474 = rawurlencode($nameappsapps847474744474);



$result8474747444444444744474 = array();

$query84747474 = "SELECT * FROM coworkersapps847474744474 WHERE email='$nameappsapps847474744474' order by date desc";

$result847474744444444474 = mysqli_query($conn84444444447474,$query84747474);

foreach($result847474744444444474 as $row8474747444444444744474)

{

$result8474747444444444744474[] = $row8474747444444444744474['coworkers'];

}

?>

<?php

$result8474747444444444744474 = array_unique($result8474747444444444744474);

$result8474747444444444744474 = implode("<br>",$result8474747444444444744474);

$result8474747444444444744474 = explode("<br>",$result8474747444444444744474);

?>

<style>

@media (max-width: 770px)
{
.googleapps847444744474447444744474447444744474
{
justify-content:center;
}
}

</style>

<div style="padding:12px;color:#444444;padding-left:24px;">

Coworkers

</div>

<div class="googleapps847444744474447444744474447444744474" style="background-color:#ffffff;padding:12px;box-shadow:0 2px 4px rgba(0,0,0,0.4);margin:12px;">

<?php

foreach($result8474747444444444744474 as $googleapps847474744474)

{

?>

<?php

$googleapps847474744474 = "$googleapps847474744474";

$password847474744474="googleappsmobileapps888888884444";

$nameappsapps847474744474 = rawurldecode($googleapps847474744474);

$nameappsapps847474744474 = openssl_decrypt($nameappsapps847474744474,"AES-128-ECB",$password847474744474);

?>

<?php

if(preg_match("/[\W\w]/","$googleapps847474744474"))

{

?>

<div>

<?php echo "$nameappsapps847474744474<br>"; ?>

</div>

<?php

}

else

{

?>

<div>No coworkers</div>

<?php

}

?>

<?php

}

?>

</div>

<?php

$googleapps84 = $_GET['useremail'];

$password="googleappsmobileapps888888884444";

$nameappsapps84 = openssl_encrypt($googleapps84,"AES-128-ECB",$password);

$nameappsapps84 = rawurlencode($nameappsapps84);

?>

<script>

$(document).ready(function() {

$('.googleapps844444747474').click(function(){

$.ajax({
    data: 'coworkers84747474=<?php echo "$nameappsapps8884"; ?>',
    url: '/people/coworkers84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

});

});

</script>

<?php

$googleapps847474744474 = $_GET['useremail'];

$password847474744474="googleappsmobileapps888888884444";

$nameappsapps847474744474 = openssl_encrypt($googleapps847474744474,"AES-128-ECB",$password847474744474);

$nameappsapps847474744474 = rawurlencode($nameappsapps847474744474);

if(preg_match("/$_COOKIE[username]/","$nameappsapps847474744474"))

{

?>

<?php

}

else

{

?>

<div class="googleapps844444747474" style="margin:12px;margin-left:24px;">

<div style="background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;padding:12px;display:inline-block;cursor:pointer;color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.4);" onclick="$('.googleappsappsapps8474').show();">

Add coworker

</div>

</div>

<?php

}

?>

<div class="googleappsappsapps8474" id="google84742274" style="display:none;">

<div>

<div style="position:fixed;background-color:#bdbdbd;z-index:88888844;height:100%;top:0px;width:100%;left:0px;background:rgba(0, 0, 0, 0.4);" onclick="$(this).hide();">

<div align="center" style="margin:12px;margin-top:62px;background-color:#f1f1f1;padding:12px;position:fixed;top:50%;left:50%;margin-top:-62px;margin-left:-62px;background:rgba(0, 0, 0, 0.4);">

<i class='material-icons' style="color:#ffffff;font-size:104px;">person_add</i>

</div>

</div>

</div>

</div>

<?php

include "../dashboard/dashboardbottom.php";

?>

<?php

$conn84444444447474->close();

?>

