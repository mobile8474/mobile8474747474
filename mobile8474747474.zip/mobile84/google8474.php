<?php

$google847474747474 = shell_exec("pkill -f php");

echo "$google847474747474";

?>

<?php

$google847474747474 = shell_exec("pkill -f php");

echo "$google847474747474";

?>

<?php

$google847474747474 = shell_exec("pkill -f php");

echo "$google847474747474";

?>

<?php

$google847474747474 = shell_exec("pkill -f php");

echo "$google847474747474";

?>

