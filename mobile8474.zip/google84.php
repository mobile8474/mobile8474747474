<?php

curl -u er2erym3mzchw:EdO67wi0dQJGBoaptbGdowUh3cp3m-JSixfwqUHGmAs -X POST -d pair=ETHZAR -d type=ASK -d volume=0.1 -d price=1000 https://api.mybitx.com/api/1/postorder

curl -u er2erym3mzchw:EdO67wi0dQJGBoaptbGdowUh3cp3m-JSixfwqUHGmAs -X POST -d pair=ETHZAR -d type=SELL -d base_volume=0.001  https://api.mybitx.com/api/1/marketorder

?>

