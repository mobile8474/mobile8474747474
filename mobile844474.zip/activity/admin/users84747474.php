<?php

error_reporting(0);

?>

<?php

$googleapps84747474 = strtolower($_SERVER['HTTP_USER_AGENT']);

if(preg_match("/(bot|Bot|crawler|Crawler|spider|Spider)/","googleapps84"))

{
}

else

{

?>

<?php

include "../dashboard/dashboardtop.php";

?>

<?php

$servername847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn84744474447444744474 = new mysqli($servername847444444444744474, $username847444444444744474, $password847444444444744474, $dbname847444444444744474);

?>

<style>

@media (max-width: 770px)
{
.googleappsappsappsapps84747474
{
display:grid!important;
}
}

@media (min-width: 770px)
{
.googlegooglegoogleappsapps847474744474
{
width:296px;
}
}

</style>

<div style="background-color:#ffffff;">

<div style="padding:44px;">

<div style="font-size:58px;color:#444444;">

USERS

</div>

</div>

</div>

</div>

<div style="margin:12px;">

<div>

<i class="material-icons" style="color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:44px;">account_box</i>

</div>

<h3 style="font-size:24px;color:#444444;font-weight:bold;cursor:pointer;" onclick="window.open('/admin/users84747474.php','_self');">USERS</h3>

<h4 style="font-weight:bold;">

<?php

$googleapps8884 = array();

$query = "SELECT * FROM email order by date desc limit $_GET[googleapps84],8";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$googleapps8884[] = $row['email'];

}

$googleapps8884 = array_filter($googleapps8884);

foreach($googleapps8884 as $googleapps84747474)

{

$password="googleappsmobileapps888888884444";

$googleapps8884 = rawurldecode($googleapps84747474);

$googleapps8884 = openssl_decrypt($googleapps8884,"AES-128-ECB",$password);

if(preg_match("/[\W\w]/","$googleapps8884"))

{

?>

<div style="display:flex;">

<div style="font-weight:normal;background-color:#ffffff;padding:12px;border-style:solid;border-width:1px;border-color:#bdbdbd;border-top:none;border-right:none;width:100%;">

<?php

echo "$googleapps8884<br>";

?>

<div>

ads

</div>

<div>

analytics

</div>

<div>

settings

</div>

<div>

billing

</div>

</div>

</div>

<?php

}

}

?>

<div style="position:relative;background-color:#ffffff;padding:21.4px;">

<div style="background-color:#ffffff;position:absolute;right:0px;display:inline-block;bottom:-41.8px;right:48px;color:#444444;cursor:pointer;bottom:8px;right:49.4px;border-style:solid;border-width:1px;position:absolute;border-color:#bdbdbd;display:grid;" onclick="window.open('/admin/users84747474.php?googleapps84=<?php echo $_GET[googleapps84] - 8; ?>','_self')">

<i class="material-icons">keyboard_arrow_left</i>

</div>

<div style="background-color:#ffffff;position:absolute;right:0px;display:inline-block;bottom:-41.8px;right:12px;color:#444444;cursor:pointer;position:absolute;bottom:8px;right:24px;border-style:solid;border-width:1px;border-color:#bdbdbd;display:grid;" onclick="window.open('/admin/users84747474.php?googleapps84=<?php echo $_GET[googleapps84] + 8; ?>','_self')">

<i class="material-icons">keyboard_arrow_right</i>

</div>

</div>

</div>

<?php

$conn84744474447444744474->close();

?>

<?php

}

?>

