<?php

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

$decryptedstring84747474 = $_COOKIE['username'];

$date84747474 = date("Y-m-d-H-i-s");

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

$googleappsapps84747474 = "$ip";

$image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
$sql8474747444744474 = "INSERT INTO imagesappsgoogle84747474 (email,date,imagesapps84747474,userip) VALUES('$decryptedstring84747474','$date84747474','$image','$googleappsapps84747474')";

if ($conn->query($sql8474747444744474) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql8474747444744474 . "<br>" . $conn->error;
}

?>

<?php

$conn->close();

?>

<?php

$googleapps847474744474 = "$decryptedstring84747474";

$password847474744474="googleappsmobileapps888888884444";

$nameappsapps847474744474 = rawurldecode($googleapps847474744474);

$nameappsapps847474744474 = openssl_decrypt($nameappsapps847474744474,"AES-128-ECB",$password847474744474);

?>

<script>

setTimeout(function()

{

window.location = "/people/usermail.php?useremail=<?php echo $nameappsapps847474744474; ?>";

}, 884);

</script>

