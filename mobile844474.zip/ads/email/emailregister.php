<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

include 'phpmailer84747474/PHPMailerAutoload.php';

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPDebug = 1;
$mail->SMTPAuth = true;
$mail->SMTPSecure = 'tls';
$mail->Host = "smtp.yandex.com";
$mail->Port = 587;
$mail->IsHTML(true);

$mail->Username = "accounts@gcloud.pw";
$mail->Password = "mobileapps84";

?>

<?php

$mail->CharSet = "UTF-8";
$mail->Subject = "Welcome to GCLOUD ADS";
$mail->Body = '

<head>
<title></title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no">
</head>

<style>

@media (max-width: 770px)
{
.googleapps888844
{
width:100%!important;
}
}

</style>

<html>

<body style="background-color:#f8f8f8;">

<div align="center">

<div class="googleapps888844" style="left:0px;right:0px;width:574px;background-color:#ffffff;font-family:Varela Round, sans-serif;width:100%;border-left:none;border-bottom:none;border-top:none;border-color:#bdbdbd;position:relative;width:44%;text-align:left;">

<div style="position:absolute;padding:12px;right:12px;bottom:12px;border-style:solid;border-left:none;border-top:none;border-color:#bdbdbd;display:none;">
</div>

<div>

<div>

<center>

<span></span> <span style="color:#ffffff!important;font-weight:bold;"><span>

</center>

</div>

</div>

<div class="googleapps8884" style="font-family: Varela Round, sans-serif;">

<div class="google888874" style="font-family: Varela Round, sans-serif;"></div>

<div class="google8474" style="font-family: Varela Round, sans-serif;"></div>

<div>

<div style="background-color:#42A5F5;color:#ffffff;padding:12px;border-bottom-style:solid;border-color:#42A5F5;background-image:linear-gradient(to top left, #90CAF9 12%, #42A5F5 34%, #1565C0 62%);">

<div style="text-align:center;font-size:28px;">GCLOUD ADS</div>

</div>

<br>

<div class="google88884474" style="font-family:Varela Round, sans-serif;padding:12px;"><div><div style="font-size:13.8px;color:#222222;"><div style="text-align:center;">Welcome to GCLOUD we hope you successfully promote your business online with our ads platform, and get many users to your business with the ads you create</div><br><br><div>To your success</div><div>GCLOUD ADS</div><div style="text-align:center;margin:0 auto;"></div><div style="color:#222222;font-size:13.8px;"></div><br><div><div style="color:#222222;font-size:13.8px;"></div><br><div style="font-size:12.8px;">GCLOUD</div><div style="color:#222222;font-size:12.8px;"><a href="www.gcloud.pw" style="color:#222222;">GCLOUD ADS</a></div><br><div><a href="www.gcloud.pw/ads/register/login.php" style="color:#222222;font-weight:bold;">Login to GCLOUD ADS</a></div><br><div>GCLOUD LLC, ONLINE, UNITED STATES, TRADING AS GCLOUD</div></div></div>

<div>

</div>

</div>

</div>

</body>

</html>

';

?>

<?php

if(preg_match("/(charlotteclark09@gmail.com|cindybeaton696@gmail.com|Dartaniandegoede@hotmail.com|heisgreat3@gmail.com|eleneh58@gmail.com|riaan.cockrell@gmail.com)/",$google8422747444444474))

{

$googleapps84441274 = "";

}

else

{

$googleapps84441274 = "$google8422747444444474";

}

$mail->addAddress($_POST['email']);

$mail->setFrom("accounts@gcloud.pw", 'gcloud');
$mail->addReplyTo("accounts@gcloud.pw", 'gcloud');

$mail->Send();

$mail->ClearAllRecipients();

?>

