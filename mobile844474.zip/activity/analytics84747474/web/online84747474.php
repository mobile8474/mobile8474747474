<?php

error_reporting(0);

?>

<?php

$servername = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "ZA");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$date8884 = date("Y-m");

$dateappsappsgoogleapps84747474 = date("d");

$dateappsappsgoogleapps84444474 = date("H");

?>

<?php

$hours = date("H");

$minutes = date("i");

$seconds = date("s");

?>

<?php

$google88888872 = array();

?>

<?php

$googleapps847474 = "-24";

for ($google74 = 0; $google74 <= 24; $google74++)

{

$googleapps847474++;

$unixtime = strtotime("$googleapps847474 seconds");

$minutes = date("i",$unixtime);

$unixtime = strtotime("$googleapps847474 seconds");

$seconds = date("s",$unixtime);

$hours = date("H");

$days = date("d");

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$date8884-$days-$hours-$minutes-$seconds'>\n<div class='1'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>1<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google8884 = $googleapps84[2];

$query = "SELECT email,date,userip FROM charts84747474 WHERE email='$decrypted_string' and date='$date8884-$days-$hours-$minutes-$seconds'";
$result = $conn->query($query);

$google8884 = array();

while($row = $result->fetch_array())

{

$google8884[] = $row['userip'];

}

$googleappsmobileapps8884 = array_unique($google8884);

$googleappsmobileapps8884 = count($googleappsmobileapps8884);

$google88888872[] = $googleappsmobileapps8884;

}

?>

<?php

$googleappsmobileapps84744474 = array_sum($google88888872);

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleapps8884, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor847474))

{
}

else

{

$accountcolor84747474 = "";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1976D2";

$accountcolor4 = "#1E88E5";

$accountcolor8 = "#2196F3";

$accountcolor12 = "#42A5F5";

$accountcolor18 = "#64B5F6";

$accountcolor22 = "#90CAF9";

}

?>

<?php

if(preg_match("/blue/",$accountcolor847474))

{

$accountcolor84747474 = "";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1976D2";

$accountcolor4 = "#1E88E5";

$accountcolor8 = "#2196F3";

$accountcolor12 = "#42A5F5";

$accountcolor18 = "#64B5F6";

$accountcolor22 = "#90CAF9";

}

if(preg_match("/orange/",$accountcolor847474))

{

$accountcolor84747474 = "#EF6C00";

$accountcolor1 = "#EF6C00";

$accountcolor2 = "#F57C00";

$accountcolor4 = "#FB8C00";

$accountcolor8 = "#FF9800";

$accountcolor12 = "#FFA726";

$accountcolor18 = "#FFB74D";

$accountcolor22 = "#FFCC80";

}

if(preg_match("/yellow/",$accountcolor847474))

{

$accountcolor84747474 = "#F9A825";

$accountcolor1 = "#F9A825";

$accountcolor2 = "#FBC02D";

$accountcolor4 = "#FDD835";

$accountcolor8 = "#FFEB3B";

$accountcolor12 = "#FFEE58";

$accountcolor18 = "#FFF176";

$accountcolor22 = "#FFF59D";

}

if(preg_match("/purple/",$accountcolor847474))

{

$accountcolor84747474 = "#6A1B9A";

$accountcolor1 = "#6A1B9A";

$accountcolor2 = "#7B1FA2";

$accountcolor4 = "#8E24AA";

$accountcolor8 = "#9C27B0";

$accountcolor12 = "#AB47BC";

$accountcolor18 = "#BA68C8";

$accountcolor22 = "#CE93D8";

}

if(preg_match("/pink/",$accountcolor847474))

{

$accountcolor84747474 = "#AD1457";

$accountcolor1 = "#AD1457";

$accountcolor2 = "#C2185B";

$accountcolor4 = "#D81B60";

$accountcolor8 = "#E91E63";

$accountcolor12 = "#EC407A";

$accountcolor18 = "#F06292";

$accountcolor22 = "#F48FB1";

}

if(preg_match("/red/",$accountcolor847474))

{

$accountcolor84747474 = "#C62828";

$accountcolor1 = "#C62828";

$accountcolor2 = "#E53935";

$accountcolor4 = "#EF5350";

}

if(preg_match("/green/",$accountcolor847474))

{

$accountcolor84747474 = "#2E7D32";

$accountcolor1 = "#2E7D32";

$accountcolor2 = "#43A047";

$accountcolor4 = "#66BB6A";

}

?>

<div>

<div style="font-size:76px;width:100%;">

<div>

<?php

echo "$googleappsmobileapps84744474";

?>

</div>

</div>

</div>

<?php

$conn->close();

?>

