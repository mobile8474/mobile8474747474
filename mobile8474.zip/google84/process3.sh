#!/bin/bash  

touch pid3.sh

startme() {

google84=$(cat pid3.sh)
   
if [[ $google84 == "" ]];

then

cd /var/www/html/mobile8474/
php ./googleapps84.php google3 &> /dev/null &

mypid=$!

echo $mypid > pid3.sh 

else

echo "google84"

fi

}

stopme() {
    kill -9 $(cat pid3.sh)

echo "" > pid3.sh

}

case "$1" in 
    start)   startme ;;
    stop)    stopme ;;
    restart) stopme; startme ;;
    *) echo "usage: $0 start|stop|restart" >&2
       exit 1
       ;;
esac

