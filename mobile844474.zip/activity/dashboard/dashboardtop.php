<?php

if(preg_match("/analytics/",$_SERVER['REQUEST_URI']))

{

$googleapps84747474 = "Devcloudplatform Analytics";

}

if(preg_match("/ads/",$_SERVER['REQUEST_URI']))

{

$googleapps84747474 = "Devcloudplatform Ads";

$googleapps847474744474 = "Your dashboard for your ads to check clicks impressions and cpc";

}

if(preg_match("/accountapps84747474/",$_SERVER['REQUEST_URI']))

{

$googleapps84747474 = "Devcloudplatform Settings";

$googleapps847474744474 = "Your settings to change your account information like your username and other features";

}

if(preg_match("/settingsapps84747474/",$_SERVER['REQUEST_URI']))

{

$googleapps84747474 = "Devcloudplatform Billing";

$googleapps847474744474 = "Your page to check account balance and do payments";

}

if(preg_match("/people\/usermail\.php/",$_SERVER['REQUEST_URI']))

{

$googleapps84747474 = "Devcloudplatform Activity";

$googleapps847474744474 = "Your activity where you should find your images and other information about you";

}

if(preg_match("/admin\/accountapps84747474\.php/",$_SERVER['REQUEST_URI']))

{

$googleapps84747474 = "Devcloudplatform Admin";

$googleapps847474744474 = "Show users information";

}

if(preg_match("/admin\/users84747474\.php/",$_SERVER['REQUEST_URI']))

{

$googleapps84747474 = "Devcloudplatform Users";

$googleapps847474744474 = "user setting like analytics and ads";

}

if(preg_match("/people\/pagemail\.php/",$_SERVER['REQUEST_URI']))

{

$googleapps84747474 = "Devcloudplatform Inbox";

$googleapps847474744474 = "check your mail with Devcloudplatform inbox";

}

if(preg_match("/people\/pagemail84747474\.php/",$_SERVER['REQUEST_URI']))

{

$googleapps84747474 = "Devcloudplatform Sent";

$googleapps847474744474 = "your sent mails to other users on gcloud";

}

if(preg_match("/googleappsappsapps84\/googleapps84\.php/",$_SERVER['REQUEST_URI']))

{

$googleapps84747474 = "Devcloudplatform Audio";

$googleapps847474744474 = "Audio messages that you have received from other users";

}

if(preg_match("/analytics\/web\/overview84747474\.php/",$_SERVER['REQUEST_URI']))

{

$googleapps84747474 = "Devcloudplatform Real Time";

$googleapps847474744474 = "Analytics realtime stats for your website";

}

if(preg_match("/analytics\/web\/overview\.php/",$_SERVER['REQUEST_URI']))

{

$googleapps84747474 = "Devcloudplatform Audience";

$googleapps847474744474 = "Analytics audience shows your website users bounce rate, online users and time on site";

}

if(preg_match("/analytics\/web\/googleappssourceapps84747474\.php/",$_SERVER['REQUEST_URI']))

{

$googleapps84747474 = "Devcloudplatform Acquisition";

$googleapps847474744474 = "Shows analytics information about user referer and information about users";

}

if(preg_match("/analytics\/web\/googleappscountriesapps847474744474\.php/",$_SERVER['REQUEST_URI']))

{

$googleapps84747474 = "Devcloudplatform Countries";

$googleapps847474744474 = "Shows users country";

}

if(preg_match("/analytics\/web\/overview847474744474\.php/",$_SERVER['REQUEST_URI']))

{

$googleapps84747474 = "Devcloudplatform Prediction";

$googleapps847474744474 = "Shows a forecast about user information";

}

if(preg_match("/analytics\/web\/analyticscode\.php/",$_SERVER['REQUEST_URI']))

{

$googleapps84747474 = "Devcloudplatform Code";

$googleapps847474744474 = "Get tracking code for your website";

}

if(preg_match("/accounts\/paymentappsappsapps84747474\.php/",$_SERVER['REQUEST_URI']))

{

$googleapps84747474 = "Devcloudplatform Payments";

$googleapps847474744474 = "Make a payment";

}

if(preg_match("/\/activity\/panel\/overview\.php/",$_SERVER['REQUEST_URI']))

{

$googleapps84747474 = "Devcloudplatform activity";

$googleapps847474744474 = "Activity of users";

}

?>

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<head>
<title><?php echo "$googleapps84747474"; ?></title>
<meta name='description' content='<?php echo "$googleapps847474744474"; ?>'>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="/<?php echo "$google847474747474747474744474"; ?>/dashboard/jquery.js"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="https://code.getmdl.io/1.2.0/material.indigo-pink.min.css">
<script defer src="https://code.getmdl.io/1.2.0/material.min.js"></script>
<link rel="stylesheet" href="https://codeartisan-ui.github.io/material-dialogs/css/app.css">
<link rel="stylesheet" href="https://codeartisan-ui.github.io/material-dialogs/css/dialog.css">
<script defer src="https://codeartisan-ui.github.io/material-dialogs/js/dialog.js"></script>
<script defer src="https://code.getmdl.io/1.2.0/material.min.js"></script>
</head>

<?php

$googleapps84747474 = strtolower($_SERVER['HTTP_USER_AGENT']);

if(preg_match("/(bot|Bot|crawler|Crawler|spider|Spider)/","googleapps84"))

{
}

else

{

?>

<?php

error_reporting(0)

?>

<?php

if(preg_match("/analytics\/web\//",$_SERVER['REQUEST_URI']))

{

$servername8474747444444474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps84.sh"));
$username8474747444444474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps1.sh"));
$password8474747444444474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps2.sh"));
$dbname8474747444444474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps4.sh"));

}

else

{

$servername8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

}

$conn = new mysqli($servername8474747444444474, $username8474747444444474, $password8474747444444474, $dbname8474747444444474);

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<script>

$(document).ready(function(){

$('#content-wrapper').click(function() {

$('.googleappsappsappsappsapps84747474747474744474').hide();

}

);

}

);

</script>

<div id="minutesappsgooglegoogleapps44"></div>

<script>

$(document).ready(function(){

$("#minutesappsgooglegoogleapps44").load('/dashboard/notifications84744474.php');

}

);

</script>

<?php

include "notifications84744474.php";

?>

<style> 

div[style*="box-shadow"]
{
box-shadow:0 1px 4px rgba(0,0,0,0.4)!important;
}

</style>

<style> 

div[style*="z-index"]
{
z-index:0!important;
}

</style>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

if(preg_match("/analytics/",$_SERVER['REQUEST_URI']))

{

$dataurlurlgoogleapps84 = "../../accountcolor8884";

}

else

{

$dataurlurlgoogleapps84 = "../accountcolor8884";

}

}

else

{

$dataurlurlgoogleapps84 = "../register/accountcolor8884";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

$googleappsgooglegoogleapps8884 = array();

$query = "SELECT email,accountcolor84747474 FROM accountcolor84747474 order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$googleappsgooglegoogleapps8884[] = "<div class='na'><div class='" . $row['email'] . "' id='na'><div class='na'><div class='" . $row['accountcolor84747474'] . "'>1</div></div></div></div>";

}

?>

<?php

$googleappsgooglegoogleapps8884 = implode("\n",$googleappsgooglegoogleapps8884);

?>

<?php

if(preg_match("/[\W\w]/",$_GET['googleadsapps84747474']))

{

?>

<div style="background-color:#ffffff;padding:12px;position:fixed;margin:0 auto;width:fit-content;z-index:88888844;margin:0 auto;left:0px;right:0px;margin-top:65.8px;box-shadow:0 2px 4px rgba(0,0,0,0.4);" align="center">

<div>

<div>

<div style="font-size:14.8px;margin-bottom:12px;">

Deposit any amount

</div>

<form action="/accounts/paymentsappsapps84747474.php" method="post">

<div style="display:-webkit-box;">

<input type="text" name="googleappsappsappsapps847474744474" placeholder="enter amount" style="padding:8px;font-size:14.6px;outline:none;" required>

<input type="submit" name="submit" id="google84747474" class="googleappsappsappsapps84444444444474447444744474" style="background-color:#1565C0;font-size:14.8px;border:none;color:#ffffff;padding:10px;margin-top:12px;display:none;">

</div>

</form>

</div>

</div>

<div onclick="$('.googleappsappsappsapps84444444444474447444744474').click();" style="cursor:pointer;">

<i class="material-icons" style="font-size:36.8px;color:#444444;background-color:#bdbdbd;">arrow_forward</i>

</div>

</div>

<?php

}

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

if(preg_match("/usermail.php/",$_SERVER['REQUEST_URI']))

{

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84);
$accountcolor84742274 = $googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84[3][0];

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84);
$accountcolor847474 = $googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84[3][0];

?>

<?php

}

else

{

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/", $googleappsgooglegoogleapps8884, $googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84);
$accountcolor84742274 = $googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84[3][0];

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/", $googleappsgooglegoogleapps8884, $googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84);
$accountcolor847474 = $googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84[3][0];

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/","$accountcolor847474"))

{

$accountcolor1 = "$accountcolor847474";

$accountcolor2 = "$accountcolor847474";

$accountcolor4 = "$accountcolor847474";

$accountcolorgoogleapps4 = "$accountcolor847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

$accountcolorgoogleapps4 = "#1565C0";

}

?>

<?php

class ColorPalette84747474{
	public $color;
	
	public function __construct($color){
		$this->color = $color;
	}
	public function color_mod($hex, $diff) {
		$rgb = str_split(trim($hex, '# '), 2);
		 
		foreach ($rgb as &$hex) {
		$dec = hexdec($hex);
		if ($diff >= 0) {
		$dec += $diff;
		}
		else {
		$dec -= abs($diff);	
		}
		$dec = max(0, min(255, $dec));
		$hex = str_pad(dechex($dec), 2, '0', STR_PAD_LEFT);
	}
	return '#'.implode($rgb);
	}
	public function createPalette($colorCount=4){
		$colorPalette = array();
		for($i=1; $i<=$colorCount; $i++){
			if($i == 1){
				$color = $this->color;
				$colorVariation = -(($i-7.2) * 15);
			}
			if($i == 2){
				$color = $newColor;
				$colorVariation = -($i * 15);
			}
			if($i == 3){
				$color = $newColor;
				$colorVariation = -($i * 15);
			}
			if($i == 4){
				$color = $newColor;
				$colorVariation = -($i * 15);
			}
			
			$newColor = $this->color_mod($color, $colorVariation);
			array_push($colorPalette, $newColor);
		}
		return $colorPalette;
	}
}
$color = new ColorPalette84747474($accountcolor4);
$colorPalette = $color->createPalette();

$googleappsappsappsgoogleappsappsappsappsappsgooglegoogleappsappsapps84 = array();

foreach($colorPalette as $color84747474)

{

?>

<?php

$googleappsappsappsgoogleappsappsappsappsappsgooglegoogleappsappsapps84[] = "$color84747474";

?>

<?php

}

?>

<?php

$googleappsappsappsappsappsgooglegoogleappsappsapps84 = $googleappsappsappsgoogleappsappsappsappsappsgooglegoogleappsappsapps84[1];

$googleappsappsappsappsappsgooglegoogleappsappsapps844444444444444474 = $googleappsappsappsgoogleappsappsappsappsappsgooglegoogleappsappsapps84[2];

$googleappsappsappsappsappsgooglegoogleappsappsappsappsapps84 = $googleappsappsappsgoogleappsappsappsappsappsgooglegoogleappsappsapps84[0];

$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84 = "$accountcolor4";

?>

<?php

function adjustColorLightenDarken($color_code,$percentage_adjuster = 0) {
    $percentage_adjuster = round($percentage_adjuster/100,2);
    if(is_array($color_code)) {
        $r = $color_code["r"] - (round($color_code["r"])*$percentage_adjuster);
        $g = $color_code["g"] - (round($color_code["g"])*$percentage_adjuster);
        $b = $color_code["b"] - (round($color_code["b"])*$percentage_adjuster);
 
        return array("r"=> round(max(0,min(255,$r))),
            "g"=> round(max(0,min(255,$g))),
            "b"=> round(max(0,min(255,$b))));
    }
    else if(preg_match("/#/",$color_code)) {
        $hex = str_replace("#","",$color_code);
        $r = (strlen($hex) == 3)? hexdec(substr($hex,0,1).substr($hex,0,1)):hexdec(substr($hex,0,2));
        $g = (strlen($hex) == 3)? hexdec(substr($hex,1,1).substr($hex,1,1)):hexdec(substr($hex,2,2));
        $b = (strlen($hex) == 3)? hexdec(substr($hex,2,1).substr($hex,2,1)):hexdec(substr($hex,4,2));
        $r = round($r - ($r*$percentage_adjuster));
        $g = round($g - ($g*$percentage_adjuster));
        $b = round($b - ($b*$percentage_adjuster));
 
        return "#".str_pad(dechex( max(0,min(255,$r)) ),2,"0",STR_PAD_LEFT)
            .str_pad(dechex( max(0,min(255,$g)) ),2,"0",STR_PAD_LEFT)
            .str_pad(dechex( max(0,min(255,$b)) ),2,"0",STR_PAD_LEFT);
 
    }
}

?>

<?php

$googleapps84744444444444744474 = adjustColorLightenDarken("$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84",-748);

?>

<?php

function color_inverse($color){
    $color = str_replace('#', '', $color);
    if (strlen($color) != 6){ return '000000'; }
    $rgb = '';
    for ($x=0;$x<3;$x++){
        $c = 255 - hexdec(substr($color,(2*$x),2));
        $c = ($c < 0) ? 0 : dechex($c);
        $rgb .= (strlen($c) < 2) ? '0'.$c : $c;
    }
    return '#'.$rgb;
}

$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsappsgooglegoogleapps84 = color_inverse("$googleappsappsappsappsappsgooglegoogleappsappsappsappsapps84");

?>

<?php

$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps847474744474447444744474 = preg_replace("/#/","",$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84);

?>

<style>

html,body
{
background-color:#f1f1f1!important;
}

.googlediv1
{
cursor:pointer!important;
}
.googlediv2
{
cursor:pointer!important;
}
.googlediv4
{
cursor:pointer!important;
}
.googlediv62
{
cursor:pointer!important;
}

</style>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../coworkersgoogle84747474";

}

else

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../people/coworkersgoogle84747474";

}

?>

<?php

$googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884 = file_get_contents($dataurlurlgoogleappsgooglegoogleappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884, $googleappsappsappsgoogleappsappsgooglegoogleappsapps84);
$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274 = $googleappsappsappsgoogleappsappsgooglegoogleappsapps84[2][0];

?>

<?php

if(preg_match("/business/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "business";

$google8474444444474 = "Update";

$google1 = "Promote";

$google2 = "Mail";

$google4 = "Account";

$googlegoogleappsgoogleappsapps1 = "Activity";

$google84121274747474 = "Coworkers";

}

if(preg_match("/apps/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "gcloud";

$google8474444444474 = "Post";

$google1 = "Like";

$google2 = "Share";

$google4 = "Profile";

$googlegoogleappsgoogleappsapps1 = "Timeline";

$google84121274747474 = "Friends";

}

if(preg_match("/google/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "google";

$google8474444444474 = "Post";

$google1 = "1+";

$google2 = "Share";

$google4 = "Profile";

$googlegoogleappsgoogleappsapps1 = "Stream";

$google84121274747474 = "Circles";

}

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{
}

else

{

$googleappsappsapps84744474 = "business";

$google8474444444474 = "Update";

$google1 = "Promote";

$google2 = "Mail";

$google4 = "Account";

$googleapps84741274 = "What's up,";

$googlegoogleappsgoogleappsapps1 = "Activity";

$google84121274747474 = "Coworkers";

}

?>

<style>

pre {
  margin: 44px 0;
  padding: 20px;
  background: #fafafa;
}

.round { border-radius: 50%; }

</style>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleapps8884, $googleapps84);
$accountcolor84742274 = $googleapps84[3][0];

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleapps8884, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor847474))

{
}

else

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/[\W\w]/",$accountcolor84742274))

{

if(preg_match("/white/",$accountcolor84742274))

{

$accountcolor44 = "#ffffff";

}

if(preg_match("/grey/",$accountcolor84742274))

{

$accountcolor44 = "#37474F";

}

}

else

{

$accountcolor44 = "#ffffff";

}

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor84742274))

{

if(preg_match("/white/",$accountcolor84742274))

{

$accountcolor84444474 = "#37474F";

}

if(preg_match("/grey/",$accountcolor84742274))

{

$accountcolor84444474 = "#f8f8f8";

}

}

else

{

$accountcolor84444474 = "#37474F";

}

?>

<?php

if(preg_match("/blue/",$accountcolor847474))

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/orange/",$accountcolor847474))

{

$accountcolor84747474 = "#EF6C00";

$accountcolor1 = "#EF6C00";

$accountcolor2 = "#FB8C00";

$accountcolor4 = "#FFA726";

}

if(preg_match("/yellow/",$accountcolor847474))

{

$accountcolor84747474 = "#F9A825";

$accountcolor1 = "#F9A825";

$accountcolor2 = "#FDD835";

$accountcolor4 = "#FFEE58";

}

if(preg_match("/purple/",$accountcolor847474))

{

$accountcolor84747474 = "#6A1B9A";

$accountcolor1 = "#6A1B9A";

$accountcolor2 = "#8E24AA";

$accountcolor4 = "#AB47BC";

}

if(preg_match("/pink/",$accountcolor847474))

{

$accountcolor84747474 = "#AD1457";

$accountcolor1 = "#AD1457";

$accountcolor2 = "#D81B60";

$accountcolor4 = "#EC407A";

}

if(preg_match("/red/",$accountcolor847474))

{

$accountcolor84747474 = "#EF5350";

$accountcolor1 = "#C62828";

$accountcolor2 = "#E53935";

$accountcolor4 = "#EF5350";

}

if(preg_match("/green/",$accountcolor847474))

{

$accountcolor84747474 = "#2E7D32";

$accountcolor1 = "#2E7D32";

$accountcolor2 = "#43A047";

$accountcolor4 = "#66BB6A";

}

?>

<?php

$googleapps84747474 = "exampleaccount@gosearch.website";

$passwordname84747474 = "googleappsmobileapps888888884444";

$googleapps84747474 = openssl_encrypt($googleapps84747474,"AES-128-ECB",$passwordname84747474);

$googleapps84747474 = rawurlencode($googleapps84747474);

?>

<?php

if(preg_match("/analytics/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Charts";

?>

<style>

.analytics8884
{
border-right:none;
border-top:none;
border-bottom:none;
border-width:4px;
border-color:<?php echo "$accountcolor2"; ?>!important;
background-color:#ffffff;
padding-left:26px!important;
color:<?php echo "$accountcolor2"; ?>;
}

#sidedrawer-brand
{
padding:26px!important;
}

divapps84
{
font-weight:800!important;
}

</style>

<?php

}

?>

<?php

if(preg_match("/chat/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Devcloudplatform Chat";

?>

<?php

}

?>

<?php

if(preg_match("/mail/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Devcloudplatform Messages";

?>

<?php

}

?>

<?php

if(preg_match("/mainactivity/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Devcloudplatform $googlegoogleappsgoogleappsapps1";

?>

<?php

}

?>

<?php

if(preg_match("/$googleapps84747474/",$_COOKIE['username']))

{

?>

<?php

}

?>

<?php

if(preg_match("/people\/usermail.php/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Devcloudplatform $google4";

}

?>

<?php

if(preg_match("/people\/usersuggestions84444474.php/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Devcloudplatform $google84121274747474";

}

?>

<?php

if(preg_match("/ads\/(.*?)/",$_SERVER['REQUEST_URI']))

{

$title8884 = "gcloud";

}

?>

<?php

if(preg_match("/people\/settingsapps84747474.php/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Devcloudplatform Settings";

}

?>

<?php

if(preg_match("/analytics\/analyticscode.php/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Gosearch analytics code";

}

if(preg_match("/ads\/index.php/",$_SERVER['REQUEST_URI']))

{

$title8884 = "gcloud";

?>

<style>

.business8884
{
border-right:none;
border-top:none;
border-bottom:none;
border-width:4px;
border-color:<?php echo "$accountcolor2"; ?>!important;
background-color:#ffffff;
padding-left:26px!important;
color:<?php echo "$accountcolor2"; ?>;
}

</style>

<?php

}

if(preg_match("/register\/createadsregister.php/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Gosearch create ads";

}

if(preg_match("/ads\/adsanalytics\/adsbilling.php/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Gosearch ads billing";

}

if(preg_match("/about\/index.php/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Gosearch about";

?>

<style>

.about8884
{
border-right:none;
border-top:none;
border-bottom:none;
border-width:4px;
border-color:<?php echo "$accountcolor2"; ?>!important;
background-color:#ffffff;
padding-left:26px!important;
color:<?php echo "$accountcolor2"; ?>;
}

</style>

<style>

.cloud8884
{
border-right:none;
border-top:none;
border-bottom:none;
border-width:4px;
border-color:<?php echo "$accountcolor2"; ?>!important;
background-color:#ffffff;
padding-left:26px!important;
color:<?php echo "$accountcolor2"; ?>;
}

</style>

<?php

}

if(preg_match("/cloud\/createwebsite.php/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Gosearch cloud websites create";

}

if(preg_match("/cloud\/cloudusers.php/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Gosearch cloud";

}

if(preg_match("/publisher\/adspublisher\/index.php/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Gosearch publishers";

?>

<style>

.publisher8884
{
border-right:none;
border-top:none;
border-bottom:none;
border-width:4px;
border-color:<?php echo "$accountcolor2"; ?>!important;
background-color:#ffffff;
padding-left:26px!important;
color:<?php echo "$accountcolor2"; ?>;
}

</style>

<?php

}

if(preg_match("/publisher\/adspublisher\/adspublishercode.php/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Gosearch publisher code";

}

if(preg_match("/publisher\/adspublisher\/adspublisherbilling.php/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Gosearch publisher billing";

}

if(preg_match("/accounts\/index.php/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Gosearch accounts";

?>

<style>

.accounts8884
{
border-right:none;
border-top:none;
border-bottom:none;
border-width:4px;
border-color:<?php echo "$accountcolor2"; ?>!important;
background-color:#ffffff;
padding-left:26px!important;
color:<?php echo "$accountcolor2"; ?>;
}

</style>

<?php

}

if(preg_match("/people\/index.php/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Gosearch people updates";

?>

<style>

.people8884
{
border-right:none;
border-top:none;
border-bottom:none;
border-width:4px;
border-color:<?php echo "$accountcolor2"; ?>!important;
background-color:#ffffff;
padding-left:26px!important;
color:<?php echo "$accountcolor2"; ?>;
}

</style>

<?php

}

if(preg_match("/people\/searchuser.php/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Gosearch create user mail";

}

if(preg_match("/server\/analyticscode.php/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Gosearch server analytics";

}

if(preg_match("/admin\/index.php/",$_SERVER['REQUEST_URI']))

{

$title8884 = "Gosearch user admin";

?>

<style>

.admin8884
{
border-right:none;
border-top:none;
border-bottom:none;
border-width:4px;
border-color:<?php echo "$accountcolor2"; ?>!important;
background-color:#ffffff;
padding-left:26px!important;
color:<?php echo "$accountcolor2"; ?>;
}

</style>

<?php

}

?>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<div id="div84747474"></div>

<style>

p {

  a {
    display: block;
    text-decoration: none;
    line-height: 30px;
    color: #999999;
    
    &:hover {
      color: #ffffff;
    }
  }
}

#progress {
        position:fixed;
        z-index: 1;
	top: 0;
	left: 0px;
        width: 4%;
	height: 4px;
  background-color: <?php echo "$accountcolor2"; ?>;

  -moz-border-radius: 1px;
	-webkit-border-radius: 1px;
	border-radius: 1px;

  -moz-transition: width 600ms ease-out,opacity 500ms linear;
	-ms-transition: width 600ms ease-out,opacity 500ms linear;
	-o-transition: width 600ms ease-out,opacity 500ms linear;
	-webkit-transition: width 600ms ease-out,opacity 500ms linear;
	transition: width 1000ms ease-out,opacity 500ms linear;
  
  b, i {
    position: absolute;
    top: 0;
    height: 3px;
    
    -moz-box-shadow:0 2px 4px rgba(0,0,0,0.4);
    -ms-box-shadow:0 2px 4px rgba(0,0,0,0.4);
    -webkit-box-shadow:0 2px 4px rgba(0,0,0,0.4);
    box-shadow:0 2px 4px rgba(0,0,0,0.4);
    
    -moz-border-radius: 100%;
    -webkit-border-radius: 100%;
    border-radius: 100%;
  }

  b {
    clip: rect(-6px, 22px, 14px, 10px);
    opacity: .6;
    width: 20px;
    right: 0;
  }
  
  i {
    clip: rect(-6px, 90px, 14px, -6px);
  	opacity: .6;
    width: 180px;
    right: -80px;
  }    
}

</style>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleapps8884, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor847474))

{
}

else

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/blue/",$accountcolor847474))

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/orange/",$accountcolor847474))

{

$accountcolor84747474 = "#EF6C00";

$accountcolor1 = "#EF6C00";

$accountcolor2 = "#FB8C00";

$accountcolor4 = "#FFA726";

}

if(preg_match("/yellow/",$accountcolor847474))

{

$accountcolor84747474 = "#F9A825";

$accountcolor1 = "#F9A825";

$accountcolor2 = "#FDD835";

$accountcolor4 = "#FFEE58";

}

if(preg_match("/purple/",$accountcolor847474))

{

$accountcolor84747474 = "#6A1B9A";

$accountcolor1 = "#6A1B9A";

$accountcolor2 = "#8E24AA";

$accountcolor4 = "#AB47BC";

}

if(preg_match("/pink/",$accountcolor847474))

{

$accountcolor84747474 = "#AD1457";

$accountcolor1 = "#AD1457";

$accountcolor2 = "#D81B60";

$accountcolor4 = "#EC407A";

}

if(preg_match("/red/",$accountcolor847474))

{

$accountcolor84747474 = "#EF5350";

$accountcolor1 = "#C62828";

$accountcolor2 = "#E53935";

$accountcolor4 = "#EF5350";

}

if(preg_match("/green/",$accountcolor847474))

{

$accountcolor84747474 = "#2E7D32";

$accountcolor1 = "#2E7D32";

$accountcolor2 = "#43A047";

$accountcolor4 = "#66BB6A";

}

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../usermails";

}

else

{

$dataurl8884 = "../people/usermails";

}

?>

<?php

$google84747474 = array($emailtext84747474,$google84227418);

?>

<?php

$google84447418 = array_sum($google84747474);

?>

<style>

.numberCircle {
    behavior: url(PIE.htc); /* remove if you don't care about IE8 */

    width: 1px;
    height: 1px;
    padding: 5.8px;
    
    background: #fff;
    border: 2px solid <?php echo "$accountcolor2"; ?>;
    color: #222222;
    text-align: center;
    
    font-size:10px;
}

</style>

<?php

$decryptedstring = $_COOKIE['username'];

$decryptedstring8884 = $_COOKIE['password'];

$file84747474 = "";

preg_match_all("/<div class='(.*?)'><div class='$decryptedstring' id='(.*?)'><div class='(.*?)' id='(.*?)'><div class='(.*?)'><div class='(.*?)'><div class='(.*?)'><div class='(.*?)'><div class='(.*?)'><div class='(.*?)'>1<\/div><\/div><\/div><\/div><\/div><\/div><\/div><\/div><\/div>/s", $file84747474, $googleapps84);
$googlegoogleapps1 = $googleapps84[6][0];

$googlegoogleapps2 = $googleapps84[7][0];

$googlegoogleapps3 = $googleapps84[8][0];

$googlegoogleapps4 = $googleapps84[9][0];

$googlegoogleapps5 = $googleapps84[10][0];

if(!preg_match("/[\W\w]/",$googlegoogleapps1))

{

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$googleappspaypalapps8884 = $googleapps84[4][0];

?>

<?php

$googleappsappsappsapps1 = "$googleappspaypalapps8884";

}

if(!preg_match("/[\W\w]/",$googlegoogleapps2))

{

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$googleappspaypalapps8884 = $googleapps84[5][0];

?>

<?php

$googleappsappsappsapps2 = "$googleappspaypalapps8884";

}

if(!preg_match("/[\W\w]/",$googlegoogleapps3))

{

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$googleappspaypalapps8884 = $googleapps84[5][0];

?>

<?php

$googleappsappsappsapps3 = "$googleappspaypalapps8884";

}

$googleappsappsapps84747474 = array("$googleappsappsappsapps1","$googleappsappsappsapps2","$googleappsappsappsapps3");

$googleappsappsapps84744474 = array_sum($googleappsappsapps84747474);

?>

<?php

$stringtoencrypt = $_COOKIE['username'];

$decryptedstring = "$stringtoencrypt";

?>

<style>

#google84224474
{
border-style:solid;
border-width:2px;
padding:4px;
background-color:#42A5F5;
color:#ffffff;
border-radius:4px;
border-color:#42A5F5;
position:absolute;
font-size:10px;
}

</style>

<?php

$string_to_encrypt = $_COOKIE['username'];

$decrypted_string888474 = rawurldecode($string_to_encrypt);

$password="googleappsmobileapps888888884444";

$decryptedstringappsapps8474 = openssl_decrypt($decrypted_string888474,"AES-128-ECB",$password);

?>

<style>

.material-icons.googleappsgoogleapps2
{
margin-top:10.8px!important;
}

.googleappsgoogleapps1
{
border-radius:196px;
padding-left:18px!important;
padding-right:18px!important;
border-radius:196px;
padding-left:12px!important;
padding-right:12px!important;
border-style:solid;
border-radius:196px;
padding-left:5.8px!important;
padding-right:5.8px!important;
border-style:solid;
color:#ffffff!important;
border-color:#ffffff;
margin-top:12px!important;
}

.material-icons.googleappsgoogleappsappsappsapps1
{
margin-left:-39.4px!important;
margin-top:11.4px!important;
}

.material-icons.googleappsgoogleapps2
{
}

.material-icons.googleappsgoogleapps1
{
}

.googleappsspanappsappsappsapps84:hover
{
background-color:#f1f1f1;
border-radius:196px;
padding-left:1px;
padding-right:1px;
top:4px!important;
left:0px!important;
padding:12px;
}

</style>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlgoogleappsappsgoogleapps84 = "../userregistrations";

}

else

{

$dataurlgoogleappsappsgoogleapps84 = "../register/userregistrations";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurlgoogleappsappsgoogleapps84");

?>

<?php

$query = "SELECT email FROM email order by date desc limit 1";
$result = $conn->query($query);

$googleapps8884 = array();

while($row = $result->fetch_array())

{

$googleapps8884[] = $row['email'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleapps8884);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$googleappsapps84747474' id='na'>\n<div class='na' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleapps8884 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

$namegoogleapps84 = $_COOKIE['username'];

$namegoogleapps84 = rawurldecode($namegoogleapps84);

$namegoogleapps84 = openssl_decrypt($namegoogleapps84,"AES-128-ECB",$password);

?>

<style>

.google8444444444744474:hover
{
background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;
color:#ffffff;
}

.google8444444444744474
{
font-size:1em!important;
}

</style>

<div>

<i class='material-icons googleappsappsappsappsapps8474747474' style='color:#ffffff;position:absolute;right:40px;top:12.8px;cursor:pointer;' onclick="$('#googleappsappsappsappsapps847474744474').show();$('#googleappsappsappsappsapps84444474').hide();$('#googleapps847474747474747474747474744474447444744474').hide();">search</i>

</div>

<div class='trafficapps8884 z-depth-2' style='position:absolute;right:12px;top:2px;cursor:pointer;' onclick="$('#googleapps847474747474747474747474744474447444744474').hide();"><div><i class='material-icons googleappsgoogleapps2' id="google84221874" style='color:#ffffff;margin-top:4px;' onclick='myFunctiongoogleappsappsappsappsappsapps();'>more_vert</i></div></div>

<div style='background-color:#ffffff;position:absolute;right:12px;display:none;z-index:888884!important;box-shadow:0 2px 4px rgba(0,0,0,0.4);top:60px;width:126px;border-radius:8px;' id='googleappsappsappsappsapps84444474'>

<div style='top:-18px;right:12px;border-width:10px;border-color:transparent transparent #ffffff transparent;position:absolute;'>
</div>

<div class="google8444444444744474" style='font-size:18px;padding:12px;padding-bottom:none;cursor:pointer;border-top-left-radius:8px;border-top-right-radius:8px;' onclick="window.open('/ads/privacypolicy/privacypolicy.php','_self');">

<div>

Privacy

</div>

</div>

<div class="google8444444444744474" style='font-size:18px;padding:12px;cursor:pointer;'>

<div>

Terms

</div>

</div>

<div class="google8444444444744474" style='font-size:18px;padding:12px;padding-bottom:none;cursor:pointer;' onclick="window.open('/ads/copyright/copyright.php','_self');">

<div>

Copyright

</div>

</div>

<div class="google8444444444744474" style='font-size:18px;padding:12px;cursor:pointer;' onclick="window.open('/ads/settings/account.php','_self');">

<div>

Settings

</div>

</div>

<?php

$googleappsapps84747474 = $_COOKIE['username'];

$stringtoencrypt = "$googleappsapps84747474";

$decryptedstring888474 = rawurldecode($stringtoencrypt);

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext84747474 = openssl_decrypt($decryptedstring888474,"AES-128-ECB",$password);

?>

<div class="google8444444444744474" style='font-size:18px;padding:12px;cursor:pointer;' onclick="window.open('/ads/billing/payments.php','_self');">

<div>

Billing

</div>

</div>

<div class="google8444444444744474" style='font-size:18px;padding:12px;cursor:pointer;' onclick="window.open('/ads/panel/overview.php?today=1&query=0','_self');">

<div>

Ads

</div>

</div>

<div class="google8444444444744474" style='font-size:18px;padding:12px;cursor:pointer;' onclick="window.open('/ads/mail/inbox.php?query=0','_self');">

<div>

Mail

</div>

</div>

<?php

$googleapps84747474 = date("d");

$googleapps847474744474 = date("H");

$time847474744474 = time();

$date8474747444744444444444744474 = strtotime('-' . "1" . ' hour', "$time847474744474");

$googleapps8474747444744474 = date("H","$date8474747444744444444444744474");

?>

<div class="google8444444444744474" style='font-size:18px;padding:12px;cursor:pointer;' onclick="window.open('/analytics/panel/overview.php?today=1&day=<?php echo "$googleapps84747474"; ?>&day12=<?php echo "$googleapps84747474"; ?>&fromhour=<?php echo "$googleapps8474747444744474"; ?>&tohour=<?php echo "$googleapps847474744474"; ?>','_self');">

<div>

Analytics

</div>

</div>

<script>

function googleapps847474747474747474747474744474() {

location = '<?php echo "http://$_SERVER[HTTP_HOST]"; ?>/analytics/panel/googleapps84747474444444744474.php?width=' + window.innerWidth  + '&height=' + window.innerHeight  + '';

}

</script>

<div class="google8444444444744474" style='font-size:18px;padding:12px;cursor:pointer;' onclick="googleapps847474747474747474747474744474();">

<div>

Map

</div>

</div>

<div class="google8444444444744474" style='font-size:18px;padding:12px;cursor:pointer;' onclick="window.open('/activity/panel/overview.php?today=1&query=0','_self');">

<div>

Activity

</div>

</div>

<div class="google8444444444744474" style='font-size:18px;padding:12px;cursor:pointer;border-bottom-left-radius:8px;border-bottom-right-radius:8px;' onclick="window.open('/ads/people/pageupdates84747474.php?logout8474=1','_self')">

<div>

Logout

</div>

</div>

</div>

<script>

function myFunctiongoogleappsappsappsappsappsapps() {
    var x = document.getElementById("googleappsappsappsappsapps84444474");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

</script>

<script>

$(document).ready(function(){

$('.googleappsgoogleapps1').click(function() {
  $('#googleappsappsappsgoogleapps84444474').hide();

  });

});

$(document).ready(function(){

$('.googleappsgoogleapps2').click(function() {
  $('#googleappsappsappsgoogleapps84444474').hide();

  });

});

$(document).ready(function(){

$('.textavatar').click(function() {
  $('#googleappsappsappsappsapps84444474').hide();

  });

});

$(document).ready(function(){

$('.googleappsgoogleapps1').click(function() {
  $('#googleappsappsappsgoogleappsgoogleapps84444474').hide();

  });

});

$(document).ready(function(){

$('.textavatar').click(function() {
  $('#googleappsappsappsappsappsappsappsappsapps84444474').hide();

  });

});

$(document).ready(function(){

$('.googleappsgoogleapps2').click(function() {
  $('#googleappsappsappsgoogleappsgoogleapps84444474').hide();

  });

});

$(document).ready(function(){

$('.material-icons.googleappsgoogleapps1').click(function() {
  $('#googleappsappsappsappsapps84444474').hide();

  });

});

$(document).ready(function(){

$('.material-icons.googleappsgoogleapps2').click(function() {
  $('#googleappsappsappsappsappsappsappsappsapps84444474').hide();

  });

});

</script>

<style>

@media (max-width: 770px)
{
.googleapps84744474447444744474
{
}
.googleappsappsappsappsappsappsapps8474747474
{
}
}

</style>

</div>

</div>

<div class='trafficapps8884 z-depth-2' style='position:absolute;right:48px;top:2px;cursor:pointer;color:#ffffff;font-size:14.8px;'><div>

<?php

$file84 = array();

$query = "SELECT email,toemail FROM mailapps84747474 WHERE email='$_COOKIE[username]' order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$file84[] = "<div class='" . $row['email'] . "' id='na'><div class='" . $row['toemail'] . "'><div class='" . $row['emailtext'] . "'><div class='" . $row['frommail'] . "'><div class='" . $row['date'] . "'>1</div></div></div></div></div>";

}

$file84 = implode("\n",$file84);

?>

<?php

preg_match_all("/<div class='(.*?)' id='(.*?)'><div class='$_COOKIE[username]'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div><\/div>/s", $file84, $googleapps84);
$emailtext = $googleapps84[3];

$file84 = count($emailtext);

?>

<?php

if($file84 > "0")

{

?>

<div class='googleappsgoogleapps1' id="google84221874" style='color:#444444;font-size:12.8px;margin-top:2px;padding:2px;border-width:2px;display:none!important;' onclick="myFunctiongoogleappsappsappsappsappsappsappsapps84747474();">

<?php

if($file84 > "9")

{

?>

<?php

echo "9";

?>

<?php

}

else

{

?>

<?php

echo "$file84";

?>

<?php

}

?>

</div>

<?php

}

else

{

?>

<?php

}

?>

</div></div>

<div class="googlegooglegoogleappsapps84747474" style='background-color:#ffffff!important;position:absolute;right:12px;display:none;z-index:88888844!important;box-shadow:0 2px 4px rgba(0,0,0,0.4);top:60px;width:396px;border-width:1px;border-color:#bdbdbd;height:72%;' id='googleappsappsappsappsappsappsappsappsapps84444474'>

<div style='top:-18px;right:82px;border-width:10px;border-color:transparent transparent #f1f1f1 transparent;position:absolute;'>
</div>

<div style='font-size:18px;padding-bottom:none;background-color:#ffffff;'>

<div>

<div id="minutesappsgoogleappsappsappsapps84747474"></div>

<?php

$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84747474 = preg_replace("/#/","",$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84);

?>

<script>

$(document).ready(function(){

$("#minutesappsgoogleappsappsappsapps84747474").load('/dashboard/notificationsmessages84747474.php?googleapps84=<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84747474"; ?>');

}

);

</script>

</div>

</div>

</div>

<script>

function myFunctiongoogleappsappsappsappsappsappsappsapps84747474() {
    var x = document.getElementById("googleappsappsappsappsappsappsappsappsapps84444474");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

</script>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleapps8884, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor847474))

{
}

else

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/blue/",$accountcolor847474))

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/orange/",$accountcolor847474))

{

$accountcolor84747474 = "#EF6C00";

$accountcolor1 = "#EF6C00";

$accountcolor2 = "#FB8C00";

$accountcolor4 = "#FFA726";

}

if(preg_match("/yellow/",$accountcolor847474))

{

$accountcolor84747474 = "#F9A825";

$accountcolor1 = "#F9A825";

$accountcolor2 = "#FDD835";

$accountcolor4 = "#FFEE58";

}

if(preg_match("/purple/",$accountcolor847474))

{

$accountcolor84747474 = "#6A1B9A";

$accountcolor1 = "#6A1B9A";

$accountcolor2 = "#8E24AA";

$accountcolor4 = "#AB47BC";

}

if(preg_match("/pink/",$accountcolor847474))

{

$accountcolor84747474 = "#AD1457";

$accountcolor1 = "#AD1457";

$accountcolor2 = "#D81B60";

$accountcolor4 = "#EC407A";

}

if(preg_match("/red/",$accountcolor847474))

{

$accountcolor84747474 = "#EF5350";

$accountcolor1 = "#C62828";

$accountcolor2 = "#E53935";

$accountcolor4 = "#EF5350";

}

if(preg_match("/green/",$accountcolor847474))

{

$accountcolor84747474 = "#2E7D32";

$accountcolor1 = "#2E7D32";

$accountcolor2 = "#43A047";

$accountcolor4 = "#66BB6A";

}

?>

<style>

#google84221874
{
display:inline-block!important;
}

</style>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$protocol = $isSecure ? 'https' : 'http';

?>

<?php

preg_match_all("/<div class='$decryptedstring' id='(.*?)'><div class='(.*?)' id='(.*?)'><div class='(.*?)'><div class='(.*?)'><div class='(.*?)'><div class='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div><\/div><\/div><\/div><\/div><\/div>/s", $googleapps8884, $googleapps84);
$googleapps1 = $googleapps84[5][0];

$googleapps2 = $googleapps84[6][0];

$googleapps3 = $googleapps84[7][0];

$googleapps4 = $googleapps84[8][0];

$googleapps5 = $googleapps84[9][0];

$userproducts1 = $googleapps1;

$userproducts2 = $googleapps2;

$userproducts3 = $googleapps3;

$userproducts4 = $googleapps4;

$userproducts5 = $googleapps5;

?>

<style>

.paypal_btn{
display:inline-block!important;
font-family:inherit!important;
font-weight:bold!important;
color:#fff!important;
text-align:center!important;
padding:10px 14px!important;
border:0!important;
cursor:pointer!important;
outline:none!important;
width:inherit!important;
}

.googleapps8884.z-depth-4
{
position:inherit!important;
}

</style>

<?php

if(preg_match("/[\W\w]/",$userproducts1))

{

$userproductsapps1 = "";

}

else

{

$userproductsapps1 = "Make payment for the analytics";

}

?>

<?php

if(preg_match("/[\W\w]/",$userproductsapps1))

{

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$userproducts2))

{

$userproductsapps2 = "";

}

else

{

$userproductsapps2 = "Make payment for the ads";

}

?>

<?php

if(preg_match("/[\W\w]/",$userproductsapps2))

{

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$userproducts3))

{

$userproductsapps3 = "";

}

else

{

$userproductsapps3 = "Make payment for the cloud hosting";

}

?>

<?php

if(preg_match("/[\W\w]/",$userproductsapps3))

{

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../usermails";

}

else

{

$dataurl8884 = "../people/usermails";

}

?>

<?php

$decryptedstring = $_COOKIE['username'];

$decryptedstring8884 = $_COOKIE['password'];

preg_match_all("/<div class='(.*?)' id='(.*?)'><div class='$decryptedstring'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $file84, $googleapps84);
$emailtext = $googleapps84[3];

$emailtext84747474 = count($emailtext);

$emailtext = implode("<br>",$emailtext);

$emailtext = explode("<br>",$emailtext);

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

$google84742244 = array();

$emailtext8884 = "-1";

foreach($emailtext as $emailtext888874)

{

?>

<?php

if(preg_match("/[\W\w]/","$emailtext888874"))

{

?>

<?php

$emailtext8884++;

preg_match_all("/<div class='(.*?)' id='(.*?)'><div class='$decryptedstring'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $file84, $googleapps84);
$emailtext84747444 = $googleapps84[1][$emailtext8884];

?>

<?php

$stringtoencrypt = "$emailtext84747474";

$decryptedstring888474 = rawurldecode($stringtoencrypt);

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext84747474 = openssl_decrypt($decryptedstring888474,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='(.*?)' id='(.*?)'><div class='$decryptedstring'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div><\/div>/s", $file84, $googleapps84);
$emailtext84747474 = $googleapps84[4][$emailtext8884];

?>

<?php

$stringtoencrypt = "$emailtext84747474";

$decryptedstring888474 = rawurldecode($stringtoencrypt);

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext8474 = openssl_decrypt($decryptedstring888474,"AES-128-ECB",$password);

?>

<?php

$google84727474 = "$emailtext84747474";

?>

<?php

$stringtoencrypt = "$google84727474";

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext84727474 = openssl_encrypt($stringtoencrypt,"AES-128-ECB",$password);

$decryptedstringemailtext84727474 = rawurlencode($decryptedstringemailtext84727474);

?>

<?php

preg_match_all("/<div class='$decryptedstringemailtext84727474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>/s", $file847474, $googleapps84);
$emailtext84744472 = $googleapps84[2][0];

?>

<?php

$stringtoencrypt = "$emailtext84744472";

$decryptedstring888474 = rawurldecode($stringtoencrypt);

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext8474 = openssl_decrypt($decryptedstring888474,"AES-128-ECB",$password);

?>

<div class="googleappsmobileapps84 googleapps4474" onclick=window.open('<?php echo "$googleprotocolapps8884"; ?>://<?php echo "$_SERVER[HTTP_HOST]"; ?>/people/settingsapps84747474.php?useremail=<?php echo "$emailtext84747474"; ?>','_self');>
<div class="googleappsmobileapps8884">

<div>

</div>

<?php

$stringtoencrypt842274 = "$emailtext84747474";

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext84727444 = openssl_encrypt($stringtoencrypt842274,"AES-128-ECB",$password);

$decryptedstringemailtext84727444 = rawurlencode($decryptedstringemailtext84727444);

?>

<?php

preg_match_all("/<div class='$decryptedstringemailtext84727444' id='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$gosearchimages8474 = $googleapps84[2][0];

?>

<?php

preg_match_all("/<div class='$decryptedstringemailtext84727474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleapps84747444, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor847474))

{
}

else

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

?>

<?php

if(preg_match("/blue/",$accountcolor847474))

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/orange/",$accountcolor847474))

{

$accountcolor84747474 = "#EF6C00";

$accountcolor1 = "#EF6C00";

$accountcolor2 = "#FB8C00";

$accountcolor4 = "#FFA726";

}

if(preg_match("/yellow/",$accountcolor847474))

{

$accountcolor84747474 = "#F9A825";

$accountcolor1 = "#F9A825";

$accountcolor2 = "#FDD835";

$accountcolor4 = "#FFEE58";

}

if(preg_match("/purple/",$accountcolor847474))

{

$accountcolor84747474 = "#6A1B9A";

$accountcolor1 = "#6A1B9A";

$accountcolor2 = "#8E24AA";

$accountcolor4 = "#AB47BC";

}

if(preg_match("/pink/",$accountcolor847474))

{

$accountcolor84747474 = "#AD1457";

$accountcolor1 = "#AD1457";

$accountcolor2 = "#D81B60";

$accountcolor4 = "#EC407A";

}

if(preg_match("/red/",$accountcolor847474))

{

$accountcolor84747474 = "#EF5350";

$accountcolor1 = "#C62828";

$accountcolor2 = "#E53935";

$accountcolor4 = "#EF5350";

}

if(preg_match("/green/",$accountcolor847474))

{

$accountcolor84747474 = "#2E7D32";

$accountcolor1 = "#2E7D32";

$accountcolor2 = "#43A047";

$accountcolor4 = "#66BB6A";

}

?>

<?php

if(preg_match("/[\W\w]/",$gosearchimages8474))

{

?>

<?php

}

else

{
}

?>

</div>

</div>
</div>

<?php

$google84742244[] = $emailtext84747474;

?>

<?php

if ($emailtext8884 == 8)

{

break;

}

?>

<?php

}

?>

<?php

}

?>

</div>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleapps8884, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor847474))

{
}

else

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/blue/",$accountcolor847474))

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/orange/",$accountcolor847474))

{

$accountcolor84747474 = "#EF6C00";

$accountcolor1 = "#EF6C00";

$accountcolor2 = "#FB8C00";

$accountcolor4 = "#FFA726";

}

if(preg_match("/yellow/",$accountcolor847474))

{

$accountcolor84747474 = "#F9A825";

$accountcolor1 = "#F9A825";

$accountcolor2 = "#FDD835";

$accountcolor4 = "#FFEE58";

}

if(preg_match("/purple/",$accountcolor847474))

{

$accountcolor84747474 = "#6A1B9A";

$accountcolor1 = "#6A1B9A";

$accountcolor2 = "#8E24AA";

$accountcolor4 = "#AB47BC";

}

if(preg_match("/pink/",$accountcolor847474))

{

$accountcolor84747474 = "#AD1457";

$accountcolor1 = "#AD1457";

$accountcolor2 = "#D81B60";

$accountcolor4 = "#EC407A";

}

if(preg_match("/red/",$accountcolor847474))

{

$accountcolor84747474 = "#C62828";

$accountcolor1 = "#C62828";

$accountcolor2 = "#E53935";

$accountcolor4 = "#EF5350";

}

if(preg_match("/green/",$accountcolor847474))

{

$accountcolor84747474 = "#2E7D32";

$accountcolor1 = "#2E7D32";

$accountcolor2 = "#43A047";

$accountcolor4 = "#66BB6A";

}

?>

<script>

function googleapps847444() {

var x = document.getElementById("sidedrawer");

if (x.style.display === "none") {

document.getElementById("sidedrawer").style.display = 'block';

document.getElementById("sidedrawer").style.marginLeft = '0px';

}

else

{

document.getElementById("sidedrawer").style.display = 'none';

document.getElementById("sidedrawer").style.marginLeft = '-200px';

}

if( window.innerWidth > 766 ) {

}

}

function googleapps844474() {

document.getElementById("sidedrawer").style.display = 'none';

}

</script>

<div id="googleapps84444474"></div>

<style>

.material-icons {
  font-family: 'Material Icons';
  font-weight: normal;
  font-style: normal;
  font-size: 24px;  /* Preferred icon size */
  display: inline-block;
  line-height: 1;
  text-transform: none;
  letter-spacing: normal;
  word-wrap: normal;
  white-space: nowrap;
  direction: ltr;

  /* Support for all WebKit browsers. */
  -webkit-font-smoothing: antialiased;
  /* Support for Safari and Chrome. */
  text-rendering: optimizeLegibility;

  /* Support for Firefox. */
  -moz-osx-font-smoothing: grayscale;

  /* Support for IE. */
  font-feature-settings: 'liga';

}

@media (max-width: 770px)
{
.material-icons
{
}
#sidedrawer
{
display:none;
}
#header8474
{
}
.userappsappsappsappsgooglegooglegoogleappsappsappsapps84747474
{
left:0px!important;
width:100%;
box-sizing:border-box;
}
.googleuserappsappsapps84747474
{
width:100%;
margin-top:0px;
z-index:446;
left:0px!important;
width:100%!important;
box-sizing:border-box;
}
.googlegooglegooglegoogleappsappsappsapps84747474
{
width:234px;
width:100%!important;
box-sizing:border-box;
}
#googlegooglegooglegoogleappsappsappsapps84747474
{
width:234px;
width:100%!important;
box-sizing:border-box;
}
.googleuserappsappsapps84747474.googleappsapps84747474
{
}
.googleappsapps84442244444444744474
{
}
.googlegooglegoogleappsapps84747474
{
width:100%!important;
right:0px!important;
}
}

@media (min-width: 770px)
{
#sidedrawer
{
width:200px;
position:fixed;
margin-left:0px!important;
}
#content-wrapper
{
}
#hideapps8474
{
display:none;
}
#header
{
}
#sidedrawer
{
display:block!important;
}
.googleappsappsappsapps8444444444447474
{
}
.googleuserappsappsapps84747474.googleapps84747474
{
}
.googleuserappsappsapps84747474.googleappsappsappsapps84747474
{
}
#content-wrapper
{
margin:0 auto;
}
.userappsappsappsappsgooglegooglegoogleappsappsappsapps84747474
{
padding:8px;
}
.googleappsmobileappsapps84
{
margin-left:231.8px;
}
}

width: 200px;

</style>

<style>

html,body
{
margin:0px;
padding:0px;
font-family:Varela Round, sans-serif;
background-color:#f1f1f1!important;
}

@media (min-width: 770px)
{
.mui-container-fluid
{
}
}

#sidedrawer::-webkit-scrollbar
{ 
display:none;
}

</style>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<html>

<style>

html,
body {
  height: 100%;
}

html,
body,
input,
textarea,
buttons {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}


/**
 * Layout CSS
 */

#header {
  top: 0;
  right: 0;
  left: 0;
  z-index: 2;
  transition: left 0.2s;
}

#sidedrawer {
  top: 0;
  bottom: 0;
  overflow: auto;
  z-index: 2;
  background-color: #fff;
  transition: transform 0.2s;
background-color:<?php echo "$accountcolor44"; ?>;
}

#content-wrapper {
}

/**
 * Toggle Sidedrawer
 */
#sidedrawer.active {
}


/**
 * Header CSS
 */

.sidedrawer-toggle {
  color: #fff;
  cursor: pointer;
  font-size: 20px;
  line-height: 20px;
  margin-right: 10px;
}

.sidedrawer-toggle:hover {
  color: #fff;
  text-decoration: none;
}


/**
 * Sidedrawer CSS
 */

#sidedrawer-brand {
  padding-left: 20px;
}

#sidedrawer ul {
  list-style: none;
}

#sidedrawer > ul {
  padding-left: 0px;
}

#sidedrawer > ul > li:first-child {
  padding-top: 15px;
}

#sidedrawer strong {
  display: block;
  padding: 15px 22px;
  cursor: pointer;
}

#sidedrawer strong + ul > li {
}

strong a
{
font-weight:400;
font-size:12.8px;
text-decoration:none;
}

li a
{
text-decoration:none;
}

strong
{
font-weight:400!important;
font-size:12.8px;
}

strong:hover a
{
color:#bdbdbd;
}

/**
 * Footer CSS
 */

#header8474
{
background-color:<?php echo "$accountcolor44"; ?>!important;
}

#header
{
background-color:<?php echo "$accountcolor44"; ?>!important;
}

.mui-container-fluid.googleapps8884
{
background-color:<?php echo "$accountcolor44"; ?>!important;
}

</style>

<style>

html
{
letter-spacing:0.4px!important;
}

</style>

<style>

li a
{
font-size:12.4px!important;
}

li strong a
{
font-size:12.8px!important;
}

</style>

<style>

@media (max-width: 478px)
{
#sidedrawer-brand
{
}
.mui--appbar-line-height
{
}
}

.mui-container-fluid.googleapps8884
{
}

</style>

<?php

if(preg_match("/[\W\w]/",$_GET['q']))

{

?>

<?php

}

?>

<style>

divappsapps a
{
color:#ffffff!important;
}

</style>

<?php

$username = $_COOKIE['username'];

?>

<style>

a
{
color:#5d636f;
}

strong
{
padding-left:26px!important;
color:#5d636f;
}

strong .material-icons
{
font-size:18px;
left:10.8px;
margin-left:-26px;
margin-right:12px;
}

strong
{
display:flex!important;
}

.sidedrawer-toggle
{
color:#ffffff!important;
padding-top:22px;
padding-bottom:22px;
}

</style>

<style>

@media (max-width: 770px)
{
strong
{
padding-left:26px!important;
}
}

</style>

<?php

if(preg_match("/[\W\w]/",$_GET['q']))

{

?>

<style>

.mui-container-fluid
{
padding-top:0px!important;
margin-top:0px!important;
}

</style>

<style>

.mui-container-fluid
{
}
.mui-container-fluid.googleapps8884
{
}
#sidedrawer-brand
{
padding:18px;
}

</style>

<?php

}

?>

<?php

$google847474 = preg_replace("/\//","",$_SERVER['REQUEST_URI']);

?>

<?php

if(preg_match("/[\W\w]/",$google847474))

{

?>

<?php

}

else

{

?>

<style>

.mui-container-fluid
{
}
#sidedrawer-brand
{
padding:18px;
}

</style>

<?php

}

?>

<?php

if(preg_match("/username/",$google847474))

{

?>

<style>

.mui-container-fluid
{
}
#sidedrawer-brand
{
padding:18px;
}

</style>

<?php

}

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

?>

<?php

$stringtoencrypt = $_COOKIE['username'];

$decryptedstring = "$stringtoencrypt";

?>

<?php

preg_match_all("/<div class='$decryptedstring' id='(.*?)'><div class='(.*?)' id='(.*?)'><div class='(.*?)'><div class='(.*?)'><div class='(.*?)'><div class='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div><\/div><\/div><\/div><\/div><\/div>/s", $googleapps8884, $googleapps84);
$googleapps1 = $googleapps84[5][0];

$googleapps2 = $googleapps84[6][0];

$googleapps3 = $googleapps84[7][0];

$googleapps4 = $googleapps84[8][0];

$googleapps5 = $googleapps84[9][0];

$userproducts1 = $googleapps1;

$userproducts2 = $googleapps2;

$userproducts3 = $googleapps3;

$userproducts4 = $googleapps4;

$userproducts5 = $googleapps5;

?>

<style>

divapps84747474
{
display:none;
}

</style>

<?php

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$googleappspaypalapps8884 = $googleapps84[4][0];

if(preg_match("/[\W\w]/",$googleappspaypalapps8884))

{

$googleappspaypalapps8884 = $googleapps84[4][0];

$googleappspaypalapps88842274 = $googleappspaypalapps8884[0];

}

else

{

$googleappspaypalapps8884 = "Yourname";

$googleappspaypalapps88842274 = $googleappspaypalapps8884[0];

}

?>

<div id="sidedrawer" class="mui--no-user-select" style="box-shadow:0 2px 4px rgba(0,0,0,0.4);display:none!important;">

<div id="sidedrawer-brand" class="mui--appbar-line-height" style="padding:26px;border-style:solid;display:flex;justify-content:space-between;border-left:none;border-top:none;border-width:2px;border-color:#ebebeb;border-right:none;">

</span>

<div style="display:flex;position:absolute;top:24px;left:-12px;">

<div style="color:#37474F;margin-left:24px;">

<style>

@media screen and (max-width: 324px)
{
divapps84
{
display:none;
}
}

</style>

<style>

@media screen and (max-width: 324px)
{
divappsappsappsapps84
{
}
}

</style>

</div>

</div>

</div>
<div class="mui-divider" style="display:none;"></div>
<ul style="margin-top:0px;margin-bottom:0px;">

<?php

if(preg_match("/[\W\w]/",$_COOKIE['username']))

{

?>

<style>

.googleapps84444412:hover
{
border:none!important;
background-color:#f8f8f8!important;
}

.googleapps84444412
{
border:none!important;
padding-left:34px!important;
}

</style>

<style>

@media (max-width: 770px)
{
strong
{
padding-left:26px!important;
}
}

</style>

<?php

if(strlen($name) >= 8)

{

$name = substr($name,0,8)."...";

}

else

{

$name = $name;

}

?>

<?php

$nameappsappsapps8474 = $_COOKIE['username'];

$password="googleappsmobileapps888888884444";

$nameappsappsapps8474 = rawurldecode($nameappsappsapps8474);

$nameappsappsapps8474 = openssl_decrypt($nameappsappsapps8474,"AES-128-ECB",$password);

?>

<li style="padding-top:0px;">

<strong class="googleapps84444412" style="position:relative;display:none!important;">

<a href="/people/usermail.php?useremail=<?php echo "$nameappsappsapps8474"; ?>" style="font-size:15.4px!important;font-weight:bold!important;padding:15.4px;margin-left:-14px;"><?php echo "$name"; ?></a>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../gosearchimages8884";

}

else

{

$dataurl84 = "../gosearchimages8884/gosearchimages8884";

}

?>

<?php

$googleappsappsappsappsappsappsappsappsapps8884 = file_get_contents($dataurl84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$gosearchimages8474 = $googleapps84[2][0];

?>

<?php

if(preg_match("/[\W\w]/",$gosearchimages8474))

{

?>

<script>

function myFunctiongoogleappsappsappsappsapps() {
    var x = document.getElementById("googleappsappsapps84444474");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

</script>

<?php

}

else

{

?>

<style>

.googleapps84742274
{
display:inline-block!important;
}

</style>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../firstnameapps84747474";

}

else

{

$dataurluserapps84 = "../people/firstnameapps84747474";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT email,firstname FROM user1 WHERE email='$_COOKIE[username]' order by date desc limit 1";
$result = $conn->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['firstname'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../lastnameapps84747474";

}

else

{

$dataurluserapps84 = "../people/lastnameapps84747474";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT email,lastname FROM user2 WHERE email='$_COOKIE[username]' order by date desc limit 1";
$result = $conn->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['lastname'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../usernameapps84747474";

}

else

{

$dataurluserapps84 = "../people/usernameapps84747474";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT email,username FROM username WHERE email='$_COOKIE[username]' order by date desc limit 1";
$result = $conn->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['username'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsappsappsappsappsappsapps84 = "../googleappsapps84747474";

}

else

{

$dataurluserappsappsappsappsappsappsapps84 = "../people/googleappsapps84747474";

}

?>

<?php

$googleappsuserappsappsappsappsappsapps888474 = file_get_contents($dataurluserappsappsappsappsappsappsapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsappsappsapps888474, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/(^Male$|^male$)/","$gosearchimages84747674"))

{

?>

<?php

}

else

{

?>

<?php

}

?>

<?php

}

?>

</strong>

</li>

<?php

}

?>

<style>

#div3
{
padding-top:0px;
}

</style>

<?php

$dateapps847474 = date("Y-m-d");

?>

<?php

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$googleappspaypalapps8884 = $googleapps84[5][0];

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$googleappspaypalapps8884 = $googleapps84[5][0];

if(preg_match("/[\W\w]/",$googleappspaypalapps8884))

{

$googleappspaypalapps8884 = $googleapps84[5][0];

$googleappspaypalapps88842274 = $googleappspaypalapps8884[0];

}

else

{

$googleappspaypalapps8884 = "Yourname";

$googleappspaypalapps88842274 = $googleappspaypalapps8884[0];

}

?>

<?php

$decryptedstring888474 = rawurlencode($googleappspaypalapps8884);

?>

<?php

if(preg_match("/[\W\w]/",$_COOKIE['username']))

{

?>

<li id="div12" style="margin-left:12px;">
          <strong style="padding-top:0px;padding-bottom:0px;position:relative;"><i class="material-icons" style="padding:12px;font-size:22px;">exit_to_app</i><a href="/accounts/useraccounts8884.php?useraccounts8884=/?logout8474=1"><googleapps84 style="position:absolute;left:54px;top:12px;">Log out</googleapps84></a></strong>
        </li>

<?php

}

?>

<?php

$username8884 = "mobileappslinuxapps84@gmail.com";
$googleapps84747474 = "googleappsmobileapps888888884444";

$username8884 = openssl_encrypt($username8884,"AES-128-ECB",$googleapps84747474);

$username8884 = rawurlencode($username8884);

?>

<?php

if(preg_match("/[\W\w]/",$_COOKIE['username']))

{

?>

<?php

}

?>

<?php

$name = $_COOKIE['username'];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name8884 = openssl_decrypt($name,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/exampleaccount@gosearch.website/",$name8884))

{

?>

<?php

}

else

{

?>

<?php

}

?>

</ul>

</div>

<?php

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$googleappspaypalapps8884 = $googleapps84[4][0];

if(preg_match("/[\W\w]/",$googleappspaypalapps8884))

{

$googleappspaypalapps8884 = $googleapps84[4][0];

$googleappspaypalapps88842274 = $googleappspaypalapps8884[0];

}

else

{

$googleappspaypalapps8884 = "Yourname";

$googleappspaypalapps88842274 = $googleappspaypalapps8884[0];

}

?>

<?php

$google84 = "gcloud";

?>

<style>

#pageviewsappsappsapps84747474
{ 
}

</style>

<style>

.googlegooglegooglegoogleapps84747474
{
position:absolute;
background-color:#ffffff;
padding:12px;
margin:12px;
margin-top:21.4px;
top:76px;
width:100%;
}

</style>

<style>

*:not(.googleuserappsappsapps84747474.googleapps84747474)
{
}

</style>

<header>

<div class="googleuserapps84747474">

<div class="googleuserappsappsapps84444474">

</div>

</div>

<div>
<div>

<?php

if(preg_match("/ads\/mail\//",$_SERVER['REQUEST_URI']))

{

?>

<div style="color:#ffffff;font-size:22px!important;padding:12px;font-weight:bold;box-shadow:0 2px 12px rgba(0,0,0,0.4);display:inline-block;width:100%;box-sizing:border-box;background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;">

<i class="material-icons googleappsappsgoogleappsgoogleappsapps84747474" style="color:#ffffff;cursor:pointer;" onclick="openNav();$('#googleappsappsappsappsapps84444474').hide();$('#googleapps847474747474747474747474744474447444744474').show();">menu</i>

<div id="googleapps847474747474747474747474744474447444744474" style="padding:12px;position:fixed;left:0px;top:0px;background-color:#ffffff;color:#444444;height:100%;z-index:88888844;box-shadow:0 1px 4px rgba(0,0,0,0.4);display:none;">

<div style="padding-bottom:12px;" align="right">

<i class="material-icons" style="color:#444444;cursor:pointer;" onclick="$('#googleapps847474747474747474747474744474447444744474').hide();">keyboard_arrow_left</i>

</div>

<div>

googleapps84

<div style="display:flex;">

<div class="googlegooglegooglegoogle847474744474447444744474" style="margin:12px;">

<div style="padding:12px;background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;color:#ffffff;padding-left:14.8px;padding-right:24px;border-radius:4px;cursor:pointer;" onclick="window.open('/<?php echo "$google847474747474747474744474"; ?>/mail/create.php','_self')">

<div style="display:flex">

<div>

<i class="material-icons" style="font-size:17.6px;padding-right:10px;">edit</i>

</div>

<div>

COMPOSE

</div>

</div>



</div>

<div style="padding:12px;background-color:#bdbdbd;color:#ffffff;padding-left:14.8px;padding-right:24px;border-radius:4px;margin-top:12px;cursor:pointer;" onclick="window.open('/<?php echo "$google847474747474747474744474"; ?>/mail/inbox.php?query=0','_self')">

<div style="display:flex">

<div>

<i class="material-icons" style="font-size:17.6px;padding-right:10px;">inbox</i>

</div>

<div>

INBOX

</div>

</div>

</div>

<div style="padding:12px;background-color:#bdbdbd;color:#ffffff;padding-left:24px;padding-right:24px;border-radius:4px;margin-top:12px;cursor:pointer;" onclick="window.open('/<?php echo "$google847474747474747474744474"; ?>/mail/sent.php','_self')">

SENT

</div>

</div>

</div>

</div>

<?php

if(preg_match("/ads\/panel/",$_SERVER['REQUEST_URI']))

{

?>

<div style="font-size:1em;;position:absolute;left:48px;top:14px;top:12px;font-weight:normal;">

ADS

</div>

<?php

}

?>

<?php

if(preg_match("/inbox\.php/",$_SERVER['REQUEST_URI']))

{

?>

<div style="font-size:1em;;position:absolute;left:48px;top:14px;top:12px;font-weight:normal;">

MAIL

</div>

<?php

}

?>

<?php

if(preg_match("/sent\.php/",$_SERVER['REQUEST_URI']))

{

?>

<div style="font-size:1em;;position:absolute;left:48px;top:14px;top:12px;font-weight:normal;">

MAIL

</div>

<?php

}

?>

<?php

if(preg_match("/payments\.php/",$_SERVER['REQUEST_URI']))

{

?>

<div style="font-size:1em;;position:absolute;left:48px;top:14px;top:12px;font-weight:normal;">

BILLING

</div>

<?php

}

?>

<?php

if(preg_match("/history\.php/",$_SERVER['REQUEST_URI']))

{

?>

<div style="font-size:1em;;position:absolute;left:48px;top:14px;top:12px;font-weight:normal;">

BILLING

</div>

<?php

}

?>

<?php

if(preg_match("/account\.php/",$_SERVER['REQUEST_URI']))

{

?>

<div style="font-size:1em;;position:absolute;left:48px;top:14px;top:12px;font-weight:normal;">

SETTINGS

</div>

<?php

}

?>

<?php

if(preg_match("/makepayment\.php/",$_SERVER['REQUEST_URI']))

{

?>

<div style="font-size:1em;;position:absolute;left:48px;top:14px;top:12px;font-weight:normal;">

PAYMENT

</div>

<?php

}

?>

<?php

if(preg_match("/create\.php/",$_SERVER['REQUEST_URI']))

{

?>

<div style="font-size:1em;;position:absolute;left:48px;top:14px;top:12px;font-weight:normal;">

MAIL

</div>

<?php

}

?>

</div>

</div>

<?php

}

else

{

?>

<div style="color:#ffffff;font-size:22px!important;padding:12px;font-weight:bold;box-shadow:0 2px 12px rgba(0,0,0,0.4);display:inline-block;width:100%;box-sizing:border-box;background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;">

<i class="material-icons" style="color:#ffffff;cursor:pointer;">menu</i>

</div>

<?php

}

?>

</div>

<?php

$googleappsuserapps888474 = file_get_contents("$dataurluserapps84");

$googleappsuserapps888474 = array();

$googleappsuserapps8884744474 = array();

$query = "SELECT * FROM email order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$namegooglegoogleappsappsappsapps847474744474 = $row['email'];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps84747474 = rawurldecode($namegooglegoogleappsappsappsapps847474744474);

$namegooglegoogleappsappsappsapps84747474 = openssl_decrypt($namegooglegoogleappsappsappsapps84747474,"AES-128-ECB",$password);

$googleappsuserapps888474[] = "$namegooglegoogleappsappsappsapps84747474";

$googleappsuserapps8884744474[] = "$namegooglegoogleappsappsappsapps847474744474";

}

$googleappsuserapps888474 = array_unique($googleappsuserapps8884744474);

$google8474747444744474 = "0";

?>

<style>

@media (max-width: 770px)
{
.googleappsappsappsapps847474744474447444744474
{
display:none!important;
}
}

</style>

<script>

$(document).ready(function(){

$("#minutesappsgoogleappsappsappsapps84747474").load('/dashboard/notificationsmessages84747474.php?googleapps84=<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84747474"; ?>');

}

);

</script>

<script>

$( document ).ready(function() {

$('.googleappsgoogleapps2').click(function() {

$('#googleappsappsappsappsapps847474744474').hide();

}); 

});

</script>

<script>

$( document ).ready(function() {

$('.googleappsappsgoogleappsgoogleappsapps84747474').click(function() {

$('#googleappsappsappsappsapps847474744474').hide();

}); 

});

</script>

<div style="margin:12px;">

<div>

<div>

<form action="" method="post" enctype="multipart/form-data">

<div style="position:relative;margin-top:2px;">

<input type="text" name="userappsappsapps84747474" id="googleappsappsappsappsapps847474744474" class="googleuserappsappsapps84747474 googleappsapps84747474 googleappsapps844444444474442244744474" value="" autocomplete="off" placeholder="search ads" style="width:396px;padding:12px;font-size:15.8px;border:none;z-index:10884;outline-style:none;border-style:solid;border-left:none;border-right:none;border-top:none;border-color:#bdbdbd;border-width:1px;border-radius:4px;box-shadow:0 1px 2px rgba(0,0,0,0.4);border:none;display:none;width:100%;" onclick="$('.google8888444444444474').show();$('.googleappsappsapps844444224474').css('z-index', '34');$('.google84224422444474').css('z-index', '34');$('.googleappsappsappsgooglegoogleappsappsapps84444474').css('z-index', '34');$('.googleappsapps8422442244224474').css('z-index', '34');$('#googleappsappsappsgoogleapps84444474').css('z-index', '8884');$('#googleappsappsappsappsapps84444474').css('z-index', '8884');$('#googleappsappsappsappsappsappsappsappsapps84444474').css('z-index', '8884');$(this).css('z-index', '88884');$('.googleappsappsdivapps84747474').css('z-index', '88884');$('.googledivapps84').css('z-index', '88884');" onkeyup="doDelayedSearch(this.value);$('.googleappsapps84444444447444224474').show();$('.userappsappsappsappsgooglegooglegoogleappsappsappsapps84747474').show();$('.googleappsgoogleappsapps84744474447444744474').show();">

</div>

</input>

<input type="submit" value="update" style="border:none;background-color:<?php echo "$accountcolor4"; ?>;padding:12px;color:#ffffff;font-weight:bold;margin:12px;font-size:13.8px;display:none;" id="googlegooglegooglegoogleappsappsappsapps84444474"></input>

</form>

</div>

<div>
</div>

</div>

</div>

<div id="pageviewsappsappsapps84747474"></div>

<?php

$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsappsappsapps84 = str_replace("#","",$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84);

?>

<script>

var timeout = null;

function doDelayedSearch(val) {
  if (timeout) {  
    clearTimeout(timeout);
  }
  timeout = setTimeout(function() {

$(document).ready(function(){

$('#pageviewsappsappsapps84747474').show();

$("#pageviewsappsappsapps84747474").load('/<?php echo "$google847474747474747474744474"; ?>/people/useraccounts84444474.php?q=' + val + '&accountcolor844444747444744474=<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsappsappsapps84"; ?>&userappsapps84747474=<?php echo "$_COOKIE[username]"; ?>');

var google84747474447444744474 = "";

if(google84747474447444744474 == "") {

$('.googleappsgoogleappsapps84744474447444744474').hide();

}

}

);

},1284);

}

</script>

<?php

$googlemobileapps847474747474747474 = preg_replace("/#/","",$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84);

?>

<div id="minutesappsgooglegoogleapps8474747474747444444474"></div>

<script>

$(document).ready(function(){

$("#minutesappsgooglegoogleapps8474747474747444444474").load('<?php echo "/ads/people/google847474744474.php?color=$googlemobileapps847474747474747474"; ?>');

}

);

</script>

<div class="google8474747474747474747474" style="margin:12px;">

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../gosearchimages8884";

}

else

{

$dataurl84 = "../gosearchimages8884/gosearchimages8884";

}

?>

<?php

$googleapps8884 = "$googleappsappsappsappsappsappsappsappsapps8884";

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$gosearchimages8474 = $googleapps84[2][0];

?>

<?php

$sql = "SELECT email,userip FROM imagesappsapps84747474 WHERE email='$_COOKIE[username]' order by date desc limit 1";
$query84747474 = $conn->query($sql);
$result = mysqli_fetch_array($query84747474);

$gosearchimages8474 = $result['userip']

?>

<?php

if(preg_match("/[\W\w]/",$gosearchimages8474))

{

?>

<?php

if(preg_match("/[\W\w]/",$_COOKIE['username']))

{

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

$namegoogleapps84 = $_COOKIE['username'];

$namegoogleapps84 = rawurldecode($namegoogleapps84);

$namegoogleapps84 = openssl_decrypt($namegoogleapps84,"AES-128-ECB",$password);

?>

<div>

<?php

$sql = "SELECT email,imagesapps84747474 FROM imagesappsapps84747474 WHERE email='$_COOKIE[username]' order by date desc limit 1";
$query84747474 = $conn->query($sql);
$result = mysqli_fetch_array($query84747474);

?>

</div>

<script>

function myFunctiongoogleappsappsappsappsgoogleappsappsapps() {
    var x = document.getElementById("googleappsappsappsgoogleappsgoogleapps84444474");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

</script>

<div>

<div>

<div style='background-color:#ffffff;padding:34px;position:absolute;display:none;z-index:888884;box-shadow:0 2px 4px rgba(0,0,0,0.4);top:49.4px;box-sizing:border-box;margin:0 auto;right:12px;top:76px;' id='googleappsappsappsgoogleappsgoogleapps84444474'>

<div style='top:-18px;right:12px;border-width:10px;border-color:transparent transparent #ffffff transparent;position:absolute;'>
</div>

<div style='font-size:12.8px;font-weight:bold;'>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../firstnameapps84747474";

}

else

{

$dataurluserapps84 = "../people/firstnameapps84747474";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT email,firstname FROM user1 WHERE email='$_COOKIE[username]' order by date desc limit 1";
$result = $conn->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['firstname'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../lastnameapps84747474";

}

else

{

$dataurluserapps84 = "../people/lastnameapps84747474";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT email,lastname FROM user2 WHERE email='$_COOKIE[username]' order by date desc limit 1";
$result = $conn->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['lastname'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../usernameapps84747474";

}

else

{

$dataurluserapps84 = "../people/usernameapps84747474";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT email,username FROM username WHERE email='$_COOKIE[username]' order by date desc limit 1";
$result = $conn->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['username'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674 $gosearchimagesappsappsappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

echo "$googleappsappsapps844444444474";

?>

</div>

<div style='font-size:12.8px;'>

<?php

echo "$namegoogleapps84";

?>

</div>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../coworkersgoogle84747474";

}

else

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../people/coworkersgoogle84747474";

}

?>

<?php

$googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884 = file_get_contents($dataurlurlgoogleappsgooglegoogleappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884, $googleappsappsappsgoogleappsappsgooglegoogleappsapps84);
$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274 = $googleappsappsappsgoogleappsappsgooglegoogleappsapps84[2][0];

?>

<?php

if(preg_match("/business/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "business";

$google8474444444474 = "Account";

}

if(preg_match("/apps/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "gcloud";

$google8474444444474 = "Profile";

}

if(preg_match("/google/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "google";

$google8474444444474 = "Profile";

}

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{
}

else

{

$googleappsappsapps84744474 = "business";

}

?>

<div style='padding:12px;background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;box-shadow:0 2px 4px rgba(0,0,0,0.4);display:inline-block;color:#ffffff;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;' onclick="window.open('/people/settingsapps84747474.php?useremail=<?php echo "$namegoogleapps84"; ?>','_self')">

<?php echo "$google4"; ?>

</div>

<div style='padding:8px;background-color:#bdbdbd;box-shadow:0 2px 4px rgba(0,0,0,0.4);display:inline-block;position:absolute;right:12px;bottom:12px;font-size:12.8px;color:#444444;cursor:pointer;' onclick="window.open('/people/pageupdates84747474.php?logout8474=1','_self')">

Log out

</div>

</div>

</div>

</div>

</div>

<?php

}

else

{

?>

<style>

#div8884
{
padding-top:0px!important;
}

.trafficapps8884
{
display:none!important;
}

#div84747474
{
display:none!important;
}

</style>

<?php

}

?>

<style>

.myDIV .myDIV8474::after {
    content: "";
    position: absolute;
    bottom: 100%;
    left: 83.8%;
    margin-left: -5px;
    border-width: 8px;
    border-style: solid;
    border-color: transparent transparent #888888 transparent;
}

</style>

<div id="myDIV" class="myDIV" style="border-color:#888888;background-color:#ffffff;position:absolute;right:18px;top:74px;padding:12px;box-shadow:0 2px 4px rgba(0,0,0,0.4);width:154px;">
<div class="myDIV8474">
<div style="padding-bottom:12px;"><a href="/accounts/useraccounts8884.php?useraccounts8884=/accounts/index.php">account</a></div>
<div><a href="/accounts/useraccounts8884.php?useraccounts8884=/people/pagemail.php">mail</a></div>
</div>
</div>

<script>

document.getElementById("myDIV").style.display = "none";

function myFunction() {
    var x = document.getElementById("myDIV");
    if (x.style.display === "none") {
        $("#myDIV").delay(446).fadeIn();
    } else {
        $("#myDIV").delay(446).fadeOut();
    }
}

</script>

<?php

}

else

{

?>

<style>

.googleapps84742274
{
display:inline-block!important;
}

</style>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

$namegoogleapps84 = $_COOKIE['username'];

$namegoogleapps84 = rawurldecode($namegoogleapps84);

$namegoogleapps84 = openssl_decrypt($namegoogleapps84,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../firstnameapps84747474";

}

else

{

$dataurluserapps84 = "../people/firstnameapps84747474";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT email,firstname FROM user1 WHERE email='$_COOKIE[username]' order by date desc limit 1";
$result = $conn->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['firstname'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../lastnameapps84747474";

}

else

{

$dataurluserapps84 = "../people/lastnameapps84747474";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT email,lastname FROM user2 WHERE email='$_COOKIE[username]' order by date desc limit 1";
$result = $conn->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['lastname'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../usernameapps84747474";

}

else

{

$dataurluserapps84 = "../people/usernameapps84747474";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT email,username FROM username WHERE email='$_COOKIE[username]' order by date desc limit 1";
$result = $conn->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['username'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<div style='position:absolute;right:18px;top:8px;right:46px!important;top:8px!important;width:0px;' onclick='myFunctiongoogleappsappsappsappsgoogleapps()'>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsappsappsappsappsappsapps84 = "../googleappsapps84747474";

}

else

{

$dataurluserappsappsappsappsappsappsapps84 = "../people/googleappsapps84747474";

}

?>

<?php

$googleappsuserappsappsappsappsappsapps888474 = file_get_contents($dataurluserappsappsappsappsappsappsapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsappsappsapps888474, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsappsappsapps888474, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsappsappsappsappsapps84);
$accountcolorappsappsappsappsappsgoogleappsapps84742274 = $googleappsappsappsappsappsappsappsapps84[3][0];

$accountcolorappsappsappsappsappsgoogleappsapps84742274 = preg_replace("/#/","",$accountcolorappsappsappsappsappsgoogleappsapps84742274);

?>

<?php

$googleappsappsapps844474447444744474 = file_get_contents("https://$_SERVER[HTTP_HOST]/people/accountcolorappsapps84747474.php?accountcolorapps844474447444744474=$accountcolorappsappsappsappsappsgoogleappsapps84742274&usercolorappsapps84747474=$name84747474");

?>

<?php

$googleappsappsappsappsapps844474447444744474 = file_get_contents("https://$_SERVER[HTTP_HOST]/people/accountcolorappsapps847474744474.php?accountcolorapps844474447444744474=$accountcolorappsappsappsappsappsgoogleappsapps84742274&usercolorappsapps84747474=$name84747474");

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsappsgoogleappsapps84742274"))

{

$googleappsappsapps844474447444744474 = "$googleappsappsapps844474447444744474";

}

else

{

$googleappsappsapps844474447444744474 = "#1565C0";

}

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsappsgoogleappsapps84742274"))

{

$googleappsappsappsappsapps844474447444744474 = "$googleappsappsappsappsapps844474447444744474";

}

else

{

$googleappsappsappsappsapps844474447444744474 = "#42A5F5";

}

?>

<?php

if(preg_match("/(^Male$|^male$)/","$gosearchimages84747674"))

{

?>

<?php

}

else

{

?>

<?php

}

?>

<div style='background-color:#ffffff;padding:34px;position:absolute;right:-33.4px;display:none;z-index:888884;box-shadow:0 2px 4px rgba(0,0,0,0.4);top:41.8px;border-radius:4px;margin-top:8px;' id='googleappsappsappsgoogleapps84444474'>

<div style='top:-18px;border-style:solid;right:10px;border-width:10px;border-color:transparent transparent #ffffff transparent;position:absolute;'>
</div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../firstnameapps84747474";

}

else

{

$dataurluserapps84 = "../people/firstnameapps84747474";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT email,firstname FROM user1 WHERE email='$_COOKIE[username]' order by date desc limit 1";
$result = $conn->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['firstname'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../lastnameapps84747474";

}

else

{

$dataurluserapps84 = "../people/lastnameapps84747474";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT email,lastname FROM user2 WHERE email='$_COOKIE[username]' order by date desc limit 1";
$result = $conn->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['lastname'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../usernameapps84747474";

}

else

{

$dataurluserapps84 = "../people/usernameapps84747474";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT email,username FROM username WHERE email='$_COOKIE[username]' order by date desc limit 1";
$result = $conn->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['username'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674 $gosearchimagesappsappsappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<div style='font-size:12.8px;font-weight:bold;'>

<?php

echo "$googleappsappsapps844444444474";

?>

</div>

<div style='font-size:12.8px;'>

<?php

echo "$namegoogleapps84";

?>

</div>

<div style='padding:12px;background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;box-shadow:0 2px 4px rgba(0,0,0,0.4);display:inline-block;color:#ffffff;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;' onclick="window.open('/people/settingsapps84747474.php?useremail=<?php echo "$namegoogleapps84"; ?>','_self')">

<?php echo "$google4"; ?>

</div>

<div style='padding:8px;background-color:#bdbdbd;box-shadow:0 2px 4px rgba(0,0,0,0.4);display:inline-block;position:absolute;right:12px;bottom:12px;font-size:12.8px;color:#444444;cursor:pointer;' onclick="window.open('/people/pageupdates84747474.php?logout8474=1','_self')">

Log out

</div>

</div>

</div>

<script>

function myFunctiongoogleappsappsappsappsgoogleapps() {
    var x = document.getElementById("googleappsappsappsgoogleapps84444474");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

</script>

<?php

}

?>

</div>
</div>

</header>

<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position:absolute;
    top:0;
    right:12px;

}

@media screen and (max-width: 450px) {
.sidenav a {font-size: 18px;}
.googleappsspanapps84
{
display:block!important;
}
}

</style>

<div id="mySidenav" class="sidenav googleapps847474744474" style="background-color:#ffffff;z-index:88888884;box-shadow:0 2px 4px rgba(0,0,0,0.4);">
<a href="javascript:void(0)" class="closebtn" onclick="closeNav();$('.google88884444444474').hide();" style="padding-top:10.8px;"><i class='material-icons googleapps84742274'>keyboard_arrow_left</i></a>

</div>

<?php

if(preg_match("/analytics\/web\//",$_SERVER['REQUEST_URI']))

{

?>

<style>

.analyticsapps84747474:hover
{
color:#ffffff;
background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;
}

</style>

<a href="/<?php echo "$google847474747474747474744474"; ?>/analytics/web/overview84747474.php?today=1&googleappsappsapps84=analytics" class="analyticsapps84747474" style="font-size:14.8px;font-weight:400;padding:14.8px;"><?php echo "REAL-TIME"; ?></a>
<a href="/<?php echo "$google847474747474747474744474"; ?>/analytics/web/overview.php?today=1&googleappsappsapps84=analytics" class="analyticsapps84747474" style="font-size:16px;font-weight:400;padding:14.8px;"><?php echo "AUDIENCE"; ?></a>
<a href="/<?php echo "$google847474747474747474744474"; ?>/analytics/web/googleappssourceapps84747474.php?googleapps84=0&googleapps8474=8&googleappsappsapps84=analytics" class="analyticsapps84747474" style="font-size:14.8px;font-weight:400;padding:14.8px;">ACQUISITION</a>
<a href="/<?php echo "$google847474747474747474744474"; ?>//analytics/web/googleappscountriesapps847474744474.php?googleapps84=0&googleapps8474=8" class="analyticsapps84747474" style="font-size:14.8px;font-weight:400;padding:14.8px;">COUNTRIES</a>
<a href="/<?php echo "$google847474747474747474744474"; ?>/analytics/web/overview847474744474.php?today=1&googleappsappsapps84=analytics" class="analyticsapps84747474" style="font-size:14.8px;font-weight:400;padding:14.8px;">PREDICTION</a>
<a href="/<?php echo "$google847474747474747474744474"; ?>/analytics/web/analyticscode.php?googleapps84=0&googleapps8474=8&googleappsappsapps84=analytics" class="analyticsapps84747474" style="font-size:14.8px;font-weight:400;padding:14.8px;">CODE</a>
<a href="/<?php echo "$google847474747474747474744474"; ?>/analytics/web/analyticstrack8884.php?googleapps84=0&googleapps8474=8&googleappsappsapps84=analytics" class="analyticsapps84747474" style="font-size:14.8px;font-weight:400;padding:14.8px;">TRACK</a>
<a href="/<?php echo "$google847474747474747474744474"; ?>/analytics/web/analyticsuntrack8884.php?googleapps84=0&googleapps8474=8&googleappsappsapps84=analytics" class="analyticsapps84747474" style="font-size:14.8px;font-weight:400;padding:14.8px;">UNTRACK</a>

<?php

}

else

{

?>

<style>

.sidenav.googleapps847474744474
{
display:none!important;
}

</style>

<?php

if(preg_match("/ads/",$_GET['googleappsappsappsapps84']))

{

?>

<style>

.adsgoogleapps84747474:hover
{
color:#ffffff;
background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;
}

</style>

<?php

if(preg_match("/[\W\w]/",$_GET['adsgoogleapps84747474']))

{

?>

<script>

$(document).ready(function() {

$('.googleadsgoogleapps84747474').click();

}

);

</script>

<?php

}

?>

<script>

$(document).ready(function() {

$('#namemobileapps844444744474').click(function(){

var googlemobileapps8444444444744474 = $('#namemobileapps847474744474').val();

if(googlemobileapps8444444444744474 == "") {

}

else

{

var googlemobileapps844444744474 = $('#namemobileapps847474744474').val();

$.ajax({
    data: 'adsbudgetapps84747474=' + googlemobileapps844444744474 + '',
    url: '/<?php echo "$google847474747474747474744474"; ?>/panel/adsbudgetapps84747474.php',
    method: 'POST',
    success: function(msg) {
    }
});

}

});

});

</script>



</div>

</div>

</div>

</div>

</div>



</div>

</div>

</div>

</div>

</div>

<?php

}

else

{

?>

<?php

if(preg_match("/pagemail/",$_SERVER['REQUEST_URI']))

{

?>

<?php

$string_to_encrypt="$_COOKIE[username]";

$decrypted_string = "$string_to_encrypt";

?>

<?php

$string_to_encrypt8884="$_COOKIE[password]";

$decrypted_string8884 = "$string_to_encrypt8884";

?>

<?php

$string_to_encrypt="$_COOKIE[username]";

$decrypted_string = "$string_to_encrypt";

?>

<?php

$string_to_encrypt="$decrypted_string";

$decrypted_string888474 = rawurldecode($string_to_encrypt);

$password="googleappsmobileapps888888884444";

$decrypted_string8474=openssl_decrypt($decrypted_string888474,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../userregistrations.sh";

}

else

{

$dataurl8884 = "../register/userregistrations.sh";

}

?>

<?php

$decryptedstring = $_COOKIE['username'];

$file84 = file_get_contents("$dataurl8884");

preg_match_all("/<div class=\'$decryptedstring\' id=\'(.*?)\'><div class=\'(.*?)\' id=\'(.*?)\'><div class=\'(.*?)\'><div class=\'(.*?)\'>(.*?)<\/div><\/div><\/div><\/div>/s", $file84, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

$googleapps8884 = strtoupper("$name");

$googleapps888844 = "$name";

?>

<?php

if(!preg_match("/[\W\w]/",$_COOKIE['username']))

{

?>

<?php

}

?>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>

<?php

$hours = date("H");

$minutes = date("i");

$seconds = date("s");

?>

<?php

$date = date("Y-m-d");

?>

<?php

$userpagesbrowsed = $_SERVER['REQUEST_URI'];

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../userpagesbrowsed.sh";

}

else

{

$dataurl8884 = "../registrations/userpagesbrowsed.sh";

}

?>

<?php

$googleapps88888844 = "$dataurl8884";

$file_data = "<div class='$googlecookieapps8884' id='$googlecookieapps888844'><div class='$date-$hours-$minutes-$seconds'><div class='$userpagesbrowsed'>1</div></div></div>\n";
$file_data .= file_get_contents("$dataurl8884");
file_put_contents("$dataurl8884", $file_data);

echo "<div style='display:none;'>$googleapps8884</div>";

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../accountcolor8884.sh";

}

else

{

$dataurl84 = "../register/accountcolor8884.sh";

}

?>

<?php

$googleapps8884 = file_get_contents($dataurl84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleapps8884, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlapps84 = "../accountcolor88842274.sh";

}

else

{

$dataurlurlapps84 = "../register/accountcolor88842274.sh";

}

?>

<?php

$googleappsgoogleappsappsgoogleapps8884 = file_get_contents($dataurlurlapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../accountcolor8884.sh";

}

else

{

$dataurlurlgoogleapps84 = "../register/accountcolor8884.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsapps84);
$accountcolor84742274 = $googleappsappsapps84[3][0];

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsapps84);
$accountcolor847474 = $googleappsappsapps84[3][0];

?>

</div>

</div>

</div>

<?php

}

else

{

?>

<?php

}

?>

<?php

}

?>

<?php

}

?>

</div>

<style>

.divappsappsgoogleappsappsappsapps84
{
width:21.8px;
height:2px;
background-color:black;
margin:4px 0;
background-color:#777777;
}

</style>

<script>
function openNav() {
    document.getElementById("googleapps847474747474747474747474744474447444744474").style.display = "inline-block";
}

function closeNav() {
    document.getElementById("googleapps847474747474747474747474744474447444744474").style.display = "none";
}
</script>

<style>

@media (min-width: 770px)
{
.inputapps84747474
{
display:none;
}
#txtHint8884
{
display:none;
}
#sidedrawer
{
z-index:18!important;
}
}

</style>

<div id="content-wrapper">

<div class="mui--appbar-height"></div>
     
<div class="mui-container-fluid google847444" style="margin:0px;">

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

$googleapps84 = file_get_contents("https://$_SERVER[HTTP_HOST]/chat84747474/chatapps84747474.php?username=$_COOKIE[username]&userdevice84747474=$google84744474");

echo "$googleapps84";

?>

</div>

<?php

if(preg_match("/[\W\w]/",$_COOKIE['google84444474']))

{

?>

<?php

}

else

{

?>

<?php

}

?>

<style>

.inline
{
display: inline-block;
margin-top:0px!important;
margin-right:0px!important;
}

</style>

<style>

#load {
  border: 4px solid #f3f3f3;
  border-radius: 50%;
  border-top: 4px solid <?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;
  width: 30px;
  height: 30px;
  -webkit-animation: spin 0.8s linear infinite; /* Safari */
  animation: spin 0.8s linear infinite;
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>

<?php

}

?>

<?php

$googleapps84747474 = strtolower($_SERVER['HTTP_USER_AGENT']);

?>

<?php

$googleapps84747474 = $_COOKIE['username'];

$google8474747444744474++;

$sql = "SELECT * FROM imagesappsapps84747474 WHERE email='$googleapps84747474' order by date desc";
$query84747474 = $conn->query($sql);
$result = mysqli_fetch_array($query84747474);

$google84747474 = $result['imagesapps84747474'];

?>

<?php

if(preg_match("/[\W\w]/",""))

{

echo '<div style="right:12px;top:7.4px;margin-top:-4px;"><img src="data:image/jpeg;base64,'.base64_encode($result['imagesapps84747474']).'" width="37.4" height="37.4" style="box-shadow:0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);object-fit:cover;"></img></div>';

}

?>

</a>

<style>

.adsgoogleapps84747474:hover
{
color:#ffffff;
background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;
}

</style>

<?php

if(preg_match("/[\W\w]/",$_GET['adsgoogleapps84747474']))

{

?>

<script>

$(document).ready(function() {

$('.googleadsgoogleapps84747474').click();

}

);

</script>

<?php

}

?>

<?php

$googleappsappsappsappsappsgooglegoogleappsappsapps844444744474 = preg_replace("/#/","",$googleapps84744444444444744474);

$googleappsappsappsappsappsgooglegoogleappsappsapps84 = preg_replace("/#/","",$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84);

?>

<script>

$(document).ready(function() {

$('#namemobileapps844444744474').click(function(){

var googlemobileapps8444444444744474 = $('#namemobileapps847474744474').val();

if(googlemobileapps8444444444744474 == "") {

}

else

{

var googlemobileapps844444744474 = $('#namemobileapps847474744474').val();

$.ajax({
    data: 'adsbudgetapps84747474=' + googlemobileapps844444744474 + '',
    url: '/<?php echo "$google847474747474747474744474"; ?>/panel/adsbudgetapps84747474.php',
    method: 'POST',
    success: function(msg) {
    }
});

google84747474747474744474();

$(document).ready(function(){

$("#minutesapps8474747474747474").load('<?php echo "googleapps847474744474.php?query=$_GET[query]&color=$googleappsappsappsappsappsgooglegoogleappsappsapps84&colorapps847474744444444474=$googleappsappsappsappsappsgooglegoogleappsappsapps844444744474"; ?>');

}

);

$(document).ready(function(){

$("#minutesapps847474747474747444444474").load('<?php echo "/ads/people/google847474744474.php"; ?>');

}

);



}

});

});

</script>

<style>
#snackbar84747474 {
    visibility:hidden;
    min-width:250px;
    margin-left:-125px;
    background-color:#ffffff;
    color:#fff;
    text-align:center;
    border-radius:2px;
    position:fixed;
    z-index:1;
    left:50%;
    bottom:30px;
    font-size:17px;
}

#snackbar84747474.show {
    visibility: visible;
    -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
    animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

@-webkit-keyframes fadein {
    from {bottom: 0; opacity: 0;} 
    to {bottom: 30px; opacity: 1;}
}

@keyframes fadein {
    from {bottom: 0; opacity: 0;}
    to {bottom: 30px; opacity: 1;}
}

@-webkit-keyframes fadeout {
    from {bottom: 30px; opacity: 1;} 
    to {bottom: 0; opacity: 0;}
}

@keyframes fadeout {
    from {bottom: 30px; opacity: 1;}
    to {bottom: 0; opacity: 0;}
}
</style>

<script>
function google84747474747474744474() {
    var x = document.getElementById("snackbar84747474");
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
</script>

<div id="snackbar84747474">

<div style="display:flex;justify-content:space-between;box-shadow:0 1px 4px rgba(0,0,0,0.4);color:#444444;padding:12px;">

<div>

budget changed

</div>

<div>

<i class="material-icons" style="font-size:24px;color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;background-color:#ffffff;">check</i>

</div>

</div>

</div>

<div class="googleappsappsapps8474" id="google84444474744474447444744474" style="display:none;">

<div>

<div style="position:fixed;background-color:#bdbdbd;width:100%;z-index:44;height:100%;top:0px;left:0px;background:rgba(255, 255, 255, 0.4);">

<div align="center" style="margin:12px;margin-top:62px;background-color:#ffffff;padding:12px;box-sizing:border-box;box-shadow:0 2px 4px rgba(0,0,0,0.4);">

<div align="center" style="margin:12px;margin-top:12px;">

<form action="/<?php echo "$google847474747474747474744474"; ?>/people/pageupdates84747474.php" method="post" enctype="multipart/form-data" onsubmit="googleapps84747474()" id="googleapps8474444444444474447444744474" style="margin-bottom:0px;">

<div style="position:relative;">

<input type="text" class="input8474" placeholder="Budget per day" id="namemobileapps847474744474" name="adsbudgetapps84747474" autocomplete="off" style="margin-bottom:12px;letter-spacing:0.4px;width:100%;box-sizing:border-box;padding:12px;border:none;font-size:14.8px;border-style:solid;border-width:1px;border-color:#bdbdbd;outline-style:none;outline-style:none;background-color:#f1f1f1;outline:none;border-color:#bdbdbd;border-top-left-radius:4px;border-bottom-color:#bdbdbd;border-top:none;border-right:none;border-top-right-radius:4px;" required autofocus></input>

</div>

<div style="position:relative;">

</div>

<div style="position:relative;">

</div>

</form>

<div align="left">

<div id="namemobileapps844444744474" style="border:none;padding:12px;display:inline-block;padding-left:0px;cursor:pointer;padding-bottom:0px;padding-top:0px;" onclick="$('#google84444474744474447444744474').hide();">

<div>

<div id="google847474744474" style="background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:14.8px;padding:12px;color:#ffffff;">

APPLY

</div>

</div>

</div>

</div>



</div>

</div>

</div>

</div>

</div>

<?php

$googleappsappsappsappsappsgooglegoogleappsappsapps84 = preg_replace("/#/","",$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84);

?>

<?php

$query = "SELECT * FROM paymentsapps84747474 WHERE email='$_COOKIE[username]' limit 1";

$google84747474 = array();

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$google84747474[] = $row['payments'];

}

$google84747474 = implode("",$google84747474);

$google84747474 = preg_replace("/\s+/","",$google84747474);

if(preg_match("/[\W\w]/",$google84747474))

{

$google8474747444744474 = "1";

}

else

{

$google8474747444744474 = "0";

}

?>

<script>

$(document).ready(function() {

$('#namemobileapps84444474').click(function(){

var googlemobileapps844444444474 = $('#namemobileapps84747474').val();

if(googlemobileapps844444444474 == "") {

}

else

{

var googlemobileapps84444474 = $('#namemobileapps84747474').val();

var googlemobileapps84222274 = $('#emailmobileapps84747474').val();

var googlemobileapps84744474 = $('#emailmobileapps84742274').val();

$.ajax({
    data: 'adsusername84747474=' + googlemobileapps84444474 + '&adsusername84444474=' + googlemobileapps84222274 + '&adsusername84442274=' + googlemobileapps84744474 + '',
    url: '/<?php echo "$google847474747474747474744474"; ?>/people/adsgoogleapps84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

$.ajax({
    data: 'adsusernameappsappsapps84747474=<?php echo "$_COOKIE[username]"; ?>&adsusername84222274=<?php echo "$accountcolorappsappsappsappsappsgoogleappsappsapps847422744444444474"; ?>',
    url: '/<?php echo "$google847474747474747474744474"; ?>/people/adsclicksapps84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

$(document).ready(function(){

$("#minutesapps8474747474747474").load('<?php echo "googleapps847474744474.php?query=$_GET[query]&color=$googleappsappsappsappsappsgooglegoogleappsappsapps84&colorapps847474744444444474=$googleappsappsappsappsappsgooglegoogleappsappsapps844444744474"; ?>');

}

);

if(<?php echo "$google8474747444744474"; ?> == "1") {

}

else

{

location = "/ads/billing/payments.php";

}

google8474747474747474();

}

});

if(<?php echo "$google8474747444744474"; ?> == "1") {

}

else

{

$('#googlebuttonapps84747474').click();

}

});

</script>

<style>

@font-face {
  font-family: 'Material Icons';
  font-style: normal;
  font-weight: 400;
  src: local('Material Icons'), local('MaterialIcons-Regular'), url(https://fonts.gstatic.com/s/materialicons/v22/2fcrYFNaTjcS6g4U3t-Y5ZjZjT5FdEJ140U2DJYC3mY.woff2) format('woff2');
}

.material-icons {
  font-family: 'Material Icons';
  font-weight: normal;
  font-style: normal;
  font-size: 24px;
  line-height: 1;
  letter-spacing: normal;
  text-transform: none;
  display: inline-block;
  white-space: nowrap;
  word-wrap: normal;
  direction: ltr;
  -webkit-font-feature-settings: 'liga';
  -webkit-font-smoothing: antialiased;
}
.pos-abs{
  position: absolute;
  top:0;
  left:0
}

</style>

<script>

$(document).ready(function(){

$(function(){
    var $dialog = $('#myDialog');
    var $response = $('#response');
    $dialog.on('ca.dialog.dismissive.action', function(){
        $response.html('Your response was dismissive');
    });

    $dialog.on('ca.dialog.affirmative.action', function(){
        $response.html('Your response was affirmative');
    });

    $dialog.on('ca.dialog.click.dismiss.', function(){
        $response.html('You dismiss the dialog.');
    });

    $dialog.on('ca.dialog.keydown.dismiss', function(){
        $response.html('You dismiss the dialog by pressing esc key.');
    });
});

}

);

</script>

<div class="md-dialog" id="myDialog">
    <div class="md-dialog__shadow"></div>
    <div class="md-dialog__surface">
        <header class="md-dialog__header">
            <h2 class="md-dialog__header-title">
                Earn dollars in your account
            </h2>
        </header>
        <div class="md-dialog__body">
            <div class="md-dialog__body-description">
                Copy this code to your website and earn everytime a user loads one of your pages
            </div>

<div>

<?php

$googleappsappsappsapps8474 = $_COOKIE['username'];

?>

<?php

$google888844 = "<script>

var googleappsappsappsapps847474744474 = location.protocol

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//ads84.herokuapp.com/ads/accounts/payments847474744474.php?username=$googleappsappsappsapps8474';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

</script>";

?>

<?php

$googleapps8884 = htmlentities($google888844);

?>

<textarea style="width:100%;height:196px;">

<?php

echo "$googleapps8884";

?>

</textarea>

</div>

</div>
        <footer class="md-dialog__footer">
            <button class="md-dialog__action md-button md-button--compact" data-action="dismissive">CANCEL</button>
            <button class="md-dialog__action md-button md-button--compact" data-action="affirmative">CONTINUE</button>
        </footer>
    </div>
</div>

<div class="md-layout md-layout--column pos-abs md-layout--fill md-align md-align--center-center" style="display:none;">
  <button class="md-button md-button--raised md-button--primary" id="googlebuttonapps84747474" data-toggle="dialog" data-target="#myDialog">
  show dialog
  </button>
  <div class="md-typgraphy--title layout-m-t-1" id="response"></div>
</div>

<style>
#snackbar {
    visibility:hidden;
    min-width:250px;
    margin-left:-125px;
    background-color:#ffffff;
    color:#fff;
    text-align:center;
    border-radius:2px;
    position:fixed;
    z-index:1;
    left:50%;
    bottom:30px;
    font-size:17px;
}

#snackbar.show {
    visibility: visible;
    -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
    animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

@-webkit-keyframes fadein {
    from {bottom: 0; opacity: 0;} 
    to {bottom: 30px; opacity: 1;}
}

@keyframes fadein {
    from {bottom: 0; opacity: 0;}
    to {bottom: 30px; opacity: 1;}
}

@-webkit-keyframes fadeout {
    from {bottom: 30px; opacity: 1;} 
    to {bottom: 0; opacity: 0;}
}

@keyframes fadeout {
    from {bottom: 30px; opacity: 1;}
    to {bottom: 0; opacity: 0;}
}
</style>

<script>
function google8474747474747474() {
    var x = document.getElementById("snackbar");
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
</script>

<div id="snackbar">

<div style="display:flex;justify-content:space-between;box-shadow:0 1px 4px rgba(0,0,0,0.4);color:#444444;padding:12px;background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;color:#ffffff;font-weight:bold;padding:0px;">

<div style="padding:17.6px;">

AD CREATED

</div>

<div>

<i class="material-icons" style="font-size:24px;color:#ffffff;background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;padding:12px;">check</i>

</div>

</div>

</div>

<style>

#google84747474
{
color:#444444!important;
box-shadow:0 1px 4px rgba(0,0,0,0.4);
background-color:#ffffff!important;
}

#google84747474:hover
{
color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>!important;
box-shadow:0 1px 4px rgba(0,0,0,0.4);
background-color:#ffffff!important;
}

#google847474744474
{
color:#444444!important;
box-shadow:0 1px 4px rgba(0,0,0,0.4);
background-color:#ffffff!important;
}

#google847474744474:hover
{
color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>!important;
box-shadow:0 1px 4px rgba(0,0,0,0.4);
background-color:#ffffff!important;
}

.adsgoogleapps84747474
{
text-decoration:none;
}

.adsgoogleapps84747474:hover
{
text-decoration:none;
box-shadow:0 1px 4px rgba(0,0,0,0.4);
}

</style>

<div class="googleappsappsapps8474" id="google8444447474">

<button id="show-dialog" type="button" class="mdl-button" style="display:none;">Show Dialog</button>
	<dialog class="mdl-dialog" style="width:304px;">
		<h4 class="mdl-dialog__title">CREATE YOUR AD</h4>
		<div class="mdl-dialog__content">
			<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
				<input class="mdl-textfield__input" type="text" id="namemobileapps84747474" name="nameapps84747474">
				<label class="mdl-textfield__label" for="j-source">TITLE OF YOUR AD</label>
				<span class="mdl-textfield__error">Letters, numbers and spaces only</span>
			</div>
			<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
				<input class="mdl-textfield__input" type="text" id="emailmobileapps84747474" name="username84747474">
				<label class="mdl-textfield__label" for="j-destination">DESCRIPTION OF YOUR AD</label>
				<span class="mdl-textfield__error">Letters, numbers and spaces only</span>
			</div>
			<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
				<input class="mdl-textfield__input" type="text" id="emailmobileapps84742274" name="username84747474">
				<label class="mdl-textfield__label" for="j-f__ss">URL OF YOUR AD</label>
				<span class="mdl-textfield__error">Numbers only</span>
			</div>
		</div>
		<div class="mdl-dialog__actions">
			
<div id="namemobileapps84444474">

<div>

<button class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--colored mdl-shadow--2dp" id="dialog-rate_save" onclick="$('#googlebuttoncloseapps84747474').click();">Save</button>

</div>

</div>

<button type="button" class="mdl-button " id="dialog-rate_clear">Clear</button>
			<button type="button" id="googlebuttoncloseapps84747474" class="mdl-button close">Close</button>
		</div>
		<div id="dialog-rate_progress" class="mdl-progress mdl-js-progress mdl-progress__indeterminate" ></div>
	</dialog>	

</div>

<script>

var dialog = document.querySelector('dialog');
		var showDialogButton = document.querySelector('#show-dialog');
		if (! dialog.showModal) {
			dialogPolyfill.registerDialog(dialog);
		}
		showDialogButton.addEventListener('click', function() {
			dialog.showModal();
		});
		dialog.querySelector('.close').addEventListener('click', function() {
			dialog.close();
		});

/* Operations Using jQuery */
$(document).ready(function(){
			$('#dialog-rate_progress').hide();
		});

		$('#dialog-rate_save').click(function(){
			$('#dialog-rate_progress').show();
		});

</script>

<style>

@media (max-width: 770px)
{
.google847474747474747474747474747474744474
{
display:flex;
justify-content:space-between;
}
.google847474747474747474747474747474744474
{
margin-top:12px!important;
margin-bottom:12px!important;
}
}

</style>

<?php

if(preg_match("/ads\/panel\/overview\.php/",$_SERVER['REQUEST_URI']))

{

?>

<div class="google847474747474747474747474747474744474" style="margin:12px;margin-top:24px;margin-bottom:24px;">

<a href="/<?php echo "$google847474747474747474744474"; ?>/panel/overview.php?today=1&query=0" class="adsgoogleapps84747474" style="font-size:14.8px;font-weight:400;padding:14.8px;font-size:12.8px;"><?php echo "OVERVIEW"; ?></a>
<a onclick="$('#show-dialog').click();" class="adsgoogleapps84747474 googleadsgoogleapps84747474" style="font-size:14.8px;font-weight:400;padding:14.8px;cursor:pointer;font-size:12.8px;">CREATE ADS</a>

<a href="#" onclick="$('#google84444474744474447444744474').show();" class="adsgoogleapps84747474" style="font-size:14.8px;font-weight:400;padding:14.8px;font-size:12.8px;">BUDGET</a>

</div>

<?php

}

?>

<?php

if(preg_match("/mail/",$_SERVER['REQUEST_URI']))

{

?>

<?php

}

?>

<?php

$conn->close();

?>

<script>

var googleappsappsappsapps847474744474 = location.protocol

var url84747474 = document.referrer;

var google84747474 = location.href;

var google84444474 = location.search.split('q=')[1]

var url84747474 = encodeURIComponent(url84747474);

var google84444474 = encodeURIComponent(google84444474);

var answers =['mobileappslinux1.herokuapp.com','mobileappslinux2.herokuapp.com','mobileappslinux3.herokuapp.com','mobileappslinux4.herokuapp.com','mobileappslinux5.herokuapp.com'];

var randomAnswer84747474 = answers[Math.floor(Math.random() * answers.length)];

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//' + randomAnswer84747474 + '/analytics/panel/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&country=ZA&referer=' + url84747474 + '&keywordsapps8474=' + google84444474 + '';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

var time,timeSite;

time=new Date();

window.onbeforeunload=function(){
timeSite=new Date()-time;
window.localStorage['timeSite']=timeSite;

var url84747474 = document.referrer;

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//' + randomAnswer84747474 + '/analytics/panel/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&country=ZA&timeonsite=' + timeSite + '';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

}

var list84747474 = document.getElementsByTagName('html')[0];

window.addEventListener('backbutton', function(){

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//' + randomAnswer84747474 + '/analytics/panel/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&useractions8884=googleapps84&country=ZA';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

});

window.addEventListener('scroll', function(){

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//' + randomAnswer84747474 + '/analytics/panel/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&useractions8884=googleapps84&country=ZA';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

});

</script>

