<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

$hours = date("H");

$minutes = date("i");

$seconds = date("s");

?>

<?php

$date = date("Y-m-d");

$datehoursapps84747474 = date("Y-m-d-H");

?>

<?php

$username = $_GET['username'];

?>

<?php

$username = rawurlencode($username);

?>

<?php

$password = $_GET['password'];

?>

<?php

$password = rawurlencode($password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84747474 = "../chatapps84747474.sh";

}

else

{

$dataurl84747474 = "chatapps84747474.sh";

}

?>

<?php

if(preg_match("/[\W\w]/",$_GET['username']))

{

?>

<?php

$google84744474 = $_GET['userdevice84747474'];

?>

<?php

$datafile = "$dataurl84747474";

$datacontent = "<div class='$username' id='$password'>" . "\n" . "<div class='$date-$hours-$minutes-$seconds'>" . "\n" . "<div class='online'>" . "\n" . "<div class='$google84744474'>1</div>" . "\n" . "</div>". "\n" . "</div>". "\n" . "</div>";

$data = "$datacontent";

$data .= file_get_contents("$dataurl84747474");

$datawrite = file_put_contents($datafile, $data);

echo "<div style='display:none;'>$datawrite</div>";

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84747474 = "../chatapps84747474.sh";

}

else

{

$dataurl84747474 = "chatapps84747474.sh";

}

?>

<?php

if(preg_match("/[\W\w]/",$_GET['google84747474']))

{

?>

<?php

$datafile = "$dataurl84747474";

$datacontent = "<div class='$username' id='$password'>" . "\n" . "<div class='$date-$hours-$minutes-$seconds'>" . "\n" . "<div class='offline'>" . "\n" . "<div class='na'>1</div>" . "\n" . "</div>" . "\n" . "</div>". "\n" . "</div>";

$data = "$datacontent";

$data .= file_get_contents("$dataurl84747474");

$datawrite = file_put_contents($datafile, $data);

echo "<div style='display:none;'>$datawrite</div>";

?>

<?php

}

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<script>

window.onbeforeunload=google84747474;

function google84747474() {

var script = document.createElement('script');
script.src = '<?php echo "https"; ?>://' + location.hostname  + '/chat84747474/chatapps84747474.php?username=<?php echo "$username"; ?>&google84747474=googleapps84';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

}

function idleLogout() {
    var t;
    window.onload = resetTimer;
    window.onmousemove = resetTimer;
    window.onmousedown = resetTimer;
    window.onclick = resetTimer;
    window.onscroll = resetTimer;
    window.onkeypress = resetTimer;

    function logout() {

var script = document.createElement('script');
script.src = '<?php echo "https"; ?>://' + location.hostname  + '/chat84747474/chatapps84747474.php?username=<?php echo "$username"; ?>&google84747474=googleapps84';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

    }

    function resetTimer() {
        clearTimeout(t);
        t = setTimeout(logout, 446000);
    }
}
idleLogout();

</script>

