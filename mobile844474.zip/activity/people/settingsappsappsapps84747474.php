<?php

error_reporting(0);

?>

<?php

$servername847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn84744474447444744474 = new mysqli($servername847444444444744474, $username847444444444744474, $password847444444444744474, $dbname847444444444744474);

?>

<?php

include "../dashboard/dashboardtop.php";

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../gosearchimages8884.sh";

}

else

{

$dataurl84 = "../gosearchimages8884/gosearchimages8884.sh";

}

?>

<?php

$googleappsappsappsappsapps8884 = file_get_contents("$dataurl84");

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlapps84 = "../accountcolor88842274.sh";

}

else

{

$dataurlurlapps84 = "../register/accountcolor88842274.sh";

}

?>

<?php

$googleappsgoogleappsappsgoogleapps8884 = file_get_contents($dataurlurlapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../accountcolor8884.sh";

}

else

{

$dataurlurlgoogleapps84 = "../register/accountcolor8884.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsapps84);
$accountcolor84742274 = $googleappsappsapps84[3][0];

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsapps84);
$accountcolor847474 = $googleappsappsapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolor847474"))

{

$accountcolor1 = "$accountcolor847474";

$accountcolor2 = "$accountcolor847474";

$accountcolor4 = "$accountcolor847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<div class="googledivappsappsapps84" style="padding:8px;box-shadow: 0 2px 4px rgba(0,0,0,0.2);margin-bottom:18px;background-color:#ffffff;margin-top:12px;margin:0 auto;margin-top:12px;">

<div style="width:100%;height:196px;position:relative;background-color:<?php echo "$accountcolor1"; ?>;display:none;">

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{
}

else

{

?>

<div style="width:100%;">

<div style="margin-top:12px;position:absolute;right:12px;">

<div class="dropdown">
  <button onclick="myFunctiongoogleappsappsappsappsappsgoogleapps84747474();" class="dropbtn" style="font-size:12.4px;background:none;border:none;"><i class='material-icons googleappsgoogleapps2' id="google84221874" style="color:#ffffff;font-size:19.4px;">more_vert</i></button>
  <div id="myDropdown" class="dropdown-content" style="display:none;margin-left:-128.4px;">
    <a href="" style="font-size:14px;background-color:#ffffff;">Report</a>
    <a href="" style="font-size:14px;background-color:#ffffff;">Show info</a>
    <a href="" style="font-size:14px;background-color:#ffffff;">Show user</a>
  </div>
</div>

<script>

function myFunctiongoogleappsappsappsappsappsgoogleapps84747474() {
    var x = document.getElementById("myDropdown");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

</script>

<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunctionappsapps84747474() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

<style>

/* Dropdown Button */
.dropbtn {
cursor: pointer;
}

/* Dropdown button on hover & focus */
.dropbtn:hover, .dropbtn:focus {
    background-color: #2980B9;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
    position: relative;
    display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow: 0px 2px 4px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color:#ebebeb!important}

/* Show the dropdown menu (use JS to add this class to the .dropdown-content container when the user clicks on the dropdown button) */
.show {display:block;}

</style>

</div>

</div>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84747474 = "../gosearchimagesgoogleappsappsapps8884.sh";

}

else

{

$dataurl84747474 = "../gosearchimages8884/gosearchimagesgoogleappsappsapps8884.sh";

}

$google842222222274 = file_get_contents("$dataurl84747474");

preg_match_all("/<div class='$nameappsapps8884' id='na'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $google842222222274, $gosearchimages844444224474);
$gosearchimages844444444474 = $gosearchimages844444224474[1][0];

if(preg_match("/[\W\w]/","$gosearchimages844444444474"))

{

?>

<img class="googleappsapps8444444444444444444474" src='<?php echo "$gosearchimages844444444474"; ?>' style="width:100%;"></img>

<?php

}

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{

?>

<script>

$(document).ready(function(){

$('#googleimageappsmobileappsappsappsappsappsapps84').on('change', function() {

document.getElementById("googleappsapps8444444444444474").click();

});

});

</script>

<div>

<div>

<form action="/google8474/googleappsgoogleappsappsapps8474.php" method="post" enctype="multipart/form-data" id="googleappsapps8474744444444474" style="display:inline-grid;">

<input type="hidden" name="username84747474" value="<?php echo "$_GET[useremail]"; ?>"></input>

<input type="file" name="image" id="googleimageappsmobileappsappsappsappsappsapps84" style="width:44px;height:44px;padding-top:62px;z-index:44;padding-left:24px;display:none;"></input>

<input type="submit" value="Submit" style="border:none;background-color:<?php echo "$accountcolor4"; ?>;padding:12px;color:#ffffff;font-weight:bold;margin:12px;font-size:13.8px;display:none;" id="googleappsapps8444444444444474"></input>

</form>

</div>

</div>

<div style="display:flex;margin-top:12px;margin-bottom:44px;">

<div class="googleappsappsappsappsapps84222274" style="font-size:12.8px;width:124px;position:absolute;right:12px;top:12px;">

<div id="googleappsappsappsappsappsappsapps844444444474" onclick="document.getElementById('googleimageappsmobileappsappsappsappsappsapps84').click();" style="padding-left:12px;position:absolute;right:0px;cursor:pointer;padding-left:12px;right:0px;cursor:pointer;padding:5.4px;background-color:#444444;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:inline-block;color:#ffffff;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;border:none;margin-top:12.8px;margin-left:12px;right:0px;top:-12px;position:absolute;">

Change image

</div>

</div>

</div>

<?php

}

else

{

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../userregistrations.sh";

}

else

{

$dataurl84 = "../register/userregistrations.sh";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl84");

?>

<?php

$googleapps84 = $_GET['useremail'];

$password="googleappsmobileapps888888884444";

$nameappsapps84 = openssl_encrypt($googleapps84,"AES-128-ECB",$password);

$nameappsapps84 = rawurlencode($nameappsapps84);

?>

<?php

preg_match_all("/<div class='$nameappsapps84' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$name = $googleapps84[2][0];

?>

<script>

$(document).ready(function() {

$('.googleapps844444747474').click(function(){

$.ajax({
    data: 'coworkers84747474=<?php echo "$nameappsapps8884"; ?>&coworkersnameapps84747474=<?php echo "$name"; ?>',
    url: '/people/coworkers84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

});

});

</script>

<div class="googleappsappsapps8474" id="google84742274" style="display:none;">

<div>

<div style="position:fixed;background-color:#bdbdbd;z-index:44;height:100%;top:0px;width:100%;left:0px;background:rgba(0, 0, 0, 0.4);" onclick="$(this).hide();">

<div align="center" style="margin:12px;margin-top:62px;background-color:#ffffff;padding:12px;">

You promoted this person to your coworkers

</div>

</div>

</div>

</div>

<div style="display:flex;">

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../coworkersappsappsappsgoogleappsgoogleapps84747474.sh";

}

else

{

$dataurlurlgoogleapps84 = "../people/coworkersappsappsappsgoogleappsgoogleapps84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

$googleapps84 = $_GET['useremail'];

$password="googleappsmobileapps888888884444";

$nameappsapps84 = openssl_encrypt($googleapps84,"AES-128-ECB",$password);

$nameappsapps84 = rawurlencode($nameappsapps84);

?>

<?php

preg_match_all("/<div class='$nameappsapps84'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsapps84742274"))

{

?>

<?php

if(preg_match("/0/","$accountcolorappsappsappsappsapps84742274"))

{

?>

<?php

}

else

{

?>

<?php

if(preg_match("/1/","$accountcolorappsappsappsappsapps84742274"))

{

?>

<div class="googleapps844444747474" style="padding:8px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:inline-block;color:#ffffff;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;color:<?php echo "$accountcolor1"; ?>;position:absolute;right:96px;bottom:-12px;" onclick="$('#google84742274').show();">

Add

</div>

<?php

}

}

}

else

{

?>

<div class="googleapps844444747474" style="padding:8px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:inline-block;color:#ffffff;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;color:<?php echo "$accountcolor1"; ?>;position:absolute;right:96px;bottom:-12px;" onclick="$('#google84742274').show();">

Add

</div>

<?php

}

?>

<div style="padding:8px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:inline-block;color:#ffffff;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;color:<?php echo "$accountcolor1"; ?>;position:absolute;right:12px;bottom:-12px;" onclick="window.open('/people/usermailapps8884.php?useremailappsappsapps84747474=<?php echo "$google84747474"; ?>','_self');">

Message

</div>

</div>

<?php

}

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='na'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsappsappsappsapps8884, $googleapps84);
$gosearchimages8474 = $googleapps84[1][0];

?>

<?php

if(preg_match("/[\W\w]/",$gosearchimages8474))

{

?>

<script>

$(document).ready(function(){

$('#googleimageapps84').on('change', function() {

document.getElementById("google84444474").click();

});

});

</script>

<div>

<div>

<form action="/google8474/googleapps8474.php" method="post" enctype="multipart/form-data" id="googleappsappsappsapps8474744444444474" style="display:inline-grid;">

<input type="hidden" name="username84747474" value="<?php echo "$_GET[useremail]"; ?>"></input>

<input type="file" name="image" id="googleimageapps84" style="width:44px;height:44px;padding-top:62px;z-index:44;padding-left:24px;display:none;"></input>

<input type="submit" value="Submit" style="border:none;background-color:<?php echo "$accountcolor4"; ?>;padding:12px;color:#ffffff;font-weight:bold;margin:12px;font-size:13.8px;display:none;" id="google84444474"></input>

</form>

</div>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{

?>

<?php

$googleapps847444444444444474 = "googleimageapps84";

?>

<?php

}

?>

<div id="div84747474" style="position:absolute;left:18px;bottom:-22px;"><img src="<?php echo $gosearchimages8474; ?>" width="104" height="104" style="border-color:#1565C0;color:#ffffff;border-radius:4px;font-size:86px;margin-top:10px;box-shadow:0 2px 4px rgba(0,0,0,0.4);" onclick="document.getElementById('<?php echo $googleapps847444444444444474; ?>').click();"></img></div>

</div>

<?php

}

else

{

?>

<style>

.googleapps84742274
{
display:inline-block!important;
}

</style>

<script>

$(document).ready(function(){

$('#googleimageapps84').on('change', function() {

document.getElementById("google84444474").click();

});

});

</script>

<div>

<div>

<form action="/google8474/googleapps8474.php" method="post" enctype="multipart/form-data" id="googleappsappsappsapps8474744444444474" style="display:inline-grid;">

<input type="hidden" name="username84747474" value="<?php echo "$_GET[useremail]"; ?>"></input>

<input type="file" name="image" id="googleimageapps84" style="width:44px;height:44px;padding-top:62px;z-index:44;padding-left:24px;display:none;"></input>

<input type="submit" value="Submit" style="border:none;background-color:<?php echo "$accountcolor4"; ?>;padding:12px;color:#ffffff;font-weight:bold;margin:12px;font-size:13.8px;display:none;" id="google84444474"></input>

</form>

</div>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{

?>

<?php

$googleapps847444444444444474 = "googleimageapps84";

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../userregistrations.sh";

}

else

{

$dataurl8884 = "../register/userregistrations.sh";

}

?>

<?php

$decryptedstring = $_COOKIE['username'];

$file84 = file_get_contents("$dataurl8884");

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $file84, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

$nameappsapps8884 = strtoupper($name[0]);

?>

<?php

echo "<div style='position:absolute;left:18px;bottom:-22px;'><div class='googleapps84742274' style='border-color:#1565C0;color:#444444;font-size:86px;margin-top:10px;box-shadow:0 2px 4px rgba(0,0,0,0.4);background-color:#ffffff;' onclick=\"document.getElementById('$googleapps847444444444444474').click();\"><div style='color:#444444;padding-left:24px;padding-right:24px;'>$nameappsapps8884</div><div></div></div></div>";

?>

</div>

<?php

}

?>

</div>

<style>

@media screen and (min-width: 1884px)
{
html
{
zoom:1.4;
}
}

@media screen and (min-width: 2560px)
{
html
{
zoom:2;
}
}

</style>

<style>

@media screen and (min-width: 770px)
{
.googledivappsappsapps84
{
margin-left:96px;
margin-right:196px;
width:796px;
}
.google84744474
{
margin-left:140px;
}
.googleappsapps8444444444444444444474
{
height:100%;
width:100%;
object-fit:contain;
}
}

@media screen and (max-width: 770px)
{
.googleappsapps8444444444444444444474
{
height:100%;
width:100%;
object-fit:contain;
}
}

</style>

<?php

$string_to_encrypt="$_COOKIE[username]";

$decrypted_string = "$string_to_encrypt";

?>

<?php

$string_to_encrypt8884="$_COOKIE[password]";

$decrypted_string8884 = "$string_to_encrypt8884";

?>

<?php

$string_to_encrypt="$_COOKIE[username]";

$decrypted_string = "$string_to_encrypt";

?>

<?php

$string_to_encrypt="$decrypted_string";

$decrypted_string888474 = rawurldecode($string_to_encrypt);

$password="googleappsmobileapps888888884444";

$decrypted_string8474=openssl_decrypt($decrypted_string888474,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../userregistrations.sh";

}

else

{

$dataurl8884 = "../register/userregistrations.sh";

}

?>

<?php

$decryptedstring = $_COOKIE['username'];

$file84 = file_get_contents("$dataurl8884");

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $file84, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

$googleapps8884 = strtoupper("$name");

$googleapps888844 = "$name";

?>

<?php

if(!preg_match("/[\W\w]/",$_COOKIE['username']))

{

?>

<?php

}

?>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>

<?php

$hours = date("H");

$minutes = date("i");

$seconds = date("s");

?>

<?php

$date = date("Y-m-d");

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84447422 = "../accountcolor8884.sh";

}

else

{

$dataurl84447422 = "../register/accountcolor8884.sh";

}

?>

<?php

$googleapps84747444 = file_get_contents($dataurl84447422);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../gosearchimages8884.sh";

}

else

{

$dataurl84 = "../gosearchimages8884/gosearchimages8884.sh";

}

?>

<?php

$googleapps8884 = file_get_contents($dataurl84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$gosearchimages8474 = $googleapps84[2][0];

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleapps84747444, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor847474))

{
}

else

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

?>

<?php

if(preg_match("/blue/",$accountcolor847474))

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/orange/",$accountcolor847474))

{

$accountcolor84747474 = "#EF6C00";

$accountcolor1 = "#EF6C00";

$accountcolor2 = "#FB8C00";

$accountcolor4 = "#FFA726";

}

if(preg_match("/yellow/",$accountcolor847474))

{

$accountcolor84747474 = "#F9A825";

$accountcolor1 = "#F9A825";

$accountcolor2 = "#FDD835";

$accountcolor4 = "#FFEE58";

}

if(preg_match("/purple/",$accountcolor847474))

{

$accountcolor84747474 = "#6A1B9A";

$accountcolor1 = "#6A1B9A";

$accountcolor2 = "#8E24AA";

$accountcolor4 = "#AB47BC";

}

if(preg_match("/pink/",$accountcolor847474))

{

$accountcolor84747474 = "#AD1457";

$accountcolor1 = "#AD1457";

$accountcolor2 = "#D81B60";

$accountcolor4 = "#EC407A";

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../userregistrations.sh";

}

else

{

$dataurluserapps84 = "../register/userregistrations.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name84747474 = rawurldecode($gosearchimages84747674);

$name84747474 = openssl_decrypt($name84747474,"AES-128-ECB",$password);

?>

<div style="margin-top:12px;margin-left:12px;">

Settings

</div>

<div style="display:flex;position:relative;border-left:none;border-color:<?php echo "$accountcolor4"; ?>;border-right:none;border-top:none;border-width:4px;">

<div style='padding:12px;position:relative;width:100%;overflow:hidden;'>

<div style="font-size:14.8px;padding:12px;padding-top:0px;">

</div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../workapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/workapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT * FROM workapps84747474 order by date desc limit 1";
$result = $conn84744474447444744474->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['work'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<div style="display:flex;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

Work

</div>

<div style="display:flex;">

<div onclick="$('.googleapps44847474').show();" style="font-size:12.8px;cursor:pointer;">

edit

</div>

<div style="font-size:12.8px;margin-left:4px;">

<?php

echo "$gosearchimages84747674";

?>

</div>

</div>

<div>

<div align="center" class="googleapps44847474" style="position:fixed;left:0px;top:0px;background:rgba(0, 0, 0, 0.4);width:100%;height:100%;display:none;z-index:8884;">

<div style="padding:12px;margin-top:54px;background-color:#ffffff;">



<form action="/people/workapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" placeholder="Work" value="" name="workapps84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $_COOKIE[username]; ?>" name="workappsuser84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" required></input>

</form>



</div>

</div>

</div>



</div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../educationapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/educationapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT * FROM educationapps84747474 order by date desc limit 1";
$result = $conn84744474447444744474->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['education'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<div style="display:flex;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

Education

</div>

<div style="display:flex;">

<div onclick="$('.googleappsappsapps44847474').show();" style="font-size:12.8px;cursor:pointer;">

edit

</div>

<div style="font-size:12.8px;margin-left:4px;">

<?php

echo "$gosearchimages84747674";

?>

</div>

</div>

<div>

<div align="center" class="googleappsappsapps44847474" style="position:fixed;left:0px;top:0px;background:rgba(0, 0, 0, 0.4);width:100%;height:100%;display:none;z-index:8884;">

<div style="padding:12px;margin-top:54px;background-color:#ffffff;">



<form action="/people/educationapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" placeholder="Education" value="" name="educationapps84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $_COOKIE[username]; ?>" name="educationappsuser84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" required></input>

</form>



</div>

</div>

</div>



</div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../countryapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/countryapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT * FROM countryapps84747474 order by date desc limit 1";
$result = $conn84744474447444744474->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['country'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<div style="display:flex;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

Country

</div>

<div style="display:flex;">

<div onclick="$('.googleappsappsappsapps44847474').show();" style="font-size:12.8px;cursor:pointer;">

edit

</div>

<div style="font-size:12.8px;margin-left:4px;">

<?php

echo "$gosearchimages84747674";

?>

</div>

</div>

<div>

<div align="center" class="googleappsappsappsapps44847474" style="position:fixed;left:0px;top:0px;background:rgba(0, 0, 0, 0.4);width:100%;height:100%;display:none;z-index:8884;">

<div style="padding:12px;margin-top:54px;background-color:#ffffff;">



<form action="/people/countryapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" placeholder="Country" value="" name="countryapps84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $_COOKIE[username]; ?>" name="countryappsuser84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" required></input>

</form>



</div>

</div>

</div>



</div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../ageapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/ageapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT * FROM ageapps84747474 order by date desc limit 1";
$result = $conn84744474447444744474->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['age'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<div style="display:flex;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

Age

</div>

<div style="display:flex;">

<div onclick="$('.googleappsappsappsappsappsapps44847474').show();" style="font-size:12.8px;cursor:pointer;">

edit

</div>

<div style="font-size:12.8px;margin-left:4px;">

<?php

echo "$gosearchimages84747674";

?>

</div>

</div>

<div>

<div align="center" class="googleappsappsappsappsappsapps44847474" style="position:fixed;left:0px;top:0px;background:rgba(0, 0, 0, 0.4);width:100%;height:100%;display:none;z-index:8884;">

<div style="padding:12px;margin-top:54px;background-color:#ffffff;">



<form action="/people/ageapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" placeholder="Age" value="" name="ageapps84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $_COOKIE[username]; ?>" name="ageappsuser84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" required></input>

</form>



</div>

</div>

</div>



</div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../mobileapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/mobileapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT * FROM mobileapps84747474 order by date desc limit 1";
$result = $conn84744474447444744474->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['mobile'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<div style="display:flex;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

Mobile

</div>

<div style="display:flex;">

<div onclick="$('.googleappsappsappsappsappsappsappsapps44847474').show();" style="font-size:12.8px;cursor:pointer;">

edit

</div>

<div style="font-size:12.8px;margin-left:4px;">

<?php

echo "$gosearchimages84747674";

?>

</div>

</div>

<div>

<div align="center" class="googleappsappsappsappsappsappsappsapps44847474" style="position:fixed;left:0px;top:0px;background:rgba(0, 0, 0, 0.4);width:100%;height:100%;display:none;z-index:8884;">

<div style="padding:12px;margin-top:54px;background-color:#ffffff;">



<form action="/people/mobileapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" placeholder="Mobile" value="" name="mobileapps84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $_COOKIE[username]; ?>" name="mobileappsuser84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" required></input>

</form>



</div>

</div>

</div>



</div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../firstnameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/firstnameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$date84747474 = date("Y");

$query = "SELECT * FROM user1 order by date desc limit 1";
$result = $conn84744474447444744474->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['firstname'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<div style="display:flex;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

First name

</div>

<div style="display:flex;">

<div onclick="$('.googleappsappsappsappsappsappsappsappsappsapps44847474').show();" style="font-size:12.8px;cursor:pointer;">

edit

</div>

<div style="font-size:12.8px;margin-left:4px;">

<?php

echo "$gosearchimages84747674";

?>

</div>

</div>

<div>

<div align="center" class="googleappsappsappsappsappsappsappsappsappsapps44847474" style="position:fixed;left:0px;top:0px;background:rgba(0, 0, 0, 0.4);width:100%;height:100%;display:none;z-index:8884;">

<div style="padding:12px;margin-top:54px;background-color:#ffffff;">



<form action="/people/firstnameapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" placeholder="First name" value="" name="firstnameapps84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $_COOKIE[username]; ?>" name="firstnameappsuser84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" required></input>

</form>



</div>

</div>

</div>



</div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../lastnameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/lastnameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$date84747474 = date("Y");

$query = "SELECT * FROM user2 order by date desc limit 1";
$result = $conn84744474447444744474->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['lastname'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<div style="display:flex;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

Last name

</div>

<div style="display:flex;">

<div onclick="$('.googleappsappsappsappsappsappsappsappsappsappsappsapps44847474').show();" style="font-size:12.8px;cursor:pointer;">

edit

</div>

<div style="font-size:12.8px;margin-left:4px;">

<?php

echo "$gosearchimages84747674";

?>

</div>

</div>

<div>

<div align="center" class="googleappsappsappsappsappsappsappsappsappsappsappsapps44847474" style="position:fixed;left:0px;top:0px;background:rgba(0, 0, 0, 0.4);width:100%;height:100%;display:none;z-index:8884;">

<div style="padding:12px;margin-top:54px;background-color:#ffffff;">



<form action="/people/lastnameapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" placeholder="Last name" value="" name="lastnameapps84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $_COOKIE[username]; ?>" name="lastnameappsuser84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" required></input>

</form>



</div>

</div>

</div>



</div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../secondemailapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/secondemailapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<div style="display:flex;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

Second email

</div>

<div style="display:flex;">

<div onclick="$('.googleappsappsappsappsappsappsappsappsappsappsappsappsappsapps44847474').show();" style="font-size:12.8px;cursor:pointer;">

edit

</div>

<div style="font-size:12.8px;margin-left:4px;">

<?php

echo "$gosearchimages84747674";

?>

</div>

</div>

<div>

<div align="center" class="googleappsappsappsappsappsappsappsappsappsappsappsappsappsapps44847474" style="position:fixed;left:0px;top:0px;background:rgba(0, 0, 0, 0.4);width:100%;height:100%;display:none;z-index:8884;">

<div style="padding:12px;margin-top:54px;background-color:#ffffff;">



<form action="/people/secondemailapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" placeholder="Second email" value="" name="secondemailapps84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $_COOKIE[username]; ?>" name="secondemailappsuser84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" required></input>

</form>



</div>

</div>

</div>



</div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../cityapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/cityapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT * FROM cityapps84747474 order by date desc limit 1";
$result = $conn84744474447444744474->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['city'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<div style="display:flex;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

City

</div>

<div style="display:flex;">

<div onclick="$('.googleappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsapps44847474').show();" style="font-size:12.8px;cursor:pointer;">

edit

</div>

<div style="font-size:12.8px;margin-left:4px;">

<?php

echo "$gosearchimages84747674";

?>

</div>

</div>

<div>

<div align="center" class="googleappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsapps44847474" style="position:fixed;left:0px;top:0px;background:rgba(0, 0, 0, 0.4);width:100%;height:100%;display:none;z-index:8884;">

<div style="padding:12px;margin-top:54px;background-color:#ffffff;">



<form action="/people/cityapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" placeholder="City" value="" name="cityapps84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $_COOKIE[username]; ?>" name="cityappsuser84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" required></input>

</form>



</div>

</div>

</div>



</div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../googleappsapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/googleappsapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT * FROM genderapps84747474 order by date desc limit 1";
$result = $conn84744474447444744474->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['gender'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<div style="display:flex;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

Gender

</div>

<div style="display:flex;">

<div onclick="$('.googleappsappsappsappsgooglegooglegooglegoogleapps44847474').show();" style="font-size:12.8px;cursor:pointer;">

edit

</div>

<div style="font-size:12.8px;margin-left:4px;">

<?php

echo "$gosearchimages84747674";

?>

</div>

</div>

<div>

<div align="center" class="googleappsappsappsappsgooglegooglegooglegoogleapps44847474" style="position:fixed;left:0px;top:0px;background:rgba(0, 0, 0, 0.4);width:100%;height:100%;display:none;z-index:8884;">

<div style="padding:12px;margin-top:54px;background-color:#ffffff;">



<form action="/people/googleappsapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" placeholder="Gender" value="" name="googleappsapps84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $_COOKIE[username]; ?>" name="googleappsappsuser84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" required></input>

</form>



</div>

</div>

</div>



</div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../aboutapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/aboutapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT * FROM aboutapps84747474 order by date desc limit 1";
$result = $conn84744474447444744474->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['about'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<div style="display:flex;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

About

</div>

<div style="display:flex;">

<div onclick="$('.googleappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsapps44847474').show();" style="font-size:12.8px;cursor:pointer;">

edit

</div>

<div style="font-size:12.8px;margin-left:4px;">

<?php

echo "$gosearchimages84747674";

?>

</div>

</div>

<div>

<div align="center" class="googleappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsapps44847474" style="position:fixed;left:0px;top:0px;background:rgba(0, 0, 0, 0.4);width:100%;height:100%;display:none;z-index:8884;">

<div style="padding:12px;margin-top:54px;background-color:#ffffff;">



<form action="/people/aboutapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" placeholder="About" value="" name="aboutapps84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $_COOKIE[username]; ?>" name="aboutappsuser84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" required></input>

</form>



</div>

</div>

</div>



</div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../usernameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/usernameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT * FROM username order by date desc limit 1";
$result = $conn84744474447444744474->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['username'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<div style="display:flex;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

Username

</div>

<div style="display:flex;">

<div onclick="$('.googleappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsapps44847474').show();" style="font-size:12.8px;cursor:pointer;">

edit

</div>

<div style="font-size:12.8px;margin-left:4px;">

<?php

echo "$gosearchimages84747674";

?>

</div>

</div>

<div>

<div align="center" class="googleappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsapps44847474" style="position:fixed;left:0px;top:0px;background:rgba(0, 0, 0, 0.4);width:100%;height:100%;display:none;z-index:8884;">

<div style="padding:12px;margin-top:54px;background-color:#ffffff;">



<form action="/people/usernameapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" placeholder="Username" value="" name="usernameapps84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $_COOKIE[username]; ?>" name="usernameappsuser84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" required></input>

</form>



</div>

</div>

</div>



</div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../passwordapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/passwordapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$query = "SELECT * FROM user4 order by date desc limit 1";
$result = $conn84744474447444744474->query($query);

$googleappsuserapps888474 = array();

while($row = $result->fetch_array())

{

$googleappsuserapps888474[] = $row['password'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsuserapps888474 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<div style="display:flex;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

Password

</div>

<div style="display:flex;">

<div onclick="$('.googleappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsapps44847474').show();" style="font-size:12.8px;cursor:pointer;">

edit

</div>

<div style="font-size:12.8px;margin-left:4px;">

<?php

echo "********";

?>

</div>

</div>

<div>

<div align="center" class="googleappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsappsapps44847474" style="position:fixed;left:0px;top:0px;background:rgba(0, 0, 0, 0.4);width:100%;height:100%;display:none;z-index:8884;">

<div style="padding:12px;margin-top:54px;background-color:#ffffff;">



<form action="/people/passwordapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" placeholder="Password" value="" name="passwordapps84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $_COOKIE[username]; ?>" name="usernameappsuser84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" required></input>

</form>



</div>

</div>

</div>



</div>

<br>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../userregistrations.sh";

}

else

{

$dataurl84 = "../register/userregistrations.sh";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl84");

?>

<?php

$query = "SELECT * FROM email order by date desc limit 1";
$result = $conn84744474447444744474->query($query);

$googleapps8884 = array();

while($row = $result->fetch_array())

{

$googleapps8884[] = $row['email'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleapps8884);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='na'>\n<div class='$googleappsapps84747474' id='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleapps8884 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

$googleapps84 = $_GET['useremail'];

$password = "googleappsmobileapps888888884444";

$nameappsapps84 = openssl_encrypt($googleapps84,"AES-128-ECB",$password);

$nameappsapps84 = rawurlencode($nameappsapps84);

?>

<?php

preg_match_all("/<div class='$nameappsapps84' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

?>

<style>

@media screen and (max-width:446px)
{
.googleappsimagesapps84
{
width:100%;
}
.googleappsmobileappsappsapps84
{
display:none;
}
.googleappsmobilegoogleapps84
{
display:inline-block!important;
}
.googleappsappsappsmobileapps84
{
width:100%;
}
.googleappsmobilegoogleappsgooglegoogleapps84
{
display:none;
}
.googleappsmobilegoogleapps84
{
font-size:12.8px;
}
}

@media screen and (min-width:448px)
{
.googleappsmobilegoogleapps84
{
display:none;
}
.googleappsmobilegoogleappsgooglegoogleapps84
{
margin-left:-44px;
font-size:12.8px;
}
}

</style>

<?php

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

?>

<?php

$ip84747474 = $ip; 
$freegeoipjson = file_get_contents("https://freegeoip.net/json/". $ip84747474 ."");
$jsondata = json_decode($freegeoipjson);
$countryfromip = $jsondata->country_name;
$cityfromip = $jsondata->city;
$regionnamefromip = $jsondata->region_name;

?>

<div style="position:relative;">

<div style="display:flex;">

<script>

$(document).ready(function(){

$('#googleapps84444474').click(function() {
  $('#google8474').style.display = "inline-block";

  });

});

</script>

<div class="googleappsappsapps84222274" style="font-size:12.8px;width:124px;overflow:hidden;">

<?php

$name = strtolower("$name");

?>

<div style="display:flex;position:relative;">

<div>



<div class="googleappsappsapps8474" id="google8474" style="display:none;">

<div>

<div style="position:fixed;background-color:#bdbdbd;z-index:44;height:100%;top:0px;width:100%;left:0px;background:rgba(0, 0, 0, 0.4);">

<div align="center" style="margin:12px;margin-top:62px;">

<form action="/people/pageupdates84747474.php" method="post" enctype="multipart/form-data" onsubmit="googleapps84747474()" id="googleapps84744474" style="margin-bottom:0px;">

<div style="position:relative;">

<input type="text" class="input8474" placeholder="Your first name" value="" id="name" name="nameapps84747474" autocomplete="off" style="margin-bottom:8px;letter-spacing:0.4px;width:100%;box-sizing:border-box;padding:12px;" required autofocus></input>

</div>

<input type="hidden" class="input84744474" placeholder="" value="<?php echo $countryfromip; ?>" name="countryapps8884" autocomplete="off" style="margin-bottom:8px;letter-spacing:0.4px;"></input>

<div style="position:relative;">

<input type="hidden" class="inputapps1" placeholder="Your email" value="<?php echo $_GET['useremail']; ?>" id="email" name="username84747474" autocomplete="off" style="margin-bottom:8px;letter-spacing:0.4px;" required><div style="position:absolute;top:14.8px;right:54px;font-size:13.8px;color:#424242;"></div></input>

</div>

<div style="position:relative;">

<input type="password" class="input847474" placeholder="Your password" value="" id="password" name="passwordapps8474" autocomplete="off" style="margin-bottom:8px;letter-spacing:0.4px;width:100%;box-sizing:border-box;padding:12px;" required></input>

</div>

<input type="submit" class="input8474" placeholder="Your first name" value="update" id="name84444474" autocomplete="off" style="border:none;padding:12px;" required></input>

</form>

</div>

</div>

</div>

</div>



</div>

</div>

</div>

</div>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{

?>

<?php

}

?>

</div>

<div style="display:flex;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

Email:

</div>

<?php

$google84747474 = $_GET['useremail'];

$google84747474 = strtolower("$google84747474");

?>

<div class="googleappsappsapps84222274" style="font-size:12.8px;width:124px;overflow:hidden;">

<?php

echo "$google84747474";

?>

</div>

</div>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../adsclicksapps84747474.sh";

}

else

{

$dataurlappsappsapps84 = "../people/adsclicksapps84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlappsappsapps84);

?>

<?php

$query = "SELECT * FROM adsclicksapps844444444474";
$result = $conn84744474447444744474->query($query);

$googleappsgooglegoogleapps8884 = array();

while($row = $result->fetch_array())

{

$googleappsgooglegoogleapps8884[] = $row['userip'];

}

?>

<?php

$google84744474447444744474 = implode("<br>",$googleappsuserapps888474);

$google84744474447444744474 = explode("<br>",$google84744474447444744474);

?>

<?php

$googleappsgooglegoogleapps8884447444744474 = array();

foreach($google84744474447444744474 as $googleappsapps84747474)

{

$googleappsgooglegoogleapps888444744474 = "<div class='$_COOKIE[username]' id='ads'>\n<div class='na'>1</div>\n</div>";

$googleappsgooglegoogleapps8884447444744474[] .= "$googleappsgooglegoogleapps888444744474";

}

?>

<?php

$googleappsgooglegoogleapps8884 = implode("\n",$googleappsgooglegoogleapps8884447444744474);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='ads'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsappsgoogleappsappsapps847422744444444474 = $googleappsappsappsgoogleappsapps84[1][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsappsgoogleappsappsapps847422744444444474"))

{

$accountcolorappsappsappsappsappsgoogleappsappsapps847422744444444474 = $accountcolorappsappsappsappsappsgoogleappsappsapps847422744444444474 + 4;

}

else

{

$accountcolorappsappsappsappsappsgoogleappsappsapps847422744444444474 = "4";

}

?>

<script>

$(document).ready(function() {

$('#namemobileapps84444474').click(function(){

var googlemobileapps844444444474 = $('#namemobileapps84747474').val();

if(googlemobileapps844444444474 == "") {

}

else

{

var googlemobileapps84444474 = $('#namemobileapps84747474').val();

var googlemobileapps84222274 = $('#emailmobileapps84747474').val();

var googlemobileapps84744474 = $('#emailmobileapps84742274').val();

$.ajax({
    data: 'adsusername84747474=' + googlemobileapps84444474 + '&adsusername84444474=' + googlemobileapps84222274 + '&adsusername84442274=' + googlemobileapps84744474 + '',
    url: '/people/adsgoogleapps84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

$.ajax({
    data: 'adsusernameappsappsapps84747474=<?php echo "$_COOKIE[username]"; ?>&adsusername84222274=<?php echo "$accountcolorappsappsappsappsappsgoogleappsappsapps847422744444444474"; ?>',
    url: '/people/adsclicksapps84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

}

});

});

</script>

<?php

if(preg_match("/[\W\w]/",$_GET['googleapps84']))

{

?>

<script>

$(document).ready(function() {

$('#googlelabelappsgoogleapps8444444444742244').click();

}

);

</script>

<?php

}

?>

<div class="googleappsappsapps8474" id="google8444447474" style="display:none;">

<div>

<div style="position:fixed;background-color:#bdbdbd;width:100%;z-index:44;height:100%;top:0px;left:0px;background:rgba(0, 0, 0, 0.4);">

<div align="center" style="margin:12px;margin-top:62px;background-color:#ffffff;padding:12px;box-sizing:border-box;">

<div align="center" style="margin:12px;margin-top:12px;">

<div style="font-size:17.6px;font-weight:bold;margin-bottom:12px;">

Create an ad and make payment

<div style="font-weight:normal;font-size:14.8px;">

$4 dollar per ad for 400 clicks $0.01 dollar per click

</div>

<div style="font-weight:normal;font-size:12.8px;">

When ad balance is depleted buy another ad space

</div>

</div>

<form action="/people/pageupdates84747474.php" method="post" enctype="multipart/form-data" onsubmit="googleapps84747474()" id="googleapps8474444444444474" style="margin-bottom:0px;">

<div style="position:relative;">

<input type="text" class="input8474" placeholder="Your ad name" value="" id="namemobileapps84747474" name="nameapps84747474" autocomplete="off" style="margin-bottom:8px;letter-spacing:0.4px;width:100%;box-sizing:border-box;padding:12px;" required autofocus></input>

</div>

<input type="hidden" class="input84744474" placeholder="" value="<?php echo $countryfromip; ?>" name="countryapps8884" autocomplete="off" style="margin-bottom:8px;letter-spacing:0.4px;"></input>

<div style="position:relative;">

<input type="text" class="inputapps1" placeholder="Your ad description" value="" id="emailmobileapps84747474" name="username84747474" autocomplete="off" style="margin-bottom:8px;letter-spacing:0.4px;width:100%;box-sizing:border-box;padding:12px;" required><div style="position:absolute;top:14.8px;right:54px;font-size:13.8px;color:#424242;"></div></input>

</div>

<div style="position:relative;">

<input type="text" class="inputapps1" placeholder="Your ad url" value="" id="emailmobileapps84742274" name="username84747474" autocomplete="off" style="margin-bottom:8px;letter-spacing:0.4px;width:100%;box-sizing:border-box;padding:12px;" required><div style="position:absolute;top:14.8px;right:54px;font-size:13.8px;color:#424242;"></div></input>

</div>

</form>

<div id="namemobileapps84444474" style="border:none;padding:12px;display:inline-block;" onclick="$('#google8444447474').hide();">

<div>

<form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="business" value="<?php echo "mobileappsmobileapps8@gmail.com"; ?>">
<input type="hidden" name="amount" value='<?php echo "0.10"; ?>'>
<input type="hidden" name="return" value='https://<?php echo "$_SERVER[HTTP_HOST]"; ?>/accounts/payments84747474.php?paymentsapps84747474=googleapps84'>
<input name="item_name" type="hidden" value="Bluecloud ads" />
<input type="submit" value="Make payment" name="submit" title="" class="paypal_btn" id="google84747474" formtarget="_self" style="background-color:#1565C0;font-size:14.8px;">
</form>

</div>

</div>

</div>

</div>

</div>

</div>

</div>

<div style="margin-bottom:24px;margin-top:24px;">

Ads

</div>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{

?>

<style>

@import url(https://fonts.googleapis.com/css?family=Roboto:300,500);

.switch-input {
  display: none;
}
.switch-label {
  position: relative;
  display: inline-block;
  min-width: 112px;
  cursor: pointer;
  font-weight: 500;
  text-align: left;
}
.switch-label:before, .switch-label:after {
  content: "";
  position: absolute;
  margin: 0;
  outline: 0;
  top: 50%;
  -ms-transform: translate(0, -50%);
  -webkit-transform: translate(0, -50%);
  transform: translate(0, -50%);
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.switch-label:before {
  left: 1px;
  width: 34px;
  height: 14px;
  background-color: #bdbdbd;
  border-radius: 8px;
}
.switch-label:after {
  left: 0;
  width: 20px;
  height: 20px;
  background-color: #FAFAFA;
  border-radius: 50%;
  box-shadow: 0 3px 1px -2px rgba(0, 0, 0, 0.14), 0 2px 2px 0 rgba(0, 0, 0, 0.098), 0 1px 5px 0 rgba(0, 0, 0, 0.084);
}
.switch-label .toggle--on {
  display: none;
}
.switch-label .toggle--off {
  display: inline-block;
}
.switch-input:checked + .switch-label:before {
  background-color: <?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsapps84"; ?>;
}
.switch-input:checked + .switch-label:after {
  background-color: <?php echo "$accountcolor4"; ?>;
  -ms-transform: translate(80%, -50%);
  -webkit-transform: translate(80%, -50%);
  transform: translate(80%, -50%);
}
.switch-input:checked + .switch-label .toggle--on {
  display: inline-block;
}
.switch-input:checked + .switch-label .toggle--off {
  display: none;
}

</style>

<?php

}

?>

<div style="display:flex;margin-top:12px;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

Opt in to ads

</div>

<div class="googleappsappsapps84222274" style="font-size:12.8px;width:446px;margin-left:-86px;position:relative;height:44px;margin-top:-24px;padding-top:12px;">

<div class="googleappsappsapps84222274" style="font-size:12.8px;width:446px;margin-left:18px;position:absolute;left:81.4px;padding-top:12px;padding-bottom:12px;">

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../coworkersappsappsappsgoogleappsgoogleapps847474742244.sh";

}

else

{

$dataurlurlgoogleapps84 = "coworkersappsappsappsgoogleappsgoogleapps847474742244.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1][0];

if(preg_match("/1/","$accountcolorappsappsappsappsapps84742274"))

{

?>

<?php

$google84747474 = "checked";

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../adsclicksapps84747474.sh";

}

else

{

$dataurlappsappsapps84 = "../people/adsclicksapps84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlappsappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='ads'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsappsgoogleappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1][0];

?>

<?php

$query = "SELECT * FROM adsclicksapps844444444474 WHERE email='$_COOKIE[username]' order by date desc limit 1";
$result = $conn84744474447444744474->query($query);

$accountcolorappsappsappsappsappsgoogleappsappsapps84742274 = array();

while($row = $result->fetch_array())

{

$accountcolorappsappsappsappsappsgoogleappsappsapps84742274[] = $row['userip'];

}

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../adsclicksapps84747474.sh";

}

else

{

$dataurlappsappsapps84 = "../people/adsclicksapps84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlappsappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1];

?>

<?php

$query = "SELECT * FROM adsclicksapps844444444474 WHERE email='$_COOKIE[username]'";
$result = $conn84744474447444744474->query($query);

$accountcolorappsappsappsappsapps84742274 = array();

while($row = $result->fetch_array())

{

$accountcolorappsappsappsappsapps84742274[] = $row['userip'];

}

?>

<?php

$accountcolorappsappsappsappsapps84742274 = count($accountcolorappsappsappsappsapps84742274);

$accountcolorappsappsappsappsapps84742274 = $accountcolorappsappsappsappsapps84742274 / 100;

$accountcolorappsappsappsappsapps84742274 = $accountcolorappsappsappsappsappsgoogleappsappsapps84742274 - $accountcolorappsappsappsappsapps84742274;

?>

<?php

if($accountcolorappsappsappsappsapps84742274 > "4")

{

?>

<?php

$google847474744444444474 = "#google8444447474";

$google84747474 = "unchecked";

?>

<?php

}

else

{

?>

<?php

}

?>



<?php

}

else

{

?>

<?php

$google84747474 = "unchecked";

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../adsclicksapps84747474.sh";

}

else

{

$dataurlappsappsapps84 = "../people/adsclicksapps84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlappsappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='ads'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsappsgoogleappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1][0];

?>

<?php

$query = "SELECT * FROM adsclicksapps844444444474 WHERE email='$_COOKIE[username]' order by date desc limit 1";
$result = $conn84744474447444744474->query($query);

$accountcolorappsappsappsappsappsgoogleappsappsapps84742274 = array();

while($row = $result->fetch_array())

{

$accountcolorappsappsappsappsappsgoogleappsappsapps84742274[] = $row['userip'];

}

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../adsclicksapps84747474.sh";

}

else

{

$dataurlappsappsapps84 = "../people/adsclicksapps84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlappsappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1];

?>

<?php

$query = "SELECT * FROM adsclicksapps844444444474 WHERE email='$_COOKIE[username]'";
$result = $conn84744474447444744474->query($query);

$accountcolorappsappsappsappsapps84742274 = array();

while($row = $result->fetch_array())

{

$accountcolorappsappsappsappsapps84742274[] = $row['userip'];

}

?>

<?php

$accountcolorappsappsappsappsapps84742274 = count($accountcolorappsappsappsappsapps84742274);

$accountcolorappsappsappsappsapps84742274 = $accountcolorappsappsappsappsapps84742274 / 100;

$accountcolorappsappsappsappsapps84742274 = $accountcolorappsappsappsappsappsgoogleappsappsapps84742274 - $accountcolorappsappsappsappsapps84742274;

?>

<?php

if($accountcolorappsappsappsappsapps84742274 > "4")

{

?>

<?php

$google847474744444444474 = "#google8444447474";

$google84747474 = "unchecked";

?>

<?php

}

else

{

?>

<?php

}

?>

<?php

}

?>

<input type="checkbox" id="id-name--847474744444742244" value="<?php echo $google84747474; ?>" name="set-name8474444444742244" class="switch-input" <?php echo "$google84747474"; ?>>
<label for="id-name--847474744444742244" id="googlelabelappsgoogleapps8444444444742244" class="switch-label" style="padding-left:44px;" onclick="$('<?php echo "$google847474744444444474"; ?>').show();">

<span class="toggle--on">

On $4 per ad

</span>

<span class="toggle--off">

Off $4 per ad

</span></label>

<script>

$(document).ready(function() {

$('#googlelabelappsgoogleapps8444444444742244').click(function(event) {

var google84447474 = $('#id-name--847474744444742244').val();

if (google84447474 == 'unchecked') {

$.ajax({
    data: 'userappsappsappsapps84747474=1&nameapps84747474=googleapps84',
    url: '/people/coworkersappsappsappsgoogleappsgoogleapps847474742244.php',
    method: 'GET',
    success: function(msg) {
    }
});

}

else

{

$.ajax({
    data: 'userappsappsappsapps84747474=0&nameapps84747474=googleapps84',
    url: '/people/coworkersappsappsappsgoogleappsgoogleapps847474742244.php',
    method: 'GET',
    success: function(msg) {
    }
});

}

});

});

</script>

</div>

</div>

</div>

<?php

}

?>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{

?>

<div style="display:flex;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;padding-top:12px;padding-bottom:12px;">

<div style="display:flex;">

<div>

<i class="material-icons">mouse</i>

</div>

<div style="margin-left:24px;">

Total clicks

</div>

</div>

</div>

<div class="googleappsappsapps84222274" style="font-size:12.8px;width:124px;margin-left:18px;position:absolute;left:134px;padding-top:12px;padding-bottom:12px;">

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../adsclicksapps84747474.sh";

}

else

{

$dataurlappsappsapps84 = "../people/adsclicksapps84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlappsappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1];

?>

<?php

$query = "SELECT * FROM adsclicksapps844444444474 WHERE email='$_COOKIE[username]'";
$result = $conn84744474447444744474->query($query);

$accountcolorappsappsappsappsapps84742274 = array();

while($row = $result->fetch_array())

{

$accountcolorappsappsappsappsapps84742274[] = $row['userip'];

}

?>

<?php

$accountcolorappsappsappsappsapps84742274 = count($accountcolorappsappsappsappsapps84742274);

echo "$accountcolorappsappsappsappsapps84742274";

?>

</div>

</div>

<?php

}

?>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{

?>

<div style="display:flex;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;padding-top:12px;padding-bottom:12px;">

<div style="display:flex;">

<div>

<i class="material-icons">attach_money</i>

</div>

<div style="margin-left:24px;">

Available balance

</div>

</div>

</div>

<div class="googleappsappsapps84222274" style="font-size:12.8px;width:124px;margin-left:18px;position:absolute;left:134px;padding-top:12px;padding-bottom:12px;">

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../adsclicksapps84747474.sh";

}

else

{

$dataurlappsappsapps84 = "../people/adsclicksapps84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlappsappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='ads'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsappsgoogleappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1][0];

?>

<?php

$query = "SELECT * FROM adsclicksapps844444444474 WHERE email='$_COOKIE[username]' order by date desc limit 1";
$result = $conn84744474447444744474->query($query);

$accountcolorappsappsappsappsappsgoogleappsappsapps84742274 = array();

while($row = $result->fetch_array())

{

$accountcolorappsappsappsappsappsgoogleappsappsapps84742274[] = $row['userip'];

}

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../adsclicksapps84747474.sh";

}

else

{

$dataurlappsappsapps84 = "../people/adsclicksapps84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlappsappsapps84);

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsappsapps84 = "../paymentsapps84747474.sh";

}

else

{

$dataurlappsappsappsapps84 = "../paymentsapps84747474.sh";

}

?>

<?php

$googleappsgooglegoogleappsappsappsapps8884 = file_get_contents($dataurlappsappsappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/", $googleappsgooglegoogleappsappsappsapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[4];

$accountcolorappsappsappsappsapps8474227444744474447444744474 = array_sum($accountcolorappsappsappsappsapps84742274);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1];

?>

<?php

$query = "SELECT * FROM adsclicksapps844444444474 WHERE email='$_COOKIE[username]'";
$result = $conn84744474447444744474->query($query);

$accountcolorappsappsappsappsapps84742274 = array();

while($row = $result->fetch_array())

{

$accountcolorappsappsappsappsapps84742274[] = $row['userip'];

}

?>

<?php

$accountcolorappsappsappsappsapps84742274 = count($accountcolorappsappsappsappsapps84742274);

$accountcolorappsappsappsappsapps84742274 = $accountcolorappsappsappsappsapps84742274 / 100;

$accountcolorappsappsappsappsapps84742274 = "$accountcolorappsappsappsappsapps8474227444744474447444744474" - $accountcolorappsappsappsappsapps84742274;

$accountcolorappsappsappsappsapps84742274 =  str_replace("/-/","",$accountcolorappsappsappsappsapps84742274);

$accountcolorappsappsappsappsapps84742274 = number_format($accountcolorappsappsappsappsapps84742274, 2,'.', ',');

echo "$" . "$accountcolorappsappsappsappsapps84742274";

?>

</div>

</div>

<div>

<div>

<div style="font-size:14.8px;margin-bottom:12px;">

Deposit any amount

</div>

<form action="/accounts/paymentsappsapps84747474.php" method="post">

<div style="display:-webkit-box;">

<input type="text" name="googleappsappsappsapps847474744474" placeholder="enter amount" style="padding:8px;font-size:14.6px;outline:none;" required>

<input type="submit" name="submit" id="google84747474" class="googleappsappsappsapps844444444444744474" style="background-color:#1565C0;font-size:14.8px;border:none;color:#ffffff;padding:10px;margin-top:12px;display:none;">

<div onclick="$('.googleappsappsappsapps844444444444744474').click();" style="cursor:pointer;">

<i class="material-icons" style="font-size:36.8px;color:#444444;background-color:#bdbdbd;">arrow_forward</i>

</div>

</div>

</form>

</div>

</div>

<div style="padding:12px;">

</div>

<?php

}

?>

<div style="font-size:14.8px;margin-bottom:12px;">

<a href="/accounts/paymenthistoryapps84747474.php">Payment History</a>

</div>

<div style="margin-bottom:12px;">

Theme

</div>

<div>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlapps84 = "../accountcolor88842274.sh";

}

else

{

$dataurlurlapps84 = "../register/accountcolor88842274.sh";

}

?>

<?php

$googleappsgoogleappsappsgoogleapps8884 = file_get_contents($dataurlurlapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../accountcolor8884.sh";

}

else

{

$dataurlurlgoogleapps84 = "../register/accountcolor8884.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleapps84);
$accountcolor84742274 = $googleapps84[3][0];

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolor847474"))

{

$accountcolor1 = "$accountcolor847474";

$accountcolor2 = "$accountcolor847474";

$accountcolor4 = "$accountcolor847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{

?>

<form action="/register/accountcolor84747474.php" method="post">

<div style="display:flex;">

<div style="font-size:12.8px;width:124px;padding-top:12px;padding-bottom:12px;">

<div style="display:flex;">

<div>

<i class="material-icons">color_lens</i>

</div>

<div style="margin-left:24px;">

Theme

</div>

</div>

</div>

<div style="margin-left:18px;margin-top:12.8px;">

<input type="color" name="googleappscolorapps84747474" value="<?php echo $accountcolor1; ?>" style="border:none;background-color:#ffffff;margin-top:-12px;">

</div>

<div>

<input type="submit" value="update" style="padding:5.4px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:inline-block;color:#444444;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;border:none;margin-top:12.8px;margin-left:12px;">

</div>

</div>

<input type="hidden" name="useremail" value="<?php echo $_GET[useremail]; ?>">

</form>

<?php

}

?>

<script>

$(document).ready(function() {

$('#googleapps844444444474').click(function(){

$.ajax({
    data: 'thumbsupapps84747474=1&userapps84747474=<?php echo "$nameappsapps8884"; ?>',
    url: '/people/thumbsupapps84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

});

});

</script>

<div class="googleappsappsapps8474" id="google84744474" style="display:none;" onclick="$(this).hide();">

<div>

<div style="position:fixed;background-color:#bdbdbd;z-index:44;height:100%;top:0px;width:100%;left:0px;background:rgba(0, 0, 0, 0.4);">

<div align="center" style="margin:12px;margin-top:62px;background-color:#ffffff;padding:12px;">

You promoted this person

</div>

</div>

</div>

</div>

<div style="margin-bottom:24px;">

Account

</div>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../thumbsupapps84747474.sh";

}

else

{

$dataurl84 = "thumbsupapps84747474.sh";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl84");

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleappsgooglegoogleapps84);

$namegoogleapps84747474 = $googleappsgooglegoogleapps84[1];

$namegoogleapps84747474 = count($namegoogleapps84747474);

?>

<div style="display:flex;margin-top:12px;margin-bottom:12px;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

<div style="display:flex;">

<div>

<i class="material-icons">thumb_up</i>

</div>

<div style="margin-left:24px;">

Promotions

</div>

</div>

</div>

<?php

$google84747474 = $_GET['useremail'];

$google84747474 = strtolower("$google84747474");

?>

<div class="googleappsappsapps84222274" style="font-size:12.8px;width:124px;margin-left:-78px;position:relative;height:44px;">

<div id="googleapps844444444474" style="padding-left:12px;position:absolute;right:0px;cursor:pointer;padding-left:12px;right:0px;cursor:pointer;padding:5.4px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:inline-block;color:#444444;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;border:none;margin-top:12.8px;margin-left:12px;right:0px;top:-12px;position:absolute;border-radius:196px;">

<?php echo "$namegoogleapps84747474"; ?>

</div>

</div>

<?php

}

else

{

?>

<div style="display:flex;margin-top:12px;margin-bottom:44px;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

Show your interest

</div>

<?php

$google84747474 = $_GET['useremail'];

$google84747474 = strtolower("$google84747474");

?>

<div class="googleappsappsapps84222274" style="font-size:12.8px;width:124px;margin-left:-37.4px;position:relative;height:44px;">

<div id="googleapps844444444474" onclick="$('#google84744474').show();" style="padding-left:12px;position:absolute;right:0px;cursor:pointer;padding-left:12px;right:0px;cursor:pointer;padding:5.4px;background-color:#444444;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:inline-block;color:#ffffff;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;border:none;margin-top:12.8px;margin-left:12px;right:0px;top:-12px;position:absolute;">

Promote

</div>

</div>

</div>

<?php

}

?>

</div>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{

?>

<div style="display:flex;margin-top:12px;margin-bottom:44px;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

Allow users to add you

</div>

<div class="googleappsappsapps84222274" style="font-size:12.8px;width:446px;margin-left:-86px;position:relative;height:44px;margin-top:-24px;padding-top:12px;">

<div class="googleappsappsapps84222274" style="font-size:12.8px;width:446px;margin-left:18px;position:absolute;left:81.4px;padding-top:12px;padding-bottom:12px;">

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../coworkersappsappsappsgoogleappsgoogleapps84747474.sh";

}

else

{

$dataurlurlgoogleapps84 = "../people/coworkersappsappsappsgoogleappsgoogleapps84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1][0];

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsapps84742274"))

{

if(preg_match("/0/","$accountcolorappsappsappsappsapps84742274"))

{

$google84747474 = "unchecked";

}

else

{

if(preg_match("/1/","$accountcolorappsappsappsappsapps84742274"))

{

$google84747474 = "checked";

}

}

}

else

{

if(preg_match("/0/","$accountcolorappsappsappsappsapps84742274"))

{

$google84747474 = "unchecked";

}

else

{

$google84747474 = "checked";

}

}

?>

<input type="checkbox" id="id-name--84747474444474" value="<?php echo $google84747474; ?>" name="set-name847444444474" class="switch-input" <?php echo "$google84747474"; ?>>
<label for="id-name--84747474444474" id="googlelabelappsgoogleapps844444444474" class="switch-label" style="padding-left:44px;">

<span class="toggle--on">

On

</span>

<span class="toggle--off">

Off

</span></label>

<script>

$(document).ready(function() {

$('#googlelabelappsgoogleapps844444444474').click(function(event) {

var google84447474 = $('#id-name--84747474444474').val();

if (google84447474 == 'unchecked') {

$.ajax({
    data: 'userappsappsappsapps84747474=1&nameapps84747474=googleapps84',
    url: '/people/coworkersappsappsappsgoogleappsgoogleapps84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

}

else

{

$.ajax({
    data: 'userappsappsappsapps84747474=0&nameapps84747474=googleapps84',
    url: '/people/coworkersappsappsappsgoogleappsgoogleapps84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

}

});

});

</script>

</div>

</div>

</div>

<?php

}

?>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{

?>

<div style="display:flex;margin-top:12px;margin-bottom:44px;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

Layout style

</div>

<div class="googleappsappsapps84222274" style="font-size:12.8px;width:446px;margin-left:-86px;position:relative;height:44px;margin-top:-24px;padding-top:12px;">

<div class="googleappsappsapps84222274" style="font-size:12.8px;width:446px;margin-left:18px;position:absolute;left:81.4px;padding-top:12px;padding-bottom:12px;">

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../coworkersgoogle84747474.sh";

}

else

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../people/coworkersgoogle84747474.sh";

}

?>

<?php

$googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884 = file_get_contents($dataurlurlgoogleappsgooglegoogleappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884, $googleappsappsappsgoogleappsappsgooglegoogleappsapps84);
$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274 = $googleappsappsappsgoogleappsappsgooglegoogleappsapps84[2][0];

?>

<?php

if(preg_match("/business/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "business";

}

if(preg_match("/apps/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "Getit";

}

if(preg_match("/google/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "google";

}

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{
}

else

{

$googleappsappsapps84744474 = "business";

}

?>

<div style="width:100%;">

<div>

<div class="dropdown">
  <button onclick="myFunctionappsapps84747474()" class="dropbtn" style="font-size:12.4px;background:none;border:none;"><?php echo "$googleappsappsapps84744474"; ?></button>
  <div id="myDropdown" class="dropdown-content" style="margin-top:-62px;">
    <a href="/people/googleappsappsappsapps84747474.php?business84747474=googleapps84&business84444474=<?php echo $_COOKIE['username']; ?>&useremail=<?php echo $_GET['useremail']; ?>" style="font-size:14px;background-color:#ffffff;">Business</a>
    <a href="/people/googleappsappsappsapps84747474.php?googleapps84747474=googleapps84&business84444474=<?php echo $_COOKIE['username']; ?>&useremail=<?php echo $_GET['useremail']; ?>" style="font-size:14px;background-color:#ffffff;">Apps</a>
    <a href="/people/googleappsappsappsapps84747474.php?google84747474=googleapps84&business84444474=<?php echo $_COOKIE['username']; ?>&useremail=<?php echo $_GET['useremail']; ?>" style="font-size:14px;background-color:#ffffff;">Google</a>
  </div>
</div>

<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunctionappsapps84747474() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

<style>

/* Dropdown Button */
.dropbtn {
cursor: pointer;
}

/* Dropdown button on hover & focus */
.dropbtn:hover, .dropbtn:focus {
    background-color: #2980B9;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
    position: relative;
    display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow: 0px 2px 4px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color:#ebebeb!important}

/* Show the dropdown menu (use JS to add this class to the .dropdown-content container when the user clicks on the dropdown button) */
.show {display:block;}

</style>

</div>

</div>

<script>

$(document).ready(function() {

$('#googlelabelappsgoogleapps844444444474').click(function(event) {

var google84447474 = $('#id-name--84747474444474').val();

if (google84447474 == 'unchecked') {

$.ajax({
    data: 'userappsappsappsapps84747474=1&nameapps84747474=googleapps84',
    url: '/people/coworkersappsappsappsgoogleappsgoogleapps84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

}

else

{

$.ajax({
    data: 'userappsappsappsapps84747474=0&nameapps84747474=googleapps84',
    url: '/people/coworkersappsappsappsgoogleappsgoogleapps84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

}

});

});

</script>

</div>

</div>

</div>

<?php

}

?>

<div style="margin-bottom:24px;">

Search

</div>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{

?>

<div style="display:flex;margin-top:12px;margin-bottom:24px;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

Show coworkers in search

</div>

<div class="googleappsappsapps84222274" style="font-size:12.8px;width:446px;margin-left:-86px;position:relative;height:44px;margin-top:-24px;padding-top:12px;">

<div class="googleappsappsapps84222274" style="font-size:12.8px;width:446px;margin-left:18px;position:absolute;left:81.4px;padding-top:12px;padding-bottom:12px;">

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../coworkersappsappsapps84747474.sh";

}

else

{

$dataurlurlgoogleapps84 = "../people/coworkersappsappsapps84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1][0];

if(preg_match("/1/","$accountcolorappsappsappsappsapps84742274"))

{

$google84747474 = "checked";

}

else

{

$google84747474 = "unchecked";

}

?>

<input type="checkbox" id="id-name--62" value="<?php echo $google84747474; ?>" name="set-name84444474" class="switch-input" <?php echo "$google84747474"; ?>>
<label for="id-name--62" id="googlelabelapps84" class="switch-label" style="padding-left:44px;margin-left:4px;">

<span class="toggle--on">

On

</span>

<span class="toggle--off">

Off

</span></label>

<script>

$(document).ready(function() {

$('#googlelabelapps84').click(function(event) {

var google84447474 = $('#id-name--62').val();

if (google84447474 == 'unchecked') {

$.ajax({
    data: 'userappsappsappsapps84747474=1&nameapps84747474=googleapps84',
    url: '/people/coworkersappsappsapps84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

}

else

{

$.ajax({
    data: 'userappsappsappsapps84747474=0&nameapps84747474=googleapps84',
    url: '/people/coworkersappsappsapps84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

}

});

});

</script>

</div>

</div>

</div>

<?php

}

?>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{

?>

<div style="display:flex;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;padding-top:12px;padding-bottom:12px;">

Improve user search

</div>

<div class="googleappsappsapps84222274" style="font-size:12.8px;width:124px;margin-left:18px;position:absolute;left:134px;padding-top:12px;padding-bottom:12px;">

<input type="checkbox" id="id-name--4" name="set-name84747474" class="switch-input">
<label for="id-name--4" class="switch-label" style="padding-left:44px;"><span class="toggle--on"><?php echo "On"; ?></span><span class="toggle--off">Off</span></label>

</div>

</div>

<div style="padding:12px;">

</div>

<?php

}

?>

<div style="margin-bottom:24px;">

Images

</div>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleappsgooglemobileappsapps84 = "../gosearchimagesgoogleapps8884.sh";

}

else

{

$dataurlurlgoogleappsgooglemobileappsapps84 = "../gosearchimages8884/gosearchimagesgoogleapps8884.sh";

}

?>

<?php

$google842222222274 = file_get_contents($dataurlurlgoogleappsgooglemobileappsapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

if(preg_match("/$_COOKIE[username]/",$nameappsapps8884))

{

?>

<script>

$(document).ready(function(){

$('#googleimageappsmobileappsappsappsapps84').on('change', function() {

document.getElementById("google8444444444444474").click();

});

});

</script>

<div>

<div>

<form action="/google8474/googleappsgoogleapps8474.php" method="post" enctype="multipart/form-data" id="googleappsappsappsappsapps8474744444444474" style="display:inline-grid;display:none;">

<input type="hidden" name="username84747474" value="<?php echo "$_GET[useremail]"; ?>"></input>

<input type="file" name="image" id="googleimageappsmobileappsappsappsapps84" style="width:44px;height:44px;padding-top:62px;z-index:44;padding-left:24px;display:none;"></input>

<input type="submit" value="Submit" style="border:none;background-color:<?php echo "$accountcolor4"; ?>;padding:12px;color:#ffffff;font-weight:bold;margin:12px;font-size:13.8px;display:none;" id="google8444444444444474"></input>

</form>

</div>

</div>

<div style="display:flex;margin-top:12px;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

<div style="display:flex;">

<div>

<i class="material-icons">insert_photo</i>

</div>

<div style="margin-left:24px;">

Images

</div>

</div>

</div>

<div class="googleappsappsapps84222274" style="font-size:12.8px;width:124px;margin-left:-70px;position:relative;height:44px;">

<div id="googleappsappsappsappsapps844444444474" onclick="document.getElementById('googleimageappsmobileappsappsappsapps84').click();" style="padding-left:12px;position:absolute;right:0px;cursor:pointer;padding-left:12px;right:0px;cursor:pointer;padding:5.4px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:inline-block;color:#444444;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;border:none;margin-top:12.8px;margin-left:12px;right:0px;top:-12px;position:absolute;">

Add

</div>

</div>

</div>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

preg_match_all("/<div class='$nameappsapps8884' id='na'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/s", $google842222222274, $gosearchimages844444224474);
$gosearchimages844444444474 = $gosearchimages844444224474[1];

$gosearchimages844444444474 = implode("<br>",$gosearchimages844444444474);

$gosearchimages844444444474 = explode("<br>",$gosearchimages844444444474);

?>

<div>

<div style="display:flex;margin-top:12px;margin-bottom:44px;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

<div style="display:flex;">

<div>

<i class="material-icons">photo_library</i>

</div>

<div style="margin-left:24px;">

Images

</div>

</div>

</div>

<div style="margin-left:14.6px;">

<div style="display:flex;">

<?php

$googleapps84 = "0";

?>

<div class="googleappsappsapps8474" id="googlemobileappsapps847474744474" style="display:none;">

<div>

<div style="position:fixed;background-color:#bdbdbd;z-index:44;height:100%;top:0px;width:100%;left:0px;background:rgba(0, 0, 0, 0.4);overflow:scroll;">

<div align="center" style="margin:12px;margin-top:62px;background-color:#ffffff;padding:12px;display:grid;">

<?php

foreach($gosearchimages844444444474 as $googleapps8444444474747474)

{

$googleapps84++;

?>

<?php

if(preg_match("/[\W\w]/","$googleapps8444444474747474"))

{

?>

<?php

echo "<img class='googleappsappsappsmobileapps84' src='$googleapps8444444474747474' style='width:100%;'></img>";

?>

<?php

}

?>

<?php

}

?>

</div>

</div>

</div>

</div>

<div>

<div class="googleappsmobilegoogleapps84" onclick="$('#googlemobileappsapps847474744474').show();">Show all images</div>

</div>

<?php

$googleapps84 = "0";

?>

<?php

foreach($gosearchimages844444444474 as $googleapps8444444474747474)

{

$googleapps84++;

?>

<div class="googleappsappsapps8474" id="googlemobileappsapps<?php echo "$googleapps84"; ?>" style="display:none;" onclick="$(this).hide();">

<div>

<div style="position:fixed;background-color:#bdbdbd;z-index:44;height:100%;top:0px;width:100%;left:0px;background:rgba(0, 0, 0, 0.4);">

<div align="center" style="margin:12px;margin-top:62px;background-color:#ffffff;padding:12px;">

<img class='googleappsimagesapps84' src='<?php echo "$googleapps8444444474747474"; ?>' style="width:100%;"></img>

</div>

</div>

</div>

</div>

<div>

<div class="googleappsappsapps84222274">

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../coworkersappsappsappsgoogleapps84747474.sh";

}

else

{

$dataurlurlgoogleapps84 = "coworkersappsappsappsgoogleapps84747474.sh";

}

?>

<?php

$googleappsgooglegoogleappsgoogleappsgosearchimagesgoogleappsapps84747674848884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleappsgoogleappsgosearchimagesgoogleappsapps84747674848884, $googleappsappsappsgoogleappsappsgoogleappsgosearchimagesgoogleappsapps847476748484);
$accountcolorappsappsappsappsappsgoogleappsgosearchimagesgoogleappsapps847476748484742274 = $googleappsappsappsgoogleappsappsgoogleappsgosearchimagesgoogleappsapps847476748484[1][0];

if(preg_match("/1/","$accountcolorappsappsappsappsappsgoogleappsgosearchimagesgoogleappsapps847476748484742274"))

{

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleappsgoogleappsapps84 = "../coworkers84747474.sh";

}

else

{

$dataurlurlgoogleappsgoogleappsapps84 = "coworkers84747474.sh";

}

?>

<?php

$googleappsgooglegoogleappsgoogleappsapps8884 = file_get_contents($dataurlurlgoogleappsgoogleappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsgooglegoogleappsgoogleappsapps8884, $googleappsgosearchimagesgoogleappsapps8474767484);
$gosearchimagesgoogleappsapps84747674 = $googleappsgosearchimagesgoogleappsapps8474767484[1][0];

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesgoogleappsapps84747674"))

{

?>

<?php

if(preg_match("/[\W\w]/","$googleapps8444444474747474"))

{

?>

<?php

echo "<img class='googleappsmobileappsappsapps84' src='$googleapps8444444474747474' style='width:44px;border-radius:96px;height:44px;' onclick=\"$('#googlemobileappsapps$googleapps84').show();\"></img>";

?>

<?php

}

?>

<?php

if($googleapps84 == "2")

{

?>

<div class="googleappsmobilegoogleappsgooglegoogleapps84" onclick="$('#googlemobileappsapps847474744474').show();">Show all images</div>

<?php

break 1;

?>

<?php

}

?>

<?php

}

else

{

?>

<?php

echo "<div style='font-size:12.8px;'>add user to your coworkers to view images</div>";

?>

<?php

}

?>



<?php

}

else

{

?>

<?php

if(preg_match("/[\W\w]/","$googleapps8444444474747474"))

{

?>

<?php

echo "<img class='googleappsmobileappsappsapps84' src='$googleapps8444444474747474' style='width:44px;border-radius:96px;height:44px;' onclick=\"$('#googlemobileappsapps$googleapps84').show();\"></img>";

?>

<?php

}

?>

<?php

if($googleapps84 == "2")

{

?>

<div class="googleappsmobilegoogleappsgooglegoogleapps84" onclick="$('#googlemobileappsapps847474744474').show();">Show all images</div>

<?php

break 1;

?>

<?php

}

?>

<?php

}

?>

</div>



</div>

<?php

}

?>

</div>



</div>

</div>



</div>

</div>

<?php

}

?>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{

?>

<div style="display:flex;margin-top:12px;margin-bottom:44px;">

<div style="font-size:12.8px;width:124px;border-top:none;border-bottom:none;border-left:none;border-width:1px;">

Show images to coworkers

</div>

<div class="googleappsappsapps84222274" style="font-size:12.8px;width:446px;margin-left:-86px;position:relative;height:44px;margin-top:-24px;padding-top:12px;">

<div class="googleappsappsapps84222274" style="font-size:12.8px;width:446px;margin-left:18px;position:absolute;left:81.4px;padding-top:12px;padding-bottom:12px;">

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../coworkersappsappsappsgoogleapps84747474.sh";

}

else

{

$dataurlurlgoogleapps84 = "../people/coworkersappsappsappsgoogleapps84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1][0];

if(preg_match("/1/","$accountcolorappsappsappsappsapps84742274"))

{

$google84747474 = "checked";

}

else

{

$google84747474 = "unchecked";

}

?>

<input type="checkbox" id="id-name--84747474" value="<?php echo $google84747474; ?>" name="set-name847444444474" class="switch-input" <?php echo "$google84747474"; ?>>
<label for="id-name--84747474" id="googlelabelappsgoogleapps84" class="switch-label" style="padding-left:44px;">

<span class="toggle--on">

On

</span>

<span class="toggle--off">

Off

</span></label>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<script>

$(document).ready(function() {

$('#googlelabelappsgoogleapps84').click(function(event) {

var google84447474 = $('#id-name--84747474').val();

if (google84447474 == 'unchecked') {

$.ajax({
    data: 'userappsappsappsapps84747474=1&nameapps84747474=googleapps84&usernameapps84747474=<?php echo "$nameappsapps8884"; ?>',
    url: '/people/coworkersappsappsappsgoogleapps84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

}

else

{

$.ajax({
    data: 'userappsappsappsapps84747474=0&nameapps84747474=googleapps84&usernameapps84747474=<?php echo "$nameappsapps8884"; ?>',
    url: '/people/coworkersappsappsappsgoogleapps84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

}

});

});

</script>

</div>

</div>

</div>

<?php

}

?>



</div>

</div>

</div>

</div>

<div>
</div>

<?php

include "../dashboard/dashboardbottom.php";

?>

<?php

$conn84744474447444744474->close();

?>

