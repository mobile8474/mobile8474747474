<?php

error_reporting(0);

?>

<?php

$googleapps84747474 = strtolower($_SERVER['HTTP_USER_AGENT']);

if(preg_match("/(bot|Bot|crawler|Crawler|spider|Spider)/","googleapps84"))

{
}

else

{

?>

<?php

include "../dashboard/dashboardtop.php";

?>

<?php

$servername847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn84744474447444744474 = new mysqli($servername847444444444744474, $username847444444444744474, $password847444444444744474, $dbname847444444444744474);

?>

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<?php

if(preg_match("/people/",$_SERVER['HTTP_REFERER']))

{

?>

<?php

$googleapps8474747444444444444444744474447444744474 = $_COOKIE['username'];

?>

<?php

}

else

{

?>

<?php

if(preg_match("//",$_SERVER['HTTP_REFERER']))

{

?>

<?php

$googleapps8474747444444444444444744474447444744474 = $_COOKIE['username'];

?>

<?php

}

else

{

?>

<?php

$googleapps8474747444444444444444744474447444744474 = $_GET['username'];

$googleapps8474747444444444444444744474447444744474 = rawurlencode($googleapps8474747444444444444444744474447444744474);

?>

<?php

}

?>

<?php

}

?>

<style>

@media (max-width: 770px)
{
.googleappsappsappsapps84747474
{
display:grid!important;
}
}

@media (min-width: 770px)
{
.googlegooglegoogleappsapps847474744474
{
width:296px;
}
}

</style>

<div style="background-color:#ffffff;">

<div style="padding:44px;">

<div style="font-size:58px;color:#444444;">

Your Settings

</div>

</div>

</div>

</div>

<div class="googleappsappsappsapps84747474" style="display:flex;background-color:#ffffff;">

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:44px;">email</i>

</div>

<h3 style="font-size:24px;color:#444444;font-weight:bold;">EMAIL</h3>

<h4 style="font-weight:bold;">

<?php

$googleapps8884 = array();

$query = "SELECT * FROM email WHERE email='$googleapps8474747444444444444444744474447444744474' order by date desc limit 1";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$googleapps8884[] = $row['email'];

}

$password="googleappsmobileapps888888884444";

$googleapps8884 = rawurldecode($googleapps8884[0]);

$googleapps8884 = openssl_decrypt($googleapps8884,"AES-128-ECB",$password);

?>

<div class="googleappsappsapps44847474">

<div>

<form action="/<?php echo "$google847474747474747474744474"; ?>/people/educationapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" value="<?php echo "$googleapps8884"; ?>" name="educationapps84747474" autocomplete="off" class="googlegooglegoogleappsapps847474744474" style="padding:10px;font-size:14.8px;" required disabled></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $googleapps8474747444444444444444744474447444744474; ?>" name="educationappsuser84747474" autocomplete="off"  required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" style="display:none;" required></input>

</form>

</div>

</div>

</h4>

<div style="font-size:14.8px;">Change your email</div>

<div class="googleappspageapps84747474" style="padding:12px;background-color:#f1f1f1;color:#444444;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;cursor:pointer;" onclick="">

SAVE

</div>

</div>

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:44px;">account_box</i>

</div>

<h3 style="font-size:24px;color:#444444;font-weight:bold;">USERNAME</h3>

<h4 style="font-weight:bold;">

<?php

$googleapps8884 = array();

$query = "SELECT * FROM username WHERE email='$googleapps8474747444444444444444744474447444744474' order by date desc limit 1";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$googleapps8884[] = $row['username'];

}

$password="googleappsmobileapps888888884444";

$googleapps8884 = rawurldecode($googleapps8884[0]);

$googleapps8884 = openssl_decrypt($googleapps8884,"AES-128-ECB",$password);

?>

<div class="googleappsappsapps44847474">

<div>

<form action="/<?php echo "$google847474747474747474744474"; ?>/people/usernameapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" value="<?php echo "$googleapps8884"; ?>" name="usernameapps84747474" autocomplete="off" class="googlegooglegoogleappsapps847474744474" style="padding:10px;font-size:14.8px;" required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $googleapps8474747444444444444444744474447444744474; ?>" name="usernameappsuser84747474" autocomplete="off"  required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off" required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" class="google1" style="display:none;" required></input>

</form>

</div>

</div>

</h4>

<div style="font-size:14.8px;">Change your username</div>

<div class="googleappspageapps84747474" style="padding:12px;background-color:#f1f1f1;color:#444444;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;cursor:pointer;" onclick="$('.google1').click();">

SAVE

</div>

</div>

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:44px;">security</i>

</div>

<h3 style="font-size:24px;color:#444444;font-weight:bold;">PASSWORD</h3>

<h4 style="font-weight:bold;">

<?php

$googleapps8884 = array();

$query = "SELECT * FROM username WHERE email='$googleapps8474747444444444444444744474447444744474' order by date desc limit 1";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$googleapps8884[] = $row['username'];

}

$password="googleappsmobileapps888888884444";

$googleapps8884 = rawurldecode($googleapps8884[0]);

$googleapps8884 = openssl_decrypt($googleapps8884,"AES-128-ECB",$password);

?>

<div class="googleappsappsapps44847474">

<div>

<form action="/<?php echo "$google847474747474747474744474"; ?>/people/passwordapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="password" value="<?php echo "********"; ?>" name="passwordapps84747474" autocomplete="off" class="googlegooglegoogleappsapps847474744474" style="padding:10px;font-size:14.8px;" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $googleapps8474747444444444444444744474447444744474; ?>" name="passwordappsuser84747474" autocomplete="off" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" class="google2" style="display:none;" required></input>

</form>

</div>

</div>

</h4>

<div style="font-size:14.8px;">Change your password</div>

<div class="googleappspageapps84747474" style="padding:12px;background-color:#f1f1f1;color:#444444;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;cursor:pointer;" onclick="$('.google2').click();">

SAVE

</div>

</div>

</div>

<div class="googleappsappsappsapps84747474" style="display:flex;background-color:#ffffff;">

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:44px;">work</i>

</div>

<h3 style="font-size:24px;color:#444444;font-weight:bold;">WORK</h3>

<h4 style="font-weight:bold;">

<?php

$googleapps8884 = array();

$query = "SELECT * FROM workapps84747474 WHERE email='$googleapps8474747444444444444444744474447444744474' order by date desc limit 1";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$googleapps8884[] = $row['work'];

}

$password="googleappsmobileapps888888884444";

$googleapps8884 = rawurldecode($googleapps8884[0]);

$googleapps8884 = openssl_decrypt($googleapps8884,"AES-128-ECB",$password);

?>

<div class="googleappsappsapps44847474">

<div>

<form action="/<?php echo "$google847474747474747474744474"; ?>/people/workapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" value="<?php echo "$googleapps8884"; ?>" name="workapps84747474" autocomplete="off" class="googlegooglegoogleappsapps847474744474" style="padding:10px;font-size:14.8px;" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $googleapps8474747444444444444444744474447444744474; ?>" name="workappsuser84747474" autocomplete="off" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off" required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" class="google3" style="display:none;" required></input>

</form>

</div>

</div>

</h4>

<div style="font-size:14.8px;">Change your work</div>

<div class="googleappspageapps84747474" style="padding:12px;background-color:#f1f1f1;color:#444444;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;cursor:pointer;" onclick="$('.google3').click();">

SAVE

</div>

</div>

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:44px;">school</i>

</div>

<h3 style="font-size:24px;color:#444444;font-weight:bold;">EDUCATION</h3>

<h4 style="font-weight:bold;">

<?php

$googleapps8884 = array();

$query = "SELECT * FROM educationapps84747474 WHERE email='$googleapps8474747444444444444444744474447444744474' order by date desc limit 1";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$googleapps8884[] = $row['education'];

}

$password="googleappsmobileapps888888884444";

$googleapps8884 = rawurldecode($googleapps8884[0]);

$googleapps8884 = openssl_decrypt($googleapps8884,"AES-128-ECB",$password);

?>

<div class="googleappsappsapps44847474">

<div>

<form action="/<?php echo "$google847474747474747474744474"; ?>/people/educationapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" value="<?php echo "$googleapps8884"; ?>" name="educationapps84747474" autocomplete="off" class="googlegooglegoogleappsapps847474744474" style="padding:10px;font-size:14.8px;" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $googleapps8474747444444444444444744474447444744474; ?>" name="educationappsuser84747474" autocomplete="off" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off" required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" class="google4" style="display:none;" required></input>

</form>

</div>

</div>

</h4>

<div style="font-size:14.8px;">Change your education</div>

<div class="googleappspageapps84747474" style="padding:12px;background-color:#f1f1f1;color:#444444;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;cursor:pointer;" onclick="$('.google4').click();">

SAVE

</div>

</div>

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:44px;">public</i>

</div>

<h3 style="font-size:24px;color:#444444;font-weight:bold;">COUNTRY</h3>

<h4 style="font-weight:bold;">

<?php

$googleapps8884 = array();

$query = "SELECT * FROM countryapps84747474 WHERE email='$googleapps8474747444444444444444744474447444744474' order by date desc limit 1";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$googleapps8884[] = $row['country'];

}

$password="googleappsmobileapps888888884444";

$googleapps8884 = rawurldecode($googleapps8884[0]);

$googleapps8884 = openssl_decrypt($googleapps8884,"AES-128-ECB",$password);

?>

<div class="googleappsappsapps44847474">

<div>

<form action="/<?php echo "$google847474747474747474744474"; ?>/people/countryapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" value="<?php echo "$googleapps8884"; ?>" name="countryapps84747474" autocomplete="off" class="googlegooglegoogleappsapps847474744474" style="padding:10px;font-size:14.8px;" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $googleapps8474747444444444444444744474447444744474; ?>" name="countryappsuser84747474" autocomplete="off" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off" required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" class="google5" style="display:none;" required></input>

</form>

</div>

</div>

</h4>

<div style="font-size:14.8px;">Change your country</div>

<div class="googleappspageapps84747474" style="padding:12px;background-color:#f1f1f1;color:#444444;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;cursor:pointer;" onclick="$('.google5').click();">

SAVE

</div>

</div>

</div>

<div class="googleappsappsappsapps84747474" style="display:flex;background-color:#ffffff;">

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:44px;"></i>

</div>

<h3 style="font-size:24px;color:#444444;font-weight:bold;">FIRSTNAME</h3>

<h4 style="font-weight:bold;">

<?php

$googleapps8884 = array();

$query = "SELECT * FROM user1 WHERE email='$googleapps8474747444444444444444744474447444744474' order by date desc limit 1";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$googleapps8884[] = $row['firstname'];

}

$password="googleappsmobileapps888888884444";

$googleapps8884 = rawurldecode($googleapps8884[0]);

$googleapps8884 = openssl_decrypt($googleapps8884,"AES-128-ECB",$password);

?>

<div class="googleappsappsapps44847474">

<div>

<form action="/<?php echo "$google847474747474747474744474"; ?>/people/firstnameapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" value="<?php echo "$googleapps8884"; ?>" name="firstnameapps84747474" autocomplete="off" class="googlegooglegoogleappsapps847474744474" style="padding:10px;font-size:14.8px;" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $googleapps8474747444444444444444744474447444744474; ?>" name="firstnameappsuser84747474" autocomplete="off" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off" required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" class="google6" style="display:none;" required></input>

</form>

</div>

</div>

</h4>

<div style="font-size:14.8px;">Change your firstname</div>

<div class="googleappspageapps84747474" style="padding:12px;background-color:#f1f1f1;color:#444444;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;cursor:pointer;" onclick="$('.google6').click();">

SAVE

</div>

</div>

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:44px;"></i>

</div>

<h3 style="font-size:24px;color:#444444;font-weight:bold;">LASTNAME</h3>

<h4 style="font-weight:bold;">

<?php

$googleapps8884 = array();

$query = "SELECT * FROM user2 WHERE email='$googleapps8474747444444444444444744474447444744474' order by date desc limit 1";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$googleapps8884[] = $row['lastname'];

}

$password="googleappsmobileapps888888884444";

$googleapps8884 = rawurldecode($googleapps8884[0]);

$googleapps8884 = openssl_decrypt($googleapps8884,"AES-128-ECB",$password);

?>

<div class="googleappsappsapps44847474">

<div>

<form action="/<?php echo "$google847474747474747474744474"; ?>/people/lastnameapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" value="<?php echo "$googleapps8884"; ?>" name="lastnameapps84747474" autocomplete="off" class="googlegooglegoogleappsapps847474744474" style="padding:10px;font-size:14.8px;" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $googleapps8474747444444444444444744474447444744474; ?>" name="lastnameappsuser84747474" autocomplete="off" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off" required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" class="google7" style="display:none;" required></input>

</form>

</div>

</div>

</h4>

<div style="font-size:14.8px;">Change your lastname</div>

<div class="googleappspageapps84747474" style="padding:12px;background-color:#f1f1f1;color:#444444;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;cursor:pointer;" onclick="$('.google7').click();">

SAVE

</div>

</div>

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:44px;"></i>

</div>

<h3 style="font-size:24px;color:#444444;font-weight:bold;">AGE</h3>

<h4 style="font-weight:bold;">

<?php

$googleapps8884 = array();

$query = "SELECT * FROM ageapps84747474 WHERE email='$googleapps8474747444444444444444744474447444744474' order by date desc limit 1";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$googleapps8884[] = $row['age'];

}

$password="googleappsmobileapps888888884444";

$googleapps8884 = rawurldecode($googleapps8884[0]);

$googleapps8884 = openssl_decrypt($googleapps8884,"AES-128-ECB",$password);

?>

<div class="googleappsappsapps44847474">

<div>

<form action="/<?php echo "$google847474747474747474744474"; ?>/people/ageapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" value="<?php echo "$googleapps8884"; ?>" name="ageapps84747474" autocomplete="off" class="googlegooglegoogleappsapps847474744474" style="padding:10px;font-size:14.8px;" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $googleapps8474747444444444444444744474447444744474; ?>" name="ageappsuser84747474" autocomplete="off" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off" required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" class="google8" style="display:none;" required></input>

</form>

</div>

</div>

</h4>

<div style="font-size:14.8px;">Change your age</div>

<div class="googleappspageapps84747474" style="padding:12px;background-color:#f1f1f1;color:#444444;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;cursor:pointer;" onclick="$('.google8').click();">

SAVE

</div>

</div>

</div>

<div class="googleappsappsappsapps84747474" style="display:flex;background-color:#ffffff;">

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:44px;"></i>

</div>

<h3 style="font-size:24px;color:#444444;font-weight:bold;">ABOUT</h3>

<h4 style="font-weight:bold;">

<?php

$googleapps8884 = array();

$query = "SELECT * FROM aboutapps84747474 WHERE email='$googleapps8474747444444444444444744474447444744474' order by date desc limit 1";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$googleapps8884[] = $row['about'];

}

$password="googleappsmobileapps888888884444";

$googleapps8884 = rawurldecode($googleapps8884[0]);

$googleapps8884 = openssl_decrypt($googleapps8884,"AES-128-ECB",$password);

?>

<div class="googleappsappsapps44847474">

<div>

<form action="/<?php echo "$google847474747474747474744474"; ?>/people/aboutapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" value="<?php echo "$googleapps8884"; ?>" name="aboutapps84747474" autocomplete="off" class="googlegooglegoogleappsapps847474744474" style="padding:10px;font-size:14.8px;" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $googleapps8474747444444444444444744474447444744474; ?>" name="aboutappsuser84747474" autocomplete="off" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off" required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" class="google9" style="display:none;" required></input>

</form>

</div>

</div>

</h4>

<div style="font-size:14.8px;">Change your about</div>

<div class="googleappspageapps84747474" style="padding:12px;background-color:#f1f1f1;color:#444444;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;cursor:pointer;" onclick="$('.google9').click();">

SAVE

</div>

</div>

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:44px;"></i>

</div>

<h3 style="font-size:24px;color:#444444;font-weight:bold;">MOBILE</h3>

<h4 style="font-weight:bold;">

<?php

$googleapps8884 = array();

$query = "SELECT * FROM mobileapps84747474 WHERE email='$googleapps8474747444444444444444744474447444744474' order by date desc limit 1";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$googleapps8884[] = $row['mobile'];

}

$password="googleappsmobileapps888888884444";

$googleapps8884 = rawurldecode($googleapps8884[0]);

$googleapps8884 = openssl_decrypt($googleapps8884,"AES-128-ECB",$password);

?>

<div class="googleappsappsapps44847474">

<div>

<form action="/<?php echo "$google847474747474747474744474"; ?>/people/mobileapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" value="<?php echo "$googleapps8884"; ?>" name="mobileapps84747474" autocomplete="off" class="googlegooglegoogleappsapps847474744474" style="padding:10px;font-size:14.8px;" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $googleapps8474747444444444444444744474447444744474; ?>" name="mobileappsuser84747474" autocomplete="off" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off" required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" class="google10" style="display:none;" required></input>

</form>

</div>

</div>

</h4>

<div style="font-size:14.8px;">Change your mobile</div>

<div class="googleappspageapps84747474" style="padding:12px;background-color:#f1f1f1;color:#444444;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;cursor:pointer;" onclick="$('.google10').click();">

SAVE

</div>

</div>

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:44px;"></i>

</div>

<h3 style="font-size:24px;color:#444444;font-weight:bold;">CITY</h3>

<h4 style="font-weight:bold;">

<?php

$googleapps8884 = array();

$query = "SELECT * FROM cityapps84747474 WHERE email='$googleapps8474747444444444444444744474447444744474' order by date desc limit 1";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$googleapps8884[] = $row['city'];

}

$password="googleappsmobileapps888888884444";

$googleapps8884 = rawurldecode($googleapps8884[0]);

$googleapps8884 = openssl_decrypt($googleapps8884,"AES-128-ECB",$password);

?>

<div class="googleappsappsapps44847474">

<div>

<form action="/<?php echo "$google847474747474747474744474"; ?>/people/cityapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" value="<?php echo "$googleapps8884"; ?>" name="cityapps84747474" autocomplete="off" class="googlegooglegoogleappsapps847474744474" style="padding:10px;font-size:14.8px;" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $googleapps8474747444444444444444744474447444744474; ?>" name="cityappsuser84747474" autocomplete="off" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off" required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" class="google11" style="display:none;" required></input>

</form>

</div>

</div>

</h4>

<div style="font-size:14.8px;">Change your city</div>

<div class="googleappspageapps84747474" style="padding:12px;background-color:#f1f1f1;color:#444444;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;cursor:pointer;" onclick="$('.google11').click();">

SAVE

</div>

</div>

</div>

<div class="googleappsappsappsapps84747474" style="display:flex;background-color:#ffffff;">

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:44px;"></i>

</div>

<h3 style="font-size:24px;color:#444444;font-weight:bold;">GENDER</h3>

<h4 style="font-weight:bold;">

<?php

$googleapps8884 = array();

$query = "SELECT * FROM genderapps84747474 WHERE email='$googleapps8474747444444444444444744474447444744474' order by date desc limit 1";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$googleapps8884[] = $row['gender'];

}

$password="googleappsmobileapps888888884444";

$googleapps8884 = rawurldecode($googleapps8884[0]);

$googleapps8884 = openssl_decrypt($googleapps8884,"AES-128-ECB",$password);

?>

<div class="googleappsappsapps44847474">

<div>

<form action="/<?php echo "$google847474747474747474744474"; ?>/people/googleappsapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" value="<?php echo "$googleapps8884"; ?>" name="googleappsapps84747474" autocomplete="off" class="googlegooglegoogleappsapps847474744474" style="padding:10px;font-size:14.8px;" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $googleapps8474747444444444444444744474447444744474; ?>" name="googleappsappsuser84747474" autocomplete="off" required></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off" required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" class="google11" style="display:none;" required></input>

</form>

</div>

</div>

</h4>

<div style="font-size:14.8px;">Change your gender</div>

<div class="googleappspageapps84747474" style="padding:12px;background-color:#f1f1f1;color:#444444;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;cursor:pointer;" onclick="$('.google11').click();">

SAVE

</div>

</div>

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:44px;">color_lens</i>

</div>

<h3 style="font-size:24px;color:#444444;font-weight:bold;">THEME</h3>

<h4 style="font-weight:bold;">

<?php

$googleapps8884 = array();

$query = "SELECT * FROM countryapps84747474 WHERE email='$googleapps8474747444444444444444744474447444744474' order by date desc limit 1";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$googleapps8884[] = $row['country'];

}

$password="googleappsmobileapps888888884444";

$googleapps8884 = rawurldecode($googleapps8884[0]);

$googleapps8884 = openssl_decrypt($googleapps8884,"AES-128-ECB",$password);

?>

<div class="googleappsappsapps44847474">

<div>



<div>

<form action="/<?php echo "$google847474747474747474744474"; ?>/register/accountcolor84747474.php" method="post">

<div style="display:flex;">

<div>

<div style="display:flex;">

</div>

</div>

<div>

<input type="color" name="googleappscolorapps84747474" value="<?php echo $googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84; ?>">

</div>

<div>

<input type="submit" value="update" class="googleappsappsappsappsappsapps847474744474" style="padding:5.4px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:inline-block;color:#444444;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;border:none;margin-top:12.8px;margin-left:12px;display:none;">

</div>

</div>

<input type="hidden" name="useremail" value="<?php echo $_GET[useremail]; ?>">

</form>

</div>



</div>

</div>

</h4>

<div style="font-size:14.8px;">Change your theme</div>

<div class="googleappspageapps84747474" style="padding:12px;background-color:#f1f1f1;color:#444444;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;cursor:pointer;" onclick="$('.googleappsappsappsappsappsapps847474744474').click();">

SAVE

</div>

</div>

</div>

<?php

$conn84744474447444744474->close();

?>

<?php

}

?>

