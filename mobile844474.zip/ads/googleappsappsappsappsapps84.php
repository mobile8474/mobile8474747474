<?php

echo substr(uniqid(rand(10,1000),false),rand(0,10),6)

?>

