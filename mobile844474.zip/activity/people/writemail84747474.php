<?php

error_reporting(0);

?>

<?php

$toemail84747474 = $_GET['useremail'];

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

?>

<?php

if(preg_match("/[\W\w]/","$toemail84747474"))

{

?>

<?php

$string_to_encrypt="$_COOKIE[username]";

$decrypted_string = "$string_to_encrypt";

?>

<?php

$string_to_encrypt8884="$_COOKIE[password]";

$decrypted_string8884 = "$string_to_encrypt8884";

?>

<?php

$string_to_encrypt="$_COOKIE[username]";

$decrypted_string = "$string_to_encrypt";

?>

<?php

$string_to_encrypt="$decrypted_string";

$decrypted_string888474 = rawurldecode($string_to_encrypt);

$password="googleappsmobileapps888888884444";

$decrypted_string8474=openssl_decrypt($decrypted_string888474,"AES-128-ECB",$password);

?>

<?php

$decryptedstring = $_COOKIE['username'];

$file84 = file_get_contents("$dataurl8884");

preg_match_all("/<div class=\'$decryptedstring\' id=\'(.*?)\'><div class=\'(.*?)\' id=\'(.*?)\'><div class=\'(.*?)\'><div class=\'(.*?)\'>(.*?)<\/div><\/div><\/div><\/div>/s", $file84, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

$googleapps8884 = strtoupper("$name");

$googleapps888844 = "$name";

?>

<?php

$username84747474 = $_COOKIE['username'];

$password84747474 = $_COOKIE['password'];

$toemail84747474 = $_GET['useremail'];

$emailtext84747474 = $_GET['emailtext'];

$emailtext84747474 = "$emailtext84747474";
$passwordtoemail84 = "googleappsmobileapps888888884444";

$emailtext84747474 = openssl_encrypt($emailtext84747474,"AES-128-ECB",$passwordtoemail84);

$emailtext84747474 = rawurlencode($emailtext84747474);

?>

<?php

$fromemail = $_COOKIE['username'];

$fromemail84227474 = $_COOKIE['username'];

?>

<?php

$password = "googleappsmobileapps888888884444";

$fromemail = "$fromemail";

$fromemail88847474 = "$fromemail";

?>

<?php

$toemail84 = "$toemail84747474";
$passwordtoemail84 = "googleappsmobileapps888888884444";

$toemail84 = openssl_encrypt($toemail84,"AES-128-ECB",$passwordtoemail84);

$toemail84227474 = rawurlencode($toemail84);

?>

<?php

$google84747474 = $_COOKIE['username'];

?>

<?php

$googleappsgoogleappsmobileapps8884 = date("Y-m-d H:i:s");

?>

<?php

$username = $_COOKIE['username'];

$password = $_COOKIE['password'];

$toemail = $_COOKIE['username'];

$emailtext = $_GET['emailtext'];

?>

<?php

$fromemail = $_COOKIE['username'];

$fromemail84227474 = $_COOKIE['username'];

?>

<?php

$password = "googleappsmobileapps888888884444";

$fromemail = "$fromemail";

$fromemail8884 = "$fromemail";

?>

<?php

$toemail84 = "$toemail";

?>

<?php

$dateapps8884 = date("Y-m-d-H-i-s");

?>

<?php

$google84227474 = $_COOKIE['username'];

$password = "googleappsmobileapps888888884444";

$google84227474 = rawurldecode($google84227474);

$google84227474 = openssl_decrypt($google84227474,"AES-128-ECB",$password);

?>

<?php

$dateappsapps84747474 = date("Y-m-d H:i:s");

?>

<?php

$googleapps8884 = "<div class='$username' id='na'><div class='$toemail84227474'><div class='$emailtext84747474'><div class='$fromemail88847474'><div class='$dateappsapps84747474'>1</div></div></div></div></div>";

?>

<?php

$googleapps88847474 = "<div class='$toemail84227474'><div class='$dateapps8884'><div class='1'>1</div></div></div>";

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../usermailsapps8884.sh";

}

else

{

$dataurl84 = "usermailsapps8884.sh";

}

?>

<?php

$filedata = "$googleapps88847474";

?>

<?php

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

?>

<?php

$userapps84747474 = "$ip";

$date84747474 = date("Y-m-d-H-i-s");

?>

<?php

$sql84747474 = "INSERT INTO mailapps84747474 (email,toemail,emailtext,date,userip)
VALUES ('$toemail84227474','$username','$emailtext84747474','$dateappsapps84747474','$userapps84747474')";

echo "<div style='display:none;'>$googleapps888844</div>";

?>

<?php

if ($conn->query($sql84747474) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql84747474 . "<br>" . $conn->error;
}

?>

<?php

$sql847474744474447444744474 = "INSERT INTO mailappsappsapps84747474 (email,frommail,emailtext,date,userip)
VALUES ('$username','$toemail84227474','$emailtext84747474','$dateappsapps84747474','$userapps84747474')";

echo "<div style='display:none;'>$googleapps888844</div>";

?>

<?php

if ($conn->query($sql847474744474447444744474) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql847474744474447444744474 . "<br>" . $conn->error;
}

?>

<?php

$conn->close();

?>

<?php

echo "<div style='display:none;'>$googleapps888844</div>";

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../usermailsgoogleapps84747474.sh";

}

else

{

$dataurl84 = "usermailsgoogleapps84747474.sh";

}

?>

<?php

$filedata = "$googleapps8884";
$filedata .= file_get_contents("$dataurl84");
$googleapps888844 = file_put_contents("$dataurl84", $filedata);

echo "<div style='display:none;'>$googleapps888844</div>";

?>

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<script>

setTimeout(function()

{

window.location = '<?php echo "/$google847474747474747474744474/mail/inbox.php?query=0"; ?>';

}, 104);

</script>

<?php

}

?>

