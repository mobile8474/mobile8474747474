<?php

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "$isocode8884");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

$google8474224474747474 = $_GET['accountcolorapps84747474'];

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

if(preg_match("/[\W\w]/",$_GET['week']))

{

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$decrypted_string8884 = $_COOKIE['password'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = $_GET['dateanalytics'];

}

?>



<?php

$googleapps847474 = "-1";

$googleapps847474 = preg_replace("/(.*)-(.*)-(.*)/","$3",$_GET['dateanalytics']);

$googleapps847474 = $googleapps847474 + 1;

$googleapps847474--;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$googleapps84444474 = $googleapps847474;

$googleappsappsapps84 = preg_replace("/(.*)-(.*)-(.*)/","$1",$_GET['dateanalytics']);

$googleappsappsapps84747474 = preg_replace("/(.*)-(.*)-(.*)/","$2",$_GET['dateanalytics']);

$googleappsappsapps84444474 = str_replace("(.*?)-(.*?)-(.*?)","$3",$_GET['dateanalytics']);

$googlemobileapps1 = date('Y-m-d', strtotime('today'));
$googlemobileapps2 = date('Y-m-d', strtotime('-1 day'));
$googlemobileapps3 = date('Y-m-d', strtotime('-2 day'));
$googlemobileapps4 = date('Y-m-d', strtotime('-3 day'));
$googlemobileapps5 = date('Y-m-d', strtotime('-4 day'));
$googlemobileapps6 = date('Y-m-d', strtotime('-5 day'));
$googlemobileapps7 = date('Y-m-d', strtotime('-6 day'));

$googlemobileappsapps1 = date("M d", strtotime('today'));
$googlemobileappsapps2 = date("M d", strtotime('-1 day'));
$googlemobileappsapps3 = date("M d", strtotime('-2 day'));
$googlemobileappsapps4 = date("M d", strtotime('-3 day'));
$googlemobileappsapps5 = date("M d", strtotime('-4 day'));
$googlemobileappsapps6 = date("M d", strtotime('-5 day'));
$googlemobileappsapps7 = date("M d", strtotime('-6 day'));

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps1'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google1 = $googleapps84[2];

$query = "SELECT * FROM adsclicksapps844444444474 WHERE adsusername='$decrypted_string' and date REGEXP '$googlemobileapps1.*'";
$result = $conn->query($query);

$google1 = array();

while($row = $result->fetch_array())

{

$google1[] = $row['userip'];

}

$google1 = count($google1);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps2'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google2 = $googleapps84[2];

$query = "SELECT * FROM adsclicksapps844444444474 WHERE adsusername='$decrypted_string' and date REGEXP '$googlemobileapps2.*'";
$result = $conn->query($query);

$google2 = array();

while($row = $result->fetch_array())

{

$google2[] = $row['userip'];

}

$google2 = count($google2);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps3'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google3 = $googleapps84[2];

$query = "SELECT * FROM adsclicksapps844444444474 WHERE adsusername='$decrypted_string' and date REGEXP '$googlemobileapps3.*'";
$result = $conn->query($query);

$google3 = array();

while($row = $result->fetch_array())

{

$google3[] = $row['userip'];

}

$google3 = count($google3);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps4'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google4 = $googleapps84[2];

$query = "SELECT * FROM adsclicksapps844444444474 WHERE adsusername='$decrypted_string' and date REGEXP '$googlemobileapps4.*'";
$result = $conn->query($query);

$google4 = array();

while($row = $result->fetch_array())

{

$google4[] = $row['userip'];

}

$google4 = count($google4);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps5'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google5 = $googleapps84[2];

$query = "SELECT * FROM adsclicksapps844444444474 WHERE adsusername='$decrypted_string' and date REGEXP '$googlemobileapps5.*'";
$result = $conn->query($query);

$google5 = array();

while($row = $result->fetch_array())

{

$google5[] = $row['userip'];

}

$google5 = count($google5);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps6'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google6 = $googleapps84[2];

$query = "SELECT * FROM adsclicksapps844444444474 WHERE adsusername='$decrypted_string' and date REGEXP '$googlemobileapps6.*'";
$result = $conn->query($query);

$google6 = array();

while($row = $result->fetch_array())

{

$google6[] = $row['userip'];

}

$google6 = count($google6);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps7'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google7 = $googleapps84[2];

$query = "SELECT * FROM adsclicksapps844444444474 WHERE adsusername='$decrypted_string' and date REGEXP '$googlemobileapps7.*'";
$result = $conn->query($query);

$google7 = array();

while($row = $result->fetch_array())

{

$google7[] = $row['userip'];

}

$google7 = count($google7);

$google88888872[] = $google8884;

?>

<?php

$googleappsapps847444 = $google88888872[0];

$googleappsapps1 = $google88888872[1];

$googleappsapps2 = $google88888872[2];

$googleappsapps3 = $googleappsgoogleapps3;

$googleappsapps4 = $google88888872[4];

$googleappsapps5 = $google88888872[5];

$googleappsapps6 = $google88888872[6];

?>

<div>

<canvas id="canvas" width="600" height="300" style="background-color:#fff"></canvas>

</div>

<script>

let draw = Chart.controllers.line.prototype.draw;
Chart.controllers.line = Chart.controllers.line.extend({
    draw: function() {
        draw.apply(this, arguments);
        let ctx = this.chart.chart.ctx;
        let _stroke = ctx.stroke;
        ctx.stroke = function() {
            ctx.save();
            ctx.shadowColor = '#bdbdbd';
            ctx.shadowBlur = 8;
            ctx.shadowOffsetX = 0;
            ctx.shadowOffsetY = 12;
            _stroke.apply(this, arguments)
            ctx.restore();
        }
    }
});

let ctx = document.getElementById("canvas").getContext('2d');
let myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['<?php echo $googlemobileappsapps7; ?>', '<?php echo $googlemobileappsapps6; ?>', '<?php echo $googlemobileappsapps5; ?>', '<?php echo $googlemobileappsapps4; ?>', '<?php echo $googlemobileappsapps3; ?>', '<?php echo $googlemobileappsapps2; ?>', '<?php echo $googlemobileappsapps1; ?>'],
        datasets: [{
            label: "CLICKS",
            data: [<?php echo "$google7"; ?>, <?php echo "$google6"; ?>, <?php echo "$google5"; ?>, <?php echo "$google4"; ?>, <?php echo "$google3"; ?>, <?php echo "$google2"; ?>, <?php echo "$google1"; ?>],
            borderColor: '<?php echo "#" . $google8474224474747474; ?>',
            pointBackgroundColor: "#fff",
            pointBorderColor: '<?php echo "#" . $google8474224474747474; ?>',
            pointHoverBackgroundColor: '<?php echo "#" . $google8474224474747474; ?>',
            pointHoverBorderColor: "#fff",
            pointRadius: 4,
            pointHoverRadius: 4,
            fill: false,
            backgroundColor: '<?php echo "#" . $google8474224474747474; ?>',
}],

},

options: {
    scales: {
      yAxes: [{
       ticks: {
                    beginAtZero: true,

},

}],

},

},

});

</script>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_GET['today']))

{

?>



<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../adsclicksapps84747474";

}

else

{

$dataurl = "../adsclicksapps84747474";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl");

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$decrypted_string8884 = $_COOKIE['password'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = $_GET['dateanalytics'];

}

?>

<?php

$google84747474 = date("Y-m-d");

?>

<?php

$googleapps847474 = "-1";

for ($google74 = 0; $google74 <= 24; $google74++)

{

$googleapps847474++;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hours = $googleapps847474;

preg_match_all("/<div class='$decrypted_string' id='(.*?)'>\n<div class='$google84747474-$hours'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google8884 = $googleapps84[1];

$query = "SELECT * FROM adsclicksapps844444444474 WHERE adsusername='$decrypted_string' and date='$google84747474-$hours'";
$result = $conn->query($query);

$google8884 = array();

while($row = $result->fetch_array())

{

$google8884[] = $row['userip'];

}

$google8884 = count($google8884);

$google88888872[] = $google8884;

}

?>

<?php

$google847444 = $google88888872[0];

$google1 = $google88888872[1];

$google2 = $google88888872[2];

$google3 = $google88888872[3];

$google4 = $google88888872[4];

$google5 = $google88888872[5];

$google6 = $google88888872[6];

$google7 = $google88888872[7];

$google8 = $google88888872[8];

$google9 = $google88888872[9];

$google10 = $google88888872[10];

$google11 = $google88888872[11];

$google12 = $google88888872[12];

$google13 = $google88888872[13];

$google14 = $google88888872[14];

$google15 = $google88888872[15];

$google16 = $google88888872[16];

$google17 = $google88888872[17];

$google18 = $google88888872[18];

$google19 = $google88888872[19];

$google20 = $google88888872[20];

$google21 = $google88888872[21];

$google22 = $google88888872[22];

$google23 = $google88888872[23];

$google24 = $google88888872[24];

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../adsclicksapps84747474";

}

else

{

$dataurl = "../adsclicksapps84747474";

}

?>

<?php

$userdata = file_get_contents("$dataurl");

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$decrypted_string8884 = $_COOKIE['password'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = $_GET['dateanalytics'];

}

?>

<?php

$username = $_COOKIE['username'];

?>

<?php

$password = $_COOKIE['password'];

?>

<?php

$googleapps847474 = "-1";

for ($google74 = 0; $google74 <= 24; $google74++)

{

$googleapps847474++;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hours = $googleapps847474;

$dateapps84747474 = $_GET['dateanalytics'];



preg_match_all("/<div class='$username' id='(.*?)'>\n<div class='$google84747474-$hours'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $userdata, $userdata8884);
$usergoogleappsgoogleapps8474 = $userdata8884[2];

$usergoogleappsapps1 = count($usergoogleappsgoogleapps8474);

$google8884 = "$usergoogleappsapps1";

$google88888872[] = $google8884;

}

?>

<?php

$googleapps847444 = $google88888872[0];

$googleapps1 = $google88888872[1];

$googleapps2 = $google88888872[2];

$googleapps3 = $google88888872[3];

$googleapps4 = $google88888872[4];

$googleapps5 = $google88888872[5];

$googleapps6 = $google88888872[6];

$googleapps7 = $google88888872[7];

$googleapps8 = $google88888872[8];

$googleapps9 = $google88888872[9];

$googleapps10 = $google88888872[10];

$googleapps11 = $google88888872[11];

$googleapps12 = $google88888872[12];

$googleapps13 = $google88888872[13];

$googleapps14 = $google88888872[14];

$googleapps15 = $google88888872[15];

$googleapps16 = $google88888872[16];

$googleapps17 = $google88888872[17];

$googleapps18 = $google88888872[18];

$googleapps19 = $google88888872[19];

$googleapps20 = $google88888872[20];

$googleapps21 = $google88888872[21];

$googleapps22 = $google88888872[22];

$googleapps23 = $google88888872[23];

$googleapps24 = $google88888872[24];

?>



<div>

<canvas id="canvas" width="600" height="300" style="background-color:#fff"></canvas>

</div>

<script>

let draw = Chart.controllers.line.prototype.draw;
Chart.controllers.line = Chart.controllers.line.extend({
    draw: function() {
        draw.apply(this, arguments);
        let ctx = this.chart.chart.ctx;
        let _stroke = ctx.stroke;
        ctx.stroke = function() {
            ctx.save();
            ctx.shadowColor = '#bdbdbd';
            ctx.shadowBlur = 8;
            ctx.shadowOffsetX = 0;
            ctx.shadowOffsetY = 12;
            _stroke.apply(this, arguments)
            ctx.restore();
        }
    }
});

let ctx = document.getElementById("canvas").getContext('2d');
let myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23"],
        datasets: [{
            label: "CLICKS",
            data: [<?php echo "$google847444"; ?>, <?php echo "$google1"; ?>, <?php echo "$google2"; ?>, <?php echo "$google3"; ?>, <?php echo "$google4"; ?>, <?php echo "$google5"; ?>, <?php echo "$google6"; ?>, <?php echo "$google7"; ?>, <?php echo "$google8"; ?>, <?php echo "$google9"; ?>, <?php echo "$google10"; ?>, <?php echo "$google11"; ?>, <?php echo "$google12"; ?>, <?php echo "$google13"; ?>, <?php echo "$google14"; ?>, <?php echo "$google15"; ?>, <?php echo "$google16"; ?>, <?php echo "$google17"; ?>, <?php echo "$google18"; ?>, <?php echo "$google19"; ?>, <?php echo "$google20"; ?>, <?php echo "$google21"; ?>, <?php echo "$google22"; ?>, <?php echo "$google23"; ?>],
            borderColor: '<?php echo "#" . $google8474224474747474; ?>',
            pointBackgroundColor: "#fff",
            pointBorderColor: '<?php echo "#" . $google8474224474747474; ?>',
            pointHoverBackgroundColor: '<?php echo "#" . $google8474224474747474; ?>',
            pointHoverBorderColor: "#fff",
            pointRadius: 4,
            pointHoverRadius: 4,
            fill: false,
            backgroundColor: '<?php echo "#" . $google8474224474747474; ?>',
}],
    },

options: {
    scales: {
      yAxes: [{
       ticks: {
                    beginAtZero: true,

},

}],

},

},

});

</script>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_GET['yesterday']))

{

?>



<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../adsclicksapps84747474";

}

else

{

$dataurl = "../adsclicksapps84747474";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl");

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$decrypted_string8884 = $_COOKIE['password'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = $_GET['dateanalytics'];

}

?>

<?php

$google84747474 = date("Y-m-d");

$google84444474 = date('Y-m-d', strtotime('-1 day'));

?>

<?php

$googleapps847474 = "-1";

for ($google74 = 0; $google74 <= 24; $google74++)

{

$googleapps847474++;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hours = $googleapps847474;

preg_match_all("/<div class='$decrypted_string' id='(.*?)'>\n<div class='$google84444474-$hours'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google8884 = $googleapps84[1];

$google8884 = count($google8884);

$google88888872[] = $google8884;

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../adsclicksapps84747474";

}

else

{

$dataurl = "../adsclicksapps84747474";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl");

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$decrypted_string8884 = $_COOKIE['password'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = $_GET['dateanalytics'];

}

?>

<?php

$google84747474 = date("Y-m-d");

?>

<?php

$google84444474 = date('Y-m-d', strtotime('-1 day'));

$googleapps847474 = "-1";

for ($google74 = 0; $google74 <= 24; $google74++)

{

$googleapps847474++;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hours = $googleapps847474;

preg_match_all("/<div class='$decrypted_string' id='(.*?)'>\n<div class='$google84444474-$hours'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google8884 = $googleapps84[1];

$query = "SELECT * FROM adsclicksapps844444444474 WHERE adsusername='$decrypted_string' and date='$google84444474-$hours'";
$result = $conn->query($query);

$google8884 = array();

while($row = $result->fetch_array())

{

$google8884[] = $row['userip'];

}

$google8884 = count($google8884);

$google88888872[] = $google8884;

}

?>

<?php

$google847444 = $google88888872[0];

$google1 = $google88888872[1];

$google2 = $google88888872[2];

$google3 = $google88888872[3];

$google4 = $google88888872[4];

$google5 = $google88888872[5];

$google6 = $google88888872[6];

$google7 = $google88888872[7];

$google8 = $google88888872[8];

$google9 = $google88888872[9];

$google10 = $google88888872[10];

$google11 = $google88888872[11];

$google12 = $google88888872[12];

$google13 = $google88888872[13];

$google14 = $google88888872[14];

$google15 = $google88888872[15];

$google16 = $google88888872[16];

$google17 = $google88888872[17];

$google18 = $google88888872[18];

$google19 = $google88888872[19];

$google20 = $google88888872[20];

$google21 = $google88888872[21];

$google22 = $google88888872[22];

$google23 = $google88888872[23];

$google24 = $google88888872[24];

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../adsclicksapps84747474";

}

else

{

$dataurl = "../adsclicksapps84747474";

}

?>

<?php

$userdata = file_get_contents("$dataurl");

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$decrypted_string8884 = $_COOKIE['password'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = $_GET['dateanalytics'];

}

?>

<?php

$username = $_COOKIE['username'];

?>

<?php

$password = $_COOKIE['password'];

?>

<?php

$googleapps847474 = "-1";

for ($google74 = 0; $google74 <= 24; $google74++)

{

$googleapps847474++;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hours = $googleapps847474;

$dateapps84747474 = $_GET['dateanalytics'];



preg_match_all("/<div class='$username' id='(.*?)'>\n<div class='$google84444474-$hours'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $userdata, $userdata8884);
$usergoogleappsgoogleapps8474 = $userdata8884[2];

$usergoogleappsapps1 = count($usergoogleappsgoogleapps8474);

$google8884 = "$usergoogleappsapps1";

$google88888872[] = $google8884;

}

?>

<?php

$googleapps847444 = $google88888872[0];

$googleapps1 = $google88888872[1];

$googleapps2 = $google88888872[2];

$googleapps3 = $google88888872[3];

$googleapps4 = $google88888872[4];

$googleapps5 = $google88888872[5];

$googleapps6 = $google88888872[6];

$googleapps7 = $google88888872[7];

$googleapps8 = $google88888872[8];

$googleapps9 = $google88888872[9];

$googleapps10 = $google88888872[10];

$googleapps11 = $google88888872[11];

$googleapps12 = $google88888872[12];

$googleapps13 = $google88888872[13];

$googleapps14 = $google88888872[14];

$googleapps15 = $google88888872[15];

$googleapps16 = $google88888872[16];

$googleapps17 = $google88888872[17];

$googleapps18 = $google88888872[18];

$googleapps19 = $google88888872[19];

$googleapps20 = $google88888872[20];

$googleapps21 = $google88888872[21];

$googleapps22 = $google88888872[22];

$googleapps23 = $google88888872[23];

$googleapps24 = $google88888872[24];

?>



<div>

<canvas id="canvas" width="600" height="300" style="background-color:#fff"></canvas>

</div>

<script>

let draw = Chart.controllers.line.prototype.draw;
Chart.controllers.line = Chart.controllers.line.extend({
    draw: function() {
        draw.apply(this, arguments);
        let ctx = this.chart.chart.ctx;
        let _stroke = ctx.stroke;
        ctx.stroke = function() {
            ctx.save();
            ctx.shadowColor = '#bdbdbd';
            ctx.shadowBlur = 8;
            ctx.shadowOffsetX = 0;
            ctx.shadowOffsetY = 12;
            _stroke.apply(this, arguments)
            ctx.restore();
        }
    }
});

let ctx = document.getElementById("canvas").getContext('2d');
let myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23"],
        datasets: [{
            label: "CLICKS",
            data: [<?php echo "$google847444"; ?>, <?php echo "$google1"; ?>, <?php echo "$google2"; ?>, <?php echo "$google3"; ?>, <?php echo "$google4"; ?>, <?php echo "$google5"; ?>, <?php echo "$google6"; ?>, <?php echo "$google7"; ?>, <?php echo "$google8"; ?>, <?php echo "$google9"; ?>, <?php echo "$google10"; ?>, <?php echo "$google11"; ?>, <?php echo "$google12"; ?>, <?php echo "$google13"; ?>, <?php echo "$google14"; ?>, <?php echo "$google15"; ?>, <?php echo "$google16"; ?>, <?php echo "$google17"; ?>, <?php echo "$google18"; ?>, <?php echo "$google19"; ?>, <?php echo "$google20"; ?>, <?php echo "$google21"; ?>, <?php echo "$google22"; ?>, <?php echo "$google23"; ?>],
            borderColor: '<?php echo "#" . $google8474224474747474; ?>',
            pointBackgroundColor: "#fff",
            pointBorderColor: '<?php echo "#" . $google8474224474747474; ?>',
            pointHoverBackgroundColor: '<?php echo "#" . $google8474224474747474; ?>',
            pointHoverBorderColor: "#fff",
            pointRadius: 4,
            pointHoverRadius: 4,
            fill: false,
            backgroundColor: '<?php echo "#" . $google8474224474747474; ?>',
}],
    },

options: {
    scales: {
      yAxes: [{
       ticks: {
                    beginAtZero: true,

},

}],

},

},

});

</script>

<?php

}

?>

<?php

$conn->close();

?>

