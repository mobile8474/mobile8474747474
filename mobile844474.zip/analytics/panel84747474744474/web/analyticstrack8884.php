<?php

error_reporting(0);

$cookiename = "analytics";

$cookievalue = "";

setcookie("$cookiename", "$cookievalue", time()+30*24*60*60, "/");

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<script>

setTimeout(function()

{

window.location = '<?php echo "/$google847474747474747474744474/panel/web/analyticstrack8884.php?analytics=googleapps84"; ?>';

}, 104);

</script>

<?php

$dateapps847474 = date("Y-m-d");

?>

<?php

if(preg_match("/[\W\w]/",$_GET['analytics']))

{

?>

<script>

setTimeout(function()

{

window.location = '<?php echo "https://$_SERVER[HTTP_HOST]/analytics/web/overview.php?today=1&googleappsappsapps84=analytics"; ?>';

}, 884);

</script>

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<script>

setTimeout(function()

{

window.location = '<?php echo "/$google847474747474747474744474/panel/web/overview.php?today=1&googleappsappsapps84=analytics"; ?>';

}, 104);

</script>

<?php

}

?>

