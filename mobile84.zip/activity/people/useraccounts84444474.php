<?php

error_reporting(0);

?>

<?php

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php



$googleappsuserapps888474 = file_get_contents("$dataurluserapps84");

$googleappsuserapps888474 = array();

$googleappsuserapps8884744474 = array();

$googleappsuserapps88847444744444444474 = array();

$query = "SELECT * FROM adsgoogleapps84747474";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$namegooglegoogleappsappsappsapps8474747444444444744474 = $row['url'];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps847474744474 = rawurldecode($namegooglegoogleappsappsappsapps8474747444444444744474);

$namegooglegoogleappsappsappsapps847474744474 = openssl_decrypt($namegooglegoogleappsappsappsapps847474744474,"AES-128-ECB",$password);

$googleappsuserapps888474[] = "$namegooglegoogleappsappsappsapps847474744474";

$googleappsuserapps88847444744444444474[] = "$namegooglegoogleappsappsappsapps847474744444444474";

}

?>

<?php

if(preg_match("/[\W\w]/",$_GET['q']))

{

?>

<div style="background-color:#ffffff;padding:12px;margin:12px;margin-top:21.4px;box-shadow:rgba(0, 0, 0, 0.4) 0px 1px 2px;border-radius:4px;">

<?php

$example = $googleappsuserapps888474;

$googleapps8474747474747474 = "0";

foreach($example as $googleapps847474744474)

{

$googleapps8474747474747474++;

$googleappsuserapps888474 = array();

$googleappsuserapps8884744474 = array();

$googleappsuserapps88847444444474 = array();

$googleappsuserapps88847444744444444474 = array();

$namegooglegoogleappsappsappsapps847474744474 = "$googleapps847474744474";

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps84747474 = openssl_encrypt($namegooglegoogleappsappsappsapps847474744474,"AES-128-ECB",$password);

$namegooglegoogleappsappsappsapps84747474 = rawurlencode($namegooglegoogleappsappsappsapps84747474);



$query = "SELECT * FROM adsgoogleapps84747474 WHERE url='$namegooglegoogleappsappsappsapps84747474'";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$namegooglegoogleappsappsappsapps8474747444444444744474 = $row['title'];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps847474744474 = rawurldecode($namegooglegoogleappsappsappsapps8474747444444444744474);

$namegooglegoogleappsappsappsapps847474744474 = openssl_decrypt($namegooglegoogleappsappsappsapps847474744474,"AES-128-ECB",$password);

$googleappsuserapps888474[] = "$namegooglegoogleappsappsappsapps847474744474";

$googleappsuserapps88847444744444444474[] = "$namegooglegoogleappsappsappsapps847474744444444474";

}

$query = "SELECT * FROM adsgoogleapps84747474 WHERE url='$namegooglegoogleappsappsappsapps84747474'";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$namegooglegoogleappsappsappsapps8474747444444444744474 = $row['description'];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps847474744474 = rawurldecode($namegooglegoogleappsappsappsapps8474747444444444744474);

$namegooglegoogleappsappsappsapps847474744474 = openssl_decrypt($namegooglegoogleappsappsappsapps847474744474,"AES-128-ECB",$password);

$googleappsuserapps8884744474[] = "$namegooglegoogleappsappsappsapps847474744474";

$googleappsuserapps88847444744444444474[] = "$namegooglegoogleappsappsappsapps847474744444444474";

}

?>

<?php

$namegooglegoogleappsappsappsapps847474744474 = "$googleapps847474744474";

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps84747474 = openssl_encrypt($namegooglegoogleappsappsappsapps847474744474,"AES-128-ECB",$password);

$namegooglegoogleappsappsappsapps84747474 = rawurlencode($namegooglegoogleappsappsappsapps84747474);

$sql = "SELECT * FROM imagesappsapps84747474 WHERE email='$namegooglegoogleappsappsappsapps84747474' order by date desc";
$query84747474 = $conn->query($sql);
$result = mysqli_fetch_array($query84747474);

$google84747474 = $result['imagesapps84747474'];

?>

<div style="cursor:pointer;">

</div>

<?php

if(preg_match("/^[A-Z]/",$googleappsuserapps888474[0]))

{

$google8474747474747474 = ucfirst($_GET['q']);

$google847474744474 = $googleappsuserapps888474[0];

}

else

{

$google8474747474747474 = $_GET['q'];

$google847474744474 = ucfirst($googleappsuserapps888474[0]);

}

if(preg_match("/$google8474747474747474/","$google847474744474"))

{

?>

<div style="z-index:88888844;background-color:#ffffff;font-size:12.8px;padding-bottom:12px;word-wrap:break-word;">

<?php

echo "<div style='color:#1a0dab;font-size:14.8px;'><a href='" . "$googleapps847474744474" . "' style='color:#1a0dab;'>" . $googleappsuserapps888474[0] . "</a></div>";

echo "<div style='color:#006621;'>" . "$googleapps847474744474" . "</div>";

echo "<div style='color:#444444;'>" . $googleappsuserapps8884744474[0] . "</div>";

?>

</div>

<?php

}

?>

<?php

if($googleapps8474747474747474 > "12") break;

}

?>

<?php

$matches84747474 = array_filter($example);

$matches84747474 = implode("",$matches84747474);

if(preg_match("/[\W\w]/",$matches84747474))

{
}

else

{

?>

<?php

if(preg_match("/users:latest/",$_GET['q']))

{

?>

<?php

$googleappsuserapps888474 = file_get_contents("$dataurluserapps84");

$googleappsuserapps888474 = array();

$googleappsuserapps8884744474 = array();

$query = "SELECT * FROM email order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$namegooglegoogleappsappsappsapps847474744474 = $row['email'];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps84747474 = rawurldecode($namegooglegoogleappsappsappsapps847474744474);

$namegooglegoogleappsappsappsapps84747474 = openssl_decrypt($namegooglegoogleappsappsappsapps84747474,"AES-128-ECB",$password);

$googleappsuserapps888474[] = "$namegooglegoogleappsappsappsapps84747474";

$googleappsuserapps8884744474[] = "$namegooglegoogleappsappsappsapps847474744474";

}

$googleappsuserapps888474 = array_unique($googleappsuserapps8884744474);

$google8474747444744474 = "0";

foreach($googleappsuserapps888474 as $googleapps84747474)

{

$google8474747444744474++;

$sql = "SELECT * FROM imagesappsapps84747474 WHERE email='$googleapps84747474' order by date desc";
$query84747474 = $conn->query($sql);
$result = mysqli_fetch_array($query84747474);

$google84747474 = $result['imagesapps84747474'];

if(preg_match("/[\W\w]/","$google84747474"))

{

echo '<div style="right:12px;top:7.4px;margin-top:-4px;"><img src="data:image/jpeg;base64,'.base64_encode($result['imagesapps84747474']).'" width="37.4" height="37.4" style="box-shadow:0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);object-fit:cover;"></img></div>';

}

else

{

echo "<div>No images</div>";

}

$namegooglegoogleappsappsappsapps847474744474 = "$googleapps84747474";

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps84747474 = rawurldecode($namegooglegoogleappsappsappsapps847474744474);

$namegooglegoogleappsappsappsapps84747474 = openssl_decrypt($namegooglegoogleappsappsappsapps84747474,"AES-128-ECB",$password);

echo "<div style='white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%;'>" . "$namegooglegoogleappsappsappsapps84747474" . "</div>" . "<br>";

if ($google8474747444744474 == "12") break;

}

}

else

{

?>

<?php

if(preg_match("/analytics:country/",$_GET['q']))

{

?>

<?php

$googleappsuserapps888474 = array();

$googleappsuserapps8884744474 = array();

$google84747474 = $_GET['userappsapps84747474'];

$query = "SELECT * FROM countryusersapps84747474 WHERE email='$_COOKIE[username]' order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$namegooglegoogleappsappsappsapps847474744474 = $row['country'];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps84747474 = rawurldecode($namegooglegoogleappsappsappsapps847474744474);

$namegooglegoogleappsappsappsapps84747474 = openssl_decrypt($namegooglegoogleappsappsappsapps84747474,"AES-128-ECB",$password);

$googleappsuserapps888474[] = "$namegooglegoogleappsappsappsapps84747474";

$googleappsuserapps8884744474[] = "$namegooglegoogleappsappsappsapps847474744474";

}

$google8474747444744474 = "0";

foreach($googleappsuserapps8884744474 as $googleapps84747474)

{

$google8474747444744474++;

$password="googleappsmobileapps888888884444";

echo "<div style='white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%;'>" . "$googleapps84747474" . "</div>" . "<br>";

if ($google8474747444744474 == "12") break;

}

}

else

{

?>

<?php

if(preg_match("/analytics:referer:(.*?)/",$_GET['q']))

{

?>

<?php

$googleappsappsappsappsappsapps84 = preg_replace("/analytics:referer:/","",$_GET['q']);

$googleappsuserapps888474 = array();

$googleappsuserapps8884744474 = array();

$google84747474 = $_GET['userappsapps84747474'];

$query = "SELECT * FROM charts84747474 WHERE email='$_COOKIE[username]' and referer REGEXP '.*$googleappsappsappsappsappsapps84.*' order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$namegooglegoogleappsappsappsapps847474744474 = $row['referer'];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps84747474 = rawurldecode($namegooglegoogleappsappsappsapps847474744474);

$namegooglegoogleappsappsappsapps84747474 = openssl_decrypt($namegooglegoogleappsappsappsapps84747474,"AES-128-ECB",$password);

$googleappsuserapps888474[] = "$namegooglegoogleappsappsappsapps84747474";

$googleappsuserapps8884744474[] = "$namegooglegoogleappsappsappsapps847474744474";

}

$google8474747444744474 = "0";

foreach($googleappsuserapps8884744474 as $googleapps84747474)

{

$google8474747444744474++;

$password="googleappsmobileapps888888884444";

echo "<div style='white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%;'>" . "$googleapps84747474" . "</div>" . "<br>";

if ($google8474747444744474 == "12") break;

}

}

else

{

?>

<?php

if(preg_match("/analytics:page:referer:(.*?)/",$_GET['q']))

{

?>

<?php

$googleappsappsappsappsappsapps84 = preg_replace("/analytics:page:referer:/","",$_GET['q']);

$googleappsuserapps888474 = array();

$googleappsuserapps8884744474 = array();

$google84747474 = $_GET['userappsapps84747474'];

$query = "SELECT * FROM charts84747474 WHERE email='$_COOKIE[username]' and referer REGEXP '.*$googleappsappsappsappsappsapps84.*' order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$namegooglegoogleappsappsappsapps847474744474 = $row['page'];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps84747474 = rawurldecode($namegooglegoogleappsappsappsapps847474744474);

$namegooglegoogleappsappsappsapps84747474 = openssl_decrypt($namegooglegoogleappsappsappsapps84747474,"AES-128-ECB",$password);

$googleappsuserapps888474[] = "$namegooglegoogleappsappsappsapps84747474";

$googleappsuserapps8884744474[] = "$namegooglegoogleappsappsappsapps847474744474";

}

$google8474747444744474 = "0";

foreach($googleappsuserapps8884744474 as $googleapps84747474)

{

$google8474747444744474++;

$password="googleappsmobileapps888888884444";

echo "<div style='white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%;'>" . "$googleapps84747474" . "</div>" . "<br>";

if ($google8474747444744474 == "12") break;

}

}

else

{

?>

<?php

if(preg_match("/analytics84/",$_GET['q']))

{

?>

<?php

$google84747474 = $_GET['q'];

preg_match_all("/referer:(.*)/", $google84747474,$googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84444474);
$accountcolor84742274 = $googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84444474[1][0];

preg_match_all("/date:(.*)/", $google84747474,$googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84);
$accountcolor847422744474 = $googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84[2][0];

$googleappsuserapps888474 = array();

$googleappsuserapps8884744474 = array();

$google84747474 = $_GET['userappsapps84747474'];

$query = "SELECT * FROM charts84747474 WHERE email='$_COOKIE[username]' and date REGEXP '$accountcolor847422744474.*' and referer REGEXP '.*$accountcolor84742274.*' order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$namegooglegoogleappsappsappsapps847474744474 = $row['date'];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps84747474 = rawurldecode($namegooglegoogleappsappsappsapps847474744474);

$namegooglegoogleappsappsappsapps84747474 = openssl_decrypt($namegooglegoogleappsappsappsapps84747474,"AES-128-ECB",$password);

$googleappsuserapps888474[] = "$namegooglegoogleappsappsappsapps84747474";

$googleappsuserapps8884744474[] = "$namegooglegoogleappsappsappsapps847474744474";

}

$google8474747444744474 = "0";

foreach($googleappsuserapps8884744474 as $googleapps84747474)

{

$google8474747444744474++;

$password="googleappsmobileapps888888884444";

echo "<div style='white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%;'>" . "$googleapps84747474" . "</div>" . "<br>";

if ($google8474747444744474 == "12") break;

}

}

else

{

echo "<div>No users</div>";

}

}

}

}

}

}

?>

</div>

<?php

}

?>

<?php

$conn->close();

?>

