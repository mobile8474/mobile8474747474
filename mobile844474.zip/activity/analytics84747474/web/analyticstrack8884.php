<?php

error_reporting(0);

$cookiename = "analytics";

$cookievalue = "";

setcookie("$cookiename", "$cookievalue", time()+30*24*60*60, "/");

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<script>

setTimeout(function()

{

window.location = '<?php echo "https://$_SERVER[HTTP_HOST]/analytics/web/analyticstrack8884.php?analytics=googleapps84"; ?>';

}, 884);

</script>

<?php

$dateapps847474 = date("Y-m-d");

?>

<?php

if(preg_match("/[\W\w]/",$_GET['analytics']))

{

?>

<script>

setTimeout(function()

{

window.location = '<?php echo "https://$_SERVER[HTTP_HOST]/analytics/web/overview.php?today=1&googleappsappsapps84=analytics"; ?>';

}, 884);

</script>

<?php

}

?>

