<?php

$googleapps84747474 = strtolower($_SERVER['HTTP_USER_AGENT']);

if(preg_match("/(bot|Bot|crawler|Crawler|spider|Spider)/","$googleapps84747474"))

{
}

else

{

?>

<?php

$dataurl84 = "../accountcolor8884.sh";

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

?>

<?php

$date84747474 = date("Y-m-d-H-i-s");

?>

<?php

$googleapps8884 = "<div class='na'><div class='$_COOKIE[username]' id='na'><div class='na'><div class='$_POST[googleappscolorapps84747474]'>1</div></div></div></div>";

?>

<?php

$filedata = $googleapps8884;
$filedata .= file_get_contents("../accountcolor8884.sh");
$googleapps888844 = file_put_contents("../accountcolor8884.sh", $filedata);

$sql84747474 = "INSERT INTO accountcolor84747474 (email,accountcolor84747474,date)
VALUES ('$_COOKIE[username]','$_POST[googleappscolorapps84747474]','$date84747474')";

echo "<div style='display:none;'>$googleapps888844</div>";

?>

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<script>

setTimeout(function()

{

window.location = '<?php echo "/$google847474747474747474744474/settings/account.php"; ?>';

}, 104);

</script>

<?php

if ($conn->query($sql84747474) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql84747474 . "<br>" . $conn->error;
}

?>

<?php

$conn->close();

?>

<?php

}

?>

