<?php

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn84444444447474 = new mysqli($servername, $username, $password, $dbname);

?>

<?php

include "../dashboard/dashboardtop.php";

?>

<?php

$result84747474 = array();

$query = "SELECT * FROM googleappsappsappsapps84747474 WHERE email='$_COOKIE[username]' order by date desc limit $_GET[googleapps84],8";

$result = mysqli_query($conn84444444447474,$query);

foreach($result as $row)

{

$result84747474[] = $row['google84747474'];

}

?>

<div style="background-color:#ffffff;padding:12px;box-shadow:0 2px 4px rgba(0,0,0,0.4);margin:12px;">

<div style="padding:12px;color:#444444;">

Audio messages

</div>

<?php

foreach($result84747474 as $googleapps84747474)

{

?>

<?php

echo '

<audio controls>

<source src="data:audio/mpeg;base64,'.base64_encode($googleapps84747474).'" type="audio/ogg">

</audio>

<br>

';

?>

<?php

}

?>

<div style="position:relative;background-color:#ffffff;padding:21.4px;margin-left:12px;margin-right:12px;">

<div style="background-color:#ffffff;position:absolute;right:0px;display:inline-block;bottom:-41.8px;right:48px;color:#444444;cursor:pointer;bottom:8px;right:49.4px;border-style:solid;border-width:1px;position:absolute;border-color:#bdbdbd;display:grid;" onclick="window.open('/googleappsappsapps84/googleapps84.php?googleapps84=<?php echo $_GET[googleapps84] - 8; ?>&googleapps8474=<?php echo $_GET[googleapps8474] - 8; ?>','_self')">

<i class="material-icons">keyboard_arrow_left</i>

</div>

<div style="background-color:#ffffff;position:absolute;right:0px;display:inline-block;bottom:-41.8px;right:12px;color:#444444;cursor:pointer;position:absolute;bottom:8px;right:24px;border-style:solid;border-width:1px;border-color:#bdbdbd;display:grid;" onclick="window.open('/googleappsappsapps84/googleapps84.php?googleapps84=<?php echo $_GET[googleapps84] + 8; ?>&googleapps8474=<?php echo $_GET[googleapps8474] + 8; ?>','_self')">

<i class="material-icons">keyboard_arrow_right</i>

</div>

</div>

<?php

include "../dashboard/dashboardbottom.php";

?>

<?php

$conn->close();

?>

