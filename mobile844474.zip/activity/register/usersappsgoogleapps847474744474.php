<?php

$servername8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername8474747444444474, $username8474747444444474, $password8474747444444474, $dbname8474747444444474);

?>

<?php

$name = $_POST['googleapps847474744474'];

$password="googleappsmobileapps888888884444";

$name = openssl_encrypt($name,"AES-128-ECB",$password);

$name847474744474 = rawurlencode($name);

?>

<?php

$name847474747474747474 = $_POST['google84747474'];

$password="googleappsmobileapps888888884444";

$name847474747474747474 = openssl_encrypt($name847474747474747474,"AES-128-ECB",$password);

$name847474747474747474 = rawurlencode($name847474747474747474);

?>

<?php

$googleappsgooglegoogleapps888444444474 = array();

$query = "SELECT * FROM user4 WHERE email='$name847474747474747474' and password='$name847474744474' order by date desc";

$result8444444474 = mysqli_query($conn,$query);

foreach($result8444444474 as $row)

{

$name8444444474 = $row['password'];

$googleappsgooglegoogleapps888444444474[] = "$name8444444474";

}

$googleappsgooglegoogleapps8884747474747474747444444474 = implode("\n",$googleappsgooglegoogleapps888444444474);

if(preg_match("/[\W\w]/","$googleappsgooglegoogleapps8884747474747474747444444474"))

{

?>

<?php

$googleappsgooglegoogleapps888444444474 = array();

$query = "SELECT * FROM accountcolor84747474 WHERE email='$name847474747474747474' order by date desc limit 1";

$result8444444474 = mysqli_query($conn,$query);

foreach($result8444444474 as $row)

{

$name8444444474 = $row['accountcolor84747474'];

$googleappsgooglegoogleapps888444444474[] = "$name8444444474";

}

$googleappsgooglegoogleapps8884747474747474747444444474 = implode("\n",$googleappsgooglegoogleapps888444444474);

if(preg_match("/[\W\w]/","$googleappsgooglegoogleapps8884747474747474747444444474"))

{

$googleappsgooglegoogleapps8884747474747474747444444474 = preg_replace("/\s+/","",$googleappsgooglegoogleapps8884747474747474747444444474);

echo "$googleappsgooglegoogleapps8884747474747474747444444474";

}

?>

<?php

}

?>

<?php

$conn->close();

?>

