<?php

error_reporting(0);

?>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

$countryapps8884 = $_COOKIE['country'];

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../mainactivityappswrite84747474.sh";

}

else

{

$dataurlappsappsapps84 = "mainactivityappswrite84747474.sh";

}

?>

<?php

$googleapps8474 = $_GET['mainactivityapps84444474'];

$googleappsappsapps8474 = rawurlencode($googleapps8474);

?>

<?php

$googleapps8474 = $_GET['mainactivityapps84747474'];

$googleapps84444474 = "$googleapps8474";

?>

<?php

$googleapps8474 = $_GET['coworkersnameapps84747474'];

$googleapps84442274 = rawurlencode($googleapps8474);

?>

<?php

$googleapps8474 = $_GET['mainactivityappsuserapps84747474'];

$googleappsgoogleappsapps84442274 = rawurlencode($googleapps8474);

?>

<?php

$googleapps8884 = "<div class='$googleappsgoogleappsapps84442274' id='na'>" . "\n" . "<div class='$googleapps84444474' id='na'>" . "\n" . "<div class='$googleappsappsapps8474' id='$_GET[googleappsapps84444474]'>1</div>" . "\n" . "</div>" . "\n" . "</div>";

?>

<?php

echo "<div style='display:none;'>$googleapps888844</div>";

?>

<?php

$date84747474 = date("Y-m-d-H-i-s");

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

$userip8884 = $ip;

?>

<?php

$sql84747474 = "INSERT INTO mainactivityappsapps84747474 (email,date,mainactivity,mainactivity84747474,mainactivity84444474,userip)
VALUES ('$googleappsgoogleappsapps84442274','$date84747474','$googleapps84444474','$googleappsappsapps8474','$_GET[googleappsapps84444474]','$userip8884')";

echo "<div style='display:none;'>$googleapps888844</div>";

?>

<?php

if ($conn->query($sql84747474) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql84747474 . "<br>" . $conn->error;
}

?>

<?php

$conn->close();

?>

