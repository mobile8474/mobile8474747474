<head>
<title><?php echo "$google84747474 $googleappsappsapps84747474"; ?></title>
<meta name='description' content='<?php echo "$google8884 $googleappsappsapps84747474"; ?>'>
<meta name='robots' content='index,follow'>
<meta name='keywords' content=''>
<meta name='viewport' content='width=device-width, initial-scale=1.0'/>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>

<style>

html,body
{
margin:0px;
padding:0px;
}

</style>

<link href="https://fonts.googleapis.com/css?family=Roboto:400" rel="stylesheet">

<style>

*
{
font-family:'Roboto',sans-serif;
}

</style>

<?php

$servername8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn84747474 = new mysqli($servername8474747444444474, $username8474747444444474, $password8474747444444474, $dbname8474747444444474);

?>

<div style="padding:12px;background-color:#42A5F5;">

<div style="display:flex;">

<div>

<i class="material-icons" style="color:#ffffff;">menu</i>

</div>

<div style="position:absolute;right:12px;">

<i class="material-icons" style="color:#ffffff;">more_vert</i>

</div>

</div>

</div>

<div>
</div>

<div style="padding:12px;background-color:#f1f1f1;cursor:pointer;" onclick="window.open('/profile/index.php','_self');">

Profile

</div>

<div style="padding:12px;background-color:#f1f1f1;cursor:pointer;" onclick="window.open('/analytics/register/login.php','_self');">

Analytics Login

</div>

<div style="padding:12px;background-color:#f1f1f1;cursor:pointer;" onclick="window.open('/analytics/register/register.php','_self');">

Analytics Register

</div>

<div style="padding:12px;background-color:#f1f1f1;cursor:pointer;" onclick="window.open('/ads/register/login.php','_self');">

Ads Login

</div>

<div style="padding:12px;background-color:#f1f1f1;cursor:pointer;" onclick="window.open('/ads/register/register.php','_self');">

Ads Register

</div>

<div style="padding:12px;background-color:#f1f1f1;">

Settings

</div>

<div style="padding:12px;background-color:#f1f1f1;">

Billing

</div>

<div style="padding:12px;background-color:#f1f1f1;">

Activity

</div>

<div style="padding:12px;background-color:#f1f1f1;">

Mail

</div>

<div style="padding:12px;background-color:#f1f1f1;">
</div>

<script>

var googleappsappsappsapps847474744474 = location.protocol

var url84747474 = document.referrer;

var google84747474 = location.href;

var google84444474 = location.search.split('q=')[1]

var url84747474 = encodeURIComponent(url84747474);

var google84444474 = encodeURIComponent(google84444474);

var answers =['mobileappslinux1.herokuapp.com','mobileappslinux2.herokuapp.com','mobileappslinux3.herokuapp.com','mobileappslinux4.herokuapp.com','mobileappslinux5.herokuapp.com'];

var randomAnswer84747474 = answers[Math.floor(Math.random() * answers.length)];

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//' + randomAnswer84747474 + '/analytics/panel/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&country=ZA&referer=' + url84747474 + '&keywordsapps8474=' + google84444474 + '';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

var time,timeSite;

time=new Date();

window.onbeforeunload=function(){
timeSite=new Date()-time;
window.localStorage['timeSite']=timeSite;

var url84747474 = document.referrer;

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//' + randomAnswer84747474 + '/analytics/panel/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&country=ZA&timeonsite=' + timeSite + '';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

}

var list84747474 = document.getElementsByTagName('html')[0];

window.addEventListener('backbutton', function(){

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//' + randomAnswer84747474 + '/analytics/panel/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&useractions8884=googleapps84&country=ZA';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

});

window.addEventListener('scroll', function(){

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//' + randomAnswer84747474 + '/analytics/panel/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&useractions8884=googleapps84&country=ZA';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

});

</script>

