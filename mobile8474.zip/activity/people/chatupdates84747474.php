<?php

error_reporting(0);

?>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../chatapps84747474.sh";

}

else

{

$dataurl8884 = "chatapps84747474.sh";

}

?>

<?php

$decryptedstring = $_GET['between1'];

$decryptedstring84444474 = "$decryptedstring";

$decryptedstring844444444474 = rawurlencode("$decryptedstring84444474");

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../userregistrations.sh";

}

else

{

$dataurl84 = "../register/userregistrations.sh";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl84");

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../firstnameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/firstnameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../lastnameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/lastnameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../usernameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/usernameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$namegoogleapps84747474 = "$gosearchimagesappsapps84747674 $gosearchimagesappsappsappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$namegoogleapps84747474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../firstnameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/firstnameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$decryptedstring84444474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../lastnameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/lastnameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$decryptedstring84444474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../usernameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/usernameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$decryptedstring84444474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$name84747474 = "$gosearchimagesappsapps84747674 $gosearchimagesappsappsappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$name84747474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

$password="googleappsmobileapps888888884444";

$decryptedstring = rawurldecode($decryptedstring84444474);

$decryptedstring = openssl_decrypt($decryptedstring,"AES-128-ECB",$password);

$decryptedstring8884 = $_GET['between74'];

$decryptedstring88847474 = "$decryptedstring8884";

$decryptedstringappsappsappsapps88847474 = rawurlencode("$decryptedstring8884");

$decryptedstring888474444474 = rawurlencode("$decryptedstring88847474");

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../userregistrations.sh";

}

else

{

$dataurl84 = "../register/userregistrations.sh";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl84");

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../firstnameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/firstnameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$decryptedstring888474444474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../lastnameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/lastnameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$decryptedstring888474444474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../usernameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/usernameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$decryptedstring888474444474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$namegoogleappsappsapps84747474 = "$gosearchimagesappsapps84747674 $gosearchimagesappsappsappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$namegoogleappsappsapps84747474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

$password="googleappsmobileapps888888884444";

$decryptedstring8884 = rawurldecode($decryptedstring88847474);

$decryptedstring8884 = openssl_decrypt($decryptedstring8884,"AES-128-ECB",$password);

$file84 = file_get_contents("$dataurl8884");

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='$decryptedstring84444474'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $file84, $googleapps84);
$emailtext = $googleapps84[3];

$googleappsappsappsappsgoogleapps84747474 = "$decryptedstring84444474$decryptedstring88847474";

$password="googleappsmobileapps888888884444";

$googleappsappsappsappsgoogleapps84747474 = openssl_encrypt($googleappsappsappsappsgoogleapps84747474,"AES-128-ECB",$password);

$googleappsappsappsappsgoogleapps84747474 = rawurlencode($googleappsappsappsappsgoogleapps84747474);

$googleappsappsappsappsgoogleappsgoogleappsapps84747474 = "$decryptedstring88847474$decryptedstring84444474";

$password="googleappsmobileapps888888884444";

$googleappsappsappsappsgoogleappsgoogleappsapps84747474 = openssl_encrypt($googleappsappsappsappsgoogleappsgoogleappsapps84747474,"AES-128-ECB",$password);

$googleappsappsappsappsgoogleappsgoogleappsapps84747474 = rawurlencode($googleappsappsappsappsgoogleappsgoogleappsapps84747474);

preg_match_all("/<div class='$googleappsappsappsappsgoogleapps84747474'>\n<div class='na' id='na'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>1<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $file84, $googleapps84);
$emailtextappsapps84747474 = $googleapps84[1];

preg_match_all("/<div class='$googleappsappsappsappsgoogleappsgoogleappsapps84747474'>\n<div class='na' id='na'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>1<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $file84, $googleapps84);
$emailtextappsappsappsapps84747474 = $googleapps84[1];

$googleappsappsapps84444474 = array_merge($emailtextappsapps84747474,$emailtextappsappsappsapps84747474);

$google84744474 = implode("<br>",$googleappsappsapps84444474);

$emailtext84747474 = explode("<br>",$google84744474);

?>

<style>

@media screen and (max-width:770px)
{
.googleappsappsgoogleappsappsapps84
{
position:fixed;
top:0px;
width:100%;
height:100%!important;
z-index:446;
box-sizing:border-box;
top:54px!important;
}
.google84222274
{
position:fixed;
bottom:0px;
}
}
}

</style>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlapps84 = "../accountcolor88842274.sh";

}

else

{

$dataurlurlapps84 = "../register/accountcolor88842274.sh";

}

?>

<?php

$googleappsgoogleappsappsgoogleapps8884 = file_get_contents($dataurlurlapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../accountcolor8884.sh";

}

else

{

$dataurlurlgoogleapps84 = "../register/accountcolor8884.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<script>

$(document).ready(function(){

$('.googleappsappsgoogleappsappsapps84').scrollTop(1000000);

});

</script>

<?php

echo "<div class='googleappsappsgoogleappsappsapps84' id='googleappsappsappsappsapps84447474' style='padding:12px;justify-content:space-between;background-color:#ffffff;height:408px;overflow:scroll;padding-bottom:0px;box-shadow:0 2px 4px rgba(0,0,0,0.2);padding-bottom:196px;'>";

echo "<div style='font-size:22px;' onclick='googleappsapps84();'>";

?>

<div id="googleappsappsapps84447474" style="display:flex;">

<div>

<?php

echo "<i class='material-icons googleapps84742274' style='font-size:34px;'>keyboard_arrow_left</i>";

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../gosearchimages8884.sh";

}

else

{

$dataurlappsappsapps84 = "../gosearchimages8884/gosearchimages8884.sh";

}

?>

<?php

$googleappsappsappsapps8884 = file_get_contents($dataurlappsappsapps84);

?>

<?php

preg_match_all("/<div class='$decryptedstringappsappsappsapps88847474' id='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsappsappsapps8884, $googleappsgoogleappsappsapps84);
$gosearchimagesappsapps8474 = $googleappsgoogleappsappsapps84[2][0];

?>

</div>

<?php

preg_match_all("/<div class='$decryptedstring888474444474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleapps84);
$accountcolor84742274 = $googleapps84[3][0];

?>

<?php

preg_match_all("/<div class='$decryptedstring888474444474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor847474))

{
}

else

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/[\W\w]/",$accountcolor84742274))

{

if(preg_match("/white/",$accountcolor84742274))

{

$accountcolor44 = "#ffffff";

}

if(preg_match("/grey/",$accountcolor84742274))

{

$accountcolor44 = "#37474F";

}

}

else

{

$accountcolor44 = "#ffffff";

}

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor84742274))

{

if(preg_match("/white/",$accountcolor84742274))

{

$accountcolor84444474 = "#37474F";

}

if(preg_match("/grey/",$accountcolor84742274))

{

$accountcolor84444474 = "#f8f8f8";

}

}

else

{

$accountcolor84444474 = "#37474F";

}

?>

<?php

if(preg_match("/blue/",$accountcolor847474))

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/orange/",$accountcolor847474))

{

$accountcolor84747474 = "#EF6C00";

$accountcolor1 = "#EF6C00";

$accountcolor2 = "#FB8C00";

$accountcolor4 = "#FFA726";

}

if(preg_match("/yellow/",$accountcolor847474))

{

$accountcolor84747474 = "#F9A825";

$accountcolor1 = "#F9A825";

$accountcolor2 = "#FDD835";

$accountcolor4 = "#FFEE58";

}

if(preg_match("/purple/",$accountcolor847474))

{

$accountcolor84747474 = "#6A1B9A";

$accountcolor1 = "#6A1B9A";

$accountcolor2 = "#8E24AA";

$accountcolor4 = "#AB47BC";

}

if(preg_match("/pink/",$accountcolor847474))

{

$accountcolor84747474 = "#AD1457";

$accountcolor1 = "#AD1457";

$accountcolor2 = "#D81B60";

$accountcolor4 = "#EC407A";

}

if(preg_match("/red/",$accountcolor847474))

{

$accountcolor84747474 = "#EF5350";

$accountcolor1 = "#C62828";

$accountcolor2 = "#E53935";

$accountcolor4 = "#EF5350";

}

if(preg_match("/green/",$accountcolor847474))

{

$accountcolor84747474 = "#2E7D32";

$accountcolor1 = "#2E7D32";

$accountcolor2 = "#43A047";

$accountcolor4 = "#66BB6A";

}

if(preg_match("/[\W\w]/","$accountcolor847474"))

{

$accountcolor1 = "$accountcolor847474";

$accountcolor2 = "$accountcolor847474";

$accountcolor4 = "$accountcolor847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<div>

<?php

if(preg_match("/[\W\w]/",$gosearchimagesappsapps8474))

{

?>

<div id="div84747474" style="right:18px;top:18px;"><img src="<?php echo $gosearchimagesappsapps8474; ?>" width="34" height="34" style="border-radius:24px;border-radius:24px;border-color:<?php echo "$accountcolor2"; ?>;border-width:2px;box-shadow:0 2px 4px rgba(0,0,0,0.1);margin-top:0px;"></img></div>

<?php

}

else

{

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsappsappsappsappsappsapps84 = "../googleappsapps84747474.sh";

}

else

{

$dataurluserappsappsappsappsappsappsapps84 = "../people/googleappsapps84747474.sh";

}

?>

<?php

$googleappsuserappsappsappsappsappsapps888474 = file_get_contents($dataurluserappsappsappsappsappsappsapps84);

?>

<?php

preg_match_all("/<div class='$decryptedstring888474444474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsappsappsapps888474, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/(^Male$|^male$)/","$gosearchimages84747674"))

{

?>

<div style='left:18px;bottom:-22px;'>

<div onclick="document.getElementById('<?php echo "$googleapps847444444444444474"; ?>').click();">

<div class='inline'>
<img class='textavatar' src="/gosearchimages8884/googleapps84.jpg" style='width:34px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;' data-name='<?php echo "$namegoogleappsappsapps84747474"; ?>'></img>
</div>

</div>

</div>

<?php

}

else

{

?>

<div style='left:18px;bottom:-22px;'>

<div onclick="document.getElementById('<?php echo "$googleapps847444444444444474"; ?>').click();">

<div class='inline'>
<img class='textavatar' src="/gosearchimages8884/googleapps84747474.jpeg" style='width:34px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;' data-name='<?php echo "$namegoogleappsappsapps84747474"; ?>'></img>
</div>

</div>

</div>

<?php

}

?>

<?php

}

?>

</div>

<div style="font-size:14px;font-weight:bold;margin-left:12px;margin-top:0px;">

<?php

echo "$namegoogleappsappsapps84747474";

?>

<div style="font-weight:normal;font-size:10px;margin-top:4px;">

Online

</div>

</div>

</div>

<?php

echo "</div>";

echo "<div style='font-size:14.6px;margin-bottom:12px;'>";

if(preg_match("/$_COOKIE[username]/","$decryptedstring844444444474"))

{

echo "Between You and $namegoogleappsappsapps84747474";

}

else

{

echo "Check if chat is online type message";

}

echo "</div>";

?>

<script>

function googleappsapps84() {

$('#google<?php echo $_GET[googleapps84747474]; ?>').hide();

$('.googledivapps84').hide();

document.getElementsByTagName("body")[0].style.overflow = "scroll";

}

</script>

<?php

echo "<div>";

$googleapps84 = array();

$googleapps8474 = array();

foreach($emailtext84747474 as $googleapps84747474)

{

$googleapps84[] = "$googleapps84747474";

}

$googleapps84444474 = implode("<br>",$googleapps84);

$googleapps84444474 = explode("<br>",$googleapps84444474);

$google84747474 = "0";

foreach($googleapps84444474 as $googleappsappsapps84747474)

{

?>

<style>

.google84444474:empty
{
display:none!important;
}

.googleappsappsappsgoogleapps84444474:empty
{
display:none!important;
}

</style>

<?php

$google84747474++;

preg_match_all("/<div class='$googleappsappsappsappsgoogleapps84747474'>\n<div class='na' id='na'>\n<div class='$google84747474'>\n<div class='(.*?)'>\n<div class='(.*?)'>1<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $file84, $googleapps84);
$emailtextappsapps84747474 = $googleapps84[1][0];

preg_match_all("/<div class='$googleappsappsappsappsgoogleapps84747474'>\n<div class='na' id='na'>\n<div class='$google84747474'>\n<div class='(.*?)'>\n<div class='(.*?)'>1<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $file84, $googleappsgoogleappsappsapps84);
$emailtextappsappsgoogleapps84747474 = $googleappsgoogleappsappsapps84[2][0];

$emailtextappsappsgoogleapps84747474 = date("M d H:i:s", strtotime("$emailtextappsappsgoogleapps84747474"));

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleapps84);
$accountcolor84742274 = $googleapps84[3][0];

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor847474))

{
}

else

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/[\W\w]/",$accountcolor84742274))

{

if(preg_match("/white/",$accountcolor84742274))

{

$accountcolor44 = "#ffffff";

}

if(preg_match("/grey/",$accountcolor84742274))

{

$accountcolor44 = "#37474F";

}

}

else

{

$accountcolor44 = "#ffffff";

}

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor84742274))

{

if(preg_match("/white/",$accountcolor84742274))

{

$accountcolor84444474 = "#37474F";

}

if(preg_match("/grey/",$accountcolor84742274))

{

$accountcolor84444474 = "#f8f8f8";

}

}

else

{

$accountcolor84444474 = "#37474F";

}

?>

<?php

if(preg_match("/blue/",$accountcolor847474))

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/orange/",$accountcolor847474))

{

$accountcolor84747474 = "#EF6C00";

$accountcolor1 = "#EF6C00";

$accountcolor2 = "#FB8C00";

$accountcolor4 = "#FFA726";

}

if(preg_match("/yellow/",$accountcolor847474))

{

$accountcolor84747474 = "#F9A825";

$accountcolor1 = "#F9A825";

$accountcolor2 = "#FDD835";

$accountcolor4 = "#FFEE58";

}

if(preg_match("/purple/",$accountcolor847474))

{

$accountcolor84747474 = "#6A1B9A";

$accountcolor1 = "#6A1B9A";

$accountcolor2 = "#8E24AA";

$accountcolor4 = "#AB47BC";

}

if(preg_match("/pink/",$accountcolor847474))

{

$accountcolor84747474 = "#AD1457";

$accountcolor1 = "#AD1457";

$accountcolor2 = "#D81B60";

$accountcolor4 = "#EC407A";

}

if(preg_match("/red/",$accountcolor847474))

{

$accountcolor84747474 = "#EF5350";

$accountcolor1 = "#C62828";

$accountcolor2 = "#E53935";

$accountcolor4 = "#EF5350";

}

if(preg_match("/green/",$accountcolor847474))

{

$accountcolor84747474 = "#2E7D32";

$accountcolor1 = "#2E7D32";

$accountcolor2 = "#43A047";

$accountcolor4 = "#66BB6A";

}

if(preg_match("/[\W\w]/","$accountcolor847474"))

{

$accountcolor1 = "$accountcolor847474";

$accountcolor2 = "$accountcolor847474";

$accountcolor4 = "$accountcolor847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<?php

if(preg_match("/[\W\w]/","$emailtextappsapps84747474"))

{

echo "<div style='position:relative;width:100%;margin:12px;'><div class='google84' style='border-style:solid;left:-8px;border-width:6.8px;border-color:$accountcolor1 $accountcolor1 transparent transparent;position:absolute;top:0px;color:#ffffff;'></div><div class='google84444474' style='padding:12px;background-color:$accountcolor1;border-radius:4px;font-size:14px;top:0px;word-wrap:break-word;max-width:196px;display:inline-block;box-shadow:0 1px 1px rgba(0,0,0,0.2);border-top-left-radius:0px;padding-bottom:22.4px;min-width:96px;color:#ffffff;'><div style='position:relative;'><div>$emailtextappsapps84747474</div><div style='font-size:10px;margin-top:4px;margin-left:4px;position:absolute;right:0px;bottom:-19px;'>$emailtextappsappsgoogleapps84747474</div></div></div></div>";

}

preg_match_all("/<div class='$googleappsappsappsappsgoogleappsgoogleappsapps84747474'>\n<div class='na' id='na'>\n<div class='$google84747474'>\n<div class='(.*?)'>\n<div class='(.*?)'>1<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $file84, $googleapps84);
$emailtextappsappsappsapps84747474 = $googleapps84[1][0];

preg_match_all("/<div class='$googleappsappsappsappsgoogleappsgoogleappsapps84747474'>\n<div class='na' id='na'>\n<div class='$google84747474'>\n<div class='(.*?)'>\n<div class='(.*?)'>1<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $file84, $googleappsgoogleappsappsappsappsapps84);
$emailtextappsappsgoogleappsappsapps84747474 = $googleappsgoogleappsappsappsappsapps84[2][0];

$emailtextappsappsgoogleappsgoogleappsappsapps84747474 = date("M d H:i:s", strtotime("$emailtextappsappsgoogleappsappsapps84747474"));

$emailtextappsappsappsappsappsapps84747474 = strlen("$emailtextappsappsappsapps84747474");

?>

<?php

preg_match_all("/<div class='$decryptedstring888474444474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleapps84);
$accountcolor84742274 = $googleapps84[3][0];

?>

<?php

preg_match_all("/<div class='$decryptedstring888474444474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor847474))

{
}

else

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/[\W\w]/",$accountcolor84742274))

{

if(preg_match("/white/",$accountcolor84742274))

{

$accountcolor44 = "#ffffff";

}

if(preg_match("/grey/",$accountcolor84742274))

{

$accountcolor44 = "#37474F";

}

}

else

{

$accountcolor44 = "#ffffff";

}

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor84742274))

{

if(preg_match("/white/",$accountcolor84742274))

{

$accountcolor84444474 = "#37474F";

}

if(preg_match("/grey/",$accountcolor84742274))

{

$accountcolor84444474 = "#f8f8f8";

}

}

else

{

$accountcolor84444474 = "#37474F";

}

?>

<?php

if(preg_match("/blue/",$accountcolor847474))

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/orange/",$accountcolor847474))

{

$accountcolor84747474 = "#EF6C00";

$accountcolor1 = "#EF6C00";

$accountcolor2 = "#FB8C00";

$accountcolor4 = "#FFA726";

}

if(preg_match("/yellow/",$accountcolor847474))

{

$accountcolor84747474 = "#F9A825";

$accountcolor1 = "#F9A825";

$accountcolor2 = "#FDD835";

$accountcolor4 = "#FFEE58";

}

if(preg_match("/purple/",$accountcolor847474))

{

$accountcolor84747474 = "#6A1B9A";

$accountcolor1 = "#6A1B9A";

$accountcolor2 = "#8E24AA";

$accountcolor4 = "#AB47BC";

}

if(preg_match("/pink/",$accountcolor847474))

{

$accountcolor84747474 = "#AD1457";

$accountcolor1 = "#AD1457";

$accountcolor2 = "#D81B60";

$accountcolor4 = "#EC407A";

}

if(preg_match("/red/",$accountcolor847474))

{

$accountcolor84747474 = "#EF5350";

$accountcolor1 = "#C62828";

$accountcolor2 = "#E53935";

$accountcolor4 = "#EF5350";

}

if(preg_match("/green/",$accountcolor847474))

{

$accountcolor84747474 = "#2E7D32";

$accountcolor1 = "#2E7D32";

$accountcolor2 = "#43A047";

$accountcolor4 = "#66BB6A";

}

if(preg_match("/[\W\w]/","$accountcolor847474"))

{

$accountcolor1 = "$accountcolor847474";

$accountcolor2 = "$accountcolor847474";

$accountcolor4 = "$accountcolor847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<?php

if(preg_match("/[\W\w]/","$emailtextappsappsappsapps84747474"))

{

if($emailtextappsappsappsappsappsapps84747474 > "34")

{

echo "<div id='google84222274' style='position:relative;width:100%;' align='right'><div style='border-style:solid;right:4px;border-width:8px;border-color:$accountcolor1 transparent transparent $accountcolor1;position:absolute;top:0px;'></div><div class='googleappsappsappsgoogleapps84444474' style='padding:12px;background-color:$accountcolor1;border-radius:4px;font-size:14px;margin-right:12px;top:0px;color:#ffffff;word-wrap:break-word;max-width:196px;box-shadow:0 1px 1px rgba(0,0,0,0.2);display:inline-block;text-align:left;border-top-right-radius:0px;margin-bottom:12px;padding-bottom:21.4px;min-width:96px;'><div><div>$emailtextappsappsappsapps84747474</div><div style='font-size:10px;position:absolute;right:19px;bottom:19px;'>$emailtextappsappsgoogleappsgoogleappsappsapps84747474</div></div></div></div>";

}

else

{

echo "<div id='google84222274' style='position:relative;width:100%;' align='right'><div style='border-style:solid;right:4px;border-width:8px;border-color:$accountcolor1 transparent transparent $accountcolor1;position:absolute;top:0px;'></div><div class='googleappsappsappsgoogleapps84444474' style='padding:12px;background-color:$accountcolor1;border-radius:4px;font-size:14px;margin-right:12px;top:0px;color:#ffffff;word-wrap:break-word;max-width:196px;box-shadow:0 1px 1px rgba(0,0,0,0.2);display:inline-block;text-align:left;border-top-right-radius:0px;margin-bottom:12px;padding-bottom:21.4px;min-width:96px;'><div><div>$emailtextappsappsappsapps84747474</div><div style='font-size:10px;margin-top:4px;margin-left:4px;position:absolute;right:19px;bottom:19px;'>$emailtextappsappsgoogleappsgoogleappsappsapps84747474</div></div></div></div>";

}

}

}

?>

<?php

echo "</div>";

echo "</div>";

?>

<style>

.googleappsappsgoogleappsappsapps84
{
top:0px;
width:100%;
height:100%!important;
z-index:446;
box-sizing:border-box;
top:54px!important;
left:0px;
}
.google84222274
{
position:fixed;
bottom:0px;
}

</style>

<div id="pageviewsappsappsapps84747474" style="width:100%;position:absolute;margin-top:54px;z-index:44;"></div>

<script>

function doDelayedSearch() {

$(document).ready(function(){

$("#wave").style.display = "inline-block";

}

);

}

</script>

<div class="spinner">
  <div class="bounce1"></div>
  <div class="bounce2"></div>
  <div class="bounce3"></div>
</div>

<style>

</style>

<div style="bottom:0px;width:100%;left:0px;">

<div>

<div class="googledivapps84" style="box-shadow:0 2px 4px 0 rgba(0, 0, 0, 0.1);width:100%;position:fixed;bottom:0px;width:100%;left:0px;z-index:1448;">

<form name="input" action='<?php echo "/people/chatwrite84747474.php"; ?>' method="get"  style="" id="google847444">

<div class="google84222274" style="display:flex;background-color:#ffffff;width:100%;z-index:996;">

<div style="width:100%;">

<input type="text" name="message84747474" id="message<?php echo $_GET[googleapps84747474]; ?>" placeholder="chat" class="" style="width:100%;padding-top:12px;padding-bottom:12px;font-size:14px;outline:none;border-top:none;border-left:none;border-right:none;box-sizing:border-box;padding:12px;border-bottom:none;margin:12px;background-color:#bdbdbd;" autocomplete="off" onchange="googleappsgooglegoogleapps84();">

<div style="border-style:solid;right:56px;border-width:8px;border-color:#bdbdbd transparent transparent #bdbdbd;position:absolute;top:12px;">
</div>

</div>

<div>

<div class="googleappsappsappsappsgooglegoogleapps<?php echo "$_GET[googleapps84747474]"; ?>" style="margin-left:-12px;padding:19px;margin:12px;margin-left:30px;border-radius:96px;border:none;position:relative;padding-left:19px;padding-right:19px;right:8px;background-color:#bdbdbd;" onclick=''>

<i class='material-icons googleapps84742274' style='font-size:26px;position:absolute;top:4px;right:4px;color:#444444;'>send</i>

</div>

</input>

</div>

</div>

<?php

$google84744474 = "$_GET[between1]";

$google84744474 = rawurlencode("$google84744474");

$google84742274 = "$_GET[between74]";

$google84742274 = rawurlencode("$google84742274");

?>

<input type="hidden" name="googlebetween1" id="googlebetween<?php echo $_GET[googleapps84747474]; ?>" placeholder="" value="<?php echo "$google84744474"; ?>" style="" autocomplete="off">

<input type="hidden" name="googlebetween74" id="googlebetweenapps<?php echo $_GET[googleapps84747474]; ?>" placeholder="" value="<?php echo "$google84742274"; ?>" style="" autocomplete="off">

</form>

</div>

</div>

</div>

<script>

function googleappsgooglegoogleapps84() {

$(document).ready(function(){

$('#googleappsappsappsappsapps84447474').scrollTop(1000000);

});

}

</script>

<script>

document.getElementById("google847444").addEventListener("submit", function(event){

event.preventDefault()

});

</script>

<div id="minutesappsappsapps<?php echo $_GET['googleapps84747474']; ?>" style="position:relative;z-index:1284;"></div>

<script>

$(document).ready(function() {

$('.googleappsappsappsappsgooglegoogleapps<?php echo "$_GET[googleapps84747474]"; ?>').click(function(){

var google84444474 = $('#message<?php echo "$_GET[googleapps84747474]"; ?>').val();

var google84222274 = $('#googlebetween<?php echo "$_GET[googleapps84747474]"; ?>').val();

var googleapps84222274 = $('#googlebetweenapps<?php echo "$_GET[googleapps84747474]"; ?>').val();

$.ajax({
    data: 'message84747474=' + google84444474 + '&googlebetween1=' + google84222274 + '&googlebetween74=' + googleapps84222274 + '',
    url: '/people/chatwrite84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

});

});

</script>

<script>

$(document).ready(function() {

$('.googleappsappsappsappsgooglegoogleapps<?php echo "$_GET[googleapps84747474]"; ?>').click(function(googleapps84){

$("#minutesappsappsapps<?php echo $_GET['googleapps84747474']; ?>").load('/people/chatupdatesappsapps84747474.php?between1=<?php echo "$google84744474"; ?>&between74=<?php echo "$google84742274"; ?>&googleapps84747474=<?php echo "$_GET[googleapps84747474]"; ?>');

$("#minutesappsappsapps<?php echo $_GET['googleapps84747474']; ?>").load('/people/chatupdatesappsapps84747474.php?between1=<?php echo "$google84744474"; ?>&between74=<?php echo "$google84742274"; ?>&googleapps84747474=<?php echo "$_GET[googleapps84747474]"; ?>');

});

});

</script>

<script>

var x = document.getElementById("google<?php echo $_GET[googleapps84747474]; ?>");

if (x.style.display === "none") {

}

else

{

setInterval(function() {

$("#minutesappsappsapps<?php echo $_GET['googleapps84747474']; ?>").load('/people/chatupdatesappsapps84747474.php?between1=<?php echo "$google84744474"; ?>&between74=<?php echo "$google84742274"; ?>&googleapps84747474=<?php echo "$_GET[googleapps84747474]"; ?>');

}, 54884);

}

</script>

<link rel="stylesheet" href="textavatar.css">
<script src="jquery.textavatar.js"></script>

<style>

.inline
{
display: inline-block;
margin-top:0px!important;
margin-right:0px!important;
}

</style>

<script>

$('.textavatar').textAvatar();

var name = $('#name').val();

var size = $('#size').val();

$('#test').textAvatar({

name: name,

width: size

});
		
</script>

