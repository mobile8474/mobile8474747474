<div>

<div>

<form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="business" value="<?php echo "mobileappsmobileapps8@gmail.com"; ?>">
<input type="hidden" name="amount" value='<?php echo $_POST['googleappsappsappsapps847474744474']; ?>'>
<input type="hidden" name="return" value='https://<?php echo "$_SERVER[HTTP_HOST]"; ?>/accounts/payments84747474.php?googleappsapps84747474447444744474=<?php echo $_POST['googleappsappsappsapps847474744474']; ?>'>
<input name="item_name" type="hidden" value="Bluecloud ads" />
<input type="submit" value="Make Payment" name="submit" title="" class="paypal_btn" id="google84747474" formtarget="_self" style="background-color:#1565C0;font-size:14.8px;padding:12px;color:#ffffff;border:none;">
</form>

</div>

</div>

<div>

Make payment with paypal

</div>

