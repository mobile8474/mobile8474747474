<?php

$cookievalue84747474 = $_GET['email'];

$passwordname8884 = "googleappsmobileapps888888884444";

$cookievalue84747474 = openssl_encrypt($cookievalue84747474,"AES-128-ECB",$passwordname8884);

$cookievalue84747474 = rawurlencode($cookievalue84747474);



$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];



if(preg_match("/[\W\w]/",$_GET['email']))

{

setcookie("username", "$cookievalue84747474", time()+30*24*60*60 , "/");

setcookie("google84444474", "googleapps84", time()+30*24*60*60 , "/");

?>

<?php

$google84747474747474744474 = $_GET['amountappsapps84747474'];

?>

<script>

setTimeout(function()

{

window.location = '/<?php echo "$google847474747474747474744474"; ?>/panel/overview.php?query=0&today=1';

}, 884);

</script>

<?php

}

if(preg_match("/[\W\w]/",$_GET['logout8474']))

{

setcookie("username", "", time()+30*24*60*60 , "/");

setcookie("google84444474", "", time()+30*24*60*60 , "/");

?>

<script>

setTimeout(function()

{

window.location = '/<?php echo "$google847474747474747474744474"; ?>/';

}, 884);

</script>

<?php

}

?>

