<?php

$servername8474747444444474 = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps84.sh"));
$username8474747444444474 = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps1.sh"));
$password8474747444444474 = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps2.sh"));
$dbname8474747444444474 = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps4.sh"));

$conn = new mysqli($servername8474747444444474, $username8474747444444474, $password8474747444444474, $dbname8474747444444474);

?>

<?php

$googleapps84 = file_get_contents("userregistrations.sh");

?>

<?php

preg_match_all("/<div class='(.*?)' id='(.*?)'>/", $googleapps84, $googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84);
$accountcolor84742274 = $googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84[1];

$accountcolor8474227474747474 = $googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84[4];

?>

<?php

$accountcolor84742274 = implode("<br>",$accountcolor84742274);

$accountcolor84742274 = explode("<br>",$accountcolor84742274);

?>

<?php

foreach($accountcolor84742274 as $googleapps84747474)

{

echo "$googleapps84747474";

?>

<?php

$date84442274444474447444744474 = date("Y-m-d-H-i-s");

$sql84744474447444744474 = "INSERT INTO email (email,date)
VALUES ('$googleapps84747474','$date84442274444474447444744474')";

?>

<?php

$googleapps84747474 = mysqli_query($conn,$sql84744474447444744474);

echo "$googleapps84747474";

?>

<?php

}

?>

<?php

$conn->close();

?>

