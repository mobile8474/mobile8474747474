<?php

error_reporting(0);

?>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../usersearchesapps84747474.sh";

}

else

{

$dataurlappsappsapps84 = "usersearchesapps84747474.sh";

}

?>

<?php

$googleappsappsappsapps8474 = $_GET['usersearchesappsapps84747474'];

$password = "googleappsmobileapps888888884444";

$googleappsappsappsapps8474 = openssl_encrypt($googleappsappsappsapps8474,"AES-128-ECB",$password);

$googleappsappsappsapps8474 = rawurlencode($googleappsappsappsapps8474);

?>

<?php

$googleapps8474 = $_GET['coworkers84747474'];

$googleapps84444474 = rawurlencode($googleapps8474);

?>

<?php

$googleapps84442274 = $_GET['usersearchesapps84747474'];

$googleapps84442274 = rawurlencode($googleapps84442274);

?>

<?php

$googleapps8884 = "<div class='$googleapps84442274' id='na'>" . "\n" . "<div class='$googleappsappsappsapps8474' id='na'>1</div>" . "\n" . "</div>";

?>

<?php

$filedata = "$googleapps8884";
$filedata .= file_get_contents("$dataurlappsappsapps84");
$googleapps888844 = file_put_contents("$dataurlappsappsapps84", $filedata);

echo "<div style='display:none;'>$googleapps888844</div>";

?>

<script>

setTimeout(function()

{

window.location = '<?php echo "/people/settingsapps84747474.php?useremail=$_POST[useremail]"; ?>';

}, 104);

</script>

