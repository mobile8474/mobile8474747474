<?php

error_reporting(0);

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../gosearchimages8884.sh";

}

else

{

$dataurl84 = "../gosearchimages8884/gosearchimages8884.sh";

}

?>

<?php

$googleappsappsappsappsapps8884 = file_get_contents("$dataurl84");

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../coworkersgoogle84747474.sh";

}

else

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../people/coworkersgoogle84747474.sh";

}

?>

<?php

$googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884 = file_get_contents($dataurlurlgoogleappsgooglegoogleappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884, $googleappsappsappsgoogleappsappsgooglegoogleappsapps84);
$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274 = $googleappsappsappsgoogleappsappsgooglegoogleappsapps84[2][0];

?>

<?php

if(preg_match("/business/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "business";

$google8474444444474 = "Update";

$google1 = "Promote";

$google2 = "Mail";

$google4 = "Account";

$googleapps84741274 = "What's up,";

$google84121274747474 = "Coworkers";

$googleappsappsapps84121274747474 = "Coworker";

}

if(preg_match("/apps/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "Getit";

$google8474444444474 = "Post";

$google1 = "Like";

$google2 = "Share";

$google4 = "Profile";

$googleapps84741274 = "What's on your mind,";

$google84121274747474 = "Friends";

$googleappsappsapps84121274747474 = "Friend";

}

if(preg_match("/google/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "google";

$google8474444444474 = "Post";

$google1 = "1+";

$google2 = "Share";

$google4 = "Profile";

$googleapps84741274 = "What's new,";

$google84121274747474 = "Circles";

$googleappsappsapps84121274747474 = "Circle";

}

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{
}

else

{

$googleappsappsapps84744474 = "business";

$google8474444444474 = "Update";

$google1 = "Promote";

$google2 = "Mail";

$google4 = "Account";

$googleapps84741274 = "What's up,";

$google84121274747474 = "Coworkers";

$googleappsappsapps84121274747474 = "Coworker";

}

?>

<style>

@media screen and (max-width: 770px)
{
.googledivappsappsapps84
{
width:100%!important;
}
}

@media screen and (max-width: 770px)
{
.googleappsapps8422444444444474
{
width:100%!important;
}
.googleappsapps8422444444444474
{
box-sizing:border-box;
}
}

.googledivappsappsapps84
{
display:flex;
flex-wrap:wrap;
float:left;
}

.googleappsapps8422444444444474
{
width:358px;
float:left;
overflow:hidden;
margin:0px!important;
margin-bottom:12px!important;
padding-bottom:0px!important;
}

@media screen and (min-width: 770px)
{
.googleappsapps8422444444444474
{
margin-right:12px!important;
}
}

</style>

<div align="center" style="margin:12px;">

<div class="googledivappsappsapps84" style="margin-bottom:18px;margin-top:12px;position:relative;width:796px;">

<div style="position:relative;">

<div style="display:flex;padding:12px;">

<div>

<?php

echo "$google84121274747474";

?>

</div>

</div>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../coworkers84747474.sh";

}

else

{

$dataurlurlgoogleapps84 = "../people/coworkers84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

$googlegoogegoogleappsappsapps84747474 = $_GET['useremail'];

$googlegoogegoogleappsappsapps84747474 = "$googlegoogegoogleappsappsapps84747474";
$passwordname8884 = "googleappsmobileapps888888884444";

$googlegoogegoogleappsappsapps84747474 = openssl_encrypt($googlegoogegoogleappsappsapps84747474,"AES-128-ECB",$passwordname8884);

$googlegoogegoogleappsappsapps84747474 = rawurlencode($googlegoogegoogleappsappsapps84747474);

?>

<?php

preg_match_all("/<div class='$googlegoogegoogleappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[2];

$accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[2][0];

$accountcolorappsappsappsappsapps84742274 = array_unique($accountcolorappsappsappsappsapps84742274);

$accountcolorappsappsappsappsapps84742274 = array_filter($accountcolorappsappsappsappsapps84742274);

$accountcolorappsappsappsappsapps84742274 = implode("<br>",$accountcolorappsappsappsappsapps84742274);

$accountcolorappsappsappsappsapps84742274 = explode("<br>",$accountcolorappsappsappsappsapps84742274);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../userregistrations.sh";

}

else

{

$dataurl8884 = "../register/userregistrations.sh";

}

?>

<?php

$file84 = file_get_contents("$dataurl8884");

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$googleappsgooglegooglegooglegoogleappsappsapps8884 = "../gosearchimages8884.sh";

}

else

{

$googleappsgooglegooglegooglegoogleappsappsapps8884 = "../gosearchimages8884/gosearchimages8884.sh";

}

?>

<?php

$googleappsgooglegooglegooglegoogleappsappsapps8884 = file_get_contents($googleappsgooglegooglegooglegoogleappsappsapps8884);

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgooglegoogleappsappsappsgoogleapps84 = "../accountcolor8884.sh";

}

else

{

$dataurlurlgooglegoogleappsappsappsgoogleapps84 = "../register/accountcolor8884.sh";

}

?>

<?php

$googleappsgooglegoogleappsappsappsappsapps8884 = file_get_contents($dataurlurlgooglegoogleappsappsappsgoogleapps84);

?>

<?php

$googleappsappsappsappsappsapps84747474444474 = array();

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274"))

{

?>

<?php

$google84444474447474747474747474 = "0";

?>

<?php

$googlegoogegoogleappsappsapps84747474 = $_GET['useremail'];

$googlegoogegoogleappsappsapps84747474 = "$googlegoogegoogleappsappsapps84747474";
$passwordname8884 = "googleappsmobileapps888888884444";

$googlegoogegoogleappsappsapps84747474 = openssl_encrypt($googlegoogegoogleappsappsapps84747474,"AES-128-ECB",$passwordname8884);

$googlegoogegoogleappsappsapps84747474 = rawurlencode($googlegoogegoogleappsappsapps84747474);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps841 = "../firstnameapps84747474.sh";

}

else

{

$dataurluserapps841 = "../people/firstnameapps84747474.sh";

}

?>

<?php

$googleappsuserapps8884741 = file_get_contents($dataurluserapps841);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps842 = "../lastnameapps84747474.sh";

}

else

{

$dataurluserapps842 = "../people/lastnameapps84747474.sh";

}

?>

<?php

$googleappsuserapps8884742 = file_get_contents($dataurluserapps842);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps848 = "../usernameapps84747474.sh";

}

else

{

$dataurluserapps848 = "../people/usernameapps84747474.sh";

}

?>

<?php

$googleappsuserapps8884748 = file_get_contents($dataurluserapps848);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsappsappsappsappsappsapps841 = "../googleappsapps84747474.sh";

}

else

{

$dataurluserappsappsappsappsappsappsapps841 = "../people/googleappsapps84747474.sh";

}

?>

<?php

$googleappsuserappsappsappsappsappsapps8884741 = file_get_contents($dataurluserappsappsappsappsappsappsapps841);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps888474841 = "../firstnameapps84747474.sh";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps888474841 = "../people/firstnameapps84747474.sh";

}

?>

<?php

$googleappsuserappsgoogleappsappsapps8884741 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsapps888474841);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps888474842 = "../lastnameapps84747474.sh";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps888474842 = "../people/lastnameapps84747474.sh";

}

?>

<?php

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps888474842 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps888474842);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484848 = "../usernameapps84747474.sh";

}

else

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484848 = "../people/usernameapps84747474.sh";

}

?>

<?php

$googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps888474848884748 = file_get_contents($dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484848);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps8884748488 = "../workapps84747474.sh";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps8884748488 = "../people/workapps84747474.sh";

}

?>

<?php

$googleappsuserappsgoogleappsappsappsappsapps88847488 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsapps8884748488);

?>

<?php

foreach($accountcolorappsappsappsappsapps84742274 as $googleappsappsappsapps84747474)

{

?>

<?php

if(preg_match("/$googlegoogegoogleappsappsapps84747474/","$googleappsappsappsapps84747474"))

{
}

else

{

?>

<?php

$google84444474447474747474747474++;

?>

<div class="googleappsapps8422444444444474" style="position:relative;padding:12px;margin:12px;background-color:#ffffff;box-shadow:0 4px 44px rgba(0,0,0,1);">

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $file84, $googleapps84);
$name = $googleapps84[2][0];

$nameapps84747474 = $googleapps84[3][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

$nameapps84747474 = rawurldecode($nameapps84747474);

$nameapps84747474 = openssl_decrypt($nameapps84747474,"AES-128-ECB",$password);

$nameappsgoogleappsapps84747474 = rawurldecode($googleappsappsappsapps84747474);

$nameappsgoogleappsapps84747474 = openssl_decrypt($nameappsgoogleappsapps84747474,"AES-128-ECB",$password);

?>

<?php

$accountcolorappsappsappsappsappsappsapps84742274 = "$googleappsappsappsapps84747474";

$password="googleappsmobileapps888888884444";

$accountcolorappsappsappsappsappsappsapps84742274 = rawurldecode($accountcolorappsappsappsappsappsappsapps84742274);

$accountcolorappsappsappsappsappsappsapps84742274 = openssl_decrypt($accountcolorappsappsappsappsappsappsapps84742274,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegooglegooglegoogleappsappsapps8884, $googleappsappsappsappsappsappsapps84);
$gosearchimagesgoogleappsappsappsappsappsappsapps84747474 = $googleappsappsappsappsappsappsapps84[2][0];

?>

<?php

if(preg_match("/[\W\w]/",$gosearchimagesgoogleappsappsappsappsappsappsapps84747474))

{

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleappsappsappsappsapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps84742274 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleappsappsappsappsapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps847474 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorgoogleappsappsapps847474"))

{

$accountcolor1 = "$accountcolorgoogleappsappsapps847474";

$accountcolor2 = "$accountcolorgoogleappsappsapps847474";

$accountcolor4 = "$accountcolorgoogleappsappsapps847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<div align="left">

<div id="div84747474" style="left:12px;top:24px;" align="left"><img src="<?php echo $gosearchimagesgoogleappsappsappsappsappsappsapps84747474; ?>" width="34" height="34" style="border-color:<?php echo "$accountcolor4"; ?>;border-width:2px;box-shadow:0 2px 4px rgba(0,0,0,0.1);width:110px;box-shadow:rgba(0, 0, 0, 0.2) 0px 2px 8px;height:110px;font-size:13.6px;margin-left:-12px;margin-top:-12px;" onclick='myFunctiongoogleappsappsappsappsapps()'></img></div>

</div>

<?php

}

else

{

?>

<style>

.googleapps84742274
{
display:inline-block!important;
}

</style>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/", $fileappsappsappsapps84, $googleappsappsappsappsapps84747474);
$nameappsappsappsapps84747474 = $googleappsappsappsappsapps84747474[2][0];

$password="googleappsmobileapps888888884444";

$nameappsappsappsapps84747474 = rawurldecode($nameappsappsappsapps84747474);

$nameappsappsappsapps84747474 = openssl_decrypt($nameappsappsappsapps84747474,"AES-128-ECB",$password);

$nameappsappsappsappsappsapps8884 = "$nameappsappsappsapps84747474";

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsappsappsapps84);
$accountcolorappsappsappsapps84742274 = $googleappsappsappsappsapps84[3][0];

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsappsappsapps84);
$accountcolorappsappsappsapps84747474 = $googleappsappsappsappsapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorappsappsappsapps84747474"))

{

$accountcolor1 = "$accountcolorappsappsappsapps84747474";

$accountcolor2 = "$accountcolorappsappsappsapps84747474";

$accountcolor4 = "$accountcolorappsappsappsapps84747474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps8884741, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps8884742, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps8884748, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleappsappsappsappsapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps84742274 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleappsappsappsappsapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps847474 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorgoogleappsappsapps847474"))

{

$accountcolor1 = "$accountcolorgoogleappsappsapps847474";

$accountcolor2 = "$accountcolorgoogleappsappsapps847474";

$accountcolor4 = "$accountcolorgoogleappsappsapps847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsappsappsapps8884741, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/(^Male$|^male$)/","$gosearchimages84747674"))

{

?>

<div align="left">

<div>

<div class='inline'>
<img class='textavatar' src="/gosearchimages8884/googleapps84.jpg" style='width:34px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;width:110px;height:110px;font-size:13.6px;margin-left:-12px;margin-top:-12px;' data-name='<?php echo "$googleappsappsapps844444444474"; ?>'></img>
</div>

</div>

</div>

<?php

}

else

{

?>

<div align="left">

<div>

<div class='inline'>
<img class='textavatar' src="/gosearchimages8884/googleapps84747474.jpeg" style='width:34px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;width:110px;height:110px;font-size:13.6px;margin-left:-12px;margin-top:-12px;' data-name='<?php echo "$googleappsappsapps844444444474"; ?>'></img>
</div>

</div>

</div>

<?php

}

?>

<?php

}

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsgoogleappsappsapps8884741, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps888474842, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps888474848884748, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674 $gosearchimagesappsappsappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsgoogleappsappsappsappsapps88847488, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../educationapps84747474.sh";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../people/educationapps84747474.sh";

}

?>

<?php

$googleappsuserappsgoogleappsappsappsgoogleapps888474 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsgoogleappsappsappsgoogleapps888474, $googleapps84);
$gosearchimagesappsappsappsappsappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsappsappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsappsappsappsappsapps84747674);

$gosearchimagesappsappsappsappsappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsappsappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../countryapps84747474.sh";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../people/countryapps84747474.sh";

}

?>

<?php

$googleappsuserappsgoogleappsappsappsgoogleapps888474 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsgoogleappsappsappsgoogleapps888474, $googleapps84);
$gosearchimagesappsappsappsappsappsappsappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsappsappsappsappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsappsappsappsappsappsappsapps84747674);

$gosearchimagesappsappsappsappsappsappsappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsappsappsappsappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<div style="display:flex;" onclick="window.open('/people/usermail.php?useremail=<?php echo "$nameappsgoogleappsapps84747474"; ?>','_self');">

<div style="position:absolute;width:196px;left:134px;top:12px;text-align:left;">

<?php

echo "$googleappsappsapps844444444474";

?>

</div>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../coworkers84747474.sh";

}

else

{

$dataurlurlgoogleapps84 = "../people/coworkers84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

$googleapps84 = $_GET['useremail'];

$password="googleappsmobileapps888888884444";

$nameappsapps84 = openssl_encrypt($googleapps84,"AES-128-ECB",$password);

$nameappsapps84 = rawurlencode($nameappsapps84);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[2];

$accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274 = array_unique($accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274);

$accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274 = count($accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274);

?>

<div style="position:absolute;top:44px;left:134px;display:flex;color:#444444;font-size:12.8px;">

<div>

<?php

echo "$accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274";

?>

</div>

<div style="margin-left:4px;">

<?php

echo "$google84121274747474";

?>

</div>

</div>

</div>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleappsgooglegooglegooglegoogle84 = "../coworkers84747474.sh";

}

else

{

$dataurlurlgoogleappsgooglegooglegooglegoogle84 = "../people/coworkers84747474.sh";

}

?>

<?php

$googleappsgooglegoogleappsgooglegooglegooglegoogle8884 = file_get_contents($dataurlurlgoogleappsgooglegooglegooglegoogle84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsgooglegoogleappsgooglegooglegooglegoogle8884, $googleappsappsappsgoogleappsappsgooglegooglegooglegoogle84);
$accountcolorappsappsappsappsappsgoogleappsappsappsappsgooglegooglegooglegoogle84742274 = $googleappsappsappsgoogleappsappsgooglegooglegooglegoogle84[1][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsappsgoogleappsappsappsappsgooglegooglegooglegoogle84742274"))

{

?>

<div class="googleappsappsappsappsgoogleapps<?php echo $google84444474447474747474747474; ?> googleapps84444474747444744474" style="padding:8px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:inline-block;color:#ffffff;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;color:<?php echo "$accountcolor1"; ?>;position:absolute;bottom:-12px;" onclick="">

<?php echo "$google84121274747474"; ?>

</div>

<?php

}

else

{

?>

<script>

function googleappsappsappsappsgooglegoogle<?php echo $google84444474447474747474747474; ?>() {

$(document).ready(function() {

$.ajax({
    data: 'coworkers84747474=<?php echo "$googleappsappsappsapps84747474"; ?>&coworkersnameapps84747474=<?php echo $_COOKIE[username]; ?>',
    url: '/people/coworkers84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

});

}

</script>

<div class="googleappsappsappsappsgoogleapps<?php echo $google84444474447474747474747474; ?> googleapps84444474747444744474" style="padding:8px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:inline-block;color:#ffffff;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;color:<?php echo "$accountcolor1"; ?>;position:absolute;bottom:-12px;left:134px!important;" onclick="$('#google84742274').show();googleappsappsappsappsgooglegoogle<?php echo $google84444474447474747474747474; ?>();">

Add

</div>

<?php

}

?>

<div align="left" style="margin-left:46px;display:flex;">

</div>

<div align="left" style="margin-left:46px;display:flex;">

</div>

</div>

<?php

$passwordname8884 = "googleappsmobileapps888888884444";

$googlegoogegoogleappsappsappsappsgooglegoogleapps84747474 = openssl_encrypt($nameappsgoogleappsapps84747474,"AES-128-ECB",$passwordname8884);

$googlegoogegoogleappsappsappsappsgooglegoogleapps84747474 = rawurlencode($googlegoogegoogleappsappsappsappsgooglegoogleapps84747474);

?>

<?php

$googleappsappsappsappsappsapps84747474444474[] = "$googlegoogegoogleappsappsappsappsgooglegoogleapps84747474";

?>

<?php

}

?>

<?php

}

?>

<?php

}

else

{

?>

<?php

$googlegoogegoogleappsappsapps84747474 = $_GET['useremail'];

$googlegoogegoogleappsappsapps84747474 = "$googlegoogegoogleappsappsapps84747474";
$passwordname8884 = "googleappsmobileapps888888884444";

$googlegoogegoogleappsappsapps84747474 = openssl_encrypt($googlegoogegoogleappsappsapps84747474,"AES-128-ECB",$passwordname8884);

$googlegoogegoogleappsappsapps84747474 = rawurlencode($googlegoogegoogleappsappsapps84747474);

?>

<?php

preg_match_all("/<div class='$googlegoogegoogleappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $file84, $googleapps84);
$name = $googleapps84[2][0];

$nameapps84747474 = $googleapps84[3][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

$nameapps84747474 = rawurldecode($nameapps84747474);

$nameapps84747474 = openssl_decrypt($nameapps84747474,"AES-128-ECB",$password);

$nameappsgoogleappsapps84747474 = rawurldecode($googleappsappsappsapps84747474);

$nameappsgoogleappsapps84747474 = openssl_decrypt($nameappsgoogleappsapps84747474,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../firstnameapps84747474.sh";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../people/firstnameapps84747474.sh";

}

?>

<?php

$googleappsuserappsgoogleappsappsapps888474 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = "../lastnameapps84747474.sh";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = "../people/lastnameapps84747474.sh";

}

?>

<?php

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484 = "../usernameapps84747474.sh";

}

else

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484 = "../people/usernameapps84747474.sh";

}

?>

<?php

$googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474 = file_get_contents($dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484);

?>

<?php

preg_match_all("/<div class='$googlegoogegoogleappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsgoogleappsappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$googlegoogegoogleappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$googlegoogegoogleappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674 $gosearchimagesappsappsappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<div style="display:flex;padding:12px;">

<div style="margin-left:4px;">

<?php

echo "$googleappsappsapps844444444474" . "<divappsapps84 style='margin-left:4px;'>has no $google84121274747474</divappsapps84>";

?>

</div>

</div>

<?php

}

?>

</div>

</div>

</div>

<link rel="stylesheet" href="textavatar.css">
<script src="jquery.textavatar.js"></script>

<style>

.inline
{
display: inline-block;
margin-top:0px!important;
margin-right:0px!important;
}

</style>

<script>

$('.textavatar').textAvatar();

var name = $('#name').val();

var size = $('#size').val();

$('#test').textAvatar({

name: name,

width: size

});
		
</script>

<?php

$googlegoogegoogleappsappsapps84747474 = $_GET['useremail'];

$googlegoogegoogleappsappsapps84747474 = "$googlegoogegoogleappsappsapps84747474";
$passwordname8884 = "googleappsmobileapps888888884444";

$googlegoogegoogleappsappsapps84747474 = openssl_encrypt($googlegoogegoogleappsappsapps84747474,"AES-128-ECB",$passwordname8884);

$googlegoogegoogleappsappsapps84747474 = rawurlencode($googlegoogegoogleappsappsapps84747474);

?>

<?php

if(preg_match("/$googlegoogegoogleappsappsapps84747474/",$_COOKIE['username']))

{

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../gosearchimages8884.sh";

}

else

{

$dataurl84 = "../gosearchimages8884/gosearchimages8884.sh";

}

?>

<?php

$googleappsappsappsappsapps8884 = file_get_contents("$dataurl84");

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../coworkersgoogle84747474.sh";

}

else

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../people/coworkersgoogle84747474.sh";

}

?>

<?php

$googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884 = file_get_contents($dataurlurlgoogleappsgooglegoogleappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884, $googleappsappsappsgoogleappsappsgooglegoogleappsapps84);
$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274 = $googleappsappsappsgoogleappsappsgooglegoogleappsapps84[2][0];

?>

<?php

if(preg_match("/business/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "business";

$google8474444444474 = "Update";

$google1 = "Promote";

$google2 = "Mail";

$google4 = "Account";

$googleapps84741274 = "What's up,";

$google84121274747474 = "Coworkers";

}

if(preg_match("/apps/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "Getit";

$google8474444444474 = "Post";

$google1 = "Like";

$google2 = "Share";

$google4 = "Profile";

$googleapps84741274 = "What's on your mind,";

$google84121274747474 = "Friends";

}

if(preg_match("/google/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "google";

$google8474444444474 = "Post";

$google1 = "1+";

$google2 = "Share";

$google4 = "Profile";

$googleapps84741274 = "What's new,";

$google84121274747474 = "Circles";

}

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{
}

else

{

$googleappsappsapps84744474 = "business";

$google8474444444474 = "Update";

$google1 = "Promote";

$google2 = "Mail";

$google4 = "Account";

$googleapps84741274 = "What's up,";

$google84121274747474 = "Coworkers";

}

?>

<style>

@media screen and (max-width: 770px)
{
.googledivappsappsapps84
{
width:100%!important;
}
}

</style>

<div align="center" style="margin:12px;">

<div class="googledivappsappsapps84" style="margin-bottom:18px;margin-top:12px;position:relative;width:796px;">

<div style="position:relative;">

<div style="display:flex;padding:12px;">

<div>

<?php

echo "$googleappsappsapps84121274747474";

?>

</div>

<div style="margin-left:4px;">

suggestions

</div>

</div>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../coworkers84747474.sh";

}

else

{

$dataurlurlgoogleapps84 = "../people/coworkers84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

$googlegoogegoogleappsappsapps84747474 = $_GET['useremail'];

$googlegoogegoogleappsappsapps84747474 = "$googlegoogegoogleappsappsapps84747474";
$passwordname8884 = "googleappsmobileapps888888884444";

$googlegoogegoogleappsappsapps84747474 = openssl_encrypt($googlegoogegoogleappsappsapps84747474,"AES-128-ECB",$passwordname8884);

$googlegoogegoogleappsappsapps84747474 = rawurlencode($googlegoogegoogleappsappsapps84747474);

?>

<?php

$googleappsappsappsappsappsapps84747474444474444474 = array_unique($googleappsappsappsappsappsapps84747474444474);

$googleappsappsappsappsappsapps84747474444474444474 = implode("<br>",$googleappsappsappsappsappsapps84747474444474444474);

$googleappsappsappsappsappsapps84747474444474444474 = explode("<br>",$googleappsappsappsappsappsapps84747474444474444474);

?>

<?php

$googleappsapps8474 = array();

?>

<?php

foreach($googleappsappsappsappsappsapps84747474444474444474 as $googleapps84444444444474)

{

?>

<?php

preg_match_all("/<div class='$googleapps84444444444474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[2];

$accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274 = implode("<br>",$accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274);

$googleappsapps8474[] = $accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274;

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../userregistrations.sh";

}

else

{

$dataurl8884 = "../register/userregistrations.sh";

}

?>

<?php

$file84 = file_get_contents("$dataurl8884");

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$googleappsgooglegooglegooglegoogleappsappsapps8884 = "../gosearchimages8884.sh";

}

else

{

$googleappsgooglegooglegooglegoogleappsappsapps8884 = "../gosearchimages8884/gosearchimages8884.sh";

}

?>

<?php

$googleappsgooglegooglegooglegoogleappsappsapps8884 = file_get_contents($googleappsgooglegooglegooglegoogleappsappsapps8884);

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgooglegoogleappsappsappsgoogleapps84 = "../accountcolor8884.sh";

}

else

{

$dataurlurlgooglegoogleappsappsappsgoogleapps84 = "../register/accountcolor8884.sh";

}

?>

<?php

$googleappsgooglegoogleappsappsappsappsapps8884 = file_get_contents($dataurlurlgooglegoogleappsappsappsgoogleapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../firstnameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/firstnameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../lastnameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/lastnameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../usernameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/usernameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$googleappsappsappsappsappsapps8474747444447444447444447474 = array_unique($googleappsapps8474);

$googleappsappsappsappsappsapps8474747444447444447444447474 = implode("<br>",$googleappsappsappsappsappsapps8474747444447444447444447474);

$googleappsappsappsappsappsapps8474747444447444447444447474 = explode("<br>",$googleappsappsappsappsappsapps8474747444447444447444447474);

$google74847444 = array();

foreach($googleappsappsappsappsappsapps8474747444447444447444447474 as $google84744444444474)

{

$google74847444[] = "$google84744444444474";

}

?>

<?php

$accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274 = "googleapps84";

$accountcolorappsappsappsappsapps84742274 = array_unique($google74847444);

$accountcolorappsappsappsappsapps84742274 = array_filter($accountcolorappsappsappsappsapps84742274);

$accountcolorappsappsappsappsapps84742274 = implode("<br>",$accountcolorappsappsappsappsapps84742274);

$accountcolorappsappsappsappsapps84742274 = explode("<br>",$accountcolorappsappsappsappsapps84742274);

?>

<?php

$googleappsappsappsappsappsapps84747474444474 = array();

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274"))

{

?>

<?php

$google844444744474747474747474744474 = "0";

?>

<?php

$googlegoogegoogleappsappsapps84747474 = $_GET['useremail'];

$googlegoogegoogleappsappsapps84747474 = "$googlegoogegoogleappsappsapps84747474";
$passwordname8884 = "googleappsmobileapps888888884444";

$googlegoogegoogleappsappsapps84747474 = openssl_encrypt($googlegoogegoogleappsappsapps84747474,"AES-128-ECB",$passwordname8884);

$googlegoogegoogleappsappsapps84747474 = rawurlencode($googlegoogegoogleappsappsapps84747474);

?>

<?php

foreach($accountcolorappsappsappsappsapps84742274 as $googleappsappsappsapps84747474)

{

?>

<?php

$google844444744474747474747474744474++;

?>

<?php

if(preg_match("/$googlegoogegoogleappsappsapps84747474/","$googleappsappsappsapps84747474"))

{
}

else

{

?>

<?php

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);

$googleappsappsappsgoogleappsappsappsappsappsapps84 = $googleappsappsappsgoogleappsapps84[1][0];

?>

<?php

if(preg_match("/$_COOKIE[username]/","$googleappsappsappsgoogleappsappsappsappsappsapps84"))

{
}

else

{

?>

<div class="googleappsapps8422444444444474" style="position:relative;padding:12px;margin:12px;background-color:#ffffff;box-shadow:0 4px 44px rgba(0,0,0,1);">

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $file84, $googleapps84);
$name = $googleapps84[2][0];

$nameapps84747474 = $googleapps84[3][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

$nameapps84747474 = rawurldecode($nameapps84747474);

$nameapps84747474 = openssl_decrypt($nameapps84747474,"AES-128-ECB",$password);

$nameappsgoogleappsapps84747474 = rawurldecode($googleappsappsappsapps84747474);

$nameappsgoogleappsapps84747474 = openssl_decrypt($nameappsgoogleappsapps84747474,"AES-128-ECB",$password);

?>

<?php

$accountcolorappsappsappsappsappsappsapps84742274 = "$googleappsappsappsapps84747474";

$password="googleappsmobileapps888888884444";

$accountcolorappsappsappsappsappsappsapps84742274 = rawurldecode($accountcolorappsappsappsappsappsappsapps84742274);

$accountcolorappsappsappsappsappsappsapps84742274 = openssl_decrypt($accountcolorappsappsappsappsappsappsapps84742274,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegooglegooglegoogleappsappsapps8884, $googleappsappsappsappsappsappsapps84);
$gosearchimagesgoogleappsappsappsappsappsappsapps84747474 = $googleappsappsappsappsappsappsapps84[2][0];

?>

<?php

if(preg_match("/[\W\w]/",$gosearchimagesgoogleappsappsappsappsappsappsapps84747474))

{

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleappsappsappsappsapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps84742274 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleappsappsappsappsapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps847474 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorgoogleappsappsapps847474"))

{

$accountcolor1 = "$accountcolorgoogleappsappsapps847474";

$accountcolor2 = "$accountcolorgoogleappsappsapps847474";

$accountcolor4 = "$accountcolorgoogleappsappsapps847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<div slign="left">

<div id="div84747474" style="left:12px;top:24px;" align="left"><img src="<?php echo $gosearchimagesgoogleappsappsappsappsappsappsapps84747474; ?>" width="34" height="34" style="border-color:<?php echo "$accountcolor4"; ?>;border-width:2px;box-shadow:0 2px 4px rgba(0,0,0,0.1);width:110px;box-shadow:rgba(0, 0, 0, 0.2) 0px 2px 8px;height:110px;font-size:13.6px;margin-left:-12px;margin-top:-12px;" onclick='myFunctiongoogleappsappsappsappsapps()'></img></div>

</div>

<?php

}

else

{

?>

<style>

.googleapps84742274
{
display:inline-block!important;
}

</style>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/", $fileappsappsappsapps84, $googleappsappsappsappsapps84747474);
$nameappsappsappsapps84747474 = $googleappsappsappsappsapps84747474[2][0];

$password="googleappsmobileapps888888884444";

$nameappsappsappsapps84747474 = rawurldecode($nameappsappsappsapps84747474);

$nameappsappsappsapps84747474 = openssl_decrypt($nameappsappsappsapps84747474,"AES-128-ECB",$password);

$nameappsappsappsappsappsapps8884 = "$nameappsappsappsapps84747474";

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsappsappsapps84);
$accountcolorappsappsappsapps84742274 = $googleappsappsappsappsapps84[3][0];

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsappsappsapps84);
$accountcolorappsappsappsapps84747474 = $googleappsappsappsappsapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorappsappsappsapps84747474"))

{

$accountcolor1 = "$accountcolorappsappsappsapps84747474";

$accountcolor2 = "$accountcolorappsappsappsapps84747474";

$accountcolor4 = "$accountcolorappsappsappsapps84747474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleappsappsappsappsapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps84742274 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleappsappsappsappsapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps847474 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorgoogleappsappsapps847474"))

{

$accountcolor1 = "$accountcolorgoogleappsappsapps847474";

$accountcolor2 = "$accountcolorgoogleappsappsapps847474";

$accountcolor4 = "$accountcolorgoogleappsappsapps847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsappsappsappsappsappsapps84 = "../googleappsapps84747474.sh";

}

else

{

$dataurluserappsappsappsappsappsappsapps84 = "../people/googleappsapps84747474.sh";

}

?>

<?php

$googleappsuserappsappsappsappsappsapps888474 = file_get_contents($dataurluserappsappsappsappsappsappsapps84);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsappsappsapps888474, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/(^Male$|^male$)/","$gosearchimages84747674"))

{

?>

<div align="left">

<div>

<div class='inline'>
<img class='textavatar' src="/gosearchimages8884/googleapps84.jpg" style='width:34px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;width:110px;height:110px;font-size:13.6px;margin-left:-12px;margin-top:-12px;' data-name='<?php echo "$googleappsappsapps844444444474"; ?>'></img>
</div>

</div>

</div>

<?php

}

else

{

?>

<div align="left">

<div>

<div class='inline'>
<img class='textavatar' src="/gosearchimages8884/googleapps84747474.jpeg" style='width:34px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;width:110px;height:110px;font-size:13.6px;margin-left:-12px;margin-top:-12px;' data-name='<?php echo "$googleappsappsapps844444444474"; ?>'></img>
</div>

</div>

</div>

<?php

}

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../firstnameapps84747474.sh";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../people/firstnameapps84747474.sh";

}

?>

<?php

$googleappsuserappsgoogleappsappsapps888474 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = "../lastnameapps84747474.sh";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = "../people/lastnameapps84747474.sh";

}

?>

<?php

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484 = "../usernameapps84747474.sh";

}

else

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484 = "../people/usernameapps84747474.sh";

}

?>

<?php

$googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474 = file_get_contents($dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsgoogleappsappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674 $gosearchimagesappsappsappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../workapps84747474.sh";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../people/workapps84747474.sh";

}

?>

<?php

$googleappsuserappsgoogleappsappsappsappsapps888474 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsgoogleappsappsappsappsapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../educationapps84747474.sh";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../people/educationapps84747474.sh";

}

?>

<?php

$googleappsuserappsgoogleappsappsappsgoogleapps888474 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsgoogleappsappsappsgoogleapps888474, $googleapps84);
$gosearchimagesappsappsappsappsappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsappsappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsappsappsappsappsapps84747674);

$gosearchimagesappsappsappsappsappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsappsappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../countryapps84747474.sh";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../people/countryapps84747474.sh";

}

?>

<?php

$googleappsuserappsgoogleappsappsappsgoogleapps888474 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsgoogleappsappsappsgoogleapps888474, $googleapps84);
$gosearchimagesappsappsappsappsappsappsappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsappsappsappsappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsappsappsappsappsappsappsapps84747674);

$gosearchimagesappsappsappsappsappsappsappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsappsappsappsappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<div style="display:flex;" onclick="window.open('/people/usermail.php?useremail=<?php echo "$nameappsgoogleappsapps84747474"; ?>','_self');">

<div style="position:absolute;width:196px;left:134px;top:12px;text-align:left;">

<?php

echo "$googleappsappsapps844444444474";

?>

</div>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../coworkers84747474.sh";

}

else

{

$dataurlurlgoogleapps84 = "../people/coworkers84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

$googleapps84 = $_GET['useremail'];

$password="googleappsmobileapps888888884444";

$nameappsapps84 = openssl_encrypt($googleapps84,"AES-128-ECB",$password);

$nameappsapps84 = rawurlencode($nameappsapps84);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[2];

$accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274 = array_unique($accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274);

$accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274 = count($accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274);

?>

<div style="position:absolute;top:44px;left:134px;display:flex;color:#444444;font-size:12.8px;">

<div>

<?php

echo "$accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274";

?>

</div>

<div style="margin-left:4px;">

<?php

echo "$google84121274747474";

?>

</div>

</div>

</div>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleappsgooglegooglegooglegoogle84 = "../coworkers84747474.sh";

}

else

{

$dataurlurlgoogleappsgooglegooglegooglegoogle84 = "../people/coworkers84747474.sh";

}

?>

<?php

$googleappsgooglegoogleappsgooglegooglegooglegoogle8884 = file_get_contents($dataurlurlgoogleappsgooglegooglegooglegoogle84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsgooglegoogleappsgooglegooglegooglegoogle8884, $googleappsappsappsgoogleappsappsgooglegooglegooglegoogle84);
$accountcolorappsappsappsappsappsgoogleappsappsappsappsgooglegooglegooglegoogle84742274 = $googleappsappsappsgoogleappsappsgooglegooglegooglegoogle84[1][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsappsgoogleappsappsappsappsgooglegooglegooglegoogle84742274"))

{

?>

<div class="googleapps84444474747444744474" style="padding:8px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:inline-block;color:#ffffff;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;color:<?php echo "$accountcolor1"; ?>;position:absolute;bottom:-12px;" onclick="">

<?php echo "$google84121274747474"; ?>

</div>

<?php

}

else

{

?>

<script>

function googleappsappsappsappsgooglegoogle<?php echo $google844444744474747474747474744474; ?>() {

$(document).ready(function() {

$.ajax({
    data: 'coworkers84747474=<?php echo "$googleappsappsappsapps84747474"; ?>&coworkersnameapps84747474=<?php echo $_COOKIE[username]; ?>',
    url: '/people/coworkers84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

});

}

</script>

<div class="googleappsappsappsappsgooglegoogle<?php echo $google844444744474747474747474744474; ?> googleapps84444474747444744474" style="padding:8px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:inline-block;color:#ffffff;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;color:<?php echo "$accountcolor1"; ?>;position:absolute;bottom:-12px;left:134px!important;" onclick="$('#google84742274').show();googleappsappsappsappsgooglegoogle<?php echo $google844444744474747474747474744474; ?>();">

Add

</div>

<?php

}

?>

</div>

<?php

}

?>

<?php

}

?>

<?php

}

?>

<?php

}

else

{

?>

<?php

$googlegoogegoogleappsappsapps84747474 = $_GET['useremail'];

$googlegoogegoogleappsappsapps84747474 = "$googlegoogegoogleappsappsapps84747474";
$passwordname8884 = "googleappsmobileapps888888884444";

$googlegoogegoogleappsappsapps84747474 = openssl_encrypt($googlegoogegoogleappsappsapps84747474,"AES-128-ECB",$passwordname8884);

$googlegoogegoogleappsappsapps84747474 = rawurlencode($googlegoogegoogleappsappsapps84747474);

?>

<?php

preg_match_all("/<div class='$googlegoogegoogleappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $file84, $googleapps84);
$name = $googleapps84[2][0];

$nameapps84747474 = $googleapps84[3][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

$nameapps84747474 = rawurldecode($nameapps84747474);

$nameapps84747474 = openssl_decrypt($nameapps84747474,"AES-128-ECB",$password);

$nameappsgoogleappsapps84747474 = rawurldecode($googleappsappsappsapps84747474);

$nameappsgoogleappsapps84747474 = openssl_decrypt($nameappsgoogleappsapps84747474,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../firstnameapps84747474.sh";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484 = "../people/firstnameapps84747474.sh";

}

?>

<?php

$googleappsuserappsgoogleappsappsapps888474 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsapps88847484);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = "../lastnameapps84747474.sh";

}

else

{

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = "../people/lastnameapps84747474.sh";

}

?>

<?php

$dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484 = file_get_contents($dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484 = "../usernameapps84747474.sh";

}

else

{

$dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484 = "../people/usernameapps84747474.sh";

}

?>

<?php

$googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474 = file_get_contents($dataurluserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps8884748484);

?>

<?php

preg_match_all("/<div class='$googlegoogegoogleappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsgoogleappsappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$googlegoogegoogleappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $dataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$googlegoogegoogleappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsdataurluserappsgoogleappsuserappsgoogleappsappsappsappsapps88847484888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674 $gosearchimagesappsappsappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<div style="display:flex;padding:12px;">

<div style="margin-left:4px;">

<?php

echo "$googleappsappsapps844444444474" . "<divappsapps84 style='margin-left:4px;'>has no $google84121274747474</divappsapps84>";

?>

</div>

</div>

<?php

}

?>

</div>

</div>

</div>

<link rel="stylesheet" href="textavatar.css">
<script src="jquery.textavatar.js"></script>

<style>

.inline
{
display: inline-block;
margin-top:0px!important;
margin-right:0px!important;
}

</style>

<script>

$('.textavatar').textAvatar();

var name = $('#name').val();

var size = $('#size').val();

$('#test').textAvatar({

name: name,

width: size

});
		
</script>

<?php

}

?>

