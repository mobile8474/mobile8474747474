<?php

error_reporting(0);

?>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

if(preg_match("/appspot/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsappsappsapps84 = "../coworkersappsappsappsgoogleappsgoogleapps847474742244.sh";

}

else

{

$dataurlappsappsappsappsapps84 = "coworkersappsappsappsgoogleappsgoogleapps847474742244.sh";

}

?>

<?php

$googleappsappsapps8884 = "<div class='$_COOKIE[username]'>" . "\n" . "<div class='$_GET[userappsappsappsapps84747474]'>1</div>" . "\n" . "</div>";

?>

<?php

$filedata = "$googleappsappsapps8884";
$filedata .= file_get_contents("$dataurlappsappsappsappsapps84");
$googleapps888844 = file_put_contents("$dataurlappsappsappsappsapps84", $filedata);

echo "<div style='display:none;'>$googleapps888844</div>";

?>

