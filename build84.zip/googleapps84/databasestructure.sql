-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 12, 2018 at 09:18 PM
-- Server version: 5.7.22
-- PHP Version: 7.0.30-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `3ye5uW6k4M`
--

-- --------------------------------------------------------

--
-- Table structure for table `aboutapps84747474`
--

CREATE TABLE `aboutapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `about` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `accountcolor84747474`
--

CREATE TABLE `accountcolor84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `accountcolor84747474` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adsbudgetapps84747474`
--

CREATE TABLE `adsbudgetapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `budget` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `userip` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adsclicksapps84747474`
--

CREATE TABLE `adsclicksapps84747474` (
  `adsusername` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `adsusername84747474` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `adsurl` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adsclicksapps844444444474`
--

CREATE TABLE `adsclicksapps844444444474` (
  `adsusername` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `adsusername84747474` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `adsurl` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `userip` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adsclicksapps847474744474`
--

CREATE TABLE `adsclicksapps847474744474` (
  `adsusername` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `adsusername84747474` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adsgoogleapps84747474`
--

CREATE TABLE `adsgoogleapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `userip` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adsgoogleapps847474744474`
--

CREATE TABLE `adsgoogleapps847474744474` (
  `email` varchar(884) NOT NULL,
  `date` varchar(884) NOT NULL,
  `title` varchar(884) NOT NULL,
  `description` varchar(884) NOT NULL,
  `url` varchar(884) NOT NULL,
  `active` varchar(884) NOT NULL,
  `userip` varchar(884) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adsgoogleappsapps84747474`
--

CREATE TABLE `adsgoogleappsapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `description` longblob NOT NULL,
  `url` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ageapps84747474`
--

CREATE TABLE `ageapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `age` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `analyticschartsapps84`
--

CREATE TABLE `analyticschartsapps84` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `userip` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `browser` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `referer` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `user` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `page` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `keywords` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `analyticsgoogle8474`
--

CREATE TABLE `analyticsgoogle8474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `referer` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cityapps84747474`
--

CREATE TABLE `cityapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `commentapps84747474`
--

CREATE TABLE `commentapps84747474` (
  `email` varchar(884) NOT NULL,
  `ID` int(11) NOT NULL,
  `date` varchar(884) NOT NULL,
  `comments` varchar(884) NOT NULL,
  `commentsapps84747474` varchar(884) NOT NULL,
  `userip` varchar(884) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `countryapps84747474`
--

CREATE TABLE `countryapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `coworkersapps847474744474`
--

CREATE TABLE `coworkersapps847474744474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `coworkers` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `userip` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cpcapps84747474`
--

CREATE TABLE `cpcapps84747474` (
  `email` varchar(884) NOT NULL,
  `ID` int(11) NOT NULL,
  `date` varchar(884) NOT NULL,
  `cpc` varchar(884) NOT NULL,
  `url` varchar(884) NOT NULL,
  `userip` varchar(884) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `educationapps84747474`
--

CREATE TABLE `educationapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `education` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `email`
--

CREATE TABLE `email` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `genderapps84747474`
--

CREATE TABLE `genderapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `googleappsappsappsapps84747474`
--

CREATE TABLE `googleappsappsappsapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `google84747474` longblob NOT NULL,
  `userip` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `images84747474`
--

CREATE TABLE `images84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `images` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `images84747474` longblob NOT NULL,
  `userip` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `imagesapps84747474`
--

CREATE TABLE `imagesapps84747474` (
  `imagesapps84747474` longblob NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `imagesappsapps84747474`
--

CREATE TABLE `imagesappsapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `images` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `imagesapps84747474` longblob NOT NULL,
  `userip` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `imagesappsgoogle84747474`
--

CREATE TABLE `imagesappsgoogle84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `imagesapps84747474` longblob NOT NULL,
  `userip` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mailapps84747474`
--

CREATE TABLE `mailapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `toemail` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `emailtext` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `userip` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mailappsapps847474744474`
--

CREATE TABLE `mailappsapps847474744474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `toemail` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `emailtext` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mailappsappsapps84747474`
--

CREATE TABLE `mailappsappsapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `frommail` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `emailtext` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `userip` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mailappsappsapps847474744474`
--

CREATE TABLE `mailappsappsapps847474744474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `toemail` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `emailtext` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `userip` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mainactivityapps84747474`
--

CREATE TABLE `mainactivityapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `mainactivity` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `mainactivity84747474` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `mainactivity84444474` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `userip` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mainactivityappsapps84747474`
--

CREATE TABLE `mainactivityappsapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `mainactivity` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `mainactivity84747474` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `mainactivity84444474` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `userip` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mobileapps84`
--

CREATE TABLE `mobileapps84` (
  `id` int(6) UNSIGNED NOT NULL,
  `firstname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mobileapps84747474`
--

CREATE TABLE `mobileapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `MyGuests`
--

CREATE TABLE `MyGuests` (
  `id` int(6) UNSIGNED NOT NULL,
  `firstname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password`
--

CREATE TABLE `password` (
  `password` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `paymentsapps84747474`
--

CREATE TABLE `paymentsapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `payments` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `userip` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `promotes84747474`
--

CREATE TABLE `promotes84747474` (
  `email` varchar(884) NOT NULL,
  `ID` int(11) NOT NULL,
  `date` varchar(884) NOT NULL,
  `promotes` varchar(884) NOT NULL,
  `userip` varchar(884) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `spendapps84747474`
--

CREATE TABLE `spendapps84747474` (
  `email` varchar(884) NOT NULL,
  `spend` varchar(884) NOT NULL,
  `date` varchar(884) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `timeonsite`
--

CREATE TABLE `timeonsite` (
  `timeonsite` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `timeonsite84444474`
--

CREATE TABLE `timeonsite84444474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `timeonsite` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `timeonsite84747474`
--

CREATE TABLE `timeonsite84747474` (
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `timeonsite` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user1`
--

CREATE TABLE `user1` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `firstname` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user2`
--

CREATE TABLE `user2` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user4`
--

CREATE TABLE `user4` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `username`
--

CREATE TABLE `username` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `userpageapps84747474`
--

CREATE TABLE `userpageapps84747474` (
  `email` varchar(884) NOT NULL,
  `id` int(11) NOT NULL,
  `userpageapps84747474` varchar(884) NOT NULL,
  `date` varchar(884) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `videosapps84747474`
--

CREATE TABLE `videosapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `videos` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `videosapps84747474` longblob NOT NULL,
  `userip` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `workapps84747474`
--

CREATE TABLE `workapps84747474` (
  `email` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `work` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(884) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `commentapps84747474`
--
ALTER TABLE `commentapps84747474`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `cpcapps84747474`
--
ALTER TABLE `cpcapps84747474`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `mobileapps84`
--
ALTER TABLE `mobileapps84`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `MyGuests`
--
ALTER TABLE `MyGuests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `promotes84747474`
--
ALTER TABLE `promotes84747474`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `userpageapps84747474`
--
ALTER TABLE `userpageapps84747474`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `commentapps84747474`
--
ALTER TABLE `commentapps84747474`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `cpcapps84747474`
--
ALTER TABLE `cpcapps84747474`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT for table `mobileapps84`
--
ALTER TABLE `mobileapps84`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `MyGuests`
--
ALTER TABLE `MyGuests`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `promotes84747474`
--
ALTER TABLE `promotes84747474`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;
--
-- AUTO_INCREMENT for table `userpageapps84747474`
--
ALTER TABLE `userpageapps84747474`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
