<head>
<title>Bluecloud continue</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="/dashboard/jquery.js" type="text/javascript"></script>

<link rel="icon" type="image/png" href="/images/googleapps84.png">

</head>

<style>

html,body
{
margin:0px;
padding:0px;
font-family:Varela Round, sans-serif;
background-color:#f1f1f1;
}

</style>

<?php

if(preg_match("/yandex\.com\.tr/","$_SERVER[HTTP_REFERER]"))

{

$result84747474 = 'DEVAM ET';

}

if(preg_match("/yandex\.ru/","$_SERVER[HTTP_REFERER]"))

{

$result84747474 = 'ПРОДОЛЖАТЬ';

}

if(preg_match("/yandex\.com/","$_SERVER[HTTP_REFERER]"))

{

$result84747474 = 'DEVAM ET';

}

else

{

$result84747474 = 'ПРОДОЛЖАТЬ';

}

?>

<?php

if(preg_match("/yandex\.com\.tr/","$_SERVER[HTTP_REFERER]"))

{

$result847474744474 = 'Mavi';

}

if(preg_match("/yandex\.ru/","$_SERVER[HTTP_REFERER]"))

{

$result847474744474 = 'синий';

}

if(preg_match("/yandex\.com/","$_SERVER[HTTP_REFERER]"))

{

$result847474744474 = 'Mavi';

}

else

{

$result847474744474 = 'синий';

}

?>

<div onclick="window.open('https://www.phpscripts.online/','_self');" style="margin:12px;background-color:#ffffff;box-shadow:0px 2px 4px rgba(0, 0, 0, 0.4);">

<div style="width:100%;padding:12px;box-sizing:border-box;">

<div style="text-align:center;padding:12px;margin-left:-44px;">

<div align="center">

<div style="font-weight:bold;">

<?php echo "$result847474744474"; ?>

</div>

<div style="transform:scale(0.58);margin-left:141.8px;margin-top:-44px;">

<div style="border-style:solid;border-width:2px;border-color:#42A5F5;border-radius:196px;width:0px;padding:34px;top:-30.8px;left:-12px;box-shadow:0 2px 4px rgba(0,0,0,1);">
</div>

<div style="position:relative;">

<div style="background-color:#42A5F5;padding:12px;border-radius:196px;width:0px;margin-top:-60.4px;left:12px;">
</div>

<div style="background-color:#42A5F5;padding:12px;border-radius:196px;width:0px;margin-left:-24px;margin-top:-4px;">
</div>

<div style="background-color:#42A5F5;padding:12px;border-radius:196px;width:0px;left:24px;margin-top:-24px;margin-left:24px;">
</div>

</div>

</div>



</div>

</div>

</div>



<div style="padding:12px;background-color:#42A5F5;text-align:center;color:#ffffff;box-sizing:border-box;">

<?php

echo "$result84747474";

?>

</div>

</div>

<script>

var googleappsapps84747474 = location.protocol

var script = document.createElement('script');
script.src = '' + googleappsapps84747474 + '//www.googletagmanager.com/gtag/js?id=UA-119997762-1';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

</script>

<script>

window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-119997762-1');

</script>

