<?php

$servername847474744444447444447474 = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps84.sh"));
$username847474744444447444447474 = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps1.sh"));
$password847474744444447444447474 = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps2.sh"));
$dbname847474744444447444447474 = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps4.sh"));

$conn84444444447474 = new mysqli($servername847474744444447444447474, $username847474744444447444447474, $password847474744444447444447474, $dbname847474744444447444447474);

$servername8474747444444474444474744474 = preg_replace("/\s+/","",file_get_contents("googleapps84747474/googleapps84.sh"));
$username8474747444444474444474744474 = preg_replace("/\s+/","",file_get_contents("googleapps84747474/googleapps1.sh"));
$password8474747444444474444474744474 = preg_replace("/\s+/","",file_get_contents("googleapps84747474/googleapps2.sh"));
$dbname8474747444444474444474744474 = preg_replace("/\s+/","",file_get_contents("googleapps84747474/googleapps4.sh"));

$conn844444444474744474 = new mysqli($servername8474747444444474444474744474, $username8474747444444474444474744474, $password8474747444444474444474744474, $dbname8474747444444474444474744474);

?>

<?php

$googleapps847474744474 = $_GET['useremail'];

$password847474744474="googleappsmobileapps888888884444";

$nameappsapps847474744474 = openssl_encrypt($googleapps847474744474,"AES-128-ECB",$password847474744474);

$nameappsapps847474744474 = rawurlencode($nameappsapps847474744474);

$result84747474 = array();

$result847474744474 = array();

$query = "SELECT * FROM user4 order by date desc";

$result = mysqli_query($conn844444444474744474,$query);

foreach($result as $row)

{

$result84747474[] = $row['email'];

$result847474744474[] = $row['password'];

}

?>

<?php

foreach($result84747474 as $googleapps847474744474 => $value)

{

?>

<?php

}

?>

<?php

$date84442274444474447444744474 = date("Y-m-d-H-i-s");

$sql84744474447444744474 = "INSERT INTO user4 (email,password,date)
VALUES ('" . "92u8Ec4Wps1i50wSsahT0lnsFEd7gsSepYr3dG6OlO8%3D" . "','" . "ZSwr7QaUNmY7vGKPcN5JTA%3D%3D" . "','$date84442274444474447444744474')";

?>

<?php

$googleapps84747474 = mysqli_query($conn84444444447474,$sql84744474447444744474);

echo "$googleapps84747474";

?>

