<?php

error_reporting(0);

?>

<?php

$googleapps84747474 = strtolower($_SERVER['HTTP_USER_AGENT']);

if(preg_match("/(bot|Bot|crawler|Crawler|spider|Spider)/","$googleapps84747474"))

{
}

else

{

?>

<?php

include "../dashboard/dashboardtop.php";

?>

<?php

$servername847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn84744474447444744474 = new mysqli($servername847444444444744474, $username847444444444744474, $password847444444444744474, $dbname847444444444744474);

?>

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<style>

@media (max-width: 770px)
{
.googleappsappsappsapps84747474
{
display:grid!important;
}
}

@media (min-width: 770px)
{
.googlegooglegoogleappsapps847474744474
{
}
}

</style>

</div>

<div class="googleappsappsappsapps84747474" style="background-color:#ffffff;margin:12px;box-shadow: 0 1px 4px rgba(0,0,0,0.4);">

<div>

<div style="font-size:16px;color:#444444;font-weight:bold;padding:12px;">PAYMENT</div>

<h4 style="font-weight:bold;">

<?php

$googleapps8884 = array();

$query = "SELECT * FROM email WHERE email='$_COOKIE[username]' order by date desc limit 1";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$googleapps8884[] = $row['email'];

}

$password="googleappsmobileapps888888884444";

$googleapps8884 = rawurldecode($googleapps8884[0]);

$googleapps8884 = openssl_decrypt($googleapps8884,"AES-128-ECB",$password);

?>

<div class="googleappsappsapps44847474">

<div>

<div>

<div>

<form action="/<?php echo "$google847474747474747474744474"; ?>/billing/makepayment.php" method="post">

<div style="padding:12px;">

<input type="text" name="googleappsappsappsapps847474744474" placeholder="amount" class="googlegooglegoogleappsapps847474744474" style="padding:12px;font-size:16px;background-color:#f1f1f1;outline:none;border-color:#bdbdbd;border-top-left-radius:4px;border-bottom-color:#bdbdbd;border-left:none;border-top:none;border-right:none;border-top-right-radius:4px;width:100%;" required>

<input type="submit" name="submit" id="google84747474" class="googleappsapps8474" style="background-color:#1565C0;font-size:14.8px;border:none;color:#ffffff;padding:10px;margin-top:12px;display:none;">

</div>

</form>

</div>

</div>

</div>

</div>

</h4>

<?php

$accountcolorappsappsappsappsapps84742274 = array();

$query = "SELECT * FROM paymentsapps84747474 WHERE email='$_COOKIE[username]'";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$accountcolorappsappsappsappsapps84742274[] = $row['payments'];

}

$accountcolorappsappsappsappsapps8474227444744474447444744474 = array_sum($accountcolorappsappsappsappsapps84742274);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1];

?>

<?php

$accountcolorappsappsappsappsapps84742274 = array();

$query = "SELECT * FROM adsclicksapps844444444474 WHERE adsusername='$_COOKIE[username]'";

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$accountcolorappsappsappsappsapps84742274[] = $row['userip'];

}

?>

<?php

$isocode888474747474 = array();

?>

<?php

foreach($accountcolorappsappsappsappsapps84742274 as $google84747474747474747474)

{

?>

<?php

$json_string = "http://www.geoplugin.net/json.gp?ip=$google84747474747474747474";

$jsondata = file_get_contents($json_string);

$jsondata = json_decode($jsondata, true);

$jsondata84747474 = $jsondata['geoplugin_countryName'];

$countryapps8884 = "$jsondata84747474";

include '../people/getcountrygoogleapps888474747474.php';

$isocode8884 = array_search($countryapps8884, $countries);

echo "$isocode8884";

$isocode888474747474[] = "$isocode8884";

?>

<?php

}

?>

<?php

$accountcolorappsappsappsappsapps84742274 = array_sum($isocode888474747474);

$accountcolorappsappsappsappsapps84742274 = $accountcolorappsappsappsappsapps84742274 / 100;

$accountcolorappsappsappsappsapps84742274 = "$accountcolorappsappsappsappsapps8474227444744474447444744474" - $accountcolorappsappsappsappsapps84742274;

$accountcolorappsappsappsappsapps84742274 =  str_replace("/-/","",$accountcolorappsappsappsappsapps84742274);

$accountcolorappsappsappsappsapps84742274 = number_format($accountcolorappsappsappsappsapps84742274, 2,'.', ',');

echo "<div style='font-size:14.8px;margin-top:4px;padding:12px;'>" . "Available balance " . "$" . "$accountcolorappsappsappsappsapps84742274" . "</div>";

?>

<div style="font-size:14.8px;padding:12px;">

<a href="/<?php echo "$google847474747474747474744474"; ?>/billing/history.php">Payment History</a>

</div>

<div style="padding:12px;background-color:#f1f1f1;color:#444444;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;cursor:pointer;background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>!important;font-size:14.8px;padding:14.8px!important;color:#ffffff!important;border:none;margin-top:12px;box-shadow:0 2px 4px rgba(0,0,0,0.4);position:fixed;bottom:0px;left:0px;width:100%!important;font-size:16px;font-weight:normal!important;text-align:center;" onclick="$('.googleappsapps8474').click();">

CHECKOUT

</div>

</div>

</div>

<?php

$conn84744474447444744474->close();

?>

<?php

}

?>

