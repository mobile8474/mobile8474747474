<head>
<title>Getit ad</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<meta name="description" content='<?php echo ""; ?>'>

<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<script type="text/javascript" src="/dashboard/jquery.js"></script>

</head>

<style>

html,body
{
margin:0px;
padding:0px;
background-color:#f1f1f1;
font-family:Varela Round, sans-serif;
}

</style>

<div style="padding:12px;margin:12px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.4);" onclick="window.open('/register/signupapps84747474.php?googleapps84=googleapps84','_self');">

<div style="font-size:28px;color:#1565C0;">

Create an ad with Getit&#153;

</div>

<div style="font-weight:bold;font-size:14.8px;padding-bottom:12px;">

https://getit.phpscripts.online/

</div>

<div style="font-size:17.6px;">

Create an ad for $4 dollars and get your brand in front of lots of people when your balance of $4 dollars is depleted you can buy another ad space for your ad to run on

</div>

<div style="padding-bottom:12px;">

We accept paypal for payments

</div>

<div style="font-size:14.6px;">

Just register go to the three dots at the top, go to settings enable the ads you should be asked for the ad title description and url put that in and make a payment and your ad should be all set,you should then get users,clients,traffic to your website

</div>

<div style="font-size:14.6px;padding:12px;margin-top:12px;margin-bottom:12px;background-color:#1565C0;color:#ffffff;display:inline-block;cursor:pointer;">

Get started

</div>

</div>

<script>

var googleappsapps84747474 = location.protocol

var script = document.createElement('script');
script.src = '' + googleappsapps84747474 + '//www.googletagmanager.com/gtag/js?id=UA-119997762-1';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

</script>

<script>

window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-119997762-1');

</script>

