<?php

error_reporting(0);

?>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../thumbsupapps84747474.sh";

}

else

{

$dataurlappsappsapps84 = "thumbsupapps84747474.sh";

}

?>

<?php

$googleapps8474 = $_GET['userapps84747474'];

$googleapps8474 = rawurlencode($googleapps8474);

?>

<?php

$googleapps8884 = "<div class='$googleapps8474'>" . "\n" . "<div class='$_GET[thumbsupapps84747474]'>" . "\n" . "<div class='$_GET[userappsappsapps84747474]'>1</div>" . "\n" . "</div>" . "\n" . "</div>";

?>

<?php

$filedata = "$googleapps8884";
$filedata .= file_get_contents("$dataurlappsappsapps84");
$googleapps888844 = file_put_contents("$dataurlappsappsapps84", $filedata);

echo "<div style='display:none;'>$googleapps888844</div>";

?>

