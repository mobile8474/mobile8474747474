<head>
<title>Bluecloud</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<meta name="description" content='<?php echo ""; ?>'>

<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<script type="text/javascript" src="/dashboard/jquery.js"></script>

<link rel="icon" type="image/png" href="/people/googleapps84.png">

</head>

<style>

html,body
{
margin:0px;
padding:0px;
font-family:Varela Round, sans-serif;
background-color:#ECEFF1!important;
}

</style>

<style>

@media (max-width: 770px)
{
.googleappsappsappsapps84747474
{
display:grid!important;
}
}

</style>

<link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">

<style>

*
{
font-family:'Roboto',sans-serif;
font-weight:100;
}

</style>

<div align="left">

<div style="padding:14px;background-color:#ffffff;color:#444444;box-sizing:border-box;cursor:pointer;font-weight:bold;box-shadow:0 2px 4px rgba(0,0,0,0.4);">

<divapps84 style="font-weight:normal;">BLUE</divapps84><divapps84 style="font-weight:bold;">CLOUD</divapps84>

<divapps84 align="right">

<divapps84 style="font-weight:normal;right:12px;position:absolute;cursor:pointer;" onclick="window.open('/loginapps84747474.php','_self');">LOGIN</divapps84>

</divapps84>

</div>

</div>

<div align="left">

<div style="padding:14px;background-color:#ffffff;color:#444444;box-sizing:border-box;cursor:pointer;font-weight:bold;box-shadow:0 2px 4px rgba(0,0,0,0.4);z-index:44;position:relative;" onclick="window.open('/','_self');">

<divapps84 align="left">

<divapps84 style="font-weight:bold;margin-left:12px;font-size:12.8px;border-style:solid;padding:12px;border-left:none;border-right:none;border-top:none;">ALL PRODUCTS</divapps84>

</divapps84>

<divapps84 align="left">

<divapps84 style="font-weight:bold;margin-left:12px;font-size:12.8px;">ANALYTICS</divapps84>

</divapps84>

<divapps84 align="left">

<divapps84 style="font-weight:bold;margin-left:12px;font-size:12.8px;">ADS</divapps84>

</divapps84>

</div>

</div>

<div style="background-color:#ffffff;">

<div style="padding:44px;">

<div style="font-size:58px;color:#444444;">

Get your Bluecloud account today

</div>

<div style="padding-top:24px;color:#444444;">

Get ads and analytics from Bluecloud, track your user on your website or websites,with our ads you can get users to your website

</div>

<div style="padding-top:12px;">

<div style="background-color:#4285f4;;padding:12px;display:inline-block;color:#ffffff;cursor:pointer;font-weight:bold;" onclick="window.open('/signupapps84747474.php','_self');">

START NOW

</div>

</div>

<div style="padding-top:12px;">

Call to get set up by our Bluecloud Support: +14845084841

</div>

</div>

</div>

<div class="googleappsappsappsapps84747474" style="display:flex;background-color:#ffffff;">

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:#4285f4;font-size:44px;">bubble_chart</i>

</div>

<h3 style="font-size:24px;color:#4285f4;font-weight:bold;">Analytics</h3>

<h4 style="font-weight:bold;">Track your website users</h4>

<div style="font-size:14.8px;">Track users on your website, with an easy to use tracking code, put the javascript code on your website and view your website users on your analytics dashboard</div>

<div style="padding:12px;background-color:#4285f4;color:#ffffff;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;">

GET ANALYTICS

</div>

</div>

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:#00c853;font-size:44px;">search</i>

</div>

<h3 style="font-size:24px;color:#00c853;font-weight:bold;">Ads</h3>

<h4 style="font-weight:bold;">Get users to your website</h4>

<div style="font-size:14.8px;">if you are tired of wasting money use our ads, to get users to your website,create an ad, set your budget and watch users browse your website</div>

<div style="padding:12px;background-color:#00c853;color:#ffffff;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;">

GET ADS

</div>

</div>

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:#f4b400;font-size:44px;">attach_money</i>

</div>

<h3 style="font-size:24px;color:#f4b400;font-weight:bold;">Billing</h3>

<h4 style="font-weight:bold;">Make payments with ease</h4>

<div style="font-size:14.8px;">Billing that shows all your payments and collects data while you watch users on your website grow</div>

<div style="padding:12px;background-color:#f4b400;color:#ffffff;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;">

BILLING

</div>

</div>

</div>

<div style="background-color:#f1f1f1;color:#444444;padding:44px;">

<div style="font-weight:normal;">

GETTING STARTED

<div style="font-weight:normal;font-size:44px;">

Sign yourself up today.

</div>

<div style="font-weight:normal;font-size:14.6px;margin-top:4px;">

Create an account with us, to track your users and if you want you can get ads to promote your website

</div>

<div style="background-color:#4285f4;;padding:12px;display:inline-block;color:#ffffff;margin-top:24px;margin-bottom:24px;cursor:pointer;font-weight:bold;" onclick="window.open('/signupapps84747474.php','_self');">

START NOW

</div>

</div>

</div>

<div>
</div>

<?php

if(preg_match("/[\W\w]/",$_COOKIE['username']))

{

?>

<?php

$string_to_encrypt = $_COOKIE['username'];

$decrypted_string888474 = rawurldecode($string_to_encrypt);

$password = "googleappsmobileapps888888884444";

$decrypted_string8474 = openssl_decrypt($decrypted_string888474,"AES-128-ECB",$password);

?>

<script>

setTimeout(function()

{

window.location = '/ads/overview.php?today=1&googleappsappsappsapps84=ads&googleapps84=0&googleapps8474=8"; ?>';

}, 884);

</script>

<?php

}

?>

<footer8474 id="footer84747474">

<div class="mui-container-fluid">

<div style="color:#222222!important;font-size:12.8px;z-index:44;left:12px;bottom:12px;position:fixed;width:100%;padding:12px;background-color:#ffffff;bottom:0px;left:0px;box-sizing:border-box;z-index:88888844;">

&copy; <?php echo date('Y',time()); ?> Bluecloud

<div style="position:absolute;right:12px;padding:12px;bottom:56px;background-color:#ffffff;width:156px;box-shadow:0 2px 4px rgba(0,0,0,0.4);">Find any malware or think this website is a phishing website, or any thing else report it</div>

<div style="float:right;cursor:pointer;" onclick="$('.googleappsapps84747474mobileapps847474744474mobileapps847474744474').show();">Report this Website</div>

<center>

<div class="googleappsapps84747474mobileapps847474744474mobileapps847474744474" style="position:fixed;padding:12px;top:12%;display:none;background-color:#ffffff;margin:0 auto;width:146px;left:12px;right:12px;box-shadow:0 2px 4px rgba(0,0,0,0.4);" onclick="$('.googleappsapps84747474mobileapps847474744474mobileapps847474744474').hide();">Thank you, this website has been reported</div>

</center>

</div>

</div>

</footer8474>

