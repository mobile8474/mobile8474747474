<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/appspot/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "gs://$_SERVER[HTTP_HOST]/register/userregistrations.sh";

}

else

{

$dataurl84 = "$googleprotocolapps8884://$_SERVER[HTTP_HOST]/register/userregistrations.sh";

}

?>

<?php

$googleapps88224474 = file_get_contents($dataurl84);

?>

<?php

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleapps88224474, $googleapps84);
$name = $googleapps84[1];

$name84747474 = $googleapps84[3];

$name84747474 = rawurldecode($name84747474);

$password = "googleappsmobileapps888888884444";

$name84747474 = openssl_decrypt($name84747474,"AES-128-ECB",$password);



$name = array_unique($name);

$googleapps84747474 = $name[array_rand($name)];

$fromemail = rawurldecode($googleapps84747474);

$password = "googleappsmobileapps888888884444";

$googleapps84441274 = openssl_decrypt($fromemail,"AES-128-ECB",$password);

echo "$name84747474";

?>

<?php

$google8884 = rand(1,1);

if(preg_match("/1/",$google8884))

{

$google8474 = "mobileappslinuxapps84@gmail.com";

$google847474 = "Chr@123chr";

}

if(preg_match("/2/",$google8884))

{

$google8474 = "mobileappsmobileapps8@gmail.com";

$google847474 = "Chr@123chr";

}

if(preg_match("/3/",$google8884))

{

$google8474 = "mobileappsblog83@gmail.com";

$google847474 = "googleapps84";

}

if(preg_match("/4/",$google8884))

{

$google8474 = "mobileappsblogapps888844@gmail.com";

$google847474 = "Chr@123chr";

}

if(preg_match("/5/",$google8884))

{

$google8474 = "mobileappsblogapps84@gmail.com";

$google847474 = "Chr@123chr";

}

if(preg_match("/6/",$google8884))

{

$google8474 = "mobileappsblogappsblogapps@gmail.com";

$google847474 = "Chr@123chr";

}

if(preg_match("/7/",$google8884))

{

$google8474 = "mobileappsinstallmobileapps@gmail.com";

$google847474 = "googleapps84";

}

if(preg_match("/8/",$google8884))

{

$google8474 = "mobileappsblogappscomputerapps@gmail.com";

$google847474 = "Chr@123chr";

}

if(preg_match("/9/",$google8884))

{

$google8474 = "mobile888888742@gmail.com";

$google847474 = "Chr@123chr";

}

if(preg_match("/10/",$google8884))

{

$google8474 = "mobile888881@gmail.com";

$google847474 = "Chr@123chr";

}

if(preg_match("/11/",$google8884))

{

$google8474 = "mobileappslinuxapps1@gmail.com";

$google847474 = "Chr@123chr";

}

if(preg_match("/12/",$google8884))

{

$google8474 = "mobileappslinuxapps3@gmail.com";

$google847474 = "Chr@123chr";

}

if(preg_match("/13/",$google8884))

{

$google8474 = "mobileapps888888844@gmail.com";

$google847474 = "Chr@123chr";

}

if(preg_match("/14/",$google8884))

{

$google8474 = "mobileapps88888882@gmail.com";

$google847474 = "Chr@123chr";

}

if(preg_match("/15/",$google8884))

{

$google8474 = "mobileapps888888824@gmail.com";

$google847474 = "Chr@123chr";

}

if(preg_match("/16/",$google8884))

{

$google8474 = "mobileapps8888888104@gmail.com";

$google847474 = "Chr@123chr";

}

if(preg_match("/17/",$google8884))

{

$google8474 = "mobileapps88888883@gmail.com";

$google847474 = "Chr@123chr";

}

?>

<?php

include "phpmailer/PHPMailerAutoload.php";

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPDebug = 0;
$mail->SMTPAuth = true;
$mail->SMTPSecure = 'tls';
$mail->Host = "smtp.gmail.com";
$mail->Port = 587;
$mail->IsHTML(true);

$mail->Username = "$google8474";
$mail->Password = "$google847474";

?>

<?php

if(preg_match("/[\W\w]/",$_GET['googleappsapps1']))

{

?>

<?php

$nameappsappsappsappsappsappsappsapps84 = $_GET['googleapps84747474'];

$nameappsappsappsappsappsappsappsapps84 = rawurlencode($nameappsappsappsappsappsappsappsapps84);

$nameappsappsappsappsappsappsappsapps84 = rawurldecode($nameappsappsappsappsappsappsappsapps84);

$nameappsappsappsappsappsappsappsapps84 = openssl_decrypt($nameappsappsappsappsappsappsappsapps84,"AES-128-ECB",$password);

$nameappsappsappsappsappsapps84 = $_GET['googleapps1'];

$password="googleappsmobileapps888888884444";

$nameappsappsappsappsappsapps84 = rawurlencode($nameappsappsappsappsappsapps84);

$nameappsappsappsappsappsapps84 = rawurldecode($nameappsappsappsappsappsapps84);

$nameappsappsappsappsappsapps84 = openssl_decrypt($nameappsappsappsappsappsapps84,"AES-128-ECB",$password);

?>

<?php

$mail->Subject = "Someone wrote on your Timeline";
$mail->Body = '

<head>
<title></title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no">
</head>

<html>

<body style="background-color:#f8f8f8;">

<div class="googleapps888844" style="left:0px;right:0px;width:574px;background-color:#ffffff;font-family: Varela Round, sans-serif;width:100%;border-style:solid;border-left:none;border-bottom:none;border-top:none;border-color:#bdbdbd;position:relative;">

<div style="position:absolute;padding:12px;right:12px;bottom:12px;border-style:solid;border-left:none;border-top:none;border-color:#bdbdbd;display:none;">
</div>

<div style="background-color:#ffffff;width:100%;height:62px;">

<div style="color:#ffffff;padding:18px;font-size:22px;">

<center>

<span style="padding-left:8px;padding-right:8px;border-width:2px;padding-top:4px;padding-bottom:4px;font-weight:bold;"></span> <span style="color:#ffffff!important;font-weight:bold;"><span>

</center>

</div>

</div>

<div class="googleapps8884" style="font-family: Varela Round, sans-serif;">

<div class="google888874" style="font-family: Varela Round, sans-serif;"></div>

<div class="google8474" style="font-family: Varela Round, sans-serif;"></div>

<div style="padding:12px;color:#5d636f;font-size:12.8px;">

<div style="text-align:center;font-size:44px;">Getit&#153;</div><br>

<div class="google88884474" style="font-family:Varela Round, sans-serif;"><div><div style="font-size:13.8px;color:#222222;"><div style="text-align:center;">Someone wrote on your Timeline</div><br><div style="text-align:center;margin:0 auto;"></div><div style="color:#222222;font-size:13.8px;"></div><br><div><div style="color:#222222;font-size:13.8px;"></div><br><div style="font-size:12.8px;">Getit&#153;</div><div style="font-weight:bold;color:#222222;font-size:12.8px;">mobileappsmobileapps8@gmail.com<br><a href="https://mobileapps888844.herokuapp.com/" style="color:#222222;">https://mobileapps4.herokuapp.com/</a></div></div><mobileapps84></mobileapps84><mobileapps84></mobileapps84><br><mobileapps84></mobileapps84><mobileapps84></mobileapps84></div>

<div>

</div>

</div>

</body>

</html>

';

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_GET['googleappsapps4']))

{

?>

<?php

$nameappsappsappsappsappsappsappsapps84 = $_GET['googleapps84747474'];

echo "$nameappsappsappsappsappsappsappsapps84";

$nameappsappsappsappsappsappsappsapps84 = openssl_encrypt($nameappsappsappsappsappsappsappsapps84,"AES-128-ECB",$password);

$nameappsappsappsappsappsappsappsapps84 = rawurlencode($nameappsappsappsappsappsappsappsapps84);

$nameappsappsappsappsappsappsappsapps84 = rawurldecode($nameappsappsappsappsappsappsappsapps84);

$nameappsappsappsappsappsappsappsapps84 = openssl_decrypt($nameappsappsappsappsappsappsappsapps84,"AES-128-ECB",$password);

$nameappsappsappsappsappsapps84 = $_GET['googleapps1'];

$password="googleappsmobileapps888888884444";

$nameappsappsappsappsappsapps84 = rawurlencode($nameappsappsappsappsappsapps84);

$nameappsappsappsappsappsapps84 = rawurldecode($nameappsappsappsappsappsapps84);

$nameappsappsappsappsappsapps84 = openssl_decrypt($nameappsappsappsappsappsapps84,"AES-128-ECB",$password);

?>

<?php

$mail->Subject = "Someone shared something with you";
$mail->Body = '

<head>
<title></title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no">
</head>

<html>

<body style="background-color:#f8f8f8;">

<div class="googleapps888844" style="left:0px;right:0px;width:574px;background-color:#ffffff;font-family: Varela Round, sans-serif;width:100%;border-style:solid;border-left:none;border-bottom:none;border-top:none;border-color:#bdbdbd;position:relative;">

<div style="position:absolute;padding:12px;right:12px;bottom:12px;border-style:solid;border-left:none;border-top:none;border-color:#bdbdbd;display:none;">
</div>

<div style="background-color:#ffffff;width:100%;height:62px;">

<div style="color:#ffffff;padding:18px;font-size:22px;">

<center>

<span style="padding-left:8px;padding-right:8px;border-width:2px;padding-top:4px;padding-bottom:4px;font-weight:bold;"></span> <span style="color:#ffffff!important;font-weight:bold;"><span>

</center>

</div>

</div>

<div class="googleapps8884" style="font-family: Varela Round, sans-serif;">

<div class="google888874" style="font-family: Varela Round, sans-serif;"></div>

<div class="google8474" style="font-family: Varela Round, sans-serif;"></div>

<div style="padding:12px;color:#5d636f;font-size:12.8px;">

<div style="text-align:center;font-size:44px;">Getit&#153;</div><br>

<div class="google88884474" style="font-family:Varela Round, sans-serif;"><div><div style="font-size:13.8px;color:#222222;"><div style="text-align:center;">Someone shared something with you</div><br><div style="text-align:center;margin:0 auto;"></div><div style="color:#222222;font-size:13.8px;"></div><br><div><div style="color:#222222;font-size:13.8px;"></div><br><div style="font-size:12.8px;">Getit&#153;</div><div style="font-weight:bold;color:#222222;font-size:12.8px;">mobileappsmobileapps8@gmail.com<br><a href="https://mobileapps888844.herokuapp.com/" style="color:#222222;">https://mobileapps4.herokuapp.com/</a></div></div><mobileapps84></mobileapps84><mobileapps84></mobileapps84><br><mobileapps84></mobileapps84><mobileapps84></mobileapps84></div>

<div>

</div>

</div>

</body>

</html>

';

?>

<?php

}

?>

<?php

$mail->AddBCC("$nameappsappsappsappsappsappsappsapps84");

echo "$nameappsappsappsappsappsappsappsapps84";

$mail->setFrom("$google8474", 'Getit');
$mail->addReplyTo("$google8474", 'Getit');

$mail->Send();

$mail->ClearAllRecipients();

?>

