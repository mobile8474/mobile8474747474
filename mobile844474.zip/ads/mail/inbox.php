<?php

error_reporting(0);

?>

<?php

include "../dashboard/dashboardtop.php";

?>

<?php

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

$conn847474744474 = new mysqli($servername, $username, $password, $dbname);

?>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<style>

@media (max-width: 770px)
{
.googlegooglegooglegoogle847474744474
{
display:none;
}
.googleapps8474747474747474747474744474
{
display:grid!important;
}
}

</style>

<script>

function googlegooglegooglegoogle847474744474447444744474() {

$(document).ready(function(){

$("#minutesappsgooglegoogleapps8474747474747444444474444444744474").load('<?php echo "createload.php"; ?>');

}

);

}

</script>

<script>

function googlegooglegooglegoogle84747474447444744474447444444474() {

$(document).ready(function(){

$("#minutesappsgooglegoogleapps8474747474747444444474444444744474").load('<?php echo "inboxload.php?query=0"; ?>');

}

);

}

</script>

<div style="display:flex;">

<div class="googlegooglegooglegoogle847474744474" style="margin:12px;">

<div style="padding:12px;background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;color:#ffffff;padding-left:14.8px;padding-right:24px;border-radius:4px;cursor:pointer;" onclick="googlegooglegooglegoogle847474744474447444744474();">

<div style="display:flex">

<div>

<i class="material-icons" style="font-size:17.6px;padding-right:10px;">edit</i>

</div>

<div>

COMPOSE

</div>

</div>



</div>

<div style="padding:12px;background-color:#bdbdbd;color:#ffffff;padding-left:14.8px;padding-right:24px;border-radius:4px;margin-top:12px;cursor:pointer;" onclick="googlegooglegooglegoogle84747474447444744474447444444474();">

<div style="display:flex">

<div>

<i class="material-icons" style="font-size:17.6px;padding-right:10px;">inbox</i>

</div>

<div>

INBOX

</div>

</div>

</div>

<div style="padding:12px;background-color:#bdbdbd;color:#ffffff;padding-left:24px;padding-right:24px;border-radius:4px;margin-top:12px;cursor:pointer;" onclick="window.open('/<?php echo "$google847474747474747474744474"; ?>/mail/sent.php','_self')">

SENT

</div>

</div>

<div style="margin-top:10px;margin:12px;width:100%;box-shadow:0 2px 12px rgba(0,0,0,0.4);">

<div id="minutesappsgooglegoogleapps8474747474747444444474444444744474" style="width:100%;"></div>

</div>

<script>

$(document).ready(function(){

$("#minutesappsgooglegoogleapps8474747474747444444474444444744474").load('<?php echo "inboxload.php?query=$_GET[query]"; ?>');

}

);

</script>

<?php

if(preg_match("/[\W\w]/",$_GET['mailappsapps847474744474447444744474']))

{

?>

<?php

$google84747474 = $_COOKIE['username'];

$google847474744474 = $_GET['mailappsapps847474744474447444744474'];

$google8474747444744444444444744474 = $_GET['dateappsapps84747474'];

?>

<?php

$query = "DELETE FROM mailapps84747474 WHERE email='$google84747474' and emailtext='$google847474744474' and date='$google8474747444744444444444744474'";

$result84747474 = mysqli_query($conn847474744474,$query);

echo "<div style='display:none;'>$result84747474</div>";

?>

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<script>

setTimeout(function()

{

window.location = '<?php echo "/$google847474747474747474744474/mail/inbox.php?query=0"; ?>';

}, 104);

</script>

<?php

}

?>

</div>

<style>

.googleapps8474747474747474747474
{
background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>!important;
border-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>!important;
}

.googleapps84747474747474747474744474
{
color:#ffffff;
}

.googlegooglegooglegooglegoogle847474744474
{
background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;
}

</style>

<?php

include "../dashboard/dashboardbottom.php";

?>

<?php

$conn847474744474->close();

?>

