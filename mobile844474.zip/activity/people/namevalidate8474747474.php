<?php

$cookievalue84747474 = $_GET['email'];

$passwordname8884 = "googleappsmobileapps888888884444";

$cookievalue84747474 = openssl_encrypt($cookievalue84747474,"AES-128-ECB",$passwordname8884);

$cookievalue84747474 = rawurlencode($cookievalue84747474);

if(preg_match("/[\W\w]/",$_GET['email']))

{

setcookie("username", "$cookievalue84747474", time()+30*24*60*60 , "/");

setcookie("google84444474", "googleapps84", time()+30*24*60*60 , "/");

?>

<?php

$google84747474747474744474 = $_GET['amountappsapps84747474'];

?>

<script>

setTimeout(function()

{

window.location = '/accounts/paymentappsappsapps84747474.php?amountappsapps84747474=<?php echo "$google84747474747474744474"; ?>';

}, 884);

</script>

<?php

}

if(preg_match("/[\W\w]/",$_GET['logout8474']))

{

setcookie("username", "", time()+30*24*60*60 , "/");

setcookie("google84444474", "", time()+30*24*60*60 , "/");

?>

<script>

setTimeout(function()

{

window.location = '/';

}, 884);

</script>

<?php

}

?>

