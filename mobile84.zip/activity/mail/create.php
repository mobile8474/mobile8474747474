<?php

error_reporting(0);

?>

<style>

@media (min-width: 770px)
{
.googleappsappsappsappsapps84747474747474744474
{
width:396px;
}
}

</style>

<head>
<title><?php echo "$googleapps84747474"; ?></title>
<meta name='description' content='<?php echo "$googleapps847474744474"; ?>'>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="/dashboard/jquery.js"></script>
<script src="/dashboard/recorder.js"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>

<?php

include "../dashboard/dashboardtop.php";

?>

<div style="padding:8px;box-shadow: 0 2px 4px rgba(0,0,0,0.2);margin-bottom:18px;background-color:#ffffff;box-shadow:0 1px 4px rgba(0,0,0,0.4);z-index:8888888844;border-radius:4px;margin:12px;box-sizing:border-box;">

<style>

@media screen and (min-width: 1884px)
{
html
{
zoom:1.4;
}
}

@media screen and (min-width: 2560px)
{
html
{
zoom:2;
}
}

</style>

<?php

$string_to_encrypt="$_COOKIE[username]";

$decrypted_string = "$string_to_encrypt";

?>

<?php

$string_to_encrypt8884="$_COOKIE[password]";

$decrypted_string8884 = "$string_to_encrypt8884";

?>

<?php

$string_to_encrypt="$_COOKIE[username]";

$decrypted_string = "$string_to_encrypt";

?>

<?php

$string_to_encrypt="$decrypted_string";

$decrypted_string888474 = rawurldecode($string_to_encrypt);

$password="googleappsmobileapps888888884444";

$decrypted_string8474=openssl_decrypt($decrypted_string888474,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../userregistrations.sh";

}

else

{

$dataurl8884 = "../register/userregistrations.sh";

}

?>

<?php

$decryptedstring = $_COOKIE['username'];

$file84 = file_get_contents("$dataurl8884");

preg_match_all("/<div class=\'$decryptedstring\' id=\'(.*?)\'><div class=\'(.*?)\' id=\'(.*?)\'><div class=\'(.*?)\'><div class=\'(.*?)\'>(.*?)<\/div><\/div><\/div><\/div>/s", $file84, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

$googleapps8884 = strtoupper("$name");

$googleapps888844 = "$name";

?>

<?php

if(!preg_match("/[\W\w]/",$_COOKIE['username']))

{

?>

<?php

}

?>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>

<?php

$hours = date("H");

$minutes = date("i");

$seconds = date("s");

?>

<?php

$date = date("Y-m-d");

?>

<?php

$userpagesbrowsed = $_SERVER['REQUEST_URI'];

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../userpagesbrowsed.sh";

}

else

{

$dataurl8884 = "../registrations/userpagesbrowsed.sh";

}

?>

<?php

$googleapps88888844 = "$dataurl8884";

$file_data = "<div class='$googlecookieapps8884' id='$googlecookieapps888844'><div class='$date-$hours-$minutes-$seconds'><div class='$userpagesbrowsed'>1</div></div></div>\n";
$file_data .= file_get_contents("$dataurl8884");
file_put_contents("$dataurl8884", $file_data);

echo "<div style='display:none;'>$googleapps8884</div>";

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../accountcolor8884.sh";

}

else

{

$dataurl84 = "../register/accountcolor8884.sh";

}

?>

<?php

$googleapps8884 = file_get_contents($dataurl84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleapps8884, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlapps84 = "../accountcolor88842274.sh";

}

else

{

$dataurlurlapps84 = "../register/accountcolor88842274.sh";

}

?>

<?php

$googleappsgoogleappsappsgoogleapps8884 = file_get_contents($dataurlurlapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../accountcolor8884.sh";

}

else

{

$dataurlurlgoogleapps84 = "../register/accountcolor8884.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsapps84);
$accountcolor84742274 = $googleappsappsapps84[3][0];

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsapps84);
$accountcolor847474 = $googleappsappsapps84[3][0];

?>

<form action='/<?php echo "$google847474747474747474744474"; ?>/people/writemail84747474.php' class="input" method="get">

<input type="text" name="useremail" placeholder="email" value="<?php echo $_GET[useremailappsappsapps84747474]; ?>" autocomplete="off" style="width:100%;height:44px;padding-left:12px;box-sizing:border-box;margin-bottom:8px;border-style:solid;border-color:#dddddd;border-width:1px;outline-style:none;font-size:16px;" required></input>

<input type="text" name="emailtext" placeholder="mail" autocomplete="off" style="width:100%;height:44px;padding-left:12px;box-sizing:border-box;border-style:solid;border-color:#dddddd;border-width:1px;outline-style:none;font-size:16px;" required></input>

<button type="submit" name="action" style="margin-top:8px;background-color:<?php echo "$accountcolor1"; ?>;padding-top:8px;padding-bottom:8px;padding-padding;outline-style:none;border:none;color:#ffffff;border-radius:2px;font-size:12px;bottom:12px;background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84"; ?>;font-size:14.8px;font-size:16px;">SEND</button>

</form>

</div>

</div>

</div>

<?php

include "../dashboard/dashboardbottom.php";

?>

