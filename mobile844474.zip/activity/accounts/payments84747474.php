<?php

error_reporting(0);

?>

<?php

$countryapps8884 = $_COOKIE['country'];

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../paymentsapps84747474.sh";

}

else

{

$dataurlappsappsapps84 = "paymentsapps84747474.sh";

}

?>

<?php

$googleappsappsappsapps8474 = $_GET['paymentsapps84747474'];

$password = "googleappsmobileapps888888884444";

$googleappsappsappsapps8474 = openssl_encrypt($googleappsappsappsapps8474,"AES-128-ECB",$password);

$googleappsappsappsapps8474 = rawurlencode($googleappsappsappsapps8474);

?>

<?php

$googleapps84442274 = $_COOKIE['username'];

?>

<?php

$googleapps8884 = "<div class='$googleapps84442274' id='na'>" . "\n" . "<div class='na' id='na'>" . "\n" . "<div class='$_GET[googleappsapps84747474447444744474]'>1</div>" . "\n" . "</div>" . "\n" . "</div>";

?>

<?php

$filedata = "$googleapps8884";
$filedata .= file_get_contents("$dataurlappsappsapps84");
$googleapps888844 = file_put_contents("$dataurlappsappsapps84", $filedata);

echo "<div style='display:none;'>$googleapps888844</div>";

?>

<?php

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip847474 = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip847474 = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip847474 = $_SERVER['REMOTE_ADDR'];
}

?>

<?php

$userip84747474 = $ip847474;

$dateappsapps84747474 = date("Y-m-d-H-i-s");

?>

<?php

$sql12 = "INSERT INTO paymentsapps84747474 (email,payments,date,userip)
VALUES ('$googleapps84442274','$_GET[googleappsapps84747474447444744474]','$dateappsapps84747474','$userip84747474')";

?>

<?php

if ($conn->query($sql12) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql12 . "<br>" . $conn->error;
}

?>

<?php

$conn->close();

?>

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<script>

setTimeout(function()

{

window.location = '<?php echo "/$google847474747474747474744474/billing/payments.php"; ?>';

}, 104);

</script>

