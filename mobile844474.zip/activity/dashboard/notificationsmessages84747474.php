<?php

error_reporting(0);

?>

<?php

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

$conn847474744474 = new mysqli($servername, $username, $password, $dbname);

?>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<style>

.googleappsappsappsapps84222274::-webkit-scrollbar
{
display:none;
}

</style>

<div style="display:flex;">

<div style="font-size:12.8px;padding:12px;color:<?php echo "#" . $_GET['googleapps84']; ?>;cursor:pointer;font-weight:bold;">

LATEST

</div>

<div style="font-size:12.8px;padding:12px;color:<?php echo "#" . $_GET['googleapps84']; ?>;position:absolute;right:0px;cursor:pointer;font-weight:bold;" onclick="$('.googleappsappsappsappsapps84747474747474744474').show();">

CREATE MESSAGE

</div>

</div>

<div class="googleappsappsappsapps84222274" style="margin-top:10px;margin:12px;height:72%;overflow:scroll;">

<style>

@media screen and (min-width: 1884px)
{
html
{
zoom:1.4;
}
}

@media screen and (min-width: 2560px)
{
html
{
zoom:2;
}
}

</style>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

$file84 = array();

$query = "SELECT * FROM mailapps84747474 WHERE email='$_COOKIE[username]' order by date desc";

$result = mysqli_query($conn847474744474,$query);

foreach($result as $row)

{

$file84[] = $row['email'];

}

?>

<?php

$googleapps84747474 = reset($file84);

if(preg_match("/[\W\w]/","$googleapps84747474"))

{

?>

<?php

$googleappsapps847474747474744474 = "-1";

?>

<?php

$file844444444444744474 = array();

$query84747474744474 = "SELECT * FROM mailapps84747474 WHERE email='$_COOKIE[username]' order by date desc";

$result84747474744474 = mysqli_query($conn847474744474,$query84747474744474);

foreach($result84747474744474 as $row84747474744474)

{

$file844444444444744474[] = $row84747474744474['emailtext'];

}

?>

<?php

$emailtextgoogleapps84747474 = array();

$query84747474744474 = "SELECT * FROM mailapps84747474 WHERE email='$_COOKIE[username]' order by date desc";

$result84747474744474 = mysqli_query($conn847474744474,$query84747474744474);

foreach($result84747474744474 as $row84747474744474)

{

$emailtextgoogleapps84747474[] = $row84747474744474['date'];

}

?>

<?php

$emailtextgoogleapps847474744444444474 = array();

$query84747474744474 = "SELECT * FROM mailapps84747474 WHERE email='$_COOKIE[username]' order by date desc";

$result84747474744474 = mysqli_query($conn847474744474,$query84747474744474);

foreach($result84747474744474 as $row84747474744474)

{

$emailtextgoogleapps847474744444444474[] = $row84747474744474['toemail'];

}

?>

<style>

.googleappsapps847474747474744474:hover
{
box-shadow:0 2px 12px rgba(0,0,0,0.4);
z-index:88888844;
position:relative;
}

</style>

<style>

.googleappsapps847474747474744474
{
background-color:#ffffff!important;
}

</style>

<?php

foreach($file84 as $googleappsapps84747474)

{

$googleappsapps847474747474744474++;

?>

<?php

$stringtoencrypt = $emailtextgoogleapps847474744444444474[$googleappsapps847474747474744474];

$decryptedstring888474 = rawurldecode($stringtoencrypt);

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext84747474 = openssl_decrypt($decryptedstring888474,"AES-128-ECB",$password);

$stringtoencrypt84747474 = $file844444444444744474[$googleappsapps847474747474744474];

$decryptedstring88847484747474 = rawurldecode($stringtoencrypt84747474);

$password84747474 = "googleappsmobileapps888888884444";

$decryptedstringemailtext8474747484747474 = openssl_decrypt($decryptedstring88847484747474,"AES-128-ECB",$password84747474);

?>

<div class="googleappsapps847474747474744474" style="padding:12px;border-bottom-style:solid;border-width:1px;border-color:#bdbdbd;cursor:pointer;" onclick="window.open('<?php echo "$googleprotocolapps8884"; ?>://<?php echo "$_SERVER[HTTP_HOST]"; ?>/people/pagemail.php?googleapps84=0&googleapps8474=8','_self');">

<div style="display:flex;">

<div style="margin-left:-12px;">

</div>

<div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">

<?php

echo "<div style='font-size:14.8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;'>";

echo "$decryptedstringemailtext84747474";

echo "</div>";

echo "<div style='font-size:14.8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;'>";

echo "$decryptedstringemailtext8474747484747474";

echo "</div>";

$google84747474 = date("M d", strtotime($emailtextgoogleapps84747474[$googleappsapps847474747474744474]));

echo "<div style='font-size:14.8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;'>";

echo "$google84747474";

echo "</div>";

?>

</div>

</div>

<div class="google8474747444744474447444744474<?php echo "$googleappsapps847474747474744474"; ?> googleappsappsapps84747474747444744474" style="padding:12px;background-color:#ffffff;display:none;position:relative;position:relative;z-index:8884;">

<i class="material-icons googleapps84" onclick="googleapps84747474747444744474<?php echo "$googleappsapps847474747474744474"; ?>();" style="color:#444444;z-index:44;position:relative;cursor:pointer;position:relative;z-index:88888884;">delete</i>

<div class="googleappsappsappsapps84747474" style="background-color:#bdbdbd;position:absolute;left:12px;top:12px;padding:12px;border-radius:196px;left:8px;top:8px;padding:15.8px;border-radius:196px;display:none;cursor:pointer;relative;z-index:8884;">
</div>

</div>

</div>

<script>

function googleapps84747474747444744474<?php echo "$googleappsapps847474747474744474"; ?>() {

$(document).ready(function(){

$('.google847474747444744474<?php echo "$googleappsapps847474747474744474"; ?>').submit();

});

}

</script>

<?php

}

?>

<?php

}

else

{

?>

<div>

<div style="margin:0px auto;width:114px;padding-top:76px;">No messages</div>

</div>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_GET['mailappsapps847474744474447444744474']))

{

?>

<?php

$google84747474 = $_COOKIE['username'];

$google847474744474 = $_GET['mailappsapps847474744474447444744474'];

$google8474747444744444444444744474 = $_GET['dateappsapps84747474'];

?>

<?php

$query = "DELETE FROM mailapps84747474 WHERE email='$google84747474' and emailtext='$google847474744474' and date='$google8474747444744444444444744474'";

$result84747474 = mysqli_query($conn847474744474,$query);

echo "<div style='display:none;'>$result84747474</div>";

?>

<script>

location = "/people/pagemail.php?googleapps84=0&googleapps8474=8";

</script>

<?php

}

?>

<?php

$conn847474744474->close();

?>

