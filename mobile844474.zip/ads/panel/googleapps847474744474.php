<?php

$countryapps8884 = $_COOKIE['country'];

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn8444444444744444444474 = new mysqli($servername, $username, $password, $dbname);

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "$isocode8884");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<?php

$namegooglegoogleappsappsappsapps84747474444444447444744444444444744474 = array();

$google8884 = array();

$query = "SELECT * FROM adsgoogleapps84747474 WHERE email='$_COOKIE[username]' order by date desc limit $_GET[query],8";

$result = mysqli_query($conn8444444444744444444474,$query);

foreach($result as $row)

{

$google8884[] = $row['ID'];

}

?>

<?php

$google8884747474744474 = reset($google8884);

?>

<?php

$google8884 = implode("<br>",$google8884);

$google8884 = explode("<br>",$google8884);

?>

<?php

?>

<?php

$googleapps847474744474 = array();

$googleappsgoogleapps847474744474 = array();

foreach($google8884 as $googleappsapps84747474)

{

$google8884 = array();

$query = "SELECT * FROM adsgoogleapps84747474 WHERE email='$_COOKIE[username]' and id='$googleappsapps84747474' order by date desc";

$result = mysqli_query($conn8444444444744444444474,$query);

foreach($result as $row)

{

$namegooglegoogleappsappsappsapps8474747444444444744474 = $row['url'];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps847474744474 = rawurldecode($namegooglegoogleappsappsappsapps8474747444444444744474);

$namegooglegoogleappsappsappsapps847474744474 = openssl_decrypt($namegooglegoogleappsappsappsapps847474744474,"AES-128-ECB",$password);

}

$url = "$namegooglegoogleappsappsappsapps847474744474";
$parse = parse_url($url);

$googleapps847474744474[] = "$namegooglegoogleappsappsappsapps847474744474";

$googleappsgoogleapps847474744474[] = "$namegooglegoogleappsappsappsapps847474744474";

}

?>

<?php

$googleapps847474744474 = array_filter($googleapps847474744474);

$googleapps847474744474 = array_count_values($googleapps847474744474);

$googleappsgooglegooglegooglegoogleapps847474744474 = array_filter($googleappsgooglegooglegooglegoogleapps847474744474);

$googleappsgooglegooglegooglegoogleapps847474744474 = array_count_values($googleappsgoogleapps847474744474);

$googleapps847474744474 = implode("<br>",$googleapps847474744474);

$googleapps847474744474 = explode("<br>",$googleapps847474744474);

$googleappsgoogleapps847474744474 = implode("<br>",$googleappsgoogleapps847474744474);

$googleappsgoogleapps847474744474 = explode("<br>",$googleappsgoogleapps847474744474);

$google847474444444444474 = array_keys($googleappsgooglegooglegooglegoogleapps847474744474);

?>

<div style="position:relative;margin-bottom:96px;">

<div>

<div style="margin-top:12px;background-color:#ffffff;margin:12px;word-wrap:break-word;box-shadow:0 2px 12px rgba(0,0,0,0.4);">

<?php

$google8474747444744474 = "0";

$googleappsappsappsapps8474747444744474 = "-1";

$googleappsappsappsappsappsapps8474747444744474 = array();

?>

<?php

if(preg_match("/[\W\w]/","$google8884747474744474"))

{

?>

<?php

foreach($googleapps847474744474 as $googleapps84222274 => $google84747474)

{

$googleappsappsappsappsappsapps8474747444744474[] = "$google84747474";

}

?>

<?php

foreach($googleapps847474744474 as $googleapps84222274 => $google84747474)

{

$google8474747444744474++;

$googleappsappsappsapps8474747444744474++;

$googleappsgooglegoogleapps84747474 = $googleappsgoogleapps847474744474[$googleapps84222274];

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../adsclicksapps84747474";

}

else

{

$dataurlappsappsapps84 = "../people/adsclicksapps84747474";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlappsappsapps84);

?>

<?php

$google84747474 = $google847474444444444474[$googleappsappsappsapps8474747444744474];

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='$google84747474'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1];

?>

<?php

$googleapps8474747444744474447444744474 = "$google84747474";

$password="googleappsmobileapps888888884444";

$googleapps8474747444744474447444744474 = openssl_encrypt($googleapps8474747444744474447444744474,"AES-128-ECB",$password);

$googleapps8474747444744474447444744474 = rawurlencode($googleapps8474747444744474447444744474);



$accountcolorappsappsappsappsapps84742274 = array();

$query = "SELECT * FROM adsclicksapps844444444474 WHERE adsusername='$_COOKIE[username]' and adsurl='$googleapps8474747444744474447444744474'";

$result = mysqli_query($conn8444444444744444444474,$query);

foreach($result as $row)

{

$accountcolorappsappsappsappsapps84742274[] = $row['userip'];

}

?>

<?php

$accountcolorappsappsappsappsapps84742274 = count($accountcolorappsappsappsappsapps84742274);

?>

<?php

$googleapps847474744474447444744474447444444474 = $google847474444444444474[$googleappsappsappsapps8474747444744474];

$password="googleappsmobileapps888888884444";

$googleapps847474744474447444744474447444444474 = openssl_encrypt($googleapps847474744474447444744474447444444474,"AES-128-ECB",$password);

$googleapps847474744474447444744474447444444474 = rawurlencode($googleapps847474744474447444744474447444444474);

$googleapps84747474747474747474 = array();

$googleapps847474747474747474744474 = array();

$googleapps8474747474747474747444744474 = array();

$google8884 = array();

$query = "SELECT * FROM adsgoogleapps84747474 WHERE url='" . $googleapps847474744474447444744474447444444474 . "' order by date desc limit 1";

$result = mysqli_query($conn8444444444744444444474,$query);

foreach($result as $row)

{

$namegooglegoogleappsappsappsapps8474747444444444744474 = $row['title'];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps847474744474 = rawurldecode($namegooglegoogleappsappsappsapps8474747444444444744474);

$namegooglegoogleappsappsappsapps847474744474 = openssl_decrypt($namegooglegoogleappsappsappsapps847474744474,"AES-128-ECB",$password);

$googleapps84747474747474747474[] = "$namegooglegoogleappsappsappsapps847474744474";



$namegooglegoogleappsappsappsapps8474747444444444744474 = $row['url'];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps847474744474 = rawurldecode($namegooglegoogleappsappsappsapps8474747444444444744474);

$namegooglegoogleappsappsappsapps847474744474 = openssl_decrypt($namegooglegoogleappsappsappsapps847474744474,"AES-128-ECB",$password);

$googleapps847474747474747474744474[] = "$namegooglegoogleappsappsappsapps847474744474";



$namegooglegoogleappsappsappsapps8474747444444444744474 = $row['description'];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps847474744474 = rawurldecode($namegooglegoogleappsappsappsapps8474747444444444744474);

$namegooglegoogleappsappsappsapps847474744474 = openssl_decrypt($namegooglegoogleappsappsappsapps847474744474,"AES-128-ECB",$password);

$googleapps8474747474747474747444744474[] = "$namegooglegoogleappsappsappsapps847474744474";



}

?>

<div>

<div class="google84747474747474747474444444744474<?php echo "$googleappsappsappsapps8474747444744474"; ?>" style='display:flex;display:flex;border-style:solid;border-width:1px;border-color:#bdbdbd;border-top:none;border-left:none;border-right:none;font-size:12.8px;position:relative;' onclick="$('#google847474744474447444744474444444444474<?php echo $google8474747444744474; ?>').toggle();"><div style='padding:12px;padding:12px;border-style:solid;border-left:none;border-top:none;border-bottom:none;border-width:1px;border-color:#bdbdbd;padding-left:12px;padding-right:14.8px;padding-top:14px;border-right:none;'>

<div>

<div style="position:relative;">

<form action="/<?php echo "$google847474747474747474744474"; ?>/panel/overview.php" method="get" class="google847474747444744474<?php echo "$googleappsappsappsapps8474747444744474"; ?>" style="margin-bottom:0px!important;">

<div class="googleapps8474747474747474744474">

<div style="position:relative;z-index:888844;border-style:solid;border-width:2px;border-radius:2px;border-color:#444444;padding:8px;position:relative;background-color:#ffffff;right:-4px;top:-2px;cursor:pointer;display:inline-block;" onclick="$('.google8474747444744474447444744474<?php echo "$googleappsappsappsapps8474747444744474"; ?>').toggle();$('.googleappsapps8474747474747474747474<?php echo "$googleappsappsappsapps8474747444744474"; ?>').toggle();$(this).toggleClass('googleapps8474747474747474747474');$('.googleappsapps8474747474747474747474<?php echo "$googleappsappsappsapps8474747444744474"; ?>').toggleClass('googleapps84747474747474747474744474');$('.google84747474747474747474444444744474<?php echo "$googleappsappsappsapps8474747444744474"; ?>').toggleClass('googleapps8474747474747474747474447444444444444474');">

<style>

.googleapps8474747474747474747474447444444444444474
{
background-color:<?php echo "#" . $_GET[colorapps847474744444444474]; ?>
}

</style>

<i class="material-icons googleappsapps8474747474747474747474<?php echo "$googleappsappsappsapps8474747444744474"; ?>" style="font-size:12px;top:2px;left:2px;font-size:19.6px;top:-1px;left:-1.4px;position:absolute;display:none;">check</i>

</div>

</div>

<input type="hidden" name="today" value="1">

<input type="hidden" name="query" value="0">

<input type="hidden" name="mailappsapps847474744474447444744474" value="<?php echo $google847474444444444474[$googleappsappsappsapps8474747444744474]; ?>">

<input type="hidden" name="dateappsapps84747474" value="<?php echo $emailtextgoogleapps84747474[$googleappsapps847474747474744474]; ?>">

<input type="submit" class="googleappsappsappsappsapps847474744474447444444474<?php echo "$googleappsappsappsapps8474747444744474"; ?>" value="Submit" style="display:none;">

</form>

</div>

</div>

<div class="google8474747444744474447444744474<?php echo "$googleappsappsappsapps8474747444744474"; ?> googleappsappsapps84747474747444744474" style="background-color:#ffffff;display:none;position:relative;z-index:8884;display:none;">

<i class="material-icons googleapps84" onclick="googleapps84747474747444744474<?php echo "$googleappsappsappsapps8474747444744474"; ?>();" style="color:#444444;z-index:44;position:relative;cursor:pointer;position:relative;z-index:88888884;margin-left:-4px;background-color:#f1f1f1;padding:4px;border-radius:196px;box-shadow:0 1px 4px rgba(0,0,0,0.4);display:none;">delete</i>

<div class="googleappsappsappsapps84747474" style="background-color:#bdbdbd;left:12px;top:12px;padding:12px;border-radius:196px;left:8px;top:8px;padding:15.8px;border-radius:196px;display:none;cursor:pointer;relative;z-index:8884;">
</div>

</div>

</div>

<div style="display:none;">

<div id="google847474744474447444744474444444444474<?php echo $google8474747444744474; ?>" style="z-index:88888844;background-color:#ffffff;font-size:12.8px;padding:12px;position:absolute;display:none;left:44px;bottom:12px;box-shadow:0 2px 12px rgba(0,0,0,0.4);">

<?php

echo "<div style='color:#1a0dab;'>" . $googleapps84747474747474747474[0] . "</div>";

echo "<div id='adsurlapps84747474$google8474747444744474' style='color:#006621;'>" . $googleapps847474747474747474744474[0] . "</div>";

echo "<div style='color:#444444;'>" . $googleapps8474747474747474747444744474[0] . "</div>";

?>

</div>

</div>

<div style='padding:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%;font-size:16px;color:#444444;'><?php echo $google847474444444444474[$googleappsappsappsapps8474747444744474]; ?></div>

<style>

.googleapps8474747474747474747474
{
background-color:<?php echo "#" . $_GET['color']; ?>!important;
border-color:<?php echo "#" . $_GET['color']; ?>!important;
}

.googleapps84747474747474747474744474
{
color:#ffffff;
}

</style>

<?php

$google84747474744474447444744474 = $_COOKIE['username'];

$accountcolorappsappsappsappsapps8474227474227474227444444474 = array();

$query8474227474227474227444444474 = "SELECT * FROM cpcapps84747474 WHERE email='$google84747474744474447444744474' and url='$googleapps8474747444744474447444744474' order by date desc";

$result8474227444444474 = mysqli_query($conn8444444444744444444474,$query8474227474227474227444444474);

foreach($result8474227444444474 as $row8474227444444474)

{

$accountcolorappsappsappsappsapps8474227474227474227444444474[] = $row8474227444444474['cpc'];

}

$accountcolorappsappsappsappsapps847422744444447474227444444474 = $accountcolorappsappsappsappsapps8474227474227474227444444474[0];

?>

<div>



<div>

<form action="/ads/panel/cpcapps84747474.php" method="post" class="google84747474744474447444444474<?php echo "$googleappsappsappsapps8474747444744474"; ?>">

<input type="text" placeholder="CPC" name="cpcapps84747474" value="<?php echo "" . "$accountcolorappsappsappsappsapps847422744444447474227444444474"; ?>" style="width:44px;margin-top:12px;">

<input type="hidden" placeholder="" name="cpcappsurl84747474" value="<?php echo "$googleapps8474747444744474447444744474"; ?>" style="width:44px;margin-top:12px;">

<input type="submit" value="Submit" style="display:none;">

</form>

</div>



</div>

<?php

$accountcolorappsappsappsappsapps84742274742274742274 = array();

$query84742274742274742274 = "SELECT * FROM adsgoogleapps847474744474 WHERE url='$googleapps8474747444744474447444744474' order by date desc";

$result84742274 = mysqli_query($conn8444444444744444444474,$query84742274742274742274);

foreach($result84742274 as $row84742274)

{

$accountcolorappsappsappsappsapps84742274742274742274[] = $row84742274['active'];

}

$accountcolorappsappsappsappsapps8474227444444474742274 = $accountcolorappsappsappsappsapps84742274742274742274[0];

?>

<?php

$colorapps84747474 = "#" . $_GET['color'];

?>

<div id="namemobileapps84444474447444444444444474<?php echo $google8474747444744474; ?>" style="padding:8px;">

<?php

if(preg_match("/1/","$accountcolorappsappsappsappsapps8474227444444474742274"))

{

?>

<i class="material-icons" style="color:#bdbdbd;cursor:pointer;" onclick="location.reload();">pause</i>

<?php

}

else

{

?>

<i class="material-icons" style="color:<?php echo $colorapps84747474; ?>;cursor:pointer;" onclick="location.reload();">play_arrow</i>

<?php

}

?>

</div>

<style>

.main847474744474
{
color:#bdbdbd!important;
}

</style>

<?php

$accountcolorappsappsappsappsapps84742274742274742274 = array();

$query84742274742274742274 = "SELECT * FROM adsgoogleapps847474744474 WHERE url='$googleapps8474747444744474447444744474' order by date desc";

$result84742274 = mysqli_query($conn8444444444744444444474,$query84742274742274742274);

foreach($result84742274 as $row84742274)

{

$accountcolorappsappsappsappsapps84742274742274742274[] = $row84742274['active'];

}

$accountcolorappsappsappsappsapps8474227444444474742274 = $accountcolorappsappsappsappsapps84742274742274742274[0];

?>

<script>

$(document).ready(function() {

$('#namemobileapps84444474447444444444444474<?php echo $google8474747444744474; ?>').click(function(){

var googlemobileapps844444744474 = '<?php echo $googleapps847474747474747474744474[0]; ?>';

var google847474747474747474744474 = '<?php echo $accountcolorappsappsappsappsapps8474227444444474742274; ?>';

if(google847474747474747474744474 == "1") {

$.ajax({
    data: 'adsgoogleapps8474747444444474=' + googlemobileapps844444744474 + '&adsgoogleapps84747474444444744474=0',
    url: '/<?php echo "$google847474747474747474744474"; ?>/panel/adsgoogleapps847474744474.php',
    method: 'POST',
    success: function(msg) {
    }
});

$('.google8474747474747474747474744474<?php echo $google8474747444744474; ?>').css('color','<?php echo $colorapps84747474; ?>');

}

else

{

$.ajax({
    data: 'adsgoogleapps8474747444444474=' + googlemobileapps844444744474 + '&adsgoogleapps84747474444444744474=1',
    url: '/<?php echo "$google847474747474747474744474"; ?>/panel/adsgoogleapps847474744474.php',
    method: 'POST',
    success: function(msg) {
    }
});

$('.google8474747474747474747474744474<?php echo $google8474747444744474; ?>').css('color','#bdbdbd');

}

});

});

</script>

<?php

if(preg_match("/1/","$accountcolorappsappsappsappsapps8474227444444474742274"))

{

$colorapps847474744474 = "#" . $_GET['color'];

}

else

{

$colorapps847474744474 = "#bdbdbd";

}

?>

<script>

function googleapps84747474747444744474<?php echo "$googleappsappsappsapps8474747444744474"; ?>() {

$(document).ready(function(){

$('.google847474747444744474<?php echo "$googleappsappsappsapps8474747444744474"; ?>').submit();

});

}

</script>

<?php

echo "<div style='margin-left:4px;padding:12px;font-weight:bold;'>$accountcolorappsappsappsappsapps84742274</div>";

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../adsclicksapps84747474";

}

else

{

$dataurlappsappsapps84 = "../people/adsclicksapps84747474";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlappsappsapps84);

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsappsapps84 = "../paymentsapps84747474";

}

else

{

$dataurlappsappsappsapps84 = "../paymentsapps84747474";

}

?>

<?php

$googleappsgooglegoogleappsappsappsapps8884 = file_get_contents($dataurlappsappsappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/", $googleappsgooglegoogleappsappsappsapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[4];

?>

<?php

$accountcolorappsappsappsappsapps84742274 = array();

$query = "SELECT * FROM paymentsapps84747474 WHERE email='$_COOKIE[username]'";

$result = mysqli_query($conn8444444444744444444474,$query);

foreach($result as $row)

{

$accountcolorappsappsappsappsapps84742274[] = $row['payments'];

}

?>

<?php

$accountcolorappsappsappsappsapps8474227444744474447444744474 = array_sum($accountcolorappsappsappsappsapps84742274);

?>

<?php

$google84744474447444744474 = $google847474444444444474[$googleappsappsappsapps8474747444744474];

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='$google84744474447444744474'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1];

?>

<?php

$accountcolorappsappsappsappsapps84742274 = array();

$query = "SELECT * FROM adsclicksapps844444444474 WHERE adsusername='$_COOKIE[username]'";
$result = $conn8444444444744444444474->query($query);

$result = mysqli_query($conn8444444444744444444474,$query);

foreach($result as $row)

{

$accountcolorappsappsappsappsapps84742274[] = $row['userip'];

}

?>

<?php

$accountcolorappsappsappsappsapps84742274 = count($accountcolorappsappsappsappsapps84742274);

$accountcolorappsappsappsappsapps84742274 = $accountcolorappsappsappsappsapps84742274 / 100;

$accountcolorappsappsappsappsapps84742274 = "$accountcolorappsappsappsappsapps8474227444744474447444744474" - $accountcolorappsappsappsappsapps84742274;

$accountcolorappsappsappsappsapps84742274 =  str_replace("/-/","",$accountcolorappsappsappsappsapps84742274);

?>

<?php

$googleapps84747474 = date("Y-m-d");

$googleappsgooglegoogleapps888444744474 = array();

$query = "SELECT * FROM adsclicksapps844444444474 WHERE adsusername='$_COOKIE[username]' and date REGEXP '$googleapps84747474.*'";

$result = mysqli_query($conn8444444444744444444474,$query);

foreach($result as $row)

{

$googleappsgooglegoogleapps888444744474[] = $row['userip'];

}

$googleappsgooglegoogleapps888444744474 = count($googleappsgooglegoogleapps888444744474);

$googleappsgooglegoogleapps888444744474 = $googleappsgooglegoogleapps888444744474 * 0.01;

?>

<?php

$accountcolorappsappsappsappsapps847422744474447444744474 = array();

$query = "SELECT * FROM adsbudgetapps84747474 WHERE email='$_COOKIE[username]' order by date desc";

$result = mysqli_query($conn8444444444744444444474,$query);

foreach($result as $row)

{

$accountcolorappsappsappsappsapps847422744474447444744474[] = $row['budget'];

}

$accountcolorappsappsappsappsapps847422744474447444744474 = reset($accountcolorappsappsappsappsapps847422744474447444744474);

?>

<?php

$accountcolorappsappsappsappsapps8474227444744474447444744474 = $accountcolorappsappsappsappsapps847422744474447444744474 - $googleappsgooglegoogleapps888444744474;

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsapps847422744474447444744474"))

{

?>

<?php

if($accountcolorappsappsappsappsapps8474227444744474447444744474 > "0")

{

?>

<?php

$accountcolorappsappsappsappsapps84742274 = array();

$query = "SELECT * FROM paymentsapps84747474 WHERE email='$_COOKIE[username]'";

$result = mysqli_query($conn8444444444744444444474,$query);

foreach($result as $row)

{

$accountcolorappsappsappsappsapps84742274[] = $row['payments'];

}

$accountcolorappsappsappsappsapps8474227444744474447444744474 = array_sum($accountcolorappsappsappsappsapps84742274);

?>

<?php

$googleapps84747474 = date("Y-m-d");

$googleappsgooglegoogleapps888444744474 = array();

$query = "SELECT * FROM adsclicksapps844444444474 WHERE adsusername='$_COOKIE[username]' and date REGEXP '$googleapps84747474.*'";

$result = mysqli_query($conn8444444444744444444474,$query);

foreach($result as $row)

{

$googleappsgooglegoogleapps888444744474[] = $row['adsusername84747474'];

}

$googleappsgooglegoogleapps888444744474 = array_sum($googleappsgooglegoogleapps888444744474);

$googleappsgooglegoogleapps888444744474 = $googleappsgooglegoogleapps888444744474;

?>

<?php

$google847474744444444444444474 = date("Y-m-d");

$accountcolorappsappsappsappsapps847422744474447444744474 = array();

$query = "SELECT * FROM adsbudgetapps84747474 WHERE email='$_COOKIE[username]' order by date desc";

$result = mysqli_query($conn8444444444744444444474,$query);

foreach($result as $row)

{

$accountcolorappsappsappsappsapps847422744474447444744474[] = $row['budget'];

}

$accountcolorappsappsappsappsapps847422744474447444744474 = reset($accountcolorappsappsappsappsapps847422744474447444744474);

?>

<?php

if($accountcolorappsappsappsappsapps847422744474447444744474 > $googleappsgooglegoogleapps888444744474)

{

?>

<?php

if($accountcolorappsappsappsappsapps8474227444744474447444744474 > "0")

{

?>

<div class="googleappsappsapps847474744444744474447444744474">

<div class="googledivapps8444744474447444744474">

<div style="position:relative;">

<i class="material-icons google8474747474747474747474744474<?php echo $google8474747444744474; ?>" style="font-size:14.8px;left:4px;color:<?php echo "$colorapps847474744474"; ?>;padding:14.8px;">brightness_1</i>

<?php

$googleappsapps84747474 = "<div style='display:none;'>running</div>";

echo "$googleappsapps84747474";

?>

</div>

</div>

</div>

<?php

}

else

{

?>

<div class="googleappsappsapps8474747444447444744474447444744474">

<div class="googledivapps8444744474447444744474">

<div style="position:relative;">

<i class="material-icons" style="font-size:14.8px;left:4px;color:#bdbdbd;padding:14.8px;">brightness_1</i>

<?php

$googleappsapps84747474 = "<div style='display:none;'>not running</div>";

echo "$googleappsapps84747474";

?>

</div>

</div>

</div>

<?php

}

?>

<?php

}

else

{

?>

<div class="googleappsappsapps8474747444447444744474447444744474">

<div class="googledivapps8444744474447444744474">

<div style="position:relative;">

<i class="material-icons" style="font-size:14.8px;left:4px;color:#bdbdbd;padding:14.8px;">brightness_1</i>

<?php

$googleappsapps84747474 = "<div style='display:none;'>not running</div>";

echo "$googleappsapps84747474";

?>

</div>

</div>

</div>

<?php

}

?>

<?php

}

else

{

?>

<?php

if($accountcolorappsappsappsappsapps84742274 > "0")

{

?>

<?php

$accountcolorappsappsappsappsapps84742274 = array();

$query = "SELECT * FROM paymentsapps84747474 WHERE email='$_COOKIE[username]'";

$result = mysqli_query($conn8444444444744444444474,$query);

foreach($result as $row)

{

$accountcolorappsappsappsappsapps84742274[] = $row['payments'];

}

$accountcolorappsappsappsappsapps8474227444744474447444744474 = array_sum($accountcolorappsappsappsappsapps84742274);

?>

<?php

if($accountcolorappsappsappsappsapps8474227444744474447444744474 > "0")

{

?>

<div class="googleappsappsapps847474744444744474447444744474">

<div class="googledivapps8444744474447444744474">

<div style="position:relative;">

<i class="material-icons google8474747474747474747474744474<?php echo $google8474747444744474; ?>" style="font-size:14.8px;left:4px;color:<?php echo "$colorapps847474744474"; ?>;padding:14.8px;">brightness_1</i>

<?php

$googleappsapps84747474 = "<div style='display:none;'>running</div>";

echo "$googleappsapps84747474";

?>

</div>

</div>

</div>

<?php

}

else

{

?>

<div class="googleappsappsapps8474747444447444744474447444744474">

<div class="googledivapps8444744474447444744474">

<div style="position:relative;">

<i class="material-icons" style="font-size:14.8px;left:4px;color:#bdbdbd;padding:14.8px;">brightness_1</i>

<?php

$googleappsapps84747474 = "<div style='display:none;'>not running</div>";

echo "$googleappsapps84747474";

?>

</div>

</div>

</div>

<?php

}

?>

<?php

}

else

{

?>

<div class="googleappsappsapps8474747444447444744474447444744474">

<div class="googledivapps8444744474447444744474">

<div style="position:relative;">

<i class="material-icons" style="font-size:14.8px;left:4px;color:#bdbdbd;padding:14.8px;">brightness_1</i>

<?php

$googleappsapps84747474 = "<div style='display:none;'>not running</div>";

echo "$googleappsapps84747474";

?>

</div>

</div>

</div>

<?php

}

?>

<?php

}

?>

<?php

}

else

{

?>

<div class="googleappsappsapps8474747444447444744474447444744474">

<div class="googledivapps8444744474447444744474">

<div style="position:relative;">

<i class="material-icons" style="font-size:14.8px;left:4px;color:#bdbdbd;padding:14.8px;">brightness_1</i>

<?php

$googleappsapps84747474 = "<div style='display:none;'>not running</div>";

echo "$googleappsapps84747474";

?>

</div>

</div>

</div>

<?php

}

?>

<?php

echo "</div>";

?>

<?php

}

?>

<?php

}

else

{

?>

<div style="padding:12px;font-size:14.8px;">

Create ads to promote your business

</div>

<?php

}

?>

<?php

if(preg_match("/not running/","$googleappsapps84747474"))

{

?>

<?php

$stringtoencrypt84747474 = $_COOKIE['username'];

$decryptedstring888474 = rawurldecode($string_to_encrypt);

$password="googleappsmobileapps888888884444";

$decryptedstringappsapps8474 = openssl_decrypt($decryptedstring888474,"AES-128-ECB",$password);

?>

<?php

}

?>

<div style="display:flex;position:absolute;right:96px;bottom:-37.4px;background-color:#ffffff;padding:4px;position:absolute;right:96px;background-color:#ffffff;z-index:44;bottom:9.6px;font-size:12.8px;color:#444444;">

<div>

<?php

echo $_GET['query'] . "-";

?>

</div>

<div>

<?php

echo $_GET['query'] + 8;

?>

</div>

</div>

<div style="position:relative;background-color:#ffffff;padding:21.4px;">

<?php

if(preg_match("/0/",$_GET['query']))

{

?>

<div style="background-color:#ffffff;position:absolute;right:0px;display:inline-block;bottom:-41.8px;right:48px;color:#bdbdbd;cursor:pointer;bottom:8px;right:49.4px;border-style:solid;border-width:1px;position:absolute;border-color:#bdbdbd;display:grid;">

<i class="material-icons">keyboard_arrow_left</i>

</div>

<?php

}

else

{

?>

<div style="background-color:#ffffff;position:absolute;right:0px;display:inline-block;bottom:-41.8px;right:48px;color:#444444;cursor:pointer;bottom:8px;right:49.4px;border-style:solid;border-width:1px;position:absolute;border-color:#bdbdbd;display:grid;" onclick="window.open('/<?php echo "$google847474747474747474744474"; ?>/panel/overview.php?query=<?php echo $_GET[query] - 8; ?>&today=1','_self')">

<i class="material-icons">keyboard_arrow_left</i>

</div>

<?php

}

?>

<div style="background-color:#ffffff;position:absolute;right:0px;display:inline-block;bottom:-41.8px;right:12px;color:#444444;cursor:pointer;position:absolute;bottom:8px;right:24px;border-style:solid;border-width:1px;border-color:#bdbdbd;display:grid;" onclick="window.open('/<?php echo "$google847474747474747474744474"; ?>/panel/overview.php?query=<?php echo $_GET[query] + 8; ?>&today=1','_self')">

<i class="material-icons">keyboard_arrow_right</i>

</div>

</div>

</div>

</div>

</div>



</div>

</div>



</div>

<?php

$conn8444444444744444444474->close();

?>

