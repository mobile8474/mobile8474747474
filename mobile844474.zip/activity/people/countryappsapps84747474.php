<?php

$dataurluserappsappsappsappsappsappsapps84 = file_get_contents("../countryapps84747474.sh");

$cookievalue84747474 = rawurlencode($_GET['googleappsappsapps84747474']);

preg_match_all("/<div class='$cookievalue84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $dataurluserappsappsappsappsappsappsapps84, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

echo "$gosearchimages84747674";

?>
