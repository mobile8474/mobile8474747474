<head>
<title><?php echo "$google84747474 $googleappsappsapps84747474"; ?></title>
<meta name='description' content='<?php echo "$google8884 $googleappsappsapps84747474"; ?>'>
<meta name='robots' content='index,follow'>
<meta name='keywords' content=''>
<meta name='viewport' content='width=device-width, initial-scale=1.0'/>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>

<style>

html,body
{
margin:0px;
padding:0px;
}

</style>

<link href="https://fonts.googleapis.com/css?family=Roboto:400" rel="stylesheet">

<style>

*
{
font-family:'Roboto',sans-serif;
}

</style>

<?php

$servername8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn84747474 = new mysqli($servername8474747444444474, $username8474747444444474, $password8474747444444474, $dbname8474747444444474);

?>

<?php

setcookie("username", "bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D", time()+30*24*60*60 , "/");

?>

<div style="padding:12px;background-color:#42A5F5;">

<div style="display:flex;">

<div style="display:flex;">

<div>

<i class="material-icons" style="color:#ffffff;">menu</i>

</div>

<div>

REGISTER

</div>

</div>

<div style="position:absolute;right:12px;">

<i class="material-icons" style="color:#ffffff;">more_vert</i>

</div>

</div>

</div>

<div>
</div>

<div style="padding:12px;background-color:#f1f1f1;cursor:pointer;" onclick="window.open('/profile/index.php','_self');">

Profile

</div>

<div style="padding:12px;background-color:#f1f1f1;cursor:pointer;" onclick="window.open('/analytics/web/overview84747474.php?today=1&googleappsappsapps84=analytics','_self');">

Analytics

</div>

<div style="padding:12px;background-color:#f1f1f1;">

Ads

</div>

<div style="padding:12px;background-color:#f1f1f1;">

Settings

</div>

<div style="padding:12px;background-color:#f1f1f1;">

Billing

</div>

<div style="padding:12px;background-color:#f1f1f1;">

Activity

</div>

<div style="padding:12px;background-color:#f1f1f1;">

Mail

</div>

<div style="padding:12px;background-color:#f1f1f1;">
</div>

