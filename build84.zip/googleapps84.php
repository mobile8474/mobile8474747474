<?php

while (1) {

$starttime = microtime(true);

$res = file_get_contents("http://127.0.0.1/mobile84/mine.php?q=info");

$info = json_decode($res, true);
$data = $info['data'];
$block = $data['block'];
$difficulty = $data['difficulty'];
$publickey = $data['public_key'];
$height = $data['height'];
$limit = $data['limit'];
$argonmemory = $data['argon_mem'];
$argonthreads = $data['argon_threads'];
$argontime = $data['argon_time'];
$nonce = base64_encode(openssl_random_pseudo_bytes(32));
$nonce = preg_replace("/[^a-zA-Z0-9]/", "", $nonce);
$base = $publickey."-"."$nonce"."-".$block."-".$difficulty;

$argon84 = ($height > 10800 && ($height < 80000 || $height % 2 == 0)) ?
password_hash($base,PASSWORD_ARGON2I,['memory_cost' => 8, "time_cost" => 1, "threads" => 1]
) :
$argon84 = password_hash($base,PASSWORD_ARGON2I,['memory_cost' => 8, "time_cost" => 1, "threads" => 1]);

$hash = $base.$argon84;
            for ($i = 0; $i < 5; $i++) {
                $hash = hash("sha512", $hash, true);
            }
            $hash = hash("sha512", $hash);


            $m = str_split($hash, 2);

            $duration = hexdec($m[10]).hexdec($m[15]).hexdec($m[20]).hexdec($m[23]).
                hexdec($m[31]).hexdec($m[40]).hexdec($m[45]).hexdec($m[55]);
            $duration = ltrim($duration, '0');

            $result = gmp_div($duration, $limit);

if ($result > 0 && $result <= $limit) {

?>

<?php

$ip = "$google84747474";

?>

<?php

$servername = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

?>

<?php

$username = "mobileapps84";

$date84442274444474447444744474 = date("Y-m-d");

$date844422744444744474447444744474 = date("H");

$sql12 = "INSERT INTO googleapps84 (email,date84,hour,valid)
VALUES ('$username','$date84442274444474447444744474','$date844422744444744474447444744474','1')";

?>

<?php

$googleapps84747474 = mysqli_query($conn,$sql12);

echo "$googleapps84747474";

?>

<?php

$conn->close();

?>

<?php

$argon = ($height > 10800 && ($height < 80000 || $height % 2 == 0)) ?
substr($argon84, 30) :
$argon = substr($argon84, 29);

echo "--> Submitting nonce $nonce / $argon\n";

$postData = http_build_query(
            [
                'argon'       => $argon,
                'nonce'       => $nonce,
                'private_key' => "2UH3zpbkkdfakKahxsa547xHbZcSeuFeYBuwfMzP6jE4TuwrydiAzUMB638QLgHNNPcfqwQdKmU5fdmG32Bkwykd",
                'public_key'  => $publickey,
                'address'     => "2UH3zpbkkdfakKahxsa547xHbZcSeuFeYBuwfMzP6jE4TuwrydiAzUMB638QLgHNNPcfqwQdKmU5fdmG32Bkwykd",
            ]
        );

        $opts = [
            'http' =>
                [
                    'method'  => 'POST',
                    'header'  => 'Content-type: application/x-www-form-urlencoded',
                    'content' => $postData,
                ],
        ];

        $context = stream_context_create($opts);

$res = file_get_contents("http://aro.cool/mine.php?q=submitNonce", false, $context);
$data = json_decode($res, true);

$google8474 = $data['status'];

}

$endtime = microtime(true);

$google84 = $endtime - $starttime;

$google84 = $google84 / ($google84 * $google84);

}

?>

