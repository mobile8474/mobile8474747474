<?php

error_reporting(0);

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../gosearchimagesgoogleapps8884.sh";

}

else

{

$dataurl84 = "../gosearchimages8884/gosearchimagesgoogleapps8884.sh";

}

?>

<?php

$googleappsappsappsappsapps8884 = file_get_contents("$dataurl84");

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

preg_match_all("/<div class='$nameappsapps8884' id='na'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/s", $googleappsappsappsappsapps8884, $gosearchimages844444224474);
$gosearchimages844444444474 = $gosearchimages844444224474[1];

$gosearchimages844444444474 = implode("<br>",$gosearchimages844444444474);

$gosearchimages844444444474 = explode("<br>",$gosearchimages844444444474);

?>

<?php

$googleapps84 = "0";

?>

<?php

foreach($gosearchimages844444444474 as $googleapps8444444474747474)

{

?>

<div class="googleappsappsappsgoogleapps8474" id="googlemobileappsappsgoogleapps847474744474" onclick="$('.googleappsappsappsappsappsappsapps8474').show();">

<div>

<div>

<div align="center" style="margin:12px;background-color:#ffffff;padding:12px;display:grid;box-shadow:0px 2px 8px rgba(0, 0, 0, 0.2);">

<?php

$googleapps84++;

?>

<?php

if(preg_match("/[\W\w]/","$googleapps8444444474747474"))

{

?>

<?php

if(preg_match("/png/","$googleapps8444444474747474"))

{

?>

<?php

echo "<img class='googleappsappsappsmobileappsappsappsappsapps84' src='$googleapps8444444474747474' style='width:100%;'></img>";

?>

<?php

}

else

{

?>

<video class='googleappsappsappsmobileappsappsappsappsapps84' style="width:100%;" controls>

<source src="<?php echo "$googleapps8444444474747474"; ?>" type="video/mp4" style="width:100%;">

</video>

<?php

}

?>

<?php

}

?>

</div>

</div>

</div>

</div>

<div class="googleappsappsappsappsappsappsapps8474" id="googlemobileappsapps847474744474" style="display:none;position:fixed;background:rgba(0, 0, 0, 0.4);width:100%;height:100%;left:0px;top:0px;z-index:14884;" onclick="$(this).hide();">

<div>

<div>

<div align="center" style="margin:12px;background-color:#ffffff;padding:12px;display:grid;">

<?php

$googleapps84++;

?>

<?php

if(preg_match("/[\W\w]/","$googleapps8444444474747474"))

{

?>

<?php

if(preg_match("/png/","$googleapps8444444474747474"))

{

?>

<?php

echo "<img class='googleappsappsappsmobileapps84' src='$googleapps8444444474747474' style='width:100%;'></img>";

?>

<?php

}

else

{

?>

<video style="width:100%;" controls>

<source src="<?php echo "$googleapps8444444474747474"; ?>" type="video/mp4" style="width:100%;">

</video>

<?php

}

?>

<?php

}

?>

</div>

</div>

</div>

</div>

<?php

}

?>

<link rel="stylesheet" href="textavatar.css">
<script src="jquery.textavatar.js"></script>

<style>

.inline
{
display: inline-block;
margin-top:0px!important;
margin-right:0px!important;
}

</style>

<script>

$('.textavatar').textAvatar();

var name = $('#name').val();

var size = $('#size').val();

$('#test').textAvatar({

name: name,

width: size

});
		
</script>

