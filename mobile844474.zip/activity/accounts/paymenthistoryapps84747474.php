<?php

error_reporting(0);

?>

<?php

$servername847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname847444444444744474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn84744474447444744474 = new mysqli($servername847444444444744474, $username847444444444744474, $password847444444444744474, $dbname847444444444744474);

?>

<?php

include "../dashboard/dashboardtop.php";

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../paymentsapps84747474.sh";

}

else

{

$dataurluserapps84 = "../paymentsapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='na'>\n<div class='na' id='na'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[1];

?>

<?php

$query = "SELECT * FROM paymentsapps84747474 WHERE email='$_COOKIE[username]'";

$gosearchimages84747674 = array();

$result = mysqli_query($conn84744474447444744474,$query);

foreach($result as $row)

{

$gosearchimages84747674[] = $row['payments'];

}


?>

<?php

$gosearchimages84747674 = implode("<br>",$gosearchimages84747674);

$gosearchimages84747674 = explode("<br>",$gosearchimages84747674);

?>

<div style="background-color:#ffffff;padding:12px;margin-top:12px;">

<?php

$googleappsappsappsapps84744474 = array();

?>

<?php

foreach($gosearchimages84747674 as $googleappsapps84747474)

{

$googleappsapps847474744444444474 = number_format($googleappsapps84747474, 2,'.', ',');

echo "<div class='googleappsapps84744474447444744474' align='right'>" . "$" . "$googleappsapps847474744444444474" . "<br>" . "</div>";

$googleappsappsappsapps84744474[] = "$googleappsapps84747474";

}

?>

<?php

$googleappsappsappsapps84744474 = array_sum($googleappsappsappsapps84744474);

$googleappsappsappsapps84744474 = number_format($googleappsappsappsapps84744474, 2,'.', ',');

?>

<divgoogleapps84747474>

Totals

</divgoogleapps84747474>

<divgoogleapps84747474 class="googleapps84747474" align="right" style="float:right;">

<?php echo "$" . "$googleappsappsappsapps84744474"; ?>

</divgoogleapps84747474>

</div>

<?php

include "../dashboard/dashboardbottom.php";

?>

<?php

$conn84744474447444744474->close();

?>

