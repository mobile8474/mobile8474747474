<?php

error_reporting(0);

?>

<?php

include "../dashboard/dashboardtop.php";

?>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

$googleapps84747474 = file_get_contents("https://$_SERVER[HTTP_HOST]/chatapps84747474.sh");

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)'>\n<div class='online'>\n<div class='(.*?)'>1<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps84747474, $googleapps84);
$userupdates = $googleapps84[1];

$userupdates = array_unique($userupdates);

$userupdates = implode("<br>",$userupdates);

$userupdates = explode("<br>",$userupdates);

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../userregistrations.sh";

}

else

{

$dataurl84 = "../register/userregistrations.sh";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl84");

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$namegoogleapps84747474 = openssl_decrypt($name,"AES-128-ECB",$password);

?>

<?php

$googleappsappsappsgoogleapps84747474 = "0";

?>

<div>

<style>

@media screen and (max-width:770px)
{
.googleappsappsapps84444474
{
bottom:0px!important;
width:100%!important;
left:0px!important;
}
#googleappsappsappsapps84227474
{
position:absolute;
width:100%;
left:0px;
}
}

@media screen and (min-width:770px)
{
.googleappsappsapps84444474
{
top:58px;
position:absolute;
}
.googleappsappsappsapps8474
{
}
}

</style>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlapps84 = "../accountcolor88842274.sh";

}

else

{

$dataurlurlapps84 = "../register/accountcolor88842274.sh";

}

?>

<?php

$googleappsgoogleappsappsgoogleapps8884 = file_get_contents($dataurlurlapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../accountcolor8884.sh";

}

else

{

$dataurlurlgoogleapps84 = "../register/accountcolor8884.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

foreach($userupdates as $google84747474)

{

$stringtoencrypt = "$google84747474";

$decryptedstring888474 = rawurldecode($stringtoencrypt);

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext84747474 = openssl_decrypt($decryptedstring888474,"AES-128-ECB",$password);

?>

<?php

$googleapps8884 = file_get_contents("$dataurl84");

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../firstnameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/firstnameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$google84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../lastnameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/lastnameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$google84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../usernameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/usernameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$google84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$name84747474 = "$gosearchimagesappsapps84747674 $gosearchimagesappsappsappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$name84747474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

preg_match_all("/<div class='$google84747474' id='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>1<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps84747474, $googleapps84);
$userupdatesapps84747474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/online/","$userupdatesapps84747474"))

{

?>

<?php

$googleappsappsappsgoogleapps84747474++;

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../gosearchimages8884.sh";

}

else

{

$dataurlappsappsapps84 = "../gosearchimages8884/gosearchimages8884.sh";

}

?>

<?php

$googleappsappsappsapps8884 = file_get_contents($dataurlappsappsapps84);

?>

<?php

preg_match_all("/<div class='$google84747474' id='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsappsappsapps8884, $googleappsgoogleappsappsapps84);
$gosearchimagesappsapps8474 = $googleappsgoogleappsappsapps84[2][0];

?>

<?php

preg_match_all("/<div class='$google84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleapps84);
$accountcolor84742274 = $googleapps84[3][0];

?>

<?php

preg_match_all("/<div class='$google84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor847474))

{
}

else

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/[\W\w]/",$accountcolor84742274))

{

if(preg_match("/white/",$accountcolor84742274))

{

$accountcolor44 = "#ffffff";

}

if(preg_match("/grey/",$accountcolor84742274))

{

$accountcolor44 = "#37474F";

}

}

else

{

$accountcolor44 = "#ffffff";

}

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor84742274))

{

if(preg_match("/white/",$accountcolor84742274))

{

$accountcolor84444474 = "#37474F";

}

if(preg_match("/grey/",$accountcolor84742274))

{

$accountcolor84444474 = "#f8f8f8";

}

}

else

{

$accountcolor84444474 = "#37474F";

}

?>

<?php

if(preg_match("/blue/",$accountcolor847474))

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/orange/",$accountcolor847474))

{

$accountcolor84747474 = "#EF6C00";

$accountcolor1 = "#EF6C00";

$accountcolor2 = "#FB8C00";

$accountcolor4 = "#FFA726";

}

if(preg_match("/yellow/",$accountcolor847474))

{

$accountcolor84747474 = "#F9A825";

$accountcolor1 = "#F9A825";

$accountcolor2 = "#FDD835";

$accountcolor4 = "#FFEE58";

}

if(preg_match("/purple/",$accountcolor847474))

{

$accountcolor84747474 = "#6A1B9A";

$accountcolor1 = "#6A1B9A";

$accountcolor2 = "#8E24AA";

$accountcolor4 = "#AB47BC";

}

if(preg_match("/pink/",$accountcolor847474))

{

$accountcolor84747474 = "#AD1457";

$accountcolor1 = "#AD1457";

$accountcolor2 = "#D81B60";

$accountcolor4 = "#EC407A";

}

if(preg_match("/red/",$accountcolor847474))

{

$accountcolor84747474 = "#EF5350";

$accountcolor1 = "#C62828";

$accountcolor2 = "#E53935";

$accountcolor4 = "#EF5350";

}

if(preg_match("/green/",$accountcolor847474))

{

$accountcolor84747474 = "#2E7D32";

$accountcolor1 = "#2E7D32";

$accountcolor2 = "#43A047";

$accountcolor4 = "#66BB6A";

}

if(preg_match("/[\W\w]/","$accountcolor847474"))

{

$accountcolor1 = "$accountcolor847474";

$accountcolor2 = "$accountcolor847474";

$accountcolor4 = "$accountcolor847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<?php

if(preg_match("/[\W\w]/","$name84747474"))

{

?>

<div class="googleappsappsappsapps8474" style="display:flex;border-style:solid;border-width:1px;padding:4px;border-top:none;border-left:none;border-right:none;border-color:#bdbdbd;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.2);margin-top:4px;margin:4px;" onclick='myFunctionappsappsappsgoogleapps<?php echo $googleappsappsappsgoogleapps84747474; ?>();'>

<?php

if(preg_match("/[\W\w]/",$gosearchimagesappsapps8474))

{

?>

<div id="div84747474" style="right:18px;top:18px;"><img src="<?php echo $gosearchimagesappsapps8474; ?>" width="34" height="34" style="border-radius:24px;border-radius:24px;border-color:<?php echo "$accountcolor2"; ?>;border-width:2px;box-shadow:0 2px 4px rgba(0,0,0,0.1);margin-top:4px;"></img></div>

<?php

}

else

{

?>

<?php

preg_match_all("/<div class='$google84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsappsappsapps84);
$accountcolorappsappsappsapps84742274 = $googleappsappsappsappsapps84[3][0];

?>

<?php

preg_match_all("/<div class='$google84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsappsappsapps84);
$accountcolorappsappsappsapps84747474 = $googleappsappsappsappsapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorappsappsappsapps84747474"))

{

$accountcolor1 = "$accountcolorappsappsappsapps84747474";

$accountcolor2 = "$accountcolorappsappsappsapps84747474";

$accountcolor4 = "$accountcolorappsappsappsapps84747474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsappsappsappsappsappsapps84 = "../googleappsapps84747474.sh";

}

else

{

$dataurluserappsappsappsappsappsappsapps84 = "../people/googleappsapps84747474.sh";

}

?>

<?php

$googleappsuserappsappsappsappsappsapps888474 = file_get_contents($dataurluserappsappsappsappsappsappsapps84);

?>

<?php

preg_match_all("/<div class='$google84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsappsappsapps888474, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/(^Male$|^male$)/","$gosearchimages84747674"))

{

?>

<div style='right:18px;top:8px;'>

<div>

<div class='inline'>
<img class='textavatar' src="/gosearchimages8884/googleapps84.jpg" style='width:34px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;' data-name='<?php echo "$name84747474"; ?>'></img>
</div>

</div>

</div>

<?php

}

else

{

?>

<div style='right:18px;top:8px;'>

<div>

<div class='inline'>
<img class='textavatar' src="/gosearchimages8884/googleapps84747474.jpeg" style='width:34px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;' data-name='<?php echo "$name84747474"; ?>'></img>
</div>

</div>

</div>

<?php

}

?>

<?php

}

?>

<?php

preg_match_all("/<div class='$google84747474' id='(.*?)'>\n<div class='(.*?)'>\n<div class='online'>\n<div class='(.*?)'>1<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps84747474, $googleappsgoogleapps84);
$userupdates84744474 = $googleappsgoogleapps84[3][0];

?>

<?php

if(preg_match("/mobile/",$userupdates84744474))

{

$googleappsgoogleappsappsgoogleapps84747474 = "<i class='material-icons' style='color:#3b78e7;font-size:12.4px;position:absolute;top:2px;'>phone_android</i>";

}

?>

<?php

if(preg_match("/desktop/",$userupdates84744474))

{

$googleappsgoogleappsappsgoogleapps84747474 = "<i class='material-icons' style='color:#3b78e7;font-size:12.4px;position:absolute;top:2px;'>desktop_mac</i>";

}

?>

<?php

if(preg_match("/tablet/","$userupdates84744474"))

{

$googleappsgoogleappsappsgoogleapps84747474 = "<i class='material-icons' style='color:#3b78e7;font-size:12.4px;position:absolute;top:2px;'>tablet</i>";

}

?>

<style>

@media screen and (min-width:770px)
{
.google8474
{
white-space:nowrap;
overflow:hidden;
text-overflow:ellipsis;
max-width:134px;
}
.google842222444474
{
white-space:nowrap;
overflow:hidden;
text-overflow:ellipsis;
max-width:134px;
}
}

</style>

<style>

@media screen and (max-width:770px)
{
.google8474
{
white-space:nowrap;
overflow:hidden;
text-overflow:ellipsis;
max-width:190px;
}
}

</style>

<style>

.google84224474:empty
{
display:none!important;
}

</style>

<div style="display:flex;justify-content:space-between;width:100%;margin-right:12px;">

<div style="width:100%;">

<?php

echo "<div style='display:flex;padding:12px;justify-content:space-between;position:relative;'>";

echo "<div class='google842222444474' style='font-size:14.6px;margin-top:-4px;font-weight:bold;'>";

echo "$name84747474";

echo "</div>";

echo "<div class='google8474' style='font-size:10px;position:absolute;top:26px;'>";

echo "$googleappsmobileapps84747474";

echo "</div>";

echo "<div class='google84224474' style='position:relative;background-color:#3b78e7;border-radius:24px;font-size:12px;color:#ffffff;padding-left:2px;padding-right:2px;padding-left:5.4px;padding-right:5.4px;padding-top:2px;padding-bottom:2px;font-weight:bold;left:12px;'>";

echo $googleappsmobileappsappsappsapps84747474;

echo "</div>";

echo "</div>";

?>

</div>

</div>

<?php

}

?>

</div>

<?php

$google84444474 = "$google84747474";

$google84444474 = rawurlencode($google84444474);

?>

<style>

.googleappsappsgoogleappsappsapps84
{
position:fixed;
top:0px;
width:100%;
height:100%!important;
z-index:446;
box-sizing:border-box;
top:54px!important;
left:0px;
}
.google84222274
{
position:fixed;
bottom:0px;
}

</style>

<div id="googleappsappsappsapps84227474">

<div id="google<?php echo $googleappsappsappsgoogleapps84747474; ?>" class="googleappsappsapps84444474" style="right:4px;left:240px;display:none;">

<div style="width:100%;">

<div id="minutesappsappsappsgoogleappsgoogleapps<?php echo $googleappsappsappsgoogleapps84747474; ?>" style="position:relative;"></div>

<div id="minutesappsappsappsgoogleapps<?php echo $googleappsappsappsgoogleapps84747474; ?>" style="position:relative;"></div>

<script>

var googleapps84 = "44";

function myFunctionappsappsappsgoogleapps<?php echo "$googleappsappsappsgoogleapps84747474"; ?>() {

$(document).ready(function(){

    var x = document.getElementById("google<?php echo $googleappsappsappsgoogleapps84747474; ?>");
    if (x.style.display === "none") {
        x.style.display = "block";

document.getElementsByTagName("body")[0].style.overflow = "hidden";

window.scroll(0, 0);

} else {
        x.style.display = "none";

document.getElementsByTagName("body")[0].style.overflow = "scroll";

}

$("#minutesappsappsappsgoogleappsgoogleapps<?php echo $googleappsappsappsgoogleapps84747474; ?>").load('/people/chatupdates84747474.php?between1=<?php echo "$_COOKIE[username]"; ?>&between74=<?php echo "$google84747474"; ?>&googleapps84747474=<?php echo $googleappsappsappsgoogleapps84747474; ?>');

});

}

</script>

</div>

</div>

</div>

</div>

<?php

}

?>

<?php

}

?>

</div>

<div style="display:flex;">

<div style="width:24%;">

<div style="width:100%;">

</div>

</div>

</div>

<link rel="stylesheet" href="textavatar.css">
<script src="jquery.textavatar.js"></script>

<style>

.inline
{
display: inline-block;
margin-top:0px!important;
margin-right:0px!important;
}

</style>

<script>

$('.textavatar').textAvatar();

var name = $('#name').val();

var size = $('#size').val();

$('#test').textAvatar({

name: name,

width: size

});
		
</script>

<?php

include "../dashboard/dashboardbottom.php";

?>

