<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "$isocode8884");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

include "../dashboard/dashboardtop.php";

?>

<style>

html,body
{
margin:0px;
padding:0px;
}

</style>

<link href="https://fonts.googleapis.com/css?family=Roboto:400" rel="stylesheet">

<style>

*
{
font-family:'Roboto',sans-serif;
}

</style>

<style>

.numberCircle {
    border-radius:50%;

    width:36px;
    height:36px;
    padding:8px;
    
    background:#fff;
    color:#ffffff;
    text-align:center;
    
    font:32px Arial, sans-serif;
background-color:#42A5F5;
color:#ffffff;
position:absolute;
box-shadow:0 2px 4px rgba(0,0,0,0.4);
left:12px;
}

</style>

<style>

.numberCircle84747474 {
    border-radius:50%;

    width:36px;
    height:36px;
    padding:8px;
    
    background:#fff;
    color:#ffffff;
    text-align:center;
    
    font:32px Arial, sans-serif;
background-color:#42A5F5;
color:#ffffff;
position:absolute;
box-shadow:0 2px 4px rgba(0,0,0,0.4);
right:12px;
}

</style>

<?php

$servername8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn84747474 = new mysqli($servername8474747444444474, $username8474747444444474, $password8474747444444474, $dbname8474747444444474);

?>

<div style="padding:12px;background-color:#42A5F5;">

<div style="display:flex;">

<div>

<i class="material-icons" style="color:#ffffff;cursor:pointer;" onclick="window.open('/','_self');">arrow_back</i>

</div>

<div style="position:absolute;right:12px;">

<i class="material-icons" style="color:#ffffff;">more_vert</i>

</div>

</div>

</div>

<div style="padding:12px;background-color:#f1f1f1;" align="center">

<?php

$googleapps84747474 = $_COOKIE['username'];

?>

<?php

$googleappsgooglegoogleapps8884 = array();

$query = "SELECT * FROM imagesappsapps84747474 WHERE email='$_COOKIE[username]' order by date desc";

$result = mysqli_query($conn84747474,$query);

foreach($result as $row)

{

$googleappsgooglegoogleapps8884[] = $row['imagesapps84747474'];

}

$googleappsgooglegoogleapps8884 = reset($googleappsgooglegoogleapps8884);

?>

<?php

if(preg_match("/[\W\w]/","$googleappsgooglegoogleapps8884"))

{

echo '<div style="right:12px;top:7.4px;margin-top:-4px;"><img src="data:image/jpeg;base64,'.base64_encode($googleappsgooglegoogleapps8884).'" width="112" height="112" style="box-shadow:0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);object-fit:cover;margin-top:44px;margin-bottom:12px;border-radius:296px;"></img></div>';

}

else

{

echo "<div>No images</div>";

}

?>

<div style="font-size:22.4px;margin-bottom:44px;">

<?php

$googleappsgooglegoogleapps8884 = array();

$query = "SELECT * FROM user1 WHERE email='$_COOKIE[username]' order by date desc";

$result = mysqli_query($conn84747474,$query);

foreach($result as $row)

{

$googleappsgooglegoogleapps8884[] = $row['firstname'];

}

$googleappsgooglegoogleapps8884 = reset($googleappsgooglegoogleapps8884);

$stringtoencrypt = "$googleappsgooglegoogleapps8884";

$decryptedstring888474 = rawurldecode($stringtoencrypt);

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext8474 = openssl_decrypt($decryptedstring888474,"AES-128-ECB",$password);

echo "<divapps84747474>googleapps84</divapps84747474>";

?>

<?php

$googleappsgooglegoogleapps8884 = array();

$query = "SELECT * FROM user2 WHERE email='$_COOKIE[username]' order by date desc";

$result = mysqli_query($conn84747474,$query);

foreach($result as $row)

{

$googleappsgooglegoogleapps8884[] = $row['lastname'];

}

$googleappsgooglegoogleapps8884 = reset($googleappsgooglegoogleapps8884);

$stringtoencrypt = "$googleappsgooglegoogleapps8884";

$decryptedstring888474 = rawurldecode($stringtoencrypt);

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext8474 = openssl_decrypt($decryptedstring888474,"AES-128-ECB",$password);

echo "<divapps84747474>googleapps84</divapps84747474>";

?>

<?php

$googleappsgooglegoogleapps8884 = array();

$query = "SELECT * FROM aboutapps84747474 WHERE email='$_COOKIE[username]' order by date desc";

$result = mysqli_query($conn84747474,$query);

foreach($result as $row)

{

$googleappsgooglegoogleapps8884[] = $row['about'];

}

$googleappsgooglegoogleapps8884 = reset($googleappsgooglegoogleapps8884);

$stringtoencrypt = "$googleappsgooglegoogleapps8884";

$decryptedstring888474 = rawurldecode($stringtoencrypt);

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext8474 = openssl_decrypt($decryptedstring888474,"AES-128-ECB",$password);

echo "<div style='font-size:19.4px;'>developer</div>";

?>

</div>

<div>

<?php

$googleappsgooglegoogleapps8884 = array();

$query = "SELECT * FROM coworkersapps847474744474 WHERE email='$_COOKIE[username]' order by date desc";

$result = mysqli_query($conn84747474,$query);

foreach($result as $row)

{

$googleappsgooglegoogleapps8884[] = $row['coworkers'];

}

$googleappsgooglegoogleapps8884 = count($googleappsgooglegoogleapps8884);

?>

<?php

$googleappsgooglegoogleapps888474744474 = array();

$query = "SELECT * FROM coworkersapps847474744474 WHERE coworker='$_COOKIE[username]' order by date desc";

$result = mysqli_query($conn84747474,$query);

foreach($result as $row)

{

$googleappsgooglegoogleapps888474744474[] = $row['coworkers'];

}

$googleappsgooglegoogleapps888474744474 = count($googleappsgooglegoogleapps888474744474);

?>

<?php

echo "<div style='display:flex;'>";

echo "<div style='font-size:19.4px;' align='left'><div></div><div><div class='numberCircle'>$googleappsgooglegoogleapps8884</div></div></div><div style='font-size:19.4px;position:absolute;right:12px;' align='right'><div></div><div><div class='numberCircle84747474'>$googleappsgooglegoogleapps888474744474</div></div></div>";

echo "</div>";

?>

</div>

<div>
</div>

</div>

<div style="padding:12px;background-color:#f1f1f1;">
</div>

<?php

include "../dashboard/dashboardbottom.php";

?>

