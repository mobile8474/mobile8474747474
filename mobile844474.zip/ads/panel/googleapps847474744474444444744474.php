<?php

$countryapps8884 = $_COOKIE['country'];

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn8444444444744444444474 = new mysqli($servername, $username, $password, $dbname);

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "$isocode8884");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<?php

$namegooglegoogleappsappsappsapps8474747444444444744474 = array();

$google8884 = array();

$query = "SELECT * FROM adsgoogleapps84747474 WHERE email='$_COOKIE[username]' order by date desc limit $_GET[query],8";

$result = mysqli_query($conn8444444444744444444474,$query);

foreach($result as $row)

{

$namegooglegoogleappsappsappsapps8474747444444444744474[] = $row['ID'];

}

print_r($namegooglegoogleappsappsappsapps8474747444444444744474);

$namegooglegoogleappsappsappsapps8474747444444444744474 = implode("<br>",$namegooglegoogleappsappsappsapps8474747444444444744474);

$namegooglegoogleappsappsappsapps8474747444444444744474 = explode("<br>",$namegooglegoogleappsappsappsapps8474747444444444744474);

?>

<?php

$namegooglegoogleappsappsappsapps847474744444444474447444744474 = array();

$namegooglegoogleappsappsappsapps84747474444444447444744474447444744474 = "-1";

?>

<?php

foreach($namegooglegoogleappsappsappsapps8474747444444444744474 as $googleapps84747474)

{

$google8884 = array();

$namegooglegoogleappsappsappsapps84747474444444447444744474447444744474++;

$query = "SELECT * FROM adsgoogleapps84747474 WHERE email='$_COOKIE[username]' and id='$googleapps84747474' order by date desc";

$result = mysqli_query($conn8444444444744444444474,$query);

foreach($result as $row)

{

$namegooglegoogleappsappsappsapps8474747444444444744474 = $row['url'];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps847474744474 = rawurldecode($namegooglegoogleappsappsappsapps8474747444444444744474);

$namegooglegoogleappsappsappsapps847474744474 = openssl_decrypt($namegooglegoogleappsappsappsapps847474744474,"AES-128-ECB",$password);

echo "$namegooglegoogleappsappsappsapps847474744474";

}

}

?>

<div style="display:flex;position:absolute;right:96px;bottom:-37.4px;background-color:#ffffff;padding:4px;position:absolute;right:96px;background-color:#ffffff;z-index:44;bottom:9.6px;font-size:12.8px;color:#444444;">

<div>

<?php

echo $_GET['query'] . "-";

?>

</div>

<div>

<?php

echo $_GET['query'] + 8;

?>

</div>

</div>

<div style="position:relative;background-color:#ffffff;padding:21.4px;">

<?php

if(preg_match("/0/",$_GET['query']))

{

?>

<div style="background-color:#ffffff;position:absolute;right:0px;display:inline-block;bottom:-41.8px;right:48px;color:#bdbdbd;cursor:pointer;bottom:8px;right:49.4px;border-style:solid;border-width:1px;position:absolute;border-color:#bdbdbd;display:grid;">

<i class="material-icons">keyboard_arrow_left</i>

</div>

<?php

}

else

{

?>

<div style="background-color:#ffffff;position:absolute;right:0px;display:inline-block;bottom:-41.8px;right:48px;color:#444444;cursor:pointer;bottom:8px;right:49.4px;border-style:solid;border-width:1px;position:absolute;border-color:#bdbdbd;display:grid;" onclick="window.open('/<?php echo "$google847474747474747474744474"; ?>/panel/overview.php?query=<?php echo $_GET[query] - 8; ?>&today=1','_self')">

<i class="material-icons">keyboard_arrow_left</i>

</div>

<?php

}

?>

<div style="background-color:#ffffff;position:absolute;right:0px;display:inline-block;bottom:-41.8px;right:12px;color:#444444;cursor:pointer;position:absolute;bottom:8px;right:24px;border-style:solid;border-width:1px;border-color:#bdbdbd;display:grid;" onclick="window.open('/<?php echo "$google847474747474747474744474"; ?>/panel/overview.php?query=<?php echo $_GET[query] + 8; ?>&today=1','_self')">

<i class="material-icons">keyboard_arrow_right</i>

</div>

</div>

<?php

$conn8444444444744444444474->close();

?>

