#!/bin/bash  

startme() {
    cd /var/www/html/mobile8474/
    php ./googleapps84.php &> /dev/null &
    passenger start
}

stopme() {
    pkill -f "php ./googleapps84.php"
}

case "$1" in 
    start)   startme ;;
    stop)    stopme ;;
    restart) stopme; startme ;;
    *) echo "usage: $0 start|stop|restart" >&2
       exit 1
       ;;
esac

