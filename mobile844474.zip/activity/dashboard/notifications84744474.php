<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84447422 = "../activityapps84747474";

}

else

{

$dataurlappsappsapps84447422 = "../dashboard/activityapps84747474";

}

?>

<?php

$googleappsappsappsapps84747444 = file_get_contents($dataurlappsappsapps84447422);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>/", $googleappsappsappsapps84747444, $googleappsgooglegoogleapps84);

$namegoogleapps84747474 = $googleappsgooglegoogleapps84[2][0];

?>

<?php

if(preg_match("/1/",$namegoogleapps84747474))

{

?>

<div style="position:fixed;top:0px;left:0px;height:100%;width:100%;background:rgba(0, 0, 0, 0.4);z-index:888888884;">
</div>

<div style="padding:18.8px;background-color:#ffffff;z-index:88888888884;position:absolute;text-align:right;width:100%;box-sizing:border-box;">

<?php

echo "Message on activity";

?>

</div>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84 = "../activityapps84747474";

}

else

{

$dataurlappsappsapps84 = "aboutapps84747474";

}

?>

<?php

$googleapps8884 = "<div class='$_COOKIE[username]' id='na'>" . "\n" . "<div class='0' id='na'>1</div>" . "\n" . "</div>";

?>

<?php

$filedata = "$googleapps8884";
$filedata .= file_get_contents("$dataurlappsappsapps84");
$googleapps888844 = file_put_contents("$dataurlappsappsapps84", $filedata);

echo "<div style='display:none;'>$googleapps888844</div>";

?>

<?php

}

?>

