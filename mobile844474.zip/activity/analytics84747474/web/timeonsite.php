<?php

error_reporting(0);

?>

<?php

$servername = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../timeonsite8884";

}

else

{

$dataurl = "../timeonsite8884";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl");

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

$googleusers88888872 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = "$_GET[dateanalytics]";

}

?>

<?php

$days84744474447444744474 = date("Y-m-d");

$googleapps847474 = "-1";

$googleapps847474++;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hours = $googleapps847474;

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='(.*?)-$hours'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/s", $googleapps8884, $googleapps84);
$google8884 = $googleapps84[1];

$google8884 = array();

$query = "SELECT email,date,userip,timeonsite FROM timeonsiteapps84747474 WHERE email='$decrypted_string' and date='$days84744474447444744474' order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$google8884[] = $row['timeonsite'];

}

$google84747444 = array_unique($google8884);

$google84747444 = count($google84747444);

$googleappsappsuserapps8884 = array_sum($google8884);

$googleusers88888872[] = $google84747444;

$google88888872[] = $googleappsappsuserapps8884;

?>

<?php

$google88888872 = array_filter($google88888872);

$googleusers88888872 = array_sum($googleusers88888872);

$average = array_sum($google88888872)/$googleusers88888872;

?>

<?php

$milliseconds = $average;
$time = $milliseconds / 1000;
$days = floor($time / (24*60*60));
$hours = floor(($time - ($days*24*60*60)) / (60*60));
$minutes = floor(($time - ($days*24*60*60)-($hours*60*60)) / 60);
$seconds = ($time - ($days*24*60*60) - ($hours*60*60) - ($minutes*60)) % 60;

?>

<?php

$seconds = str_pad($seconds, 2, '0', STR_PAD_RIGHT);

?>

<?php

if($hours > "0")

{

$googleapps84747474 = "<div style='display:flex;'><div style='padding-right:8px'>$hours</div>" . "<div style='font-size:12.4px;'>hours</div></div>";

}

elseif($minutes > "0")

{

$googleapps84747474 = "<div style='display:flex;'><div style='padding-right:8px'>$minutes</div>" . "<div style='font-size:12.4px;'>minutes</div></div>";

}

elseif($seconds > "0")

{

$googleapps84747474 = "<div style='display:flex;'><div style='padding-right:8px'>$seconds</div>" . "<div style='font-size:12.4px;'>seconds</div></div>";

}

?>

<?php

if($seconds < "0")

{

$googleapps84747474 = "none";

}

?>

<div>

<div style="color:#bdbdbd;">

Sessions

</div>

<div style="font-size:34px;width:100%;">

<div>

<?php

echo "$googleapps84747474";

?>

</div>

</div>

</div>

<?php

$conn->close();

?>

