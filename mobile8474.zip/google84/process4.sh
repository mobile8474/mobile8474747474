#!/bin/bash  

touch pid4.sh

startme() {

google84=$(cat pid4.sh)
   
if [[ $google84 == "" ]];

then

cd /var/www/html/mobile8474/
php ./googleapps84.php google4 &> /dev/null &

mypid=$!

echo $mypid > pid4.sh 

else

echo "google84"

fi

}

stopme() {
    kill -9 $(cat pid4.sh)

echo "" > pid4.sh

}

case "$1" in 
    start)   startme ;;
    stop)    stopme ;;
    restart) stopme; startme ;;
    *) echo "usage: $0 start|stop|restart" >&2
       exit 1
       ;;
esac

