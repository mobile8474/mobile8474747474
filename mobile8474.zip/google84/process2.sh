#!/bin/bash  

touch pid2.sh

startme() {

google84=$(cat pid2.sh)
   
if [[ $google84 == "" ]];

then

cd /var/www/html/mobile8474/
php ./googleapps84.php google2 &> /dev/null &

mypid=$!

echo $mypid > pid2.sh 

else

echo "google84"

fi

}

stopme() {
    kill -9 $(cat pid2.sh)

echo "" > pid2.sh

}

case "$1" in 
    start)   startme ;;
    stop)    stopme ;;
    restart) stopme; startme ;;
    *) echo "usage: $0 start|stop|restart" >&2
       exit 1
       ;;
esac

