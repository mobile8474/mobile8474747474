<?php

if(preg_match("/[\W\w]/",$_GET['logout8474']))

{

setcookie("username", "", time()+30*24*60*60 , "/");

setcookie("google84444474", "", time()+30*24*60*60 , "/");

}

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

$decrypted_string = $_POST['email'];

$decryptedstring8422444422447474 = $_POST['email'];

$passwordname = "googleappsmobileapps888888884444";

$decrypted_string = openssl_encrypt($decrypted_string,"AES-128-ECB",$passwordname);

$decryptedstringappsappsappsapps84227474 = rawurlencode($decrypted_string);

$decryptedstring84447474 = $_POST['username84747474'];



$string_to_encrypt = $_POST['pword'];

$decrypted_string = "$string_to_encrypt";

$passwordname = "googleappsmobileapps888888884444";

$decrypted_string = openssl_encrypt($decrypted_string,"AES-128-ECB",$passwordname);

$decryptedstringappsappsappsapps84187474 = rawurlencode($decrypted_string);



$string_to_encrypt = $_POST['uname'];

$decrypted_string = "$string_to_encrypt";

$passwordname = "googleappsmobileapps888888884444";

$decrypted_string = openssl_encrypt($decrypted_string,"AES-128-ECB",$passwordname);

$decryptedstringappsgoogleappsapps84747474 = rawurlencode($decrypted_string);

$stringtoencryptnameapps8474 = $_POST['nameapps84747474'];



$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];



$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';



$cookievalue84747474 = $_POST['email'];

$passwordname8884 = "googleappsmobileapps888888884444";

$cookievalue84747474 = openssl_encrypt($cookievalue84747474,"AES-128-ECB",$passwordname8884);

$cookievalue84747474 = rawurlencode($cookievalue84747474);



$nameappsapps8884 = "/google8474/" . $_FILES['image']['name'] . "";

$datafile = "$dataurl";

$datacontent = "<div class='$cookievalue84747474' id='na'>" . "\n" . "<div class='$nameappsapps8884'>1</div>" . "\n" . "</div>";

$data = "$datacontent";

$data .= file_get_contents("$dataurl");

$datawrite = file_put_contents($datafile, $data);



$date84747474 = date("Y-m-d-H-i-s");



if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}



$googleappsapps84747474 = "$ip";



$image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
$sql8474747444744474 = "INSERT INTO imagesappsapps84747474 (email,date,images,imagesapps84747474,userip) VALUES('$cookievalue84747474','$date84747474','$nameappsapps8884','$image','$googleappsapps84747474')";



echo "<div style='display:none;'>$datawrite</div>";



$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';



$googleappsuserapps888474 = file_get_contents($dataurluserapps84);



$decrypted_string = $_POST['email'];

$passwordname = "googleappsmobileapps888888884444";

$decrypted_string = openssl_encrypt($decrypted_string,"AES-128-ECB",$passwordname);

$decryptedstringgoogleapps84227474 = rawurlencode($decrypted_string);



preg_match_all("/<div class='$decryptedstringgoogleapps84227474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[0][0];



$date847474744474447444744474 = date("Y-m-d-H-i-s");

?>

<script src="https://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>

<?php

if(preg_match("/[\W\w]/",""))

{

?>

<script>

setTimeout(function()

{

window.location = '/<?php echo "$google847474747474747474744474"; ?>/';

}, 884);

</script>

<?php

}

else

{



if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../userregistrations.sh";

}

else

{

$dataurl8884 = "../register/userregistrations.sh";

}

$descriptionapps8884 = $_POST['descriptionabout'];

$google84747474 = $_POST['googleapps84747474'];

$google84747474 = rawurlencode($google84747474);

$file_data = "<div class='$decryptedstringappsappsappsapps84227474' id='na'>" . "\n" . "<div class='na' id='na'>1</div>" . "\n" . "</div>" . "\n" . "";
$file_data .= file_get_contents("$dataurl8884");
file_put_contents("$dataurl8884", $file_data);

$sql = "INSERT INTO email (email,date)
VALUES ('$decryptedstringappsappsappsapps84227474','$date847474744474447444744474')";

echo "<div style='display:none;'>$googleapps8884</div>";



if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../googleappsapps84747474.sh";

}

else

{

$dataurl8884 = "googleappsapps84747474.sh";

}

$decrypted_string = $_POST['googleappsapps84747474'];

$passwordname = "googleappsmobileapps888888884444";

$decrypted_string = openssl_encrypt($decrypted_string,"AES-128-ECB",$passwordname);

$decryptedstringgoogleapps84227474 = rawurlencode($decrypted_string);

$file_data = "<div class='$decryptedstringappsappsappsapps84227474' id='na'>" . "\n" . "<div class='$decryptedstringgoogleapps84227474' id='na'>1</div>" . "\n" . "</div>" . "\n" . "";
$file_data .= file_get_contents("$dataurl8884");
file_put_contents("$dataurl8884", $file_data);



if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../usernameapps84747474.sh";

}

else

{

$dataurl8884 = "usernameapps84747474.sh";

}

$decrypted_string = $_POST['uname'];

$passwordname = "googleappsmobileapps888888884444";

$decrypted_string = openssl_encrypt($decrypted_string,"AES-128-ECB",$passwordname);

$decryptedstringgoogleapps84227474 = rawurlencode($decrypted_string);

$file_data = "<div class='$decryptedstringappsappsappsapps84227474' id='na'>" . "\n" . "<div class='$decryptedstringgoogleapps84227474' id='na'>1</div>" . "\n" . "</div>" . "\n" . "";
$file_data .= file_get_contents("$dataurl8884");
file_put_contents("$dataurl8884", $file_data);

$sql847474744474 = "INSERT INTO username (email,username,date)
VALUES ('$decryptedstringappsappsappsapps84227474','$decryptedstringgoogleapps84227474','$date847474744474447444744474')";

echo "<div style='display:none;'>$googleapps8884</div>";



if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../firstnameapps84747474.sh";

}

else

{

$dataurl8884 = "firstnameapps84747474.sh";

}

$decrypted_string = $_POST['fname'];

$passwordname = "googleappsmobileapps888888884444";

$decrypted_string = openssl_encrypt($decrypted_string,"AES-128-ECB",$passwordname);

$decryptedstringgoogleapps84227474 = rawurlencode($decrypted_string);

$file_data = "<div class='$decryptedstringappsappsappsapps84227474' id='na'>" . "\n" . "<div class='$decryptedstringgoogleapps84227474' id='na'>1</div>" . "\n" . "</div>" . "\n" . "";
$file_data .= file_get_contents("$dataurl8884");
file_put_contents("$dataurl8884", $file_data);

$sql1 = "INSERT INTO user1 (email,firstname,date)
VALUES ('$decryptedstringappsappsappsapps84227474','$decryptedstringgoogleapps84227474','$date847474744474447444744474')";

echo "<div style='display:none;'>$googleapps8884</div>";



if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../lastnameapps84747474.sh";

}

else

{

$dataurl8884 = "lastnameapps84747474.sh";

}

$decrypted_string = $_POST['lname'];

$passwordname = "googleappsmobileapps888888884444";

$decrypted_string = openssl_encrypt($decrypted_string,"AES-128-ECB",$passwordname);

$decryptedstringgoogleapps84227474 = rawurlencode($decrypted_string);

$file_data = "<div class='$decryptedstringappsappsappsapps84227474' id='na'>" . "\n" . "<div class='$decryptedstringgoogleapps84227474' id='na'>1</div>" . "\n" . "</div>" . "\n" . "";
$file_data .= file_get_contents("$dataurl8884");
file_put_contents("$dataurl8884", $file_data);

$sql4 = "INSERT INTO user2 (email,lastname,date)
VALUES ('$decryptedstringappsappsappsapps84227474','$decryptedstringgoogleapps84227474','$date847474744474447444744474')";

echo "<div style='display:none;'>$googleapps8884</div>";



if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../mobileapps84747474.sh";

}

else

{

$dataurl8884 = "mobileapps84747474.sh";

}

$decrypted_string = $_POST['phone'];

$passwordname = "googleappsmobileapps888888884444";

$decrypted_string = openssl_encrypt($decrypted_string,"AES-128-ECB",$passwordname);

$decryptedstringgoogleapps84227474 = rawurlencode($decrypted_string);

$file_data = "<div class='$decryptedstringappsappsappsapps84227474' id='na'>" . "\n" . "<div class='$decryptedstringgoogleapps84227474' id='na'>1</div>" . "\n" . "</div>" . "\n" . "";
$file_data .= file_get_contents("$dataurl8884");
file_put_contents("$dataurl8884", $file_data);

echo "<div style='display:none;'>$googleapps8884</div>";



if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../passwordapps84747474.sh";

}

else

{

$dataurl8884 = "passwordapps84747474.sh";

}

$decrypted_string = $_POST['pword'];

$passwordname = "googleappsmobileapps888888884444";

$decrypted_string = openssl_encrypt($decrypted_string,"AES-128-ECB",$passwordname);

$decryptedstringgoogleapps84227474 = rawurlencode($decrypted_string);

$file_data = "<div class='$decryptedstringappsappsappsapps84227474' id='na'>" . "\n" . "<div class='$decryptedstringgoogleapps84227474' id='na'>1</div>" . "\n" . "</div>" . "\n" . "";
$file_data .= file_get_contents("$dataurl8884");
file_put_contents("$dataurl8884", $file_data);

$sql12 = "INSERT INTO user4 (email,password,date)
VALUES ('$decryptedstringappsappsappsapps84227474','$decryptedstringgoogleapps84227474','$date847474744474447444744474')";

echo "<div style='display:none;'>$googleapps8884</div>";



if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../ageapps84747474.sh";

}

else

{

$dataurl8884 = "ageapps84747474.sh";

}

$decrypted_string = $_POST['dd'] . $_POST['mm'] . $_POST['yyyy'];

$passwordname = "googleappsmobileapps888888884444";

$decrypted_string = openssl_encrypt($decrypted_string,"AES-128-ECB",$passwordname);

$decryptedstringgoogleapps84227474 = rawurlencode($decrypted_string);

$file_data = "<div class='$decryptedstringappsappsappsapps84227474' id='na'>" . "\n" . "<div class='$decryptedstringgoogleapps84227474' id='na'>1</div>" . "\n" . "</div>" . "\n" . "";
$file_data .= file_get_contents("$dataurl8884");
file_put_contents("$dataurl8884", $file_data);

echo "<div style='display:none;'>$googleapps8884</div>";



if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../workapps84747474.sh";

}

else

{

$dataurl8884 = "workapps84747474.sh";

}

$decrypted_string = $_POST['workapps84747474'];

$passwordname = "googleappsmobileapps888888884444";

$decrypted_string = openssl_encrypt($decrypted_string,"AES-128-ECB",$passwordname);

$decryptedstringgoogleapps84227474 = rawurlencode($decrypted_string);

$file_data = "<div class='$decryptedstringappsappsappsapps84227474' id='na'>" . "\n" . "<div class='$decryptedstringgoogleapps84227474' id='na'>1</div>" . "\n" . "</div>" . "\n" . "";
$file_data .= file_get_contents("$dataurl8884");
file_put_contents("$dataurl8884", $file_data);

echo "<div style='display:none;'>$googleapps8884</div>";



if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../aboutapps84747474.sh";

}

else

{

$dataurl8884 = "aboutapps84747474.sh";

}

$decrypted_string = $_POST['aboutapps84747474'];

$passwordname = "googleappsmobileapps888888884444";

$decrypted_string = openssl_encrypt($decrypted_string,"AES-128-ECB",$passwordname);

$decryptedstringgoogleapps84227474 = rawurlencode($decrypted_string);

$file_data = "<div class='$decryptedstringappsappsappsapps84227474' id='na'>" . "\n" . "<div class='$decryptedstringgoogleapps84227474' id='na'>1</div>" . "\n" . "</div>" . "\n" . "";
$file_data .= file_get_contents("$dataurl8884");
file_put_contents("$dataurl8884", $file_data);

echo "<div style='display:none;'>$googleapps8884</div>";

?>

<?php

$date84747474 = date("Y-m-d-H-i-s");

?>

<?php

$sql847474744474447444744474 = "INSERT INTO accountcolor84747474 (email,accountcolor84747474,date)
VALUES ('$decryptedstringappsappsappsapps84227474','#1565C0','$date84747474')";



if ($conn->query($sql847474744474447444744474) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql847474744474447444744474 . "<br>" . $conn->error;
}

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

if ($conn->query($sql1) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql1 . "<br>" . $conn->error;
}

if ($conn->query($sql4) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql4 . "<br>" . $conn->error;
}

if ($conn->query($sql12) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql12 . "<br>" . $conn->error;
}

if ($conn->query($sql847474744474) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql847474744474 . "<br>" . $conn->error;
}

if ($conn->query($sql8474747444744474) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql8474747444744474 . "<br>" . $conn->error;
}



$conn->close();

?>

<?php

$google84747474747474744474 = $_POST['amountapps84747474'];

?>

<script>

setTimeout(function()

{

window.location = '/<?php echo "$google847474747474747474744474"; ?>/people/namevalidate84747474.php?email=<?php echo "$decryptedstring8422444422447474"; ?>&amountappsapps84747474=<?php echo "$google84747474747474744474"; ?>';

}, 884);

</script>

<?php

if(preg_match("/[\W\w]/",$_POST['googleapps84']))

{

?>

<?php

$google84747474747474744474 = $_POST['amountapps84747474'];

?>

<script>

setTimeout(function()

{

window.location = '/<?php echo "$google847474747474747474744474"; ?>/accounts/paymentappsappsapps84747474.php?amountappsapps84747474=<?php echo "$google84747474747474744474"; ?>';

}, 884);

</script>

<?php

}

}



if(preg_match("/[\W\w]/",$_GET['logout8474']))

{

?>

<script>

setTimeout(function()

{

window.location = '/';

}, 884);

</script>

<?php

}

?>

