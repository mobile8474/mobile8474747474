<?php

error_reporting(0);

?>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<style>

@media screen and (max-width: 1022px)
{
.googleapps8884
{
margin-bottom:4px;
}
}

@media screen and (max-width: 426px)
{
.google8474
{
margin-left:-72px!important;
}
.google8474
{
white-space:nowrap;
overflow:hidden;
text-overflow:ellipsis;
max-width:154px;
}
.google84444474
{
white-space:nowrap;
overflow:hidden;
text-overflow:ellipsis;
max-width:154px;
margin-left:0px!important;
}
.google84222274
{
display:none;
}
.googledivappsappsappsapps84747474
{
}
}

@media screen and (min-width: 426px)
{
.google8474
{
margin-left:-72px!important;
}
.google8474
{
white-space:nowrap;
overflow:hidden;
text-overflow:ellipsis;
width:224px;
max-width:196px;
}
.google84444474
{
white-space:nowrap;
overflow:hidden;
text-overflow:ellipsis;
width:224px;
max-width:196px;
}
.googledivappsappsappsapps84747474
{
display:flex!important;
}
}

</style>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../analyticschartsrealtime84";

}

else

{

$dataurl = "../analyticschartsrealtime84";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl");

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$decrypted_string8884 = $_COOKIE['password'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

$google88444472 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = $_GET['dateanalytics'];

}

?>

<style>

html
{
background-color:#bdbdbd;
}

</style>

<?php

$googleapps847474 = "-1";

echo "<div style='box-shadow:0 2px 4px rgba(0,0,0,0.2);width:100%;padding:34px;box-sizing:border-box;background-color:#ffffff;font-size:14.6px;'>";

for ($google74 = 0; $google74 <= 10; $google74++)

{

$googleapps84742274++;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hours = date("H");

$unixtime = strtotime("-$googleapps847474 seconds");

$minutes = date("i",$unixtime);

$unixtime = strtotime("-$googleapps847474 seconds");

$seconds = date("s",$unixtime);

preg_match_all("/<div class='$decrypted_string' id='$decrypted_string8884'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google88842274 = $googleapps84[5][$googleapps84742274];

$google84444474 = $googleapps84[4][$googleapps84742274];

$googlemouseappsapps84747474 = $googleapps84[3][$googleapps84742274];

$google84224474 = $googleapps84[6][$googleapps84742274];

$google84222274 = $googleapps84[3][$googleapps84742274];

$googleappsapps84747474 = $googleapps84[7][$googleapps84742274];

$googleappsappsapps84747474 = $googleapps84[8][$googleapps84742274];

$googleappsappsappsapps84747474 = $googleapps84[9][$googleapps84742274];

$googleappsappsappsappsapps84747474 = $googleapps84[10][$googleapps84742274];

$googleappsappsappsappsappsappsapps84747474 = $googleapps84[1][$googleapps84742274];

$googleappsapps74 = $googleapps84[11][$googleapps84742274];

echo "<div class='googledivappsappsappsapps84747474' style='padding:30px;border-style:solid;border-top:none;border-left:none;border-right:none;border-width:1px;border-color:#ebebeb;position:relative;'>";

echo "<div style='margin-right:104px;font-size:12px;font-weight:bold;'>User</div>";

$google84747474 = "$google84222274";

echo "<div class='google8474' style='left:12.8%;font-size:12px;font-weight:bold;'>";

echo "<div style='left:12.8%;font-size:12px;font-weight:bold;'>$google88842274</div>";

echo "<div style='left:12.8%;font-size:12px;font-weight:bold;'>$google84222274</div>";

echo "<div style='left:12.8%;font-size:12px;font-weight:bold;'>$google84224474</div>";

echo "<div style='left:12.8%;font-size:12px;font-weight:bold;'>$googleappsapps84747474</div>";

$url = "$googleappsappsapps84747474";
$parse = parse_url($url);
$googlemobileappsapps84444474 = $parse['host'];

echo "<div style='left:12.8%;font-size:12px;font-weight:bold;'>$googlemobileappsapps84444474</div>";

$url = "$googleappsappsappsappsapps84747474";
$parse = parse_url($url);
$googlemobileappsappsappsapps84444474 = $parse['host'];

echo "<div style='left:12.8%;font-size:12px;font-weight:bold;'>$googlemobileappsappsappsapps84444474</div>";

echo "<div style='left:12.8%;font-size:12px;font-weight:bold;'>$googleappsapps74</div>";

echo "</div>";

echo "<div class='google84444474' style='margin-left:12px;font-size:12px;font-weight:bold;'>";

$google8474 = preg_replace("/(.*?)-(.*?)-(.*?)-(.*?)-(.*?)-(.*?)/","$1-$2-$3 $4:$5:$6",$googleappsappsappsappsappsappsapps84747474);

$date = "$google8474";

if (empty($date)) {
        return "No date provided";
    }
    $periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
    $lengths = array("60", "60", "24", "7", "4.35", "12", "10");
    $now = time();
    $unix_date = strtotime($date);
// check validity of date
    if (empty($unix_date)) {
        return "Bad date";
    }
// is it future date or past date
    if ($now > $unix_date) {
        $difference = $now - $unix_date;
        $tense = "ago";
    } else {
        $difference = $unix_date - $now;
        $tense = "";
    }
    for ($j = 0; $difference >= $lengths[$j] && $j < count($lengths) - 1; $j++) {
        $difference /= $lengths[$j];
    }
    $difference = round($difference);
    if ($difference != 1) {
        $periods[$j].= "s";
    }
    echo "$difference $periods[$j] {$tense}";

echo "</div>";

echo "</div>";

$googleappsmobileapps8884 = array_unique($google8884);

$googleappsmobileapps8884 = count($googleappsmobileapps8884);

$google88888872[] = $googleappsmobileapps8884;

$google88444472[] = $google88842274;

}

?>

<div style="display:flex;">

</div>

<?php

echo "</div>";

?>

<?php

$google88888872 = implode("<br>",$google88888872);

$google88888872 = explode("<br>",$google88888872);

?>

<?php

$google88884472 = implode("<br>",$google88444472);

$google88884472 = explode("<br>",$google88884472);

?>

<?php

$google847444 = "-19";

?>

<style>

@media screen and (max-width: 1022px)
{
.googleapps8884
{
margin-bottom:4px;
}
}

@media screen and (max-width: 426px)
{
.google8474
{
margin-left:-72px!important;
}
.google8474
{
white-space:nowrap;
overflow:hidden;
text-overflow:ellipsis;
max-width:154px;
}
.google84444474
{
white-space:nowrap;
overflow:hidden;
text-overflow:ellipsis;
max-width:154px;
margin-left:0px!important;
}
.google84222274
{
display:none;
}
.googledivappsappsappsapps84747474
{
display:grid!important;
}
}

@media screen and (min-width: 426px)
{
.google8474
{
margin-left:-72px!important;
}
.google8474
{
white-space:nowrap;
overflow:hidden;
text-overflow:ellipsis;
width:224px;
max-width:196px;
}
.google84444474
{
white-space:nowrap;
overflow:hidden;
text-overflow:ellipsis;
width:224px;
max-width:196px;
}
.googledivappsappsappsapps84747474
{
display:flex!important;
}
}

</style>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../accountcolor8884";

}

else

{

$dataurl84 = "../register/accountcolor8884";

}

?>

<?php

$googleapps8884 = file_get_contents($dataurl84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleapps8884, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor847474))

{
}

else

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

?>

<?php

if(preg_match("/blue/",$accountcolor847474))

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/orange/",$accountcolor847474))

{

$accountcolor84747474 = "#EF6C00";

$accountcolor1 = "#EF6C00";

$accountcolor2 = "#FB8C00";

$accountcolor4 = "#FFA726";

}

if(preg_match("/yellow/",$accountcolor847474))

{

$accountcolor84747474 = "#F9A825";

$accountcolor1 = "#F9A825";

$accountcolor2 = "#FDD835";

$accountcolor4 = "#FFEE58";

}

if(preg_match("/purple/",$accountcolor847474))

{

$accountcolor84747474 = "#6A1B9A";

$accountcolor1 = "#6A1B9A";

$accountcolor2 = "#8E24AA";

$accountcolor4 = "#AB47BC";

}

if(preg_match("/pink/",$accountcolor847474))

{

$accountcolor84747474 = "#AD1457";

$accountcolor1 = "#AD1457";

$accountcolor2 = "#D81B60";

$accountcolor4 = "#EC407A";

}

if(preg_match("/red/",$accountcolor847474))

{

$accountcolor84747474 = "#C62828";

$accountcolor1 = "#C62828";

$accountcolor2 = "#E53935";

$accountcolor4 = "#EF5350";

}

if(preg_match("/green/",$accountcolor847474))

{

$accountcolor84747474 = "#2E7D32";

$accountcolor1 = "#2E7D32";

$accountcolor2 = "#43A047";

$accountcolor4 = "#66BB6A";

}

?>

<?php

$google84744422 = "19";

?>

<?php

foreach($google88884472 as $google888844)

{

$google847444++;

$google84744422--;

?>

<?php

$hours8884 = date("s");

?>

<?php

$google847444 = str_pad($google847444, 2, "0", STR_PAD_LEFT);

?>

<?php

preg_match_all("/<div class='$decrypted_string' id='$decrypted_string8884'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/s", $google888844, $googleapps84);
$google88882244 = $googleapps84[2][0];

?>

<?php

if(preg_match("/1/","$google88882244"))

{

$googleapps84747474 = "background-color:$accountcolor1!important";

$googleapps8474747422 = "border-color:$accountcolor1!important";

$googleappsapps8474747422 = "padding-top:44px!important";

}

else

{

$googleapps84747474 = "background-color:#ebebeb!important";

$googleapps8474747422 = "border-color:#ebebeb!important";

$googleappsapps8474747422 = "padding-top:0px!important";

?>

<?php

}

?>

<?php

preg_match_all("/<div class='$decrypted_string' id='$decrypted_string8884'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/s", $google888844, $googleapps84);
$google88882244 = $googleapps84[2][0];

?>

<?php

preg_match_all("/<div class='$decrypted_string' id='$decrypted_string8884'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $google888844, $googleapps84);
$google88442244 = $googleapps84[3][0];

?>

<?php

preg_match_all("/<div class='$decrypted_string' id='$decrypted_string8884'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $google888844, $googleapps84);
$google88744444 = $googleapps84[4][0];

?>

<?php

preg_match_all("/<div class='$decrypted_string' id='$decrypted_string8884'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/s", $google888844, $googleapps84);
$google88744472 = $googleapps84[5][0];

?>

<?php

if(preg_match("/1/","$google88882244"))

{

?>

<?php

}

else

{

?>

<?php

}

?>

<?php

if($google847444 == 38) break;

?>

<?php

}

?>

</div>

</div>

</div>

