<?php

$servername = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "$isocode8884");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

$google8474224474747474 = $_GET['accountcolorapps84747474'];

?>

<?php

date_default_timezone_set($googleappscountryapps8884);

?>

<?php

$decryptedstring84747474 = $_COOKIE['username'];

?>

<?php

$google88888872 = array();

?>

<?php

$googleapps847474 = "-1";

for ($google74 = 0; $google74 <= 56; $google74++)

{

$googleapps847474++;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hoursgoogleapps84 = $googleapps847474;

$time84747474 = time();

$date847474744474 = strtotime('-' . "$hoursgoogleapps84" . ' minutes', "$time84747474");

$date847474744474 = date('Y-m-d-H-i', $date847474744474);

$query = "SELECT * FROM charts84747474 WHERE email='$decryptedstring84747474' and date REGEXP '$date847474744474.*'";
$result = mysqli_query($conn,$query);

$google8884 = array();

foreach($result as $row)

{

$google8884[] = $row['userip'];

}

$google8884 = array_unique($google8884);

$google8884 = count($google8884);

$google88888872[] = $google8884;

}

?>

<?php

$google88888872 = implode("<br>",$google88888872);

$google88888872 = explode("<br>",$google88888872);

$google847474744474 = "0";

$google8474747444744474 = "0";

$google84747474444444444444744474 = array();

$google847474744444444444447444744444444474 = array();

foreach($google88888872 as $google8474747474747474)

{

$google847474744474++;

$google8474747444744474++;

echo "$google8474747444744474";

$google84747474444444444444744474[] = "$google8474747474747474";

$google847474744444444444447444744444444474[] = "$google8474747444744474";

}

$google847474744444444444447444744444444474 = array_reverse($google847474744444444444447444744444444474);

$google84747474444444444444744474 = array_reverse($google84747474444444444444744474);

$google847474744444444444447444744444444474 = implode(",",$google847474744444444444447444744444444474);

$google84747474444444444444744474 = implode(",",$google84747474444444444444744474);

?>

<?php

echo "$google84747474444444444444744474";

?>

<?php

$conn->close();

?>

