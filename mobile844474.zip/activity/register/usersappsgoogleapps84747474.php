<?php

$servername8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername8474747444444474, $username8474747444444474, $password8474747444444474, $dbname8474747444444474);

?>

<?php

$name = $_POST['googleapps84747474444444744474'];

$password="googleappsmobileapps888888884444";

$name = openssl_encrypt($name,"AES-128-ECB",$password);

$name847474744474 = rawurlencode($name);

?>

<?php

$googleappsgooglegoogleapps8884 = array();

$query = "SELECT * FROM accountcolor84747474 WHERE email='$name847474744474' order by date desc limit 1";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$name = $row['accountcolor84747474'];

$googleappsgooglegoogleapps8884[] = "$name";

}

$googleappsgooglegoogleapps88847474747474747474 = implode("\n",$googleappsgooglegoogleapps8884);

?>

<?php

$googleappsgooglegoogleapps88847474747474747474 = preg_replace("/\s+/","",$googleappsgooglegoogleapps88847474747474747474);

echo "$googleappsgooglegoogleapps88847474747474747474";

?>

<?php

$conn->close();

?>

