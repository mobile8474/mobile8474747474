<?php

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

$date84747474 = date("Y-m-d-H-i-s");



if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}



$googleappsapps84747474 = "$ip";

$cookievalue84747474 = "bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D";

$image = addslashes(file_get_contents($_FILES['audio_data']['tmp_name']));
$sql8474747444744474 = "INSERT INTO googleappsappsappsapps84747474 (email,date,google84747474,userip) VALUES('$cookievalue84747474','$date84747474','$image','$googleappsapps84747474')";

?>

<?php

$googleapps84747474 = mysqli_query($conn,$sql8474747444744474);

echo "$googleapps84747474";

?>

<?php

$conn->close();

?>

