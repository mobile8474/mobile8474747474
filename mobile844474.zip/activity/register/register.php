<head>
<title>Login</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="/ads/dashboard/jquery.js" type="text/javascript"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>

<?php

$servername8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname8474747444444474 = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername8474747444444474, $username8474747444444474, $password8474747444444474, $dbname8474747444444474);

?>

<div class="google84747474747474744474" style="padding:12px;background-color:#4285f4;">

<div style="display:flex;">

<div style="display:flex;">

<div>

<i class="material-icons" style="color:#ffffff;cursor:pointer;">menu</i>

</div>

<div style="color:#ffffff;margin-left:12px;margin-top:12px;position:absolute;left:34px;top:3.4px;">

REGISTER

</div>

</div>

<div style="position:absolute;right:12px;">

<i class="material-icons" style="color:#ffffff;cursor:pointer;">more_vert</i>

</div>

</div>

</div>

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<style>

@media (min-width: 770px)
{
.google84747474
{
width:396px;
margin:0px auto!important;
margin-top:104px!important;
}
}

</style>

<style>

html,body
{
margin:0px;
padding:0px;
font-family:Varela Round, sans-serif;
background-color:#ffffff!important;
}

</style>

<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<style>
* {
  box-sizing: border-box;
}

body {
}

#regForm {
  padding:12px;
}

h1 {
  text-align: center;  
}

input {
  padding:1em;
  width: 100%;
  font-size:1em;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
}

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
}

button {
  background-color: #1565C0;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  font-family: Raleway;
  cursor: pointer;
}

button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #bbbbbb;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;  
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #1565C0;
}

.googleapps84747474
{
display:flex;
}

</style>

<?php

$googleappsgooglegoogleapps8884 = array();

$query = "SELECT * FROM email order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$name = $row['email'];

$googleappsgooglegoogleapps8884[] = "$name";

}

$googleappsgooglegoogleapps88847474747474747474 = implode("\n",$googleappsgooglegoogleapps8884);

?>

<?php

$googleappsgooglegoogleapps888444444474 = array();

$query = "SELECT * FROM user4 order by date desc";

$result8444444474 = mysqli_query($conn,$query);

foreach($result8444444474 as $row)

{

$name8444444474 = $row['password'];

$googleappsgooglegoogleapps888444444474[] = "$name8444444474";

}

$googleappsgooglegoogleapps8884747474747474747444444474 = implode("\n",$googleappsgooglegoogleapps888444444474);

?>

<script>

var timeout = null;

function doDelayedSearch(val) {
  if (timeout) {  
    clearTimeout(timeout);
  }
  timeout = setTimeout(function() {

$(document).ready(function(){

$.ajax({
    type: "POST",
    url: "usersapps84747474.php",
    data:{googleapps84747474 : val},
    success: function(data){

var google84747474447444744474 = "";

var google84747474447444744474447444744474 = "";

var data = data.trim();

if(data == "") {

$.ajax({
    type: "POST",
    url: "usersappsgoogleapps84747474.php",
    data:{googleapps84747474444444744474 : val},
    success: function(data8474747444744474){

var data8474747444744474 = data8474747444744474.trim();

$('.googleappsgoogleappsapps847444744474447444744474').show();

$('.google84747474747474744474').css('background-color','#4285f4');

$('.googleapps8474747474747474744474447444744474').css('background-color','#4285f4');

$('.googleappsgoogleappsapps847444744474447444744474').css('color','#4285f4');

$('#googleapps84747474747474747474744474447444744474').css('border-color','#4285f4');

$('#googleapps847474747474747474747444744474447444744474').css('border-color','#4285f4');

$('#googleapps84747474747474747474744474447444744474').css('border-top-right-radius','0px');

$('#googleapps847474747474747474747444744474447444744474').css('border-top-right-radius','4px');

}

}

);



}

else

{

if(val == "") {

$('.googleappsgoogleappsapps847444744474447444744474').hide();

$('.googleappsgoogleappsapps847444744474447444744474').css('color','#bdbdbd');

$('#googleapps84747474747474747474744474447444744474').css('border-color','#bdbdbd');

$('#googleapps847474747474747474747444744474447444744474').css('border-color','#bdbdbd');

$('#googleapps84747474747474747474744474447444744474').css('border-top-right-radius','4px');

$('.google84747474747474744474').css('background-color','#bdbdbd');

$('.googleapps8474747474747474744474447444744474').css('background-color','#bdbdbd');

}

else

{

$('.googleappsgoogleappsapps847444744474447444744474').hide();

$('.googleappsgoogleappsapps847444744474447444744474').css('color','#bdbdbd');

$('#googleapps84747474747474747474744474447444744474').css('border-color','#bdbdbd');

$('#googleapps847474747474747474747444744474447444744474').css('border-color','#bdbdbd');

$('#googleapps84747474747474747474744474447444744474').css('border-top-right-radius','4px');

$('.google84747474747474744474').css('background-color','#bdbdbd');

$('.googleapps8474747474747474744474447444744474').css('background-color','#bdbdbd');

}

}

}

});

});

});

}

</script>

<script>

googleapps84

var timeout = null;

function doDelayedSearch84747474(val84747474) {
  if (timeout) {  
    clearTimeout(timeout);
  }
  timeout = setTimeout(function() {

$(document).ready(function(){

var googlemobileapps844444744474 = $('#googleapps84747474747474747474744474447444744474').val();

$.ajax({
    type: "POST",
    url: "usersapps847474744474.php",
    data:{googleapps847474744474 : val84747474,google84747474 : googlemobileapps844444744474},
    success: function(data84747474){

var google847474744474447444741 = "";

var google8474747444744474447444741 = "";

var data84747474 = data84747474.trim();

var data84747474 = data84747474.indexOf('google847474744474');

if(data84747474 == '-1') {

$.ajax({
    type: "POST",
    url: "usersappsgoogleapps847474744474.php",
    data:{googleapps847474744474 : val84747474,google84747474 : googlemobileapps844444744474},
    success: function(data84747474447444744474){

var data84747474447444744474 = data84747474447444744474.trim();

$('.googleappsgoogleappsapps8474447444744474447444744474').show();

$('.googleappsgoogleappsapps8474447444744474447444744474').css('color','#4285f4');

$('#googleapps84747474747474747474744474447444744474447444444474').css('border-color','#4285f4');

$('#googleapps8474747474747474747474447444744474447444744474').css('border-color','#4285f4');

$('#googleapps8474747474747474747474447444744474447444744474').css('border-top-right-radius','4px');

$('#googleapps84747474747474747474744474447444744474447444444474').css('border-top-right-radius','0px');

}

}

);



}

else

{

if(val84747474 == "") {

$('.googleappsgoogleappsapps8474447444744474447444744474').hide();

$('.googleappsgoogleappsapps8474447444744474447444744474').css('color','#bdbdbd');

$('#googleapps84747474747474747474744474447444744474447444444474').css('border-color','#bdbdbd');

$('#googleapps8474747474747474747474447444744474447444744474').css('border-color','#bdbdbd');

$('#googleapps84747474747474747474744474447444744474447444444474').css('border-top-right-radius','4px');

}

else

{

$('.googleappsgoogleappsapps8474447444744474447444744474').hide();

$('.googleappsgoogleappsapps8474447444744474447444744474').css('color','#bdbdbd');

$('#googleapps84747474747474747474744474447444744474447444444474').css('border-color','#bdbdbd');

$('#googleapps8474747474747474747474447444744474447444744474').css('border-color','#bdbdbd');

$('#googleapps84747474747474747474744474447444744474447444444474').css('border-top-right-radius','4px');

}

}

}

});



});

});

}

</script>

<form id="regForm" action="/<?php echo "$google847474747474747474744474"; ?>/people/pageupdates84747474.php" enctype="multipart/form-data" method="post">
<!-- One "tab" for each step in the form: -->

<div class="tab">

<div class="googleapps84747474">

</div>

</div>  

<div class="tab">

<div class="googleapps84747474">

<input type="email" placeholder="Email" oninput="this.className = ''" name="email" id="googleapps84747474747474747474744474447444744474" style="background-color:#f1f1f1;outline:none;border-color:#bdbdbd;border-top-left-radius:4px;border-bottom-color:#bdbdbd;border-left:none;border-top:none;border-right:none;border-top-right-radius:4px;" autocomplete="off" onkeyup="doDelayedSearch(this.value);" required>

<i class="material-icons googleappsgoogleappsapps847444744474447444744474" id="googleapps847474747474747474747444744474447444744474" style="color:#bdbdbd;display:none;background-color:#f1f1f1;border-style:solid;outline:none;border-color:#bdbdbd;border-top-right-radius:4px;border-bottom-color:#bdbdbd;border-left:none;border-top:none;border-right:none;border-width:1px;padding:12px;">check</i>

</div>

</div>

<div class="tab">

</div>

<div class="tab">

<div class="googleapps84747474">

</div>

</div>



<div class="tab">

<div class="googleapps84747474" style="position:relative;">

<input placeholder="Password" oninput="this.className = ''" name="pword" type="password" id="googleapps84747474747474747474744474447444744474447444444474" style="background-color:#f1f1f1;margin-top:12px;outline:none;border-color:#bdbdbd;border-top-left-radius:4px;border-top-right-radius:4px;border-bottom-color:#bdbdbd;border-left:none;border-top:none;border-right:none;" autocomplete="off" onkeyup="doDelayedSearch84747474(this.value);" required>

<i class="material-icons googleappsgoogleappsapps8474447444744474447444744474" id="googleapps8474747474747474747474447444744474447444744474" style="color:#bdbdbd;display:none;background-color:#f1f1f1;border-style:solid;outline:none;border-color:#bdbdbd;border-top-right-radius:4px;border-bottom-color:#bdbdbd;border-left:none;border-top:none;border-right:none;border-width:1px;padding:12px;margin-top:12px;">check</i>

</div>

</div>

<div>

<input type="submit" value="REGISTER" class="googleapps8474747474747474744474447444744474" style="padding:1em;background-color:#4285f4;color:#ffffff;margin-top:12px;box-shadow:0 1px 4px rgba(0,0,0,0.4);cursor:pointer;outline:none;border:none;position:fixed;bottom:0px;left:0px;"></input>

</div>

</form>

<script>

$(document).ready(function(){

$('#googleimageappsmobileappsappsappsappsappsapps84').on('change', function() {

var google8474447444744474 = $('#googleimageappsmobileappsappsappsappsappsapps84').val();

$(".googleappsappsappsappsapps8474447444744474").text('success');

});

});

</script>

<?php

$googleapps84747474 = strtolower($_SERVER['HTTP_USER_AGENT']);

?>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-119997762-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-119997762-1');
</script>

<?php

$conn->close();

?>

