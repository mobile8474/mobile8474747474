<head>
<title>gcloud</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<meta name="description" content='<?php echo ""; ?>'>

<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<script type="text/javascript" src="/dashboard/jquery.js"></script>

<link rel="icon" type="image/png" href="/people/googleapps84.png">

</head>

<style>

html,body
{
margin:0px;
padding:0px;
font-family:Varela Round, sans-serif;
background-color:#ECEFF1!important;
}

</style>

<style>

@media (max-width: 770px)
{
.googleappsappsappsapps84747474
{
display:grid!important;
}
}

</style>

<link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">

<style>

*
{
font-family:'Roboto',sans-serif;
font-weight:100;
}

</style>

<div align="left">

<div style="padding:14px;background-color:#ffffff;color:#444444;box-sizing:border-box;cursor:pointer;font-weight:bold;box-shadow:0 2px 4px rgba(0,0,0,0.4);">

<divapps84 style="font-weight:normal;">G</divapps84><divapps84 style="font-weight:bold;">CLOUD</divapps84>

<divapps84 align="right">

<divapps84 style="font-weight:normal;right:12px;position:absolute;cursor:pointer;" onclick="window.open('/register/loginapps84747474.php','_self');">LOGIN</divapps84>

</divapps84>

</div>

</div>

<div align="left">

<div style="padding:14px;background-color:#ffffff;color:#444444;box-sizing:border-box;cursor:pointer;font-weight:bold;box-shadow:0 2px 4px rgba(0,0,0,0.4);z-index:44;position:relative;" onclick="window.open('/','_self');">

<divapps84 align="left">

<divapps84 style="font-weight:bold;margin-left:12px;font-size:12.8px;border-style:solid;padding:12px;border-left:none;border-right:none;border-top:none;">ALL PRODUCTS</divapps84>

</divapps84>

<divapps84 align="left">

<divapps84 style="font-weight:bold;margin-left:12px;font-size:12.8px;">ANALYTICS</divapps84>

</divapps84>

<divapps84 align="left">

<divapps84 style="font-weight:bold;margin-left:12px;font-size:12.8px;">ADS</divapps84>

</divapps84>

</div>

</div>

<div style="background-color:#ffffff;">

<div style="padding:44px;">

<div style="font-size:58px;color:#444444;">

Get your gcloud account today

</div>

<div style="padding-top:24px;color:#444444;">

Get ads and analytics from gcloud, track your user on your website or websites,with our ads you can get users to your website

</div>

<div style="padding-top:12px;">

<div style="background-color:#4285f4;;padding:12px;display:inline-block;color:#ffffff;cursor:pointer;font-weight:bold;" onclick="window.open('/register/signupapps84747474.php','_self');">

REGISTER

</div>

</div>

<div style="padding-top:12px;">

Mobile our team

<style>

@media (max-width: 770px)
{
.googleapps84744474447444744474
{
}
}

</style>

<script>

function googleappsappsappsappsapps8474747444444444444474() {

$(document).ready(function(){

setTimeout(function() {

document.getElementById("googleappsappsappsapps8474747444444444444444744474").innerHTML = "you can talk";

}, 4888);

}

);

}

function googleappsappsappsappsapps84747474447444444444444444744474() {

$(document).ready(function(){

document.getElementById("googleappsappsappsapps8474747444444444444444744474").innerHTML = "getting sales to talk to";

}

);

}

</script>

<div id="controls">

<div class="googleapps84744474447444744474" id="recordButton" style="font-size:11.8px;right:158px;top:19.6px;color:#444444;">

<i class="material-icons" style="font-size:14.8px;left:-28px;padding:8px;background-color:#4285f4;cursor:pointer;color:#ffffff;font-size:14.8px;border-radius:4px;box-shadow:0 2px 4px rgba(0,0,0,0.4);" onclick="$('#stopButton').show();$('#google847474744444744474447444744474').show();googleappsappsappsappsapps8474747444444444444474();">call</i>

</div>

</div>

</div>

</div>



<div style="width:196px;margin:0px auto;">

<button id="pauseButton" style="display:none;" disabled>Pause</button>

<div id="google847474744444744474447444744474" style="position:absolute;top:44%;display:none;background-color:#ffffff;z-index:88888844;width:196px;margin:0px auto;">

<div id="google847474744444744474447444744474447444744474" style="padding:12px;z-index:8888888844;position:relative;box-sizing:border-box;box-sizing:border-box;box-shadow:0 2px 12px rgba(0,0,0,0.4);z-index:88888844;width:196px;margin:0px auto;">

<div id="googleappsappsappsapps8474747444444444444444744474" style="font-size:14.8px;">

getting sales to talk to

</div>

<div id="stopButton" style="padding:8px;background-color:#4285f4;cursor:pointer;color:#ffffff;font-size:14.8px;border-radius:4px;box-shadow: 0 2px 4px rgba(0,0,0,0.4);z-index:88888844;" onclick="$('#google847474744444744474447444744474').hide();googleappsappsappsappsapps84747474447444444444444444744474();">close</div>

</div>

</div>



</div>

</div>

<div id="formats" style="display:none;"></div>

<ol id="recordingsList" style="display:none;"></ol>

<script>

//webkitURL is deprecated but nevertheless
URL = window.URL || window.webkitURL;

var gumStream; 						//stream from getUserMedia()
var rec; 							//Recorder.js object
var input; 							//MediaStreamAudioSourceNode we'll be recording

// shim for AudioContext when it's not avb. 
var AudioContext = window.AudioContext || window.webkitAudioContext;
var audioContext //audio context to help us record

var recordButton = document.getElementById("recordButton");
var stopButton = document.getElementById("stopButton");
var pauseButton = document.getElementById("pauseButton");

//add events to those 2 buttons
recordButton.addEventListener("click", startRecording);
stopButton.addEventListener("click", stopRecording);
pauseButton.addEventListener("click", pauseRecording);

function startRecording() {
	console.log("recordButton clicked");

	/*
		Simple constraints object, for more advanced audio features see
		https://addpipe.com/blog/audio-constraints-getusermedia/
	*/
    
    var constraints = { audio: true, video:false }

 	/*
    	Disable the record button until we get a success or fail from getUserMedia() 
	*/

	recordButton.disabled = true;
	stopButton.disabled = false;
	pauseButton.disabled = false

	/*
    	We're using the standard promise based getUserMedia() 
    	https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia
	*/

	navigator.mediaDevices.getUserMedia(constraints).then(function(stream) {
		console.log("getUserMedia() success, stream created, initializing Recorder.js ...");

		/*
			create an audio context after getUserMedia is called
			sampleRate might change after getUserMedia is called, like it does on macOS when recording through AirPods
			the sampleRate defaults to the one set in your OS for your playback device

		*/
		audioContext = new AudioContext();

		//update the format 
		document.getElementById("formats").innerHTML="Format: 1 channel pcm @ "+audioContext.sampleRate/1000+"kHz"

		/*  assign to gumStream for later use  */
		gumStream = stream;
		
		/* use the stream */
		input = audioContext.createMediaStreamSource(stream);

		/* 
			Create the Recorder object and configure to record mono sound (1 channel)
			Recording 2 channels  will double the file size
		*/
		rec = new Recorder(input,{numChannels:1})

		//start the recording process
		rec.record()

		console.log("Recording started");

	}).catch(function(err) {
	  	//enable the record button if getUserMedia() fails
    	recordButton.disabled = false;
    	stopButton.disabled = true;
    	pauseButton.disabled = true
	});
}

function pauseRecording(){
	console.log("pauseButton clicked rec.recording=",rec.recording );
	if (rec.recording){
		//pause
		rec.stop();
		pauseButton.innerHTML="Resume";
	}else{
		//resume
		rec.record()
		pauseButton.innerHTML="Pause";

	}
}

function stopRecording() {
	console.log("stopButton clicked");

	//disable the stop button, enable the record too allow for new recordings
	stopButton.disabled = true;
	recordButton.disabled = false;
	pauseButton.disabled = true;

	//reset button just in case the recording is stopped while paused
	pauseButton.innerHTML="Pause";
	
	//tell the recorder to stop the recording
	rec.stop();

	//stop microphone access
	gumStream.getAudioTracks()[0].stop();

	//create the wav blob and pass it on to createDownloadLink
	rec.exportWAV(createDownloadLink);
}

function createDownloadLink(blob) {
	
	var url = URL.createObjectURL(blob);
	var au = document.createElement('audio');
	var li = document.createElement('li');
	var link = document.createElement('a');

	//name of .wav file to use during upload and download (without extendion)
	var filename = new Date().toISOString();

	//add controls to the <audio> element
	au.controls = true;
	au.src = url;

	//save to disk link
	link.href = url;
	link.download = filename+".wav"; //download forces the browser to donwload the file using the  filename
	link.innerHTML = "Save to disk";

	//add the new audio element to li
	li.appendChild(au);
	
	//add the filename to the li
	li.appendChild(document.createTextNode(filename+".wav "))

	//add the save to disk link to li
	li.appendChild(link);
	
	//upload link
		  var xhr=new XMLHttpRequest();
		  xhr.onload=function(e) {
		      if(this.readyState === 4) {
		          console.log("Server returned: ",e.target.responseText);
		      }
		  };
		  var fd=new FormData();
		  fd.append("audio_data",blob, filename);
		  xhr.open("POST","/googleappsappsapps84/upload.php",true);
		  xhr.send(fd);

	li.appendChild(document.createTextNode (" "))//add a space in between

	//add the li element to the ol
	recordingsList.appendChild(li);

}

</script>

</div>

</div>

</div>

<div class="googleappsappsappsapps84747474" style="display:flex;background-color:#ffffff;">

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:#4285f4;font-size:44px;">bubble_chart</i>

</div>

<h3 style="font-size:24px;color:#4285f4;font-weight:bold;">Analytics</h3>

<h4 style="font-weight:bold;">Track your website users</h4>

<div style="font-size:14.8px;">Track users on your website, with an easy to use tracking code, put the javascript code on your website and view your website users on your analytics dashboard</div>

<div style="padding:12px;background-color:#4285f4;color:#ffffff;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;cursor:pointer;" onclick="window.open('/register/signupapps84747474.php','_self');">

GET ANALYTICS

</div>

<h4 style="font-weight:bold;">USERS</h4>

<div style="font-size:14.8px;font-size:44px;">999+</div>

</div>

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:#00c853;font-size:44px;">search</i>

</div>

<h3 style="font-size:24px;color:#00c853;font-weight:bold;">Ads</h3>

<h4 style="font-weight:bold;">Get users to your website</h4>

<div style="font-size:14.8px;">if you are tired of wasting money use our ads, to get users to your website,create an ad, set your budget and watch users browse your website</div>

<div style="padding:12px;background-color:#00c853;color:#ffffff;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;cursor:pointer;" onclick="window.open('/register/signupapps84747474.php','_self');">

GET ADS

</div>

<h4 style="font-weight:bold;">ADVERTISERS</h4>

<div style="font-size:14.8px;font-size:44px;">999+</div>

</div>

<div style="padding:12px;margin:12px;">

<div>

<i class="material-icons" style="color:#f4b400;font-size:44px;">attach_money</i>

</div>

<h3 style="font-size:24px;color:#f4b400;font-weight:bold;">Billing</h3>

<h4 style="font-weight:bold;">Make payments with ease</h4>

<div style="font-size:14.8px;">Billing that shows all your payments and collects data while you watch users on your website grow</div>

<div style="padding:12px;background-color:#f4b400;color:#ffffff;font-weight:bold;display:inline-block;margin-top:12px;box-shadow:0 2px 4px 0 rgba(0,0,0,0.4);font-size:14.8px;cursor:pointer;" onclick="window.open('/register/signupapps84747474.php','_self');">

BILLING

</div>

<h4 style="font-weight:bold;">PAYMENTS</h4>

<div style="font-size:14.8px;font-size:44px;">999+</div>

</div>

</div>



<div style="background-color:#f1f1f1;color:#444444;padding:44px;">

<div style="font-weight:normal;">

REGISTER FOR A ACCOUNT

<div style="font-weight:normal;font-size:44px;">

REGISTER

</div>

<div style="font-weight:normal;font-size:14.6px;margin-top:4px;">

Create an account with us, to track your users and if you want you can get ads to promote your website

</div>

<div style="background-color:#4285f4;;padding:12px;display:inline-block;color:#ffffff;margin-top:24px;margin-bottom:24px;cursor:pointer;font-weight:bold;" onclick="window.open('/register/signupapps84747474.php','_self');">

REGISTER

</div>

</div>

</div>

<div>
</div>

<?php

if(preg_match("/[\W\w]/",$_COOKIE['username']))

{

?>

<?php

$string_to_encrypt = $_COOKIE['username'];

$decrypted_string888474 = rawurldecode($string_to_encrypt);

$password = "googleappsmobileapps888888884444";

$decrypted_string8474 = openssl_decrypt($decrypted_string888474,"AES-128-ECB",$password);

?>

<script>

setTimeout(function()

{

window.location = '/ads/overview.php?today=1&googleappsappsappsapps84=ads&googleapps84=0&googleapps8474=8';

}, 884);

</script>

<?php

}

?>

<?php

$googleapps84747474 = strtolower($_SERVER['HTTP_USER_AGENT']);

?>

<script>

var googleappsappsappsapps847474744474 = location.protocol

var url84747474 = document.referrer;

var google84747474 = location.href;

var google84444474 = location.search.split('q=')[1]

var url84747474 = encodeURIComponent(url84747474);

var google84444474 = encodeURIComponent(google84444474);

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//www.gcloud.pw/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&country=ZA&referer=' + url84747474 + '&keywordsapps8474=' + google84444474 + '';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

var time,timeSite;

time=new Date();

window.onbeforeunload=function(){
timeSite=new Date()-time;
window.localStorage['timeSite']=timeSite;

var url84747474 = document.referrer;

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//www.gcloud.pw/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&country=ZA&timeonsite=' + timeSite + '';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

}

var list84747474 = document.getElementsByTagName('html')[0];

window.addEventListener('backbutton', function(){

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//www.gcloud.pw/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&useractions8884=googleapps84&country=ZA';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

});

window.addEventListener('scroll', function(){

var script = document.createElement('script');
script.src = '' + googleappsappsappsapps847474744474 + '//www.gcloud.pw/analytics/web/analytics/analytics.php?username=bzLy9WpnBGaPcmK0qWjwfk3rNvlTX9pdRr2DP1VidcE%3D&password=&useractions8884=googleapps84&country=ZA';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

});

</script>

