<link rel="stylesheet" href="https://code.getmdl.io/1.2.0/material.indigo-pink.min.css">
<script defer src="https://code.getmdl.io/1.2.0/material.min.js"></script>

<div class="googleappsappsapps8474" id="google8444447474">

<button id="show-dialog" type="button" class="mdl-button">Show Dialog</button>
	<dialog class="mdl-dialog">
		<h4 class="mdl-dialog__title">CREATE YOUR AD</h4>
		<div class="mdl-dialog__content">
			<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
				<input class="mdl-textfield__input" type="text" id="namemobileapps84747474" name="nameapps84747474">
				<label class="mdl-textfield__label" for="j-source">TITLE OF YOUR AD</label>
				<span class="mdl-textfield__error">Letters, numbers and spaces only</span>
			</div>
			<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
				<input class="mdl-textfield__input" type="text" id="j-destination" id="emailmobileapps84747474" name="username84747474">
				<label class="mdl-textfield__label" for="j-destination">DESCRIPTION OF YOUR AD</label>
				<span class="mdl-textfield__error">Letters, numbers and spaces only</span>
			</div>
			<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
				<input class="mdl-textfield__input" type="text" id="emailmobileapps84742274" name="username84747474">
				<label class="mdl-textfield__label" for="j-f__ss">URL OF YOUR AD</label>
				<span class="mdl-textfield__error">Numbers only</span>
			</div>
		</div>
		<div class="mdl-dialog__actions">
			
<div id="namemobileapps84444474" onclick="$('#google8444447474').hide();">

<div>

<button class="mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--colored mdl-shadow--2dp" id="dialog-rate_save">Save</button>

</div>

</div>

<button type="button" class="mdl-button " id="dialog-rate_clear">Clear</button>
			<button type="button" class="mdl-button close">Close</button>
		</div>
		<div id="dialog-rate_progress" class="mdl-progress mdl-js-progress mdl-progress__indeterminate" ></div>
	</dialog>	

</div>

<script>

var dialog = document.querySelector('dialog');
		var showDialogButton = document.querySelector('#show-dialog');
		if (! dialog.showModal) {
			dialogPolyfill.registerDialog(dialog);
		}
		showDialogButton.addEventListener('click', function() {
			dialog.showModal();
		});
		dialog.querySelector('.close').addEventListener('click', function() {
			dialog.close();
		});

/* Operations Using jQuery */
$(document).ready(function(){
			$('#dialog-rate_progress').hide();
		});

		$('#dialog-rate_save').click(function(){
			$('#dialog-rate_progress').show();
		});

</script>

