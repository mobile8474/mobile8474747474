<?php

$servername = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps4.sh"));

$conn8474747474747474 = new mysqli($servername, $username, $password, $dbname);

?>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "$isocode8884");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

$google84747474 = date("Y-m-d-H-m");

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$google88888872 = array();

$googleapps847474 = "-1";

for ($google74 = 0; $google74 <= 60; $google74++)

{

$googleapps847474++;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hoursgoogleapps84 = $googleapps847474;

$time84747474 = time();

$date847474744474 = strtotime('-' . "$hoursgoogleapps84" . ' seconds', "$time84747474");

$date847474744474 = date('Y-m-d-H-i-s', $date847474744474);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$date847474744474'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google8884 = $googleapps84[2];

?>

<?php

$google8884 = array();

$query = "SELECT email,userip FROM charts84747474 WHERE email='$decrypted_string' and date='$date847474744474'";

$result = mysqli_query($conn8474747474747474,$query);

foreach($result as $row)

{

$google8884[] = $row['userip'];

}

?>

<?php

$google8884 = array_unique($google8884);

$google8884 = count($google8884);

$google88888872[] = $google8884;

}

$googleapps847474744474447444744474 = array_sum($google88888872);

?>

<?php

$google88888872 = array();

$googleapps847474 = "-1";

for ($google74 = 60; $google74 <= 120; $google74++)

{

$googleapps847474++;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hoursgoogleapps84 = $googleapps847474;

$time84747474 = time();

$date847474744474 = strtotime('-' . "$hoursgoogleapps84" . ' seconds', "$time84747474");

$date847474744474 = date('Y-m-d-H-i-s', $date847474744474);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$date847474744474'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google8884 = $googleapps84[2];

?>

<?php

$google8884 = array();

$query = "SELECT email,userip FROM charts84747474 WHERE email='$decrypted_string' and date='$date847474744474'";

$result = mysqli_query($conn8474747474747474,$query);

foreach($result as $row)

{

$google8884[] = $row['userip'];

}

?>

<?php

$google8884 = array_unique($google8884);

$google8884 = count($google8884);

$google88888872[] = $google8884;

}

$googleapps84747474 = array_sum($google88888872);

?>

<?php

if($googleapps847474744474447444744474 < $googleapps84747474)

{

?>

<i class="material-icons" style="margin-right:24px;color:#444444;">trending_up</i>

<?php

}

else

{

?>

<?php

if($googleapps847474744474447444744474 == $googleapps84747474)

{

?>

<i class="material-icons" style="margin-right:24px;color:#444444;">trending_flat</i>

<?php

}

else

{

?>

<?php

if($googleapps847474744474447444744474 > $googleapps84747474)

{

?>

<i class="material-icons" style="margin-right:24px;color:#444444;">trending_down</i>

<?php

}

?>

<?php

}

?>

<?php

}

?>

<?php

$conn8474747474747474->close();

?>

