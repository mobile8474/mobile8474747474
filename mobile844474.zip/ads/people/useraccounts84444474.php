<?php

error_reporting(0);

?>

<?php

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php



$googleappsuserapps888474 = file_get_contents("$dataurluserapps84");

$googleappsuserapps888474 = array();

$googleappsuserapps8884744474 = array();

$googleappsuserapps88847444744444444474 = array();

$query = "SELECT * FROM adsgoogleapps84747474";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$namegooglegoogleappsappsappsapps8474747444444444744474 = $row['url'];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps847474744474 = rawurldecode($namegooglegoogleappsappsappsapps8474747444444444744474);

$namegooglegoogleappsappsappsapps847474744474 = openssl_decrypt($namegooglegoogleappsappsappsapps847474744474,"AES-128-ECB",$password);

$googleappsuserapps888474[] = "$namegooglegoogleappsappsappsapps847474744474";

$googleappsuserapps88847444744444444474[] = "$namegooglegoogleappsappsappsapps847474744444444474";

}

?>

<?php

if(preg_match("/[\W\w]/",$_GET['q']))

{

?>

<div style="background-color:#ffffff;padding:12px;margin:12px;margin-top:21.4px;box-shadow:rgba(0, 0, 0, 0.4) 0px 1px 2px;border-radius:4px;">

<?php

if(preg_match("/users:latest/",$_GET['q']))

{

?>

<?php

$googleappsuserapps888474 = array();

$googleappsuserapps8884744474 = array();

$query = "SELECT * FROM email order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$namegooglegoogleappsappsappsapps847474744474 = $row['email'];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps84747474 = rawurldecode($namegooglegoogleappsappsappsapps847474744474);

$namegooglegoogleappsappsappsapps84747474 = openssl_decrypt($namegooglegoogleappsappsappsapps84747474,"AES-128-ECB",$password);

$googleappsuserapps888474[] = "$namegooglegoogleappsappsappsapps84747474";

$googleappsuserapps8884744474[] = "$namegooglegoogleappsappsappsapps847474744474";

}

$googleappsuserapps888474 = array_unique($googleappsuserapps888474);

$google8474747444744474 = "0";

foreach($googleappsuserapps888474 as $googleapps84747474)

{

$google8474747444744474++;

$googleappsuserapps888474 = array();

$googleappsuserapps8884744474 = array();

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps84747474 = openssl_encrypt($googleapps84747474,"AES-128-ECB",$password);

$namegooglegoogleappsappsappsapps84747474 = rawurlencode($namegooglegoogleappsappsappsapps84747474);

$query = "SELECT * FROM useractions84747474 WHERE email='$namegooglegoogleappsappsappsapps84747474' order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$namegooglegoogleappsappsappsapps847474744474 = $row['useractions84747474'];

$googleappsuserapps8884744474[] = "$namegooglegoogleappsappsappsapps847474744474";

}

$googleappsuserapps8884744474 = reset($googleappsuserapps8884744474);

echo "<div style='white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%;'>" . "$googleapps84747474" . "</div>" . "<br>";

echo "<div style='white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%;'>" . "$googleappsuserapps8884744474" . "</div>" . "<br>";

if ($google8474747444744474 == "12") break;

}

?>

</div>

<?php

}

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_GET['q']))

{

?>

<div style="background-color:#ffffff;padding:12px;margin:12px;margin-top:21.4px;box-shadow:rgba(0, 0, 0, 0.4) 0px 1px 2px;border-radius:4px;">

<?php

if(preg_match("/ads:latest/",$_GET['q']))

{

?>

<?php

$googleappsuserapps888474 = array();

$googleappsuserapps8884744474 = array();

$query = "SELECT * FROM adsgoogleapps84747474 order by date desc";

$result = mysqli_query($conn,$query);

foreach($result as $row)

{

$namegooglegoogleappsappsappsapps847474744474 = $row['url'];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps84747474 = rawurldecode($namegooglegoogleappsappsappsapps847474744474);

$namegooglegoogleappsappsappsapps84747474 = openssl_decrypt($namegooglegoogleappsappsappsapps84747474,"AES-128-ECB",$password);

$googleappsuserapps888474[] = "$namegooglegoogleappsappsappsapps84747474";

$googleappsuserapps8884744474[] = "$namegooglegoogleappsappsappsapps847474744474";

}

$googleappsuserapps888474 = array_unique($googleappsuserapps888474);

$google8474747444744474 = "0";

foreach($googleappsuserapps888474 as $googleapps84747474)

{

$google8474747444744474++;

echo "<div style='white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%;'>" . "$googleapps84747474" . "</div>" . "<br>";

if ($google8474747444744474 == "12") break;

}

?>

</div>

<?php

}

?>

<?php

}

?>

<?php

$conn->close();

?>

