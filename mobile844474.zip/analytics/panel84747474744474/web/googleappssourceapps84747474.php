<?php

$countryapps8884 = $_COOKIE['country'];

$servername84747474444444744474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps84.sh"));
$username84747474444444744474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps1.sh"));
$password84747474444444744474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps2.sh"));
$dbname84747474444444744474 = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps4.sh"));

$conn84747474 = new mysqli($servername84747474444444744474, $username84747474444444744474, $password84747474444444744474, $dbname84747474444444744474);

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "$isocode8884");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

include "../../dashboard/dashboardtop.php";

?>

<?php

$google847474744474 = date("Y-m-d");

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>1<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google8884 = $googleapps84[9];

$google847474744474447444744474 = $_COOKIE['username'];

$query = "SELECT email,date,referer FROM charts84747474 WHERE email='$google847474744474447444744474' and date REGEXP '$google847474744474.*'";
$result = $conn84747474->query($query);

$google8884 = array();

while($row = $result->fetch_array())

{

$google8884[] = $row['referer'];

}

$google8884 = implode("<br>",$google8884);

$google8884 = explode("<br>",$google8884);

?>

<?php

?>

<?php

$googleapps847474744474 = array();

$googleappsgoogleapps847474744474 = array();

foreach($google8884 as $googleappsapps84747474)

{

$url = "$googleappsapps84747474";
$parse = parse_url($url);

$googleapps847474744474[] = $parse['host'];

$googleappsgoogleapps847474744474[] = $parse['host'];

}

?>

<?php

$googleapps847474744474 = array_filter($googleapps847474744474);

$googleapps847474744474 = array_count_values($googleapps847474744474);

$googleappsgooglegooglegooglegoogleapps847474744474 = array_filter($googleappsgooglegooglegooglegoogleapps847474744474);

$googleappsgooglegooglegooglegoogleapps847474744474 = array_count_values($googleappsgoogleapps847474744474);

$googleapps847474744474 = implode("<br>",$googleapps847474744474);

$googleapps847474744474 = explode("<br>",$googleapps847474744474);

$googleappsgoogleapps847474744474 = implode("<br>",$googleappsgoogleapps847474744474);

$googleappsgoogleapps847474744474 = explode("<br>",$googleappsgoogleapps847474744474);

$google847474444444444474 = array_keys($googleappsgooglegooglegooglegoogleapps847474744474);

?>

<div style="position:relative;margin-bottom:96px;">

<div>

<div style="margin-top:12px;background-color:#ffffff;margin:12px;word-wrap:break-word;box-shadow:0 2px 12px rgba(0,0,0,1);">

<?php

$google8474747444744474 = "0";

$googleappsappsappsapps8474747444744474 = "-1";

$googleappsappsappsappsappsapps8474747444744474 = array();

foreach($googleapps847474744474 as $googleapps84222274 => $google84747474)

{

$googleappsappsappsappsappsapps8474747444744474[] = "$google84747474";

}

?>

<?php

foreach($googleapps847474744474 as $googleapps84222274 => $google84747474)

{

$google8474747444744474++;

$googleappsappsappsapps8474747444744474++;

if ($googleapps84222274 < $_GET['googleapps84']) continue;

$googleappsgooglegoogleapps84747474 = $googleappsgoogleapps847474744474[$googleapps84222274];

echo "<div style='display:flex;display:flex;border-style:solid;border-width:1px;border-color:#bdbdbd;border-top:none;border-left:none;border-right:none;font-size:12.8px;'><div style='padding:12px;padding:12px;border-style:solid;border-left:none;border-top:none;border-bottom:none;border-width:1px;border-color:#bdbdbd;
'>$google8474747444744474</div>" . "<div style='padding:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%;'>" . $google847474444444444474[$googleappsappsappsapps8474747444744474] . "</div>" . "<div style='margin-left:4px;padding:12px;font-weight:bold;'>$google84747474</div></div>";

if ($googleapps84222274 > $_GET['googleapps8474']) break;

}

?>

<div style="position:relative;background-color:#ffffff;padding:21.4px;margin-left:12px;margin-right:12px;">

<div style="background-color:#ffffff;position:absolute;right:0px;display:inline-block;bottom:-41.8px;right:48px;color:#444444;cursor:pointer;bottom:8px;right:49.4px;border-style:solid;border-width:1px;position:absolute;border-color:#bdbdbd;display:grid;" onclick="window.open('/analytics/panel/web/googleappssourceapps84747474.php?googleapps84=<?php echo $_GET[googleapps84] - 8; ?>&googleapps8474=<?php echo $_GET[googleapps8474] - 8; ?>&googleappsappsapps84=analytics','_self')">

<i class="material-icons">keyboard_arrow_left</i>

</div>

<div style="background-color:#ffffff;position:absolute;right:0px;display:inline-block;bottom:-41.8px;right:12px;color:#444444;cursor:pointer;position:absolute;bottom:8px;right:24px;border-style:solid;border-width:1px;border-color:#bdbdbd;display:grid;" onclick="window.open('/analytics/panel/web/googleappssourceapps84747474.php?googleapps84=<?php echo $_GET[googleapps84] + 8; ?>&googleapps8474=<?php echo $_GET[googleapps8474] + 8; ?>&googleappsappsapps84=analytics','_self')">

<i class="material-icons">keyboard_arrow_right</i>

</div>

</div>

</div>



</div>

</div>

<?php

include "../../dashboard/dashboardbottom.php";

?>

<?php

$conn84747474->close();

?>

