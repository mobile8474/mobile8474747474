#!/bin/bash  

startme() {
    cd /var/www/html/mobile8474/
    php ./googleapps84.php &> /dev/null &
    mypid=$!
    echo $mypid > pid1.sh
}

stopme() {
    kill -9 $(cat pid1.sh)

}

case "$1" in 
    start)   startme ;;
    stop)    stopme ;;
    restart) stopme; startme ;;
    *) echo "usage: $0 start|stop|restart" >&2
       exit 1
       ;;
esac

