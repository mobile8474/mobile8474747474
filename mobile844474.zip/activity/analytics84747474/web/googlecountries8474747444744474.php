<?php

$servername = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "$isocode8884");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

$google8474224474747474 = $_GET['accountcolorapps84747474'];

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

if(preg_match("/[\W\w]/",$_GET['week']))

{

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../daysapps84747474";

}

else

{

$dataurl = "../daysapps84747474";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl");

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$decrypted_string8884 = $_COOKIE['password'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = $_GET['dateanalytics'];

}

?>

<?php

$googleapps847474 = "-1";

$googleapps847474 = preg_replace("/(.*)-(.*)-(.*)/","$3",$_GET['dateanalytics']);

$googleapps847474 = $googleapps847474 + 1;

$googleapps847474--;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$googleapps84444474 = $googleapps847474;

$googleappsappsapps84 = preg_replace("/(.*)-(.*)-(.*)/","$1",$_GET['dateanalytics']);

$googleappsappsapps84747474 = preg_replace("/(.*)-(.*)-(.*)/","$2",$_GET['dateanalytics']);

$googleappsappsapps84444474 = str_replace("(.*?)-(.*?)-(.*?)","$3",$_GET['dateanalytics']);

$googlemobileapps1 = date('Y-m-d', strtotime('today'));
$googlemobileapps2 = date('Y-m-d', strtotime('-1 day'));
$googlemobileapps3 = date('Y-m-d', strtotime('-2 day'));
$googlemobileapps4 = date('Y-m-d', strtotime('-3 day'));
$googlemobileapps5 = date('Y-m-d', strtotime('-4 day'));
$googlemobileapps6 = date('Y-m-d', strtotime('-5 day'));
$googlemobileapps7 = date('Y-m-d', strtotime('-6 day'));

$googlemobileappsapps1 = date("M d", strtotime('today'));
$googlemobileappsapps2 = date("M d", strtotime('-1 day'));
$googlemobileappsapps3 = date("M d", strtotime('-2 day'));
$googlemobileappsapps4 = date("M d", strtotime('-3 day'));
$googlemobileappsapps5 = date("M d", strtotime('-4 day'));
$googlemobileappsapps6 = date("M d", strtotime('-5 day'));
$googlemobileappsapps7 = date("M d", strtotime('-6 day'));

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps1'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google1 = $googleapps84[2];

$google1 = array_unique($google1);

$google1 = count($google1);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps2'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google2 = $googleapps84[2];

$google2 = array_unique($google2);

$google2 = count($google2);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps3'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google3 = $googleapps84[2];

$google3 = array_unique($google3);

$google3 = count($google3);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps4'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google4 = $googleapps84[2];

$google4 = array_unique($google4);

$google4 = count($google4);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps5'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google5 = $googleapps84[2];

$google5 = array_unique($google5);

$google5 = count($google5);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps6'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google6 = $googleapps84[2];

$google6 = array_unique($google6);

$google6 = count($google6);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$googlemobileapps7'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google7 = $googleapps84[2];

$google7 = array_unique($google7);

$google7 = count($google7);

$google88888872[] = $google8884;

?>

<?php

$googleappsapps847444 = $google88888872[0];

$googleappsapps1 = $google88888872[1];

$googleappsapps2 = $google88888872[2];

$googleappsapps3 = $googleappsgoogleapps3;

$googleappsapps4 = $google88888872[4];

$googleappsapps5 = $google88888872[5];

$googleappsapps6 = $google88888872[6];

?>

<div style="height:296px">

<canvas id="myChart84747474" width="400" height="400" style="background-color:#ffffff;"></canvas>

</div>

<script>

var ctx = document.getElementById("myChart84747474").getContext('2d');

var myChart = new Chart(ctx, {
type: 'line',
    data: {
        labels: ['<?php echo $googlemobileappsapps7; ?>', '<?php echo $googlemobileappsapps6; ?>', '<?php echo $googlemobileappsapps5; ?>', '<?php echo $googlemobileappsapps4; ?>', '<?php echo $googlemobileappsapps3; ?>', '<?php echo $googlemobileappsapps2; ?>', '<?php echo $googlemobileappsapps1; ?>'],
        datasets: [{
            label: 'All Traffic',
data: [<?php echo "$google7"; ?>, <?php echo "$google6"; ?>, <?php echo "$google5"; ?>, <?php echo "$google4"; ?>, <?php echo "$google3"; ?>, <?php echo "$google2"; ?>, <?php echo "$google1"; ?>],

backgroundColor:'',
borderColor:'<?php echo "#". $google8474224474747474; ?>',
borderWidth: 4,

fill: false,

borderColor:'<?php echo "#". $google8474224474747474; ?>',
backgroundColor: '<?php echo "#". $google8474224474747474; ?>',
fill: false,
pointBorderColor: 'rgba(0, 0, 0, 0)',
pointBackgroundColor: 'rgba(0, 0, 0, 0)',
pointHoverBackgroundColor: '<?php echo "#". $google8474224474747474; ?>',
pointHoverBorderColor: '#4285f4',

}]

},

options: {

responsive:true,
maintainAspectRatio:false,

spanGaps: false,
elements: {
line: {
tension: 0.000001,
}

},

tooltips: {
backgroundColor: '#ffffff',
titleFontSize: 16,
titleFontColor: '#444444',
bodyFontColor: '#222222',
bodyFontSize: 14,
displayColors: false,
mode: 'x-axis',
bodyPadding: 8,
Padding: 8,
},

scales: {
            yAxes: [{
                ticks: {
                    fontColor: "rgba(0,0,0,0.5)",
                    fontStyle: "bold",
                    beginAtZero: true,
                    maxTicksLimit: 5,
                    padding: 20,

},
                gridLines: {
                    drawTicks: false,
                    display: false,
                }
}],
            xAxes: [{
                gridLines: {
                    zeroLineColor: "transparent",
},
                ticks: {
                    padding: 18,
                    fontColor: "rgba(0,0,0,0.5)",
                    fontStyle: "bold",

}
            }]

        }
    }
});
</script>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_GET['today']))

{

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../analyticschartsrealtime84";

}

else

{

$dataurl = "../analyticschartsrealtime84";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl");

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$decrypted_string8884 = $_COOKIE['password'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = $_GET['dateanalytics'];

}

?>

<?php

$google84747474 = date("Y-m-d-H-m");

?>

<?php

$googleapps847474 = "-1";

for ($google74 = 0; $google74 <= 30; $google74++)

{

$googleapps847474++;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hoursgoogleapps84 = $googleapps847474;

$time84747474 = time();

$date847474744474 = strtotime('-' . "$hoursgoogleapps84" . ' seconds', "$time84747474");

$date847474744474 = date('Y-m-d-H-i-s', $date847474744474);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$date847474744474'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google8884 = $googleapps84[2];

$query = "SELECT email,date,userip FROM charts84747474 WHERE email='$decrypted_string' and date='$date847474744474'";
$result = $conn->query($query);

$google8884 = array();

while($row = $result->fetch_array())

{

$google8884[] = $row['userip'];

}

$google8884 = array_unique($google8884);

$google8884 = count($google8884);

$google88888872[] = $google8884;

}

?>

<?php

$google847444 = $google88888872[0];

$google1 = $google88888872[1];

$google2 = $google88888872[2];

$google3 = $google88888872[3];

$google4 = $google88888872[4];

$google5 = $google88888872[5];

$google6 = $google88888872[6];

$google7 = $google88888872[7];

$google8 = $google88888872[8];

$google9 = $google88888872[9];

$google10 = $google88888872[10];

$google11 = $google88888872[11];

$google12 = $google88888872[12];

$google13 = $google88888872[13];

$google14 = $google88888872[14];

$google15 = $google88888872[15];

$google16 = $google88888872[16];

$google17 = $google88888872[17];

$google18 = $google88888872[18];

$google19 = $google88888872[19];

$google20 = $google88888872[20];

$google21 = $google88888872[21];

$google22 = $google88888872[22];

$google23 = $google88888872[23];

$google24 = $google88888872[24];

$google25 = $google88888872[25];

$google26 = $google88888872[26];

$google27 = $google88888872[27];

$google28 = $google88888872[28];

$google29 = $google88888872[29];

$google30 = $google88888872[30];

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../analyticschartsrealtime84";

}

else

{

$dataurl = "../analyticschartsrealtime84";

}

?>

<?php

$userdata = file_get_contents("$dataurl");

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$decrypted_string8884 = $_COOKIE['password'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = $_GET['dateanalytics'];

}

?>

<?php

$username = $_COOKIE['username'];

?>

<?php

$password = $_COOKIE['password'];

?>

<?php

$googleapps847474 = "-1";

for ($google74 = 0; $google74 <= 60; $google74++)

{

$googleapps847474++;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hours = $googleapps847474;

$dateapps84747474 = $_GET['dateanalytics'];



preg_match_all("/<div class='$username' id='na'>\n<div class='$google84747474-$hours'>\n<div class='https:\/\/www.google(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $userdata, $userdata8884);
$usergoogleappsgoogleapps8474 = $userdata8884[2];

$usergoogleappsgoogleapps8474 = array_unique($usergoogleappsgoogleapps8474);

$usergoogleappsapps1 = count($usergoogleappsgoogleapps8474);

preg_match_all("/<div class='$username' id='na'>\n<div class='$google84747474-$hours'>\n<div class='http:\/\/www.google(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $userdata, $userdata8884);
$usergoogleappsgoogleapps1 = $userdata8884[2];

$usergoogleappsgoogleapps1 = array_unique($usergoogleappsgoogleapps1);

$usergoogleappsapps2 = count($usergoogleappsgoogleapps1);

preg_match_all("/<div class='$username' id='na'>\n<div class='$google84747474-$hours'>\n<div class='android-app:\/\/(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $userdata, $userdata8884);
$usergoogleappsgoogleapps4 = $userdata8884[2];

$usergoogleappsgoogleapps4 = array_unique($usergoogleappsgoogleapps4);

$usergoogleappsapps4 = count($usergoogleappsgoogleapps4);

$usergoogle847444 = array("$usergoogleappsapps1","$usergoogleappsapps2","$usergoogleappsapps4");

$google8884 = array_sum($usergoogle847444);

$google88888872[] = $google8884;

}

?>

<?php

$googleapps847444 = $google88888872[0];

$googleapps1 = $google88888872[1];

$googleapps2 = $google88888872[2];

$googleapps3 = $google88888872[3];

$googleapps4 = $google88888872[4];

$googleapps5 = $google88888872[5];

$googleapps6 = $google88888872[6];

$googleapps7 = $google88888872[7];

$googleapps8 = $google88888872[8];

$googleapps9 = $google88888872[9];

$googleapps10 = $google88888872[10];

$googleapps11 = $google88888872[11];

$googleapps12 = $google88888872[12];

$googleapps13 = $google88888872[13];

$googleapps14 = $google88888872[14];

$googleapps15 = $google88888872[15];

$googleapps16 = $google88888872[16];

$googleapps17 = $google88888872[17];

$googleapps18 = $google88888872[18];

$googleapps19 = $google88888872[19];

$googleapps20 = $google88888872[20];

$googleapps21 = $google88888872[21];

$googleapps22 = $google88888872[22];

$googleapps23 = $google88888872[23];

$googleapps24 = $google88888872[24];

?>

<style>

.canvas-con {
    display: flex;
    align-items:center;
    justify-content: center;
    min-height: 365px;
    position: relative;
}

.canvas-con-inner {
    height: 100%;
}

.canvas-con-inner, .legend-con {
    display: inline-block;
}

.legend-con {
    font-family: Roboto;
    display: inline-block;

    ul {
        list-style: none;
    }

    li {
        display: flex;
        align-items: center;
        margin-bottom: 4px;

        span {
            display: inline-block;
        }

        span.chart-legend {
            width: 25px;
            height: 25px;
            margin-right: 10px;
        }
    }
}

</style>

<div class="canvas-con">
    <div class="canvas-con-inner">
        <canvas id="mychart" height="250px"></canvas>
    </div>
    <div id="my-legend-con" class="legend-con"></div>
</div>

<script>

var chartData = [{"visitor": 39, "visit": 1}, {"visitor": 18, "visit": 2}, {"visitor": 9, "visit": 3}, {"visitor": 5, "visit": 4}, {"visitor": 6, "visit": 5}, {"visitor": 5, "visit": 6}]

var visitorData = [],
    visitData = [];

for (var i = 0; i < chartData.length; i++) {
    visitorData.push(chartData[i]['visitor'])
    visitData.push(chartData[i]['visit'])
}

var myChart = new Chart(document.getElementById('mychart'), {
    type: 'doughnut',
    animation:{
        animateScale:true
    },
    data: {
        labels: visitData,
        datasets: [{
            label: 'Visitor',
            data: visitorData,
            backgroundColor: [
                "#a2d6c4",
                "#36A2EB",
                "#3e8787",
                "#579aac",
                "#7dcfe8",
                "#b3dfe7",
            ]
        }]
    },
    options: {
        responsive: true,
        legend: false,
        legendCallback: function() {
            var legendHtml = [];
            legendHtml.push('<ul>');
            var item = chart.data.datasets[0];
            for (var i=0; i < item.data.length; i++) {
                legendHtml.push('<li>');
                legendHtml.push('<span class="chart-legend" style="background-color:' + item.backgroundColor[i] +'"></span>');
                legendHtml.push('<span class="chart-legend-label-text">' + item.data[i] + ' person - '+chart.data.labels[i]+' times</span>');
                legendHtml.push('</li>');
            }

            legendHtml.push('</ul>');
            return legendHtml.join("");
        },
        tooltips: {
             enabled: true,
             mode: 'label',
             callbacks: {
                label: function(tooltipItem, data) {
                    var indice = tooltipItem.index;
                    return data.datasets[0].data[indice] + " person visited " + data.labels[indice] + ' times';
                }
             }
         },
    }
});

$('#my-legend-con').html(myChart.generateLegend());

console.log(document.getElementById('my-legend-con'));

</script>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_GET['yesterday']))

{

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../analyticschartsrealtime84";

}

else

{

$dataurl = "../analyticschartsrealtime84";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl");

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$decrypted_string8884 = $_COOKIE['password'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = $_GET['dateanalytics'];

}

?>

<?php

$google84747474 = date("Y-m-d");

$google84444474 = date('Y-m-d', strtotime('-1 day'));

?>

<?php

$googleapps847474 = "-1";

for ($google74 = 0; $google74 <= 30; $google74++)

{

$googleapps847474++;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hoursgoogleapps84 = $googleapps847474;

$time84747474 = time();

$date847474744474 = strtotime('-' . "$hoursgoogleapps84" . ' minutes', "$time84747474");

$date847474744474 = date('Y-m-d-H-i', $date847474744474);

preg_match_all("/<div class='$decrypted_string' id='na'>\n<div class='$date847474744474.*'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$google8884 = $googleapps84[2];

$query = "SELECT email,date,userip FROM charts84747474 WHERE email='$decrypted_string' and date REGEXP '$date847474744474.*'";
$result = $conn->query($query);

$google8884 = array();

while($row = $result->fetch_array())

{

$google8884[] = $row['userip'];

}

$google8884 = array_unique($google8884);

$google8884 = count($google8884);

$google88888872[] = $google8884;

}

?>

<?php

$google847444 = $google88888872[0];

$google1 = $google88888872[1];

$google2 = $google88888872[2];

$google3 = $google88888872[3];

$google4 = $google88888872[4];

$google5 = $google88888872[5];

$google6 = $google88888872[6];

$google7 = $google88888872[7];

$google8 = $google88888872[8];

$google9 = $google88888872[9];

$google10 = $google88888872[10];

$google11 = $google88888872[11];

$google12 = $google88888872[12];

$google13 = $google88888872[13];

$google14 = $google88888872[14];

$google15 = $google88888872[15];

$google16 = $google88888872[16];

$google17 = $google88888872[17];

$google18 = $google88888872[18];

$google19 = $google88888872[19];

$google20 = $google88888872[20];

$google21 = $google88888872[21];

$google22 = $google88888872[22];

$google23 = $google88888872[23];

$google24 = $google88888872[24];

$google25 = $google88888872[25];

$google26 = $google88888872[26];

$google27 = $google88888872[27];

$google28 = $google88888872[28];

$google29 = $google88888872[29];

$google30 = $google88888872[30];

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl = "../analyticsgoogle8474";

}

else

{

$dataurl = "../analyticsgoogle8474";

}

?>

<?php

$userdata = file_get_contents("$dataurl");

?>

<?php

$decrypted_string = $_COOKIE['username'];

?>

<?php

$decrypted_string8884 = $_COOKIE['password'];

?>

<?php

$date8884 = date("Y-m");

?>

<?php

$google88888872 = array();

?>

<?php

if(preg_match("/[\W\w]/",$_GET['dateanalytics847444']))

{

$dateanalytics8474 = "2(.*?)-(.*?)-(.*?)";

}

else

{

$dateanalytics8474 = $_GET['dateanalytics'];

}

?>

<?php

$username = $_COOKIE['username'];

?>

<?php

$password = $_COOKIE['password'];

?>

<?php

$googleapps847474 = "-1";

for ($google74 = 0; $google74 <= 24; $google74++)

{

$googleapps847474++;

$googleapps847474 = str_pad($googleapps847474, 2, "0", STR_PAD_LEFT);

$days = date("d");

$hours = $googleapps847474;

$dateapps84747474 = $_GET['dateanalytics'];



preg_match_all("/<div class='$username' id='na'>\n<div class='$google84444474-$hours'>\n<div class='https:\/\/www.google(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $userdata, $userdata8884);
$usergoogleappsgoogleapps8474 = $userdata8884[2];

$usergoogleappsgoogleapps8474 = array_unique($usergoogleappsgoogleapps8474);

$usergoogleappsapps1 = count($usergoogleappsgoogleapps8474);

preg_match_all("/<div class='$username' id='na'>\n<div class='$google84444474-$hours'>\n<div class='http:\/\/www.google(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $userdata, $userdata8884);
$usergoogleappsgoogleapps1 = $userdata8884[2];

$usergoogleappsgoogleapps1 = array_unique($usergoogleappsgoogleapps1);

$usergoogleappsapps2 = count($usergoogleappsgoogleapps1);

preg_match_all("/<div class='$username' id='na'>\n<div class='$google84444474-$hours'>\n<div class='android-app:\/\/(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>\n<\/div>/", $userdata, $userdata8884);
$usergoogleappsgoogleapps4 = $userdata8884[2];

$usergoogleappsgoogleapps4 = array_unique($usergoogleappsgoogleapps4);

$usergoogleappsapps4 = count($usergoogleappsgoogleapps4);

$usergoogle847444 = array("$usergoogleappsapps1","$usergoogleappsapps2","$usergoogleappsapps4");

$google8884 = array_sum($usergoogle847444);

$google88888872[] = $google8884;

}

?>

<?php

$googleapps847444 = $google88888872[0];

$googleapps1 = $google88888872[1];

$googleapps2 = $google88888872[2];

$googleapps3 = $google88888872[3];

$googleapps4 = $google88888872[4];

$googleapps5 = $google88888872[5];

$googleapps6 = $google88888872[6];

$googleapps7 = $google88888872[7];

$googleapps8 = $google88888872[8];

$googleapps9 = $google88888872[9];

$googleapps10 = $google88888872[10];

$googleapps11 = $google88888872[11];

$googleapps12 = $google88888872[12];

$googleapps13 = $google88888872[13];

$googleapps14 = $google88888872[14];

$googleapps15 = $google88888872[15];

$googleapps16 = $google88888872[16];

$googleapps17 = $google88888872[17];

$googleapps18 = $google88888872[18];

$googleapps19 = $google88888872[19];

$googleapps20 = $google88888872[20];

$googleapps21 = $google88888872[21];

$googleapps22 = $google88888872[22];

$googleapps23 = $google88888872[23];

$googleapps24 = $google88888872[24];

?>

<div style="height:296px">

<canvas id="myChart" width="400" height="400"></canvas>

</div>

<script>

var ctx = document.getElementById("myChart").getContext('2d');

var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ["30", "29", "28", "27", "26", "25", "24", "23", "22", "21", "20", "19", "18", "17", "16", "15", "14", "13", "12", "11", "10", "09", "08", "07", "06", "05", "04", "03", "02", "01", "00"],
        datasets: [{
            label: 'Users',
            data: [<?php echo "$google30"; ?>, <?php echo "$google29"; ?>, <?php echo "$google28"; ?>, <?php echo "$google27"; ?>, <?php echo "$google26"; ?>, <?php echo "$google25"; ?>, <?php echo "$google24"; ?>, <?php echo "$google23"; ?>, <?php echo "$google22"; ?>, <?php echo "$google21"; ?>, <?php echo "$google20"; ?>, <?php echo "$google19"; ?>, <?php echo "$google18"; ?>, <?php echo "$google17"; ?>, <?php echo "$google16"; ?>, <?php echo "$google15"; ?>, <?php echo "$google14"; ?>, <?php echo "$google13"; ?>, <?php echo "$google12"; ?>, <?php echo "$google11"; ?>, <?php echo "$google10"; ?>, <?php echo "$google9"; ?>, <?php echo "$google8"; ?>, <?php echo "$google7"; ?>, <?php echo "$google6"; ?>, <?php echo "$google5"; ?>, <?php echo "$google4"; ?>, <?php echo "$google3"; ?>, <?php echo "$google2"; ?>, <?php echo "$google1"; ?>, <?php echo "$google847444"; ?>],

backgroundColor:'',
borderColor:'<?php echo "#" . $google8474224474747474; ?>',
borderWidth: 4,

fill: false,

borderColor:'<?php echo "#" . $google8474224474747474; ?>',
backgroundColor: '<?php echo "#". $google8474224474747474; ?>',
fill: false,
pointBorderColor: 'rgba(0, 0, 0, 0)',
pointBackgroundColor: 'rgba(0, 0, 0, 0)',
pointHoverBackgroundColor: '<?php echo "#" . $google8474224474747474; ?>',
pointHoverBorderColor: '<?php echo "#" . $google8474224474747474; ?>',

},

{

label: 'Google',
data: [<?php echo "$googleapps847444"; ?>, <?php echo "$googleapps1"; ?>, <?php echo "$googleapps2"; ?>, <?php echo "$googleapps3"; ?>, <?php echo "$googleapps4"; ?>, <?php echo "$googleapps5"; ?>, <?php echo "$googleapps6"; ?>, <?php echo "$googleapps7"; ?>, <?php echo "$googleapps8"; ?>, <?php echo "$googleapps9"; ?>, <?php echo "$googleapps10"; ?>, <?php echo "$googleapps11"; ?>, <?php echo "$googleapps12"; ?>, <?php echo "$googleapps13"; ?>, <?php echo "$googleapps14"; ?>, <?php echo "$googleapps15"; ?>, <?php echo "$googleapps16"; ?>, <?php echo "$googleapps17"; ?>, <?php echo "$googleapps18"; ?>, <?php echo "$googleapps19"; ?>, <?php echo "$googleapps20"; ?>, <?php echo "$googleapps21"; ?>, <?php echo "$googleapps22"; ?>, <?php echo "$googleapps23"; ?>],

backgroundColor:'',
borderColor:'<?php echo "$_GET[accountcolorapps84747474]"; ?>',
borderWidth: 4,

fill: false,

borderColor:'<?php echo "$_GET[accountcolorapps84747474]"; ?>',
backgroundColor: '<?php echo "#". $google8474224474747474; ?>',
fill: false,
pointBorderColor: 'rgba(0, 0, 0, 0)',
pointBackgroundColor: 'rgba(0, 0, 0, 0)',
pointHoverBackgroundColor: '<?php echo "#" . $google8474224474747474; ?>',
pointHoverBorderColor: '<?php echo "#" . $google8474224474747474; ?>',

}]

},

options: {

responsive:true,
maintainAspectRatio:false,

spanGaps: false,
elements: {
line: {
tension: 0.000001,
}

},

animation: false,

legend: {
display: false,
},

tooltips: {
backgroundColor: '#ffffff',
titleFontSize: 16,
titleFontColor: '#444444',
bodyFontColor: '#222222',
bodyFontSize: 14,
displayColors: false,
mode: 'x-axis',
bodyPadding: 8,
Padding: 8,
},

scales: {
            yAxes: [{
                ticks: {
                    fontColor: "rgba(0,0,0,0.5)",
                    beginAtZero: true,
                    maxTicksLimit: 4,
                    padding: 8,

},
                gridLines: {
                    drawTicks: false,
                }
}],
            xAxes: [{
                gridLines: {
                    zeroLineColor: "transparent",
},
                ticks: {
                    padding: 8,
                    fontColor: "rgba(0,0,0,0.5)",

}
            }]

        }
    }
});
</script>

<?php

}

?>

<?php

$conn->close();

?>

