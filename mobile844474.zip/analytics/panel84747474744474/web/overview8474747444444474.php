<?php

include "../../dashboard/dashboardtop.php";

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84 = str_replace("#","",$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84);

?>

<?php

$google84747474747474747474 = explode("/", $_SERVER['REQUEST_URI']);

$google847474747474747474744474 = $google84747474747474747474[1];

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84 = str_replace("#","",$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84);

?>

<?php

$googleappsappsappsappsappsgooglegoogleappsappsapps844444744474 = preg_replace("/#/","",$googleapps84744444444444744474);

$googleappsappsappsappsappsgooglegoogleappsappsapps844444444444444444744474 = preg_replace("/#/","",$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84);

?>

<div id="minutesapps84747474447444744474444444444444444444447444" style="position:relative;"></div>

<script>

$(document).ready(function(){

var myVar = setInterval(myTimer, 4008);

function myTimer() {

$("#minutesapps84747474447444744474444444444444444444447444").load('<?php echo "google8474747444744474.php?accountcolorapps84747474=$googleappsappsappsappsappsgooglegoogleappsappsappsappsappsappsappsapps84&color=$googleappsappsappsappsappsgooglegoogleappsappsapps844444444444444444744474&colorapps847474744444444474=$googleappsappsappsappsappsgooglegoogleappsappsapps844444744474"; ?>');

}

function myStopFunction() {
    clearInterval(myVar);
}

}

);

</script>

<?php

include "../../dashboard/dashboardbottom.php";

?>

