<?php

error_reporting(0);

?>

<?php

include "../dashboard/dashboardtop.php";

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../firstnameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/firstnameapps84747474.sh";

}

?>

<?php

$googleappsuserappsapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../lastnameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/lastnameapps84747474.sh";

}

?>

<?php

$googleappsuserappsappsapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../usernameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/usernameapps84747474.sh";

}

?>

<?php

$googleappsuserappsappsappsapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../gosearchimages8884.sh";

}

else

{

$dataurl84 = "../gosearchimages8884/gosearchimages8884.sh";

}

?>

<?php

$googleappsappsappsappsapps8884 = file_get_contents("$dataurl84");

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../coworkersgoogle84747474.sh";

}

else

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../people/coworkersgoogle84747474.sh";

}

?>

<?php

$googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884 = file_get_contents($dataurlurlgoogleappsgooglegoogleappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884, $googleappsappsappsgoogleappsappsgooglegoogleappsapps84);
$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274 = $googleappsappsappsgoogleappsappsgooglegoogleappsapps84[2][0];

?>

<?php

if(preg_match("/business/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "business";

$google8474444444474 = "Update";

$google1 = "Promote";

$google2 = "Mail";

$google4 = "Account";

$googleapps84741274 = "What's up,";

$google84121274747474 = "Coworkers";

$googleappsapps84121274747474 = "Activity";

$googlegoogleappsappsapps84121274747474 = "Images";

$googleappsappsappsappsapps84744444444474 = "Write";

$googlegoogleappsappsapps84121274747474444474 = "Image";

}

if(preg_match("/apps/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "Getit";

$google8474444444474 = "Post";

$google1 = "Like";

$google2 = "Share";

$google4 = "Profile";

$googleapps84741274 = "What's on your mind,";

$google84121274747474 = "Friends";

$googleappsapps84121274747474 = "Timeline";

$googlegoogleappsappsapps84121274747474 = "Photos";

$googleappsappsappsappsapps84744444444474 = "Comment";

$googlegoogleappsappsapps84121274747474444474 = "Photo";

}

if(preg_match("/google/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "google";

$google8474444444474 = "Post";

$google1 = "1+";

$google2 = "Share";

$google4 = "Profile";

$googleapps84741274 = "What's new,";

$google84121274747474 = "Circles";

$googleappsapps84121274747474 = "Stream";

$googlegoogleappsappsapps84121274747474 = "Images";

$googleappsappsappsappsapps84744444444474 = "Comment";

$googlegoogleappsappsapps84121274747474444474 = "Image";

}

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{
}

else

{

$googleappsappsapps84744474 = "business";

$google8474444444474 = "Update";

$google1 = "Promote";

$google2 = "Mail";

$google4 = "Account";

$googleapps84741274 = "What's up,";

$google84121274747474 = "Coworkers";

$googleappsapps84121274747474 = "Activity";

$googlegoogleappsappsapps84121274747474 = "Images";

$googleappsappsappsappsapps84744444444474 = "Write";

$googlegoogleappsappsapps84121274747474444474 = "Image";

}

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlapps84 = "../accountcolor88842274.sh";

}

else

{

$dataurlurlapps84 = "../register/accountcolor88842274.sh";

}

?>

<?php

$googleappsgoogleappsappsgoogleapps8884 = file_get_contents($dataurlurlapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../accountcolor8884.sh";

}

else

{

$dataurlurlgoogleapps84 = "../register/accountcolor8884.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsapps84);
$accountcolor84742274 = $googleappsappsapps84[3][0];

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsapps84);
$accountcolor847474 = $googleappsappsapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolor847474"))

{

$accountcolor1 = "$accountcolor847474";

$accountcolor2 = "$accountcolor847474";

$accountcolor4 = "$accountcolor847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<div class="googledivappsappsapps84" style="margin-top:12px;position:relative;margin-bottom:0px;">

<div style="width:100%;height:196px;position:relative;background-color:#1d2129;">

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{
}

else

{

?>

<div style="width:100%;">

<div style="margin-top:12px;position:absolute;right:12px;">

<div class="dropdown">
  <button onclick="myFunctiongoogleappsappsappsappsappsgoogleapps84747474();" class="dropbtn" style="font-size:12.4px;border:none;background-color:inherit!important;padding:0px!important;"><i class='material-icons googleappsgoogleapps2' id="google84221874" style="color:#ffffff;font-size:19.4px;">more_vert</i></button>
  <div id="myDropdown" class="dropdown-content" style="display:none;margin-left:-128.4px;">
    <a href="" style="font-size:14px;background-color:#ffffff;">Report</a>
    <a href="" style="font-size:14px;background-color:#ffffff;">Show info</a>
    <a href="" style="font-size:14px;background-color:#ffffff;">Show user</a>
  </div>
</div>

<script>

function myFunctiongoogleappsappsappsappsappsgoogleapps84747474() {
    var x = document.getElementById("myDropdown");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

</script>

<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunctionappsapps84747474() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

<style>

/* Dropdown Button */
.dropbtn {
cursor: pointer;
}

/* Dropdown button on hover & focus */
.dropbtn:hover, .dropbtn:focus {
    background-color: #2980B9;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
    position: relative;
    display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow: 0px 2px 4px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color:#ebebeb!important}

/* Show the dropdown menu (use JS to add this class to the .dropdown-content container when the user clicks on the dropdown button) */
.show {display:block;}

</style>

</div>

</div>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84747474 = "../gosearchimagesgoogleappsappsapps8884.sh";

}

else

{

$dataurl84747474 = "../gosearchimages8884/gosearchimagesgoogleappsappsapps8884.sh";

}

$google842222222274 = file_get_contents("$dataurl84747474");

preg_match_all("/<div class='$nameappsapps8884' id='na'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $google842222222274, $gosearchimages844444224474);
$gosearchimages844444444474 = $gosearchimages844444224474[1][0];

if(preg_match("/[\W\w]/","$gosearchimages844444444474"))

{

?>

<img class="googleappsapps8444444444444444444474" src='<?php echo "$gosearchimages844444444474"; ?>'></img>

<?php

}

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{

?>

<script>

$(document).ready(function(){

$('#googleimageappsmobileappsappsappsappsappsapps84').on('change', function() {

document.getElementById("googleappsapps8444444444444474").click();

});

});

</script>

<div>

<div style="display:none;">

<form action="/google8474/googleappsgoogleappsappsapps8474.php" method="post" enctype="multipart/form-data" id="googleappsapps8474744444444474" style="">

<input type="hidden" name="username84747474" value="<?php echo "$_GET[useremail]"; ?>"></input>

<input type="file" name="image" id="googleimageappsmobileappsappsappsappsappsapps84" style="width:44px;height:44px;padding-top:62px;z-index:44;padding-left:24px;display:none;"></input>

<input type="submit" value="Submit" style="border:none;background-color:<?php echo "$accountcolor4"; ?>;padding:12px;color:#ffffff;font-weight:bold;margin:12px;font-size:13.8px;display:none;" id="googleappsapps8444444444444474"></input>

</form>

</div>

</div>

<div>

<div class="googleappsappsappsappsapps84222274" style="font-size:12.8px;width:124px;position:absolute;right:12px;top:12px;">

<div id="googleappsappsappsappsappsappsapps844444444474" onclick="document.getElementById('googleimageappsmobileappsappsappsappsappsapps84').click();" style="padding-left:12px;position:absolute;right:0px;cursor:pointer;padding-left:12px;right:0px;cursor:pointer;padding:8px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:inline-block;color:#444444;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;border:none;margin-top:12.8px;margin-left:12px;right:0px;top:-12px;position:absolute;">

Change cover

</div>

</div>

</div>

<?php

}

else

{

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../userregistrations.sh";

}

else

{

$dataurl84 = "../register/userregistrations.sh";

}

?>

<?php

$googleapps8884 = file_get_contents("$dataurl84");

?>

<?php

$googleapps84 = $_GET['useremail'];

$password="googleappsmobileapps888888884444";

$nameappsapps84 = openssl_encrypt($googleapps84,"AES-128-ECB",$password);

$nameappsapps84 = rawurlencode($nameappsapps84);

?>

<?php

preg_match_all("/<div class='$nameappsapps84' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$nameappsappsappsappsappsapps84 = rawurldecode($name);

$nameappsappsappsappsappsapps84 = openssl_decrypt($nameappsappsappsappsappsapps84,"AES-128-ECB",$password);

?>

<script>

$(document).ready(function() {

$('.googleapps844444747474').click(function(){

$.ajax({
    data: 'coworkers84747474=<?php echo "$nameappsapps8884"; ?>&coworkersnameapps84747474=<?php echo "$name"; ?>',
    url: '/people/coworkers84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

});

});

</script>

<div class="googleappsappsapps8474" id="google84742274" style="display:none;">

<div>

<div style="position:fixed;background-color:#bdbdbd;z-index:9884;height:100%;top:0px;width:100%;left:0px;background:rgba(0, 0, 0, 0.4);" onclick="$(this).hide();">

<div align="center" style="margin:12px;margin-top:62px;background-color:#f1f1f1;padding:12px;position:fixed;top:50%;left:50%;margin-top:-62px;margin-left:-62px;background:rgba(0, 0, 0, 0.4);">

<i class='material-icons' style="color:#ffffff;font-size:104px;">person_add</i>

</div>

</div>

</div>

</div>

<div style="display:flex;">

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../coworkersappsappsappsgoogleappsgoogleapps84747474.sh";

}

else

{

$dataurlurlgoogleapps84 = "../people/coworkersappsappsappsgoogleappsgoogleapps84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

$googleapps84 = $_GET['useremail'];

$password="googleappsmobileapps888888884444";

$nameappsapps84 = openssl_encrypt($googleapps84,"AES-128-ECB",$password);

$nameappsapps84 = rawurlencode($nameappsapps84);

?>

<?php

preg_match_all("/<div class='$nameappsapps84'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsapps84742274"))

{

?>

<?php

if(preg_match("/0/","$accountcolorappsappsappsappsapps84742274"))

{

?>

<?php

}

else

{

?>

<?php

if(preg_match("/1/","$accountcolorappsappsappsappsapps84742274"))

{

?>

<div class="googleapps844444747474" style="padding:8px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:inline-block;color:#ffffff;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;color:<?php echo "$accountcolor1"; ?>;position:absolute;right:96px;bottom:-12px;" onclick="$('#google84742274').show();">

Add

</div>

<?php

}

}

}

else

{

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../coworkers84747474.sh";

}

else

{

$dataurlurlgoogleapps84 = "../people/coworkers84747474.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

$googleapps84 = $_GET['useremail'];

$password="googleappsmobileapps888888884444";

$nameappsapps84 = openssl_encrypt($googleapps84,"AES-128-ECB",$password);

$nameappsapps84 = rawurlencode($nameappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='$nameappsapps84' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsgooglegoogleapps8884, $googleappsappsappsgoogleappsapps84);
$accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274 = $googleappsappsappsgoogleappsapps84[1][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsappsgoogleappsappsappsapps84742274"))

{

?>

<div class="googleapps844444747474" style="padding:8px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:inline-block;color:#ffffff;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;color:<?php echo "$accountcolor1"; ?>;position:absolute;bottom:-12px;" onclick="">

<?php echo "$google84121274747474"; ?>

</div>

<?php

}

else

{

?>

<div class="googleapps844444747474" style="padding:8px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:inline-block;color:#ffffff;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;color:<?php echo "$accountcolor1"; ?>;position:absolute;bottom:-12px;" onclick="$('#google84742274').show();">

Add

</div>

<?php

}

?>

<?php

}

?>

<div class="googleapps842222442274" style="padding:8px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:inline-block;color:#ffffff;font-size:14.6px;margin-top:12px;margin-bottom:24px;cursor:pointer;color:<?php echo "$accountcolor1"; ?>;position:absolute;bottom:-12px;" onclick="window.open('/people/usermailapps8884.php?useremailappsappsapps84747474=<?php echo "$google84747474"; ?>','_self');">

Message

</div>

</div>

<?php

}

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='na'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsappsappsappsapps8884, $googleapps84);
$gosearchimages8474 = $googleapps84[1][0];

?>

<?php

if(preg_match("/[\W\w]/",$gosearchimages8474))

{

?>

<script>

$(document).ready(function(){

$('#googleimageapps84').on('change', function() {

document.getElementById("google84444474").click();

});

});

</script>

<div>

<div>

<form action="/google8474/googleapps8474.php" method="post" enctype="multipart/form-data" id="googleappsappsappsapps8474744444444474" style="">

<input type="hidden" name="username84747474" value="<?php echo "$_GET[useremail]"; ?>"></input>

<input type="file" name="image" id="googleimageapps84" style="width:44px;height:44px;padding-top:62px;z-index:44;padding-left:24px;display:none;"></input>

<input type="submit" value="Submit" style="border:none;background-color:<?php echo "$accountcolor4"; ?>;padding:12px;color:#ffffff;font-weight:bold;margin:12px;font-size:13.8px;display:none;" id="google84444474"></input>

</form>

</div>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{

?>

<?php

$googleapps847444444444444474 = "googleimageapps84";

?>

<?php

}

?>

<div id="div84747474" style="margin-left:12px;"><img src="<?php echo $gosearchimages8474; ?>" width="104" height="104" style="border-color:#1565C0;color:#ffffff;border-radius:4px;font-size:86px;box-shadow:0 2px 4px rgba(0,0,0,0.4);position:absolute;bottom:-24px;" onclick="document.getElementById('<?php echo $googleapps847444444444444474; ?>').click();"></img></div>

</div>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "<div class='googledivapps4' style='display:flex;position:absolute;bottom:8px;left:134px;color:#ffffff;'><div>$gosearchimagesappsapps84747674</div><div style='margin-left:4px;'>$gosearchimagesappsappsappsapps84747674</div></div>";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "<div class='googledivapps4' style='display:flex;position:absolute;bottom:8px;left:134px;color:#ffffff;'><div>$gosearchimages84747674</div><div style='margin-left:4px;'></div></div>";

?>

<?php

}

?>

<?php

echo "$googleappsappsapps844444444474";

?>

<?php

$googlegoogegoogleappsappsapps84747474 = $_GET['useremail'];

$googlegoogegoogleappsappsapps84747474 = "$googlegoogegoogleappsappsapps84747474";
$passwordname8884 = "googleappsmobileapps888888884444";

$googlegoogegoogleappsappsapps84747474 = openssl_encrypt($googlegoogegoogleappsappsapps84747474,"AES-128-ECB",$passwordname8884);

$googlegoogegoogleappsappsapps84747474 = rawurlencode($googlegoogegoogleappsappsapps84747474);

?>

<?php

if(preg_match("/$_COOKIE[username]/","$googlegoogegoogleappsappsapps84747474"))

{

?>

<?php

$googleapps847444444444444474 = "googleimageapps84";

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../userregistrations.sh";

}

else

{

$dataurl8884 = "../register/userregistrations.sh";

}

?>

<?php

$decryptedstring = $_COOKIE['username'];

$file84 = file_get_contents("$dataurl8884");

preg_match_all("/<div class='$googlegoogegoogleappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $file84, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

$nameappsappsgoogleapps8884 = strtoupper($name[0]);

?>

<?php

$decryptedstring = $_COOKIE['username'];

$file84 = file_get_contents("$dataurl8884");

preg_match_all("/<div class='$googlegoogegoogleappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $file84, $googleapps84);
$namegoogleapps8474444444444474 = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$namegoogleapps8474444444444474 = rawurldecode($namegoogleapps8474444444444474);

$namegoogleapps8474444444444474 = openssl_decrypt($namegoogleapps8474444444444474,"AES-128-ECB",$password);

$namegoogleapps8474444444444474 = ucfirst("$namegoogleapps8474444444444474");

?>

<?php

$decryptedstring = $_COOKIE['username'];

$file84 = file_get_contents("$dataurl8884");

preg_match_all("/<div class='$googlegoogegoogleappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $file84, $googleapps84);
$namegoogleappsappsapps8474444444444474 = $googleapps84[3][0];

$password="googleappsmobileapps888888884444";

$namegoogleappsappsapps8474444444444474 = rawurldecode($namegoogleappsappsapps8474444444444474);

$namegoogleappsappsapps8474444444444474 = openssl_decrypt($namegoogleappsappsapps8474444444444474,"AES-128-ECB",$password);

$namegoogleappsappsapps8474444444444474 = ucfirst("$namegoogleappsappsapps8474444444444474");

?>

</div>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$googleappsappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsappsgoogleappsapps844444444474 = "<div class='googledivapps4' style='display:flex;position:absolute;bottom:8px;left:134px;color:#ffffff;'><div>$gosearchimagesappsapps84747674</div><div style='margin-left:4px;'>$gosearchimagesappsappsappsapps84747674</div></div>";

?>

<?php

}

else

{

?>

<?php

$googleappsappsappsgoogleappsapps844444444474 = "<div class='googledivapps4' style='display:flex;position:absolute;bottom:8px;left:134px;color:#ffffff;'><div>$gosearchimages84747674</div><div style='margin-left:4px;'></div></div>";

?>

<?php

}

?>

<?php

}

else

{

?>

<style>

.googleapps84742274
{
display:inline-block!important;
}

</style>

<script>

$(document).ready(function(){

$('#googleimageapps84').on('change', function() {

document.getElementById("google84444474").click();

});

});

</script>

<div>

<div style="display:none;">

<form action="/google8474/googleapps8474.php" method="post" enctype="multipart/form-data" id="googleappsappsappsapps8474744444444474" style="">

<input type="hidden" name="username84747474" value="<?php echo "$_GET[useremail]"; ?>"></input>

<input type="file" name="image" id="googleimageapps84" style="width:44px;height:44px;padding-top:62px;z-index:44;padding-left:24px;display:none;"></input>

<input type="submit" value="Submit" style="border:none;background-color:<?php echo "$accountcolor4"; ?>;padding:12px;color:#ffffff;font-weight:bold;margin:12px;font-size:13.8px;display:none;" id="google84444474"></input>

</form>

</div>

<?php

$googlegoogegoogleappsappsapps84747474 = $_GET['useremail'];

$googlegoogegoogleappsappsapps84747474 = "$googlegoogegoogleappsappsapps84747474";
$passwordname8884 = "googleappsmobileapps888888884444";

$googlegoogegoogleappsappsapps84747474 = openssl_encrypt($googlegoogegoogleappsappsapps84747474,"AES-128-ECB",$passwordname8884);

$googlegoogegoogleappsappsapps84747474 = rawurlencode($googlegoogegoogleappsappsapps84747474);

?>

<?php

if(preg_match("/$_COOKIE[username]/","$googlegoogegoogleappsappsapps84747474"))

{

?>

<?php

$googleapps847444444444444474 = "googleimageapps84";

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../userregistrations.sh";

}

else

{

$dataurl8884 = "../register/userregistrations.sh";

}

?>

<?php

$decryptedstring = $_COOKIE['username'];

$file84 = file_get_contents("$dataurl8884");

preg_match_all("/<div class='$googlegoogegoogleappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $file84, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

$nameappsappsgoogleapps8884 = "$name";

?>

<?php

$decryptedstring = $_COOKIE['username'];

$file84 = file_get_contents("$dataurl8884");

preg_match_all("/<div class='$googlegoogegoogleappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $file84, $googleapps84);
$namegoogleapps8474444444444474 = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$namegoogleapps8474444444444474 = rawurldecode($namegoogleapps8474444444444474);

$namegoogleapps8474444444444474 = openssl_decrypt($namegoogleapps8474444444444474,"AES-128-ECB",$password);

$namegoogleapps8474444444444474 = ucfirst("$namegoogleapps8474444444444474");

?>

<?php

$decryptedstring = $_COOKIE['username'];

$file84 = file_get_contents("$dataurl8884");

preg_match_all("/<div class='$googlegoogegoogleappsappsapps84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $file84, $googleapps84);
$namegoogleappsappsapps8474444444444474 = $googleapps84[3][0];

$password="googleappsmobileapps888888884444";

$namegoogleappsappsapps8474444444444474 = rawurldecode($namegoogleappsappsapps8474444444444474);

$namegoogleappsappsapps8474444444444474 = openssl_decrypt($namegoogleappsappsapps8474444444444474,"AES-128-ECB",$password);

$namegoogleappsappsapps8474444444444474 = ucfirst("$namegoogleappsappsapps8474444444444474");

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674 $gosearchimagesappsappsappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

$googleappsappsappsappsapps844444444474 = preg_replace("/(.*?) (.*?)/","$1",$googleappsappsapps844444444474);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsappsappsappsappsappsapps84 = "../googleappsapps84747474.sh";

}

else

{

$dataurluserappsappsappsappsappsappsapps84 = "../people/googleappsapps84747474.sh";

}

?>

<?php

$googleappsuserappsappsappsappsappsapps888474 = file_get_contents($dataurluserappsappsappsappsappsappsapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsappsappsapps888474, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/(^Male$|^male$)/","$gosearchimages84747674"))

{

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsappsappsappsappsappsapps84 = "../googleappsapps84747474.sh";

}

else

{

$dataurluserappsappsappsappsappsappsapps84 = "../people/googleappsapps84747474.sh";

}

?>

<?php

$googleappsuserappsappsappsappsappsapps888474 = file_get_contents($dataurluserappsappsappsappsappsappsapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsappsappsapps888474, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/(^Male$|^male$)/","$gosearchimages84747674"))

{

?>

<div style='position:absolute;left:17.8px;bottom:-28px;'>

<div onclick="document.getElementById('<?php echo "$googleapps847444444444444474"; ?>').click();">

<div class='inline'>
<img class='textavatar' src="/gosearchimages8884/googleapps84.jpg" style='width:104px;padding:4px;border-style:solid;border-width:1px;border-color:#bdbdbd;border-radius:3.4px;margin-left:-5.8px;' data-name='<?php echo "$googleappsappsappsappsapps844444444474"; ?>'></img>
</div>

</div>

</div>

<?php

}

else

{

?>

<div style='position:absolute;left:17.8px;bottom:-28px;'>

<div onclick="document.getElementById('<?php echo "$googleapps847444444444444474"; ?>').click();">

<div class='inline'>
<img class='textavatar' src="/gosearchimages8884/googleapps84747474.jpeg" style='width:104px;padding:4px;border-style:solid;border-width:1px;border-color:#bdbdbd;border-radius:3.4px;margin-left:-5.8px;' data-name='<?php echo "$googleappsappsappsappsapps844444444474"; ?>'></img>
</div>

</div>

</div>

<?php

}

?>

<?php

}

else

{

?>

<div style='position:absolute;left:17.8px;bottom:-28px;'>

<div onclick="document.getElementById('<?php echo "$googleapps847444444444444474"; ?>').click();">

<div class='inline'>
<img class='textavatar' src="/gosearchimages8884/googleapps84747474.jpeg" style='width:104px;padding:4px;border-style:solid;border-width:1px;border-color:#bdbdbd;border-radius:3.4px;margin-left:-5.8px;' data-name='<?php echo "$googleappsappsappsappsapps844444444474"; ?>'></img>
</div>

</div>

</div>

<?php

}

?>

<link rel="stylesheet" href="textavatar.css">
<script src="jquery.textavatar.js"></script>

<style>
.inline {
display: inline-block;
margin-top: 16px;
margin-right: 16px;
}
.textavatar {
background-color:#ffffff;;
color:#444444;
}
</style>

<script>

$('.textavatar').textAvatar();

var name = $('#name').val();

var size = $('#size').val();

$('#test').textAvatar({

name: name,

width: size

});
		
</script>

</div>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "<div class='googledivapps4' style='display:flex;position:absolute;bottom:8px;left:134px;color:#ffffff;'><div>$gosearchimagesappsapps84747674</div><div style='margin-left:4px;'>$gosearchimagesappsappsappsapps84747674</div></div>";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "<div class='googledivapps4' style='display:flex;position:absolute;bottom:8px;left:134px;color:#ffffff;'><div>$gosearchimages84747674</div><div style='margin-left:4px;'></div></div>";

?>

<?php

}

?>

<?php

echo "$googleappsappsapps844444444474";

?>

<?php

}

?>

</div>

<style>

@media screen and (min-width: 1884px)
{
html
{
zoom:1.4;
}
}

@media screen and (min-width: 2560px)
{
html
{
zoom:2;
}
}

</style>

<style>

@media screen and (min-width: 770px)
{
.googledivappsappsapps84
{
margin-left:96px;
margin-right:196px;
width:796px;
margin:0 auto;
}
.google84744474
{
margin-left:140px;
}
.googleappsapps8444444444444444444474
{
height:100%;
width:100%;
object-fit:contain;
}
.googleappsappsappsgooglegoogleappsappsapps84444474
{
display:inline-block;
}
.google84444444444474
{
width:446px;
}
.googleappsapps84444444444474
{
display:inline-block;
}
.googleappsappsappsappsappsgooglegoogleapps84747474
{
}
.googleapps842222442274
{
right:12px!important;
}
.googleapps844444747474
{
right:96px!important;
}
.googleappsapps84444444444474
{
margin-top:328px;
margin-left:326.1px;
}
.googleappsimagesappsapps844444444474
{
width:280px;
}
.googleappsappsgoogle844444224474
{
margin-top:10px;
}
}

@media screen and (max-width: 770px)
{
.googleappsapps8444444444444444444474
{
height:100%;
width:100%;
object-fit:contain;
}
.googledivappsappsapps84
{
}
.googlediv1
{
font-size:14px;
padding-right:12px!important;
}
.googlediv2
{
font-size:14px;
padding-right:12px!important;
}
.googlediv4
{
font-size:14px;
padding-right:12px!important;
}
.googlediv62
{
font-size:14px;
padding-right:12px!important;
}
.googlediv74
{
justify-content:space-between;
padding-left:12px!important;
padding-top:34px!important;
}
.googledivapps4
{
width:156px;
overflow:hidden;
}
.googleappsdiv84747474
{
}
.googleappsappsappsappsappsgooglegoogleapps84747474
{
position:absolute;
left:194px;
top:56px;
}
.googleapps842222442274
{
top:0px!important;
left:12px!important;
display:inline-table!important;
}
.googleapps844444747474
{
top:0px;
left:96px!important;
display:inline-table!important;
}
.googleappsapps84444444444474
{
margin-top:336.2px;
margin-left:0px;
}
.aboutappsgoogleappsgoogleappsapps84747474
{
}
.aboutappsgoogleappsappsapps84747474
{
display:none;
}
.aboutappsgoogleappsgoogleappsappsappsapps84747474
{
display:none;
}
.googleappsappsapps844444224474
{
display:table;
left:0px!important;
position:absolute!important;
z-index:88888844!important;
}
.googleappsappsappsgooglegoogleappsappsapps84444474
{
position:relative;
}
.googleappsapps84444444444474444474
{
margin-top:-4px;
}
.googleappsimagesappsapps844444444474
{
display:none;
}
}

.googledivappsappsapps84
{
}

.googleappsgoogleappsgooglegooglegooglegoogleapps844444444474:hover
{
background-color:#f1f1f1!important;
}

.googlegoogleappsgoogleappsgooglegooglegooglegoogleapps84222274:hover
{
background-color:#f1f1f1!important;
}

.textgoogleapps84747474:hover
{
text-decoration:underline;
}

.googlediv1
{
font-size:14.6px;
}
.googlediv2
{
font-size:14.6px;
}
.googlediv4
{
font-size:14.6px;
}
.googlediv62
{
font-size:14.6px;
}

.googleimageappapps847474744474:hover
{
background-color:#f1f1f1!important;
}

</style>

<?php

$string_to_encrypt="$_COOKIE[username]";

$decrypted_string = "$string_to_encrypt";

?>

<?php

$string_to_encrypt8884="$_COOKIE[password]";

$decrypted_string8884 = "$string_to_encrypt8884";

?>

<?php

$string_to_encrypt="$_COOKIE[username]";

$decrypted_string = "$string_to_encrypt";

?>

<?php

$string_to_encrypt="$decrypted_string";

$decrypted_string888474 = rawurldecode($string_to_encrypt);

$password="googleappsmobileapps888888884444";

$decrypted_string8474=openssl_decrypt($decrypted_string888474,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl8884 = "../userregistrations.sh";

}

else

{

$dataurl8884 = "../register/userregistrations.sh";

}

?>

<?php

$decryptedstring = $_COOKIE['username'];

$file84 = file_get_contents("$dataurl8884");

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $file84, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$name = rawurldecode($name);

$name = openssl_decrypt($name,"AES-128-ECB",$password);

$googleapps8884 = strtoupper("$name");

$googleapps888844 = "$name";

?>

<?php

if(!preg_match("/[\W\w]/",$_COOKIE['username']))

{

?>

<?php

}

?>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>

<?php

$hours = date("H");

$minutes = date("i");

$seconds = date("s");

?>

<?php

$date = date("Y-m-d");

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84447422 = "../accountcolor8884.sh";

}

else

{

$dataurl84447422 = "../register/accountcolor8884.sh";

}

?>

<?php

$googleapps84747444 = file_get_contents($dataurl84447422);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../gosearchimages8884.sh";

}

else

{

$dataurl84 = "../gosearchimages8884/gosearchimages8884.sh";

}

?>

<?php

$googleapps8884 = file_get_contents($dataurl84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$gosearchimages8474 = $googleapps84[2][0];

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleapps84747444, $googleapps84);
$accountcolor847474 = $googleapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/",$accountcolor847474))

{
}

else

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

?>

<?php

if(preg_match("/blue/",$accountcolor847474))

{

$accountcolor84747474 = "#1565C0";

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1E88E5";

$accountcolor4 = "#42A5F5";

}

if(preg_match("/orange/",$accountcolor847474))

{

$accountcolor84747474 = "#EF6C00";

$accountcolor1 = "#EF6C00";

$accountcolor2 = "#FB8C00";

$accountcolor4 = "#FFA726";

}

if(preg_match("/yellow/",$accountcolor847474))

{

$accountcolor84747474 = "#F9A825";

$accountcolor1 = "#F9A825";

$accountcolor2 = "#FDD835";

$accountcolor4 = "#FFEE58";

}

if(preg_match("/purple/",$accountcolor847474))

{

$accountcolor84747474 = "#6A1B9A";

$accountcolor1 = "#6A1B9A";

$accountcolor2 = "#8E24AA";

$accountcolor4 = "#AB47BC";

}

if(preg_match("/pink/",$accountcolor847474))

{

$accountcolor84747474 = "#AD1457";

$accountcolor1 = "#AD1457";

$accountcolor2 = "#D81B60";

$accountcolor4 = "#EC407A";

}

?>

<style>

@media (max-width: 770px)
{
.googleappsappsapps84747474
{
width:100%;
box-sizing:border-box;
}
.google844444444474
{
width:100%;
}
#googlegooglegooglegoogleappsappsappsappsgoogleappsapps84444474
{
width:100%!important;
box-sizing:border-box;
}
#googlegooglegooglegoogleappsappsappsappsgoogleappsappsappsapps84444474
{
width:100%!important;
box-sizing:border-box;
}
.googledivdivappsapps84747474
{
width:100%;
box-sizing:border-box;
}
.googledivdivappsappsappsappsappsapps84747474
{
width:100%;
box-sizing:border-box;
position:relative;
}
#googleuserappsappsappsgoogleapps84747474
{
width:100%!important;
box-sizing:border-box;
}
#googleuserappsappsappsgoogleappsappsapps84747474
{
padding-top:62px!important;
margin-right:1px;
}
#div84747474 .googleapps84744422224474
{
margin-top:34px!important;
}
.textavatar.googleapps84744422224474
{
margin-top:34px!important;
}
}

@media (min-width: 770px)
{
.googleappsappsapps84747474
{
box-sizing:border-box;
width:796px;
}
.google844444444474
{
width:796px;
}
#googleuserappsappsappsgoogleappsappsapps84747474
{
width:470.4px;
box-sizing:border-box;
padding-left:48px;
}
}

.google844444444474
{
text-align:left;
}

</style>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84447422 = "../mainactivityapps84747474.sh";

}

else

{

$dataurlappsappsapps84447422 = "../people/mainactivityapps84747474.sh";

}

?>

<?php

$googleappsappsappsapps84747444 = file_get_contents("");

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsappsappsapps84747444, $googleappsgooglegoogleapps84);

$namegoogleapps84747474 = $googleappsgooglegoogleapps84[1];

$namegoogleapps84747474 = count($namegoogleapps84747474);

$namegoogleappsgooglegoogleapps84747474 = 99999 - $namegoogleapps84747474;

?>

<script>

$(document).ready(function() {

$('#googlegooglegooglegoogleappsappsappsappsgoogleappsappsappsapps84444474').click(function(){

var googlemobileapps844444444474 = $('#googleuserappsappsappsgoogleappsappsapps84747474').val();

if(googlemobileapps844444444474 == "") {

}

else

{

var googlemobileapps84444474 = $('#googleuserappsappsappsgoogleappsappsapps84747474').val();

$.ajax({
    data: 'mainactivityapps84444474=<?php echo "$nameappsapps8884"; ?>&mainactivityapps84747474=' + googlemobileapps84444474 + '&mainactivityappsuserapps84747474=<?php echo $_COOKIE[username]; ?>&googleappsapps84444474=<?php echo "$namegoogleappsgooglegoogleapps84747474"; ?>',
    url: '/people/mainactivity84444474.php',
    method: 'GET',
    success: function(msg) {
    }
});

$.ajax({
    data: 'googleapps84747474=<?php echo "$nameappsapps8884"; ?>&googleapps1=<?php echo $_COOKIE[username]; ?>&googleapps4=' + googlemobileapps84444474 + '&googleappsapps1=googleapps84',
    url: '/emailappsapps84747474/useremailsappsapps84444474.php',
    method: 'GET',
    success: function(msg) {
    }
});

location.reload();

}

});

});

</script>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlapps84 = "../accountcolor88842274.sh";

}

else

{

$dataurlurlapps84 = "../register/accountcolor88842274.sh";

}

?>

<?php

$googleappsgoogleappsappsgoogleapps8884 = file_get_contents($dataurlurlapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleapps84 = "../accountcolor8884.sh";

}

else

{

$dataurlurlgoogleapps84 = "../register/accountcolor8884.sh";

}

?>

<?php

$googleappsgooglegoogleapps8884 = file_get_contents($dataurlurlgoogleapps84);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84);
$accountcolor84742274 = $googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84[3][0];

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84);
$accountcolor847474 = $googleappsgoogleappsappsappsgoogleappsappsgoogleappsapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolor847474"))

{

$accountcolor1 = "$accountcolor847474";

$accountcolor2 = "$accountcolor847474";

$accountcolor4 = "$accountcolor847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../userregistrations.sh";

}

else

{

$dataurl84 = "../register/userregistrations.sh";

}

?>

<?php

$googleappsgooglegooglegoogleappsappsapps8884 = file_get_contents($dataurl84);

?>

<?php

$nameappsapps84 = $_COOKIE['username'];

?>

<?php

preg_match_all("/<div class='$nameappsapps84' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegooglegoogleappsappsapps8884, $googleapps84);
$name = $googleapps84[2][0];

$password="googleappsmobileapps888888884444";

$nameappsappsappsappsappsapps84 = rawurldecode($name);

$nameappsappsappsappsappsapps84 = openssl_decrypt($nameappsappsappsappsappsapps84,"AES-128-ECB",$password);

?>

<?php

$googlegoogegoogleappsappsapps84747474 = $_GET['useremail'];

$googlegoogegoogleappsappsapps84747474 = "$googlegoogegoogleappsappsapps84747474";
$passwordname8884 = "googleappsmobileapps888888884444";

$googlegoogegoogleappsappsapps84747474 = openssl_encrypt($googlegoogegoogleappsappsapps84747474,"AES-128-ECB",$passwordname8884);

$googlegoogegoogleappsappsapps84747474 = rawurlencode($googlegoogegoogleappsappsapps84747474);

?>

<?php

$googlegoogegoogleappsappsappsappsappsapps84747474 = $_GET['useremail'];

?>

<div class="googlediv74" style="padding:12px;background-color:#ffffff;display:flex;padding-left:141.8px;box-shadow:0px 2px 8px rgba(0, 0, 0, 0.2);">

<div class="googlediv1" style="font-weight:bold;padding-right:24px;" onclick="window.open('/people/usermail.php?useremail=<?php echo "$googlegoogegoogleappsappsappsappsappsapps84747474"; ?>','_self')">

<?php echo "$googleappsapps84121274747474"; ?>

</div>

<div class="googlediv2" style="font-weight:bold;padding-right:24px;" onclick="$('.googleappsappsappsgoogleapps84744474').show();">

About

</div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsappsappsappsappsappsapps84 = "../aboutapps84747474.sh";

}

else

{

$dataurluserappsappsappsappsappsappsapps84 = "../people/aboutapps84747474.sh";

}

?>

<?php

$googleappsuserappsappsappsappsappsapps888474 = file_get_contents($dataurluserappsappsappsappsappsappsapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsappsappsapps888474, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsappsappsappsappsappsapps84 = "../ageapps84747474.sh";

}

else

{

$dataurluserappsappsappsappsappsappsapps84 = "../people/ageapps84747474.sh";

}

?>

<?php

$googleappsuserappsappsappsappsappsapps888474 = file_get_contents($dataurluserappsappsappsappsappsappsapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsappsappsapps888474, $googleappsgoogleapps84);
$gosearchimagesappsappsappsappsappsappsapps84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsappsappsappsapps84747674);

$gosearchimagesappsappsappsappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<div class="googleappsappsappsgoogleapps84744474" style="position:fixed;width:100%;height:100%;left:0px;top:0px;z-index:14884;background:rgba(0, 0, 0, 0.4);display:none;" onclick="$(this).hide();">

<div style="position:absolute;background-color:#ffffff;width:100%;padding:12px;box-sizing:border-box;padding:12px;">

<div style="font-size:24px;font-weight:bold;">

About

</div>

<div style="font-size:14.6px;padding-top:12px;padding-bottom:12px;word-wrap:break-word;">

<?php

echo "$gosearchimages84747674";

?>

</div>

<div style="font-size:24px;font-weight:bold;">

Age

</div>

<div style="font-size:14.6px;padding-top:12px;padding-bottom:12px;word-wrap:break-word;">

<?php

echo "$gosearchimagesappsappsappsappsappsappsapps84747674";

?>

</div>



</div>

</div>

<div class="googlediv4" style="margin-left:4px;font-weight:bold;padding-right:24px;" onclick="window.open('/people/usermail844444444474.php?useremail=<?php echo "$googlegoogegoogleappsappsappsappsappsapps84747474"; ?>','_self')">

<?php echo "$google84121274747474"; ?>

</div>

<div class="googlediv62" style="margin-left:4px;font-weight:bold;padding-right:24px;" onclick="window.open('/people/usermail8444444444744474.php?useremail=<?php echo "$googlegoogegoogleappsappsappsappsappsapps84747474"; ?>','_self')">

<?php echo "$googlegoogleappsappsapps84121274747474"; ?>

</div>

</div>

<div>



<div class="googleappsdiv84747474" style="position:relative;top:0px;">

<div style="position:absolute;width:100%;">



<div>

<div class="aboutappsgoogleappsgoogleappsappsappsapps84747474" style="display:none;">

<div style="margin-top:12px;left:0px;background-color:#ffffff;width:280px;padding:12px;">

<div style="display:flex;padding:12px;">

<div style="border-radius:96px;padding:4px;background-color:<?php echo "$accountcolor4"; ?>;padding-left:6.1px;padding-right:6.1px;border-radius:396px;padding:2.4px;padding-left:6.1px;padding-right:6.1px;">

<i class='material-icons' style="font-size:17px;color:#ffffff;padding-top:3.08px;">public</i>

</div>

<div style="background-color:#ffffff;width:280px;font-size:12.8px;color:#222222;margin-left:4px;margin-top:-2px;font-size:17px;margin-top:4px;margin-left:8px;">

Intro

</div>

</div>

<div>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

if(preg_match("/$_COOKIE[username]/","$nameappsapps8884"))

{

?>

<div style="display:flex;padding:12px;cursor:pointer;" onclick="$('.googleappsappsappsappsappsappsappsappsappsappsapps44847474').show();">

<i class='material-icons' style="color:#444444;font-size:12.8px;color:<?php echo "$accountcolor4"; ?>;">add</i>

<div style="background-color:#ffffff;width:280px;font-size:12.8px;color:<?php echo "$accountcolor4"; ?>;margin-left:4px;margin-top:-2px;">

Add info about you

</div>

</div>

<?php

}

else

{

?>

<div style="display:flex;padding:12px;" onclick="$('.googleappsappsappsappsappsappsappsappsappsappsapps44847474').show();">

<div style="background-color:#ffffff;width:280px;font-size:12.8px;color:<?php echo "$accountcolor4"; ?>;margin-left:4px;margin-top:-2px;">

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsappsappsappsappsappsapps84 = "../aboutapps84747474.sh";

}

else

{

$dataurluserappsappsappsappsappsappsapps84 = "../people/aboutapps84747474.sh";

}

?>

<?php

$googleappsuserappsappsappsappsappsapps888474 = file_get_contents($dataurluserappsappsappsappsappsappsapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsappsappsapps888474, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$google84747474 = "$gosearchimages84747674";

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = rawurldecode($nameappsapps8884);

$gosearchimages84747674 = openssl_decrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

?>

<div style="color:#222222;">

<?php

echo "$gosearchimages84747674";

?>

</div>

</div>

</div>

<?php

}

?>

<div align="center" class="googleappsappsappsappsappsappsappsappsappsappsapps44847474" style="position:absolute;z-index:24884;display:inline-block!important;display:none!important;position:fixed;width:100%;height:100%;left:0px;top:0px;background:rgba(0, 0, 0, 0.4);" onclick="$(this).hide();">

<div style="padding:12px;margin-top:24px;background-color:#ffffff;margin-left:-12px;">



<form action="/people/aboutapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" placeholder="About" value="" name="aboutapps84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $_COOKIE[username]; ?>" name="aboutappsuser84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" required></input>

</form>



</div>

</div>

</div>

</div>

</div>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<script>

function getFileData(myFile){

$(document).ready(function(){

var googlemobileappsappsappsappsapps84444474 = $('#googleimageappsmobileappsappsappsapps84').val();

var file = myFile.files[0];  
var filename = file.name;

document.getElementById("google8444444444444474").click();

var str = filename;
var patt = new RegExp("png");
var googleapps84 = patt.test(str);

if (googleapps84) {

$.ajax({
    data: 'mainactivityapps84444474=<?php echo "$nameappsapps8884"; ?>&mainactivityapps84747474=<img src="/google8474/' + filename + '" style="width:100%;"></img>&mainactivityappsuserapps84747474=<?php echo "$_COOKIE[username]"; ?>&googleappsapps84444474=<?php echo "$namegoogleappsgooglegoogleapps84747474"; ?>',
    url: '/people/mainactivity84444474.php',
    method: 'GET',
    success: function(msg) {
    }
});

}

else

{

$.ajax({
    data: 'mainactivityapps84444474=<?php echo "$nameappsapps8884"; ?>&mainactivityapps84747474=<video style="width:100%;" controls><source src="/google8474/' + filename + '" type="video/mp4" style="width:100%;"></video>&mainactivityappsuserapps84747474=<?php echo "$_COOKIE[username]"; ?>&googleappsapps84444474=<?php echo "$namegoogleappsgooglegoogleapps84747474"; ?>',
    url: '/people/mainactivity84444474.php',
    method: 'GET',
    success: function(msg) {
    }
});

}

});

}

</script>

<div style="display:none;">

<div>

<form action="/google8474/googleappsgoogleapps8474.php" method="post" enctype="multipart/form-data" id="googleappsappsappsappsapps8474744444444474" style="display:none;">

<input type="hidden" name="username84747474" value="<?php echo "$_GET[useremail]"; ?>"></input>

<input type="file" name="image" id="googleimageappsmobileappsappsappsapps84" style="display:none;" onchange="getFileData(this);"></input>

<input type="submit" value="Submit" id="google8444444444444474" style="display:none;"></input>

</form>

</div>

</div>



<div>

<div class="aboutappsgoogleappsgoogleappsapps84747474" style="top:146px;">

<div class="googleappsimagesappsapps844444444474" style="margin-top:12px;left:0px;background-color:#ffffff;padding:12px;display:none;">

<div style="display:flex;padding:12px;">

<div style="border-radius:96px;padding:4px;background-color:<?php echo "$accountcolor4"; ?>;padding-left:6.1px;padding-right:6.1px;border-radius:396px;padding:2.4px;padding-left:6.1px;padding-right:6.1px;">

<i class='material-icons' style="font-size:17px;color:#ffffff;padding-top:3.08px;width:17px;">photos</i>

</div>

<div style="background-color:#ffffff;width:280px;font-size:12.8px;color:#222222;margin-left:4px;margin-top:-2px;font-size:17px;margin-top:4px;margin-left:8px;">

<?php echo "$googlegoogleappsappsapps84121274747474"; ?>

</div>

</div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleappsgooglemobileappsapps84 = "../gosearchimagesgoogleapps8884.sh";

}

else

{

$dataurlurlgoogleappsgooglemobileappsapps84 = "../gosearchimages8884/gosearchimagesgoogleapps8884.sh";

}

?>

<?php

$google842222222274 = file_get_contents($dataurlurlgoogleappsgooglemobileappsapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

preg_match_all("/<div class='$nameappsapps8884' id='na'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/s", $google842222222274, $gosearchimages844444224474);
$gosearchimages844444444474 = $gosearchimages844444224474[1];

$gosearchimages844444444474 = implode("<br>",$gosearchimages844444444474);

$gosearchimages844444444474 = explode("<br>",$gosearchimages844444444474);

?>

<?php

$googleapps84 = "0";

?>

<?php

foreach($gosearchimages844444444474 as $googleapps8444444474747474)

{

$googleapps84++;

?>

<?php

if(preg_match("/[\W\w]/","$googleapps8444444474747474"))

{

?>

<?php

if(preg_match("/png/","$googleapps8444444474747474"))

{

?>

<?php

echo "<img src='$googleapps8444444474747474' width='44' height='44'></img>";

?>

<?php

}

else

{

?>

<video style="width:44px;height:44px;" controls>

<source src="<?php echo "$googleapps8444444474747474"; ?>" type="video/mp4" style="width:100%;">

</video>

<?php

}

?>

<?php

}

?>

<?php

}

?>

<div>

<div style="display:flex;padding:12px;cursor:pointer;">

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<i class='material-icons' style="color:#444444;font-size:12.8px;color:<?php echo "$accountcolor4"; ?>;">add</i>

<div style="background-color:#ffffff;width:280px;font-size:12.8px;color:<?php echo "$accountcolor4"; ?>;margin-left:4px;margin-top:-2px;" id="googleappsappsappsappsapps844444444474" onclick="document.getElementById('googleimageappsmobileappsappsappsapps84').click();">

Add Image

</div>

<div align="center" class="googleappsappsappsappsappsappsappsappsappsappsapps44847474" style="position:absolute;z-index:24884;display:inline-block!important;display:none!important;position:fixed;width:100%;height:100%;left:0px;top:0px;background:rgba(0, 0, 0, 0.4);" onclick="$(this).hide();">

<div style="padding:12px;margin-top:24px;background-color:#ffffff;margin-left:-12px;">



<form action="/people/aboutapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" placeholder="About" value="" name="aboutapps84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $_COOKIE[username]; ?>" name="aboutappsuser84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" required></input>

</form>



</div>

</div>

</div>

</div>

</div>



<div>

<div class="aboutappsgoogleappsappsapps84747474" style="top:146px;">

<div style="margin-top:12px;background-color:#ffffff;width:280px;padding:12px;display:none;">

<div style="display:flex;padding:12px;">

<div style="border-radius:96px;padding:4px;background-color:<?php echo "$accountcolor4"; ?>;padding-left:6.1px;padding-right:6.1px;border-radius:396px;padding:2.4px;padding-left:6.1px;padding-right:6.1px;">

<i class='material-icons' style="font-size:17px;color:#ffffff;padding-top:3.08px;width:17px;">account_circle</i>

</div>

<div style="background-color:#ffffff;width:280px;font-size:12.8px;color:#222222;margin-left:4px;margin-top:-2px;font-size:17px;margin-top:4px;margin-left:8px;">

<?php echo "$google84121274747474"; ?>

</div>

</div>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleappsgooglemobileappsapps84 = "../coworkers84747474.sh";

}

else

{

$dataurlurlgoogleappsgooglemobileappsapps84 = "../people/coworkers84747474.sh";

}

?>

<?php

$google842222222274 = file_get_contents($dataurlurlgoogleappsgooglemobileappsapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $google842222222274, $gosearchimages844444224474);
$gosearchimages844444444474 = $gosearchimages844444224474[2];

$gosearchimages844444444474 = array_unique($gosearchimages844444444474);

$gosearchimages844444444474 = implode("<br>",$gosearchimages844444444474);

$gosearchimages844444444474 = explode("<br>",$gosearchimages844444444474);

?>

<?php

$googleapps84 = "0";

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../firstnameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/firstnameapps84747474.sh";

}

?>

<?php

$googleappsuserappsgoogleapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../lastnameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/lastnameapps84747474.sh";

}

?>

<?php

$googleappsuserappsgoogleappsapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../usernameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/usernameapps84747474.sh";

}

?>

<?php

$googleappsuserappsgoogleappsappsapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

foreach($gosearchimages844444444474 as $googleapps8444444474747474)

{

$googleapps84++;

?>

<?php

if(preg_match("/[\W\w]/","$googleapps8444444474747474"))

{

?>

<?php

preg_match_all("/<div class='$googleapps8444444474747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsgoogleapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$googleapps8444444474747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsgoogleappsapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$googleapps8444444474747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsgoogleappsappsapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgooglegoogleappsappsappsgoogleapps84 = "../accountcolor8884.sh";

}

else

{

$dataurlurlgooglegoogleappsappsappsgoogleapps84 = "../register/accountcolor8884.sh";

}

?>

<?php

$googleappsgooglegoogleappsappsappsappsapps8884 = file_get_contents($dataurlurlgooglegoogleappsappsappsgoogleapps84);

?>

<?php

preg_match_all("/<div class='$googleapps8444444474747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleappsappsappsappsapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps84742274 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

preg_match_all("/<div class='$googleapps8444444474747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleappsappsappsappsapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps847474 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorgoogleappsappsapps847474"))

{

$accountcolor1 = "$accountcolorgoogleappsappsapps847474";

$accountcolor2 = "$accountcolorgoogleappsappsapps847474";

$accountcolor4 = "$accountcolorgoogleappsappsapps847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<?php

$googleapps844444447474744474 = "$googleapps8444444474747474";

$passwordname8884 = "googleappsmobileapps888888884444";

$googleapps844444447474744474 = rawurldecode($googleapps844444447474744474);

$googleapps844444447474744474 = openssl_decrypt($googleapps844444447474744474,"AES-128-ECB",$passwordname8884);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$googleappsgooglegooglegooglegoogleappsappsapps8884 = "../gosearchimages8884.sh";

}

else

{

$googleappsgooglegooglegooglegoogleappsappsapps8884 = "../gosearchimages8884/gosearchimages8884.sh";

}

?>

<?php

$googleappsgooglegooglegooglegoogleappsappsapps8884 = file_get_contents($googleappsgooglegooglegooglegoogleappsappsapps8884);

?>

<?php

preg_match_all("/<div class='$googleapps8444444474747474' id='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegooglegooglegoogleappsappsapps8884, $googleappsappsappsappsappsappsapps84);
$gosearchimagesgoogleappsappsappsappsappsappsapps84747474 = $googleappsappsappsappsappsappsapps84[2][0];

?>

<?php

if(preg_match("/[\W\w]/",$gosearchimagesgoogleappsappsappsappsappsappsapps84747474))

{

?>

<divgoogle84747474 style="position:relative;cursor:pointer;" onclick="window.open('/people/usermail.php?useremail=<?php echo "$googleapps844444447474744474"; ?>','_self');">

<img src="<?php echo "$gosearchimagesgoogleappsappsappsappsappsappsapps84747474"; ?>" width="36.2" height="36.2" style="position:absolute;left:4px;top:-21px;"></img>

</divgoogle84747474>

<?php

}

else

{

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsappsappsappsappsappsapps84 = "../googleappsapps84747474.sh";

}

else

{

$dataurluserappsappsappsappsappsappsapps84 = "../people/googleappsapps84747474.sh";

}

?>

<?php

$googleappsuserappsappsappsappsappsapps888474 = file_get_contents($dataurluserappsappsappsappsappsappsapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$googleapps8444444474747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsappsappsapps888474, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/(^Male$|^male$)/","$gosearchimages84747674"))

{

?>

<div class='inline' onclick="window.open('/people/usermail.php?useremail=<?php echo "$googleapps844444447474744474"; ?>','_self');">

<img class='textavatar' src="/gosearchimages8884/googleapps84.jpg" style='width:34px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;box-shadow:0 2px 8px rgba(0,0,0,0.2);' data-name='<?php echo "$googleappsappsapps844444444474"; ?>'></img>

</div>

<?php

}

else

{

?>

<div class='inline' onclick="window.open('/people/usermail.php?useremail=<?php echo "$googleapps844444447474744474"; ?>','_self');">

<img class='textavatar' src="/gosearchimages8884/googleapps84747474.jpeg" style='width:34px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;box-shadow:0 2px 8px rgba(0,0,0,0.2);' data-name='<?php echo "$googleappsappsapps844444444474"; ?>'></img>

</div>

<?php

}

?>

<?php

}

?>



<?php

}

?>

<?php

}

?>

<div>

<div style="display:flex;padding:12px;">

<?php

if(preg_match("/$_COOKIE[username]/","$googleapps844444447474744474"))

{

?>

<i class='material-icons' style="color:#444444;font-size:12.8px;color:<?php echo "$accountcolor4"; ?>;">add</i>

<div style="background-color:#ffffff;width:280px;font-size:12.8px;color:<?php echo "$accountcolor4"; ?>;margin-left:4px;margin-top:-2px;" id="googleappsappsappsappsapps844444444474" onclick="document.getElementById('googleimageappsmobileappsappsappsapps84').click();">

Add <?php echo "$google84121274747474"; ?>

</div>

<?php

}

?>

<div align="center" class="googleappsappsappsappsappsappsappsappsappsappsapps44847474" style="position:absolute;z-index:24884;display:inline-block!important;display:none!important;position:fixed;width:100%;height:100%;left:0px;top:0px;background:rgba(0, 0, 0, 0.4);" onclick="$(this).hide();">

<div style="padding:12px;margin-top:24px;background-color:#ffffff;margin-left:-12px;">



<form action="/people/aboutapps84747474.php" method="post" enctype="multipart/form-data">

<div>

<input type="text" placeholder="About" value="" name="aboutapps84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo $_COOKIE[username]; ?>" name="aboutappsuser84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Work" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>

<input type="submit" placeholder="Your first name" value="update" autocomplete="off" required></input>

</form>



</div>

</div>

</div>

</div>

</div>

</div>

</div>

</div>

</div>

</div>

</div>

<div align="right" style="margin-top:12px;">

<div id="minutesappsappsappsgoogleappsgoogleapps844444444474"></div>

<script>

$(document).ready(function(){

$("#minutesappsappsappsgoogleappsgoogleapps844444444474").load('/people/usersgoogleapps84444474.php?useremail=<?php echo "$_GET[useremail]"; ?>');

});

</script>

<div class="googleappsappsappsgooglegoogleappsappsapps84444474" style="margin-top:12px;box-shadow:0px 2px 8px rgba(0, 0, 0, 0.2);display:none;">

<div class="googleappsappsapps844444224474" style="position:relative;left:0px;text-align:left;padding:12px;z-index:888844;background-color:#ffffff;" align="left;">

<div style="display:flex;">

<div style="display:flex;">

<divappsapps844444444474>

<i class="material-icons" style="font-size:14.6px;">public</i>

</divappsapps844444444474>

<divappsapps844444444474 style="font-size:12.8px;font-weight:bold;color:#444444;margin-left:4px;">

<?php

echo "$google8474444444474";

?>

</divappsapps844444444474>

</div>

<div style="display:flex;">

<divappsapps844444444474 style="margin-left:4px;">

<i class="material-icons" style="font-size:14.6px;">camera_alt</i>

</divappsapps844444444474>

<divappsapps844444444474 style="cursor:pointer;font-size:12.8px;font-weight:bold;margin-left:4px;color:#444444" onclick="document.getElementById('googleimageappsmobileappsappsappsapps84').click();">

<?php

echo "$googlegoogleappsappsapps84121274747474444474" . " Video";

?>

</divappsapps844444444474>

</div>

</div>

</div>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../coworkersgoogle84747474.sh";

}

else

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../people/coworkersgoogle84747474.sh";

}

?>

<?php

$googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884 = file_get_contents($dataurlurlgoogleappsgooglegoogleappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884, $googleappsappsappsgoogleappsappsgooglegoogleappsapps84);
$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274 = $googleappsappsappsgoogleappsappsgooglegoogleappsapps84[2][0];

?>

<?php

if(preg_match("/business/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "business";

$google8474444444474 = "Update";

}

if(preg_match("/apps/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "Getit";

$google8474444444474 = "Post";

}

if(preg_match("/google/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "google";

$google8474444444474 = "Post";

}

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{
}

else

{

$googleappsappsapps84744474 = "business";

}

?>

<?php

if(preg_match("/$_COOKIE[username]/","$googlegoogegoogleappsappsapps84747474"))

{

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<div class="google84224422444474" style="z-index:888844;background-color:#ffffff;position:relative;" align="left">

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegooglegooglegoogleappsappsapps8884, $googleappsappsappsappsappsappsapps84);
$gosearchimagesgoogleappsappsappsappsappsappsapps84747474 = $googleappsappsappsappsappsappsapps84[2][0];

?>

<?php

if(preg_match("/[\W\w]/",$gosearchimagesgoogleappsappsappsappsappsappsapps84747474))

{

?>

<?php

preg_match_all("/<div class='$namegoogleappsgooglegooglegoogleappsgoogleappsappsgoogleapps84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps84742274 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

preg_match_all("/<div class='$namegoogleappsgooglegooglegoogleappsgoogleappsappsgoogleapps84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps847474 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorgoogleappsappsapps847474"))

{

$accountcolor1 = "$accountcolorgoogleappsappsapps847474";

$accountcolor2 = "$accountcolorgoogleappsappsapps847474";

$accountcolor4 = "$accountcolorgoogleappsappsapps847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<div id="div84747474" style="left:12px;top:24px;position:relative;"><img class="googleapps84744422224474" src="<?php echo $gosearchimagesgoogleappsappsappsappsappsappsapps84747474; ?>" width="34" height="34" style="border-color:<?php echo "$accountcolor4"; ?>;border-width:2px;box-shadow:0 2px 4px rgba(0,0,0,0.1);position:absolute;left:0px;z-index:888884;margin-top:4px;" onclick='myFunctiongoogleappsappsappsappsapps()'></img></div>

<?php

}

else

{

?>

<?php

$googleappsappsappsappsapps844444444474 = preg_replace("/(.*?) (.*?)/","$1",$googleappsappsapps844444444474);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsappsappsappsappsappsapps84 = "../googleappsapps84747474.sh";

}

else

{

$dataurluserappsappsappsappsappsappsapps84 = "../people/googleappsapps84747474.sh";

}

?>

<?php

$googleappsuserappsappsappsappsappsapps888474 = file_get_contents($dataurluserappsappsappsappsappsappsapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsappsappsapps888474, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/(^Male$|^male$)/","$gosearchimages84747674"))

{

?>

<div style='position:absolute;left:17.6px;top:14px;bottom:-28px;'>

<div class="googleappsappsgoogle844444224474" style="position:absolute;z-index:888884;left:-4px;top:4px;">

<div class='inline'>

<img class='textavatar googleapps84744422224474' src="/gosearchimages8884/googleapps84.jpg" style='width:34px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;border-radius:196px;border-style:solid;border-color:#f1f1f1;border-width:1px;' data-name='<?php echo "$googleappsappsappsappsapps844444444474"; ?>'></img>

</div>

</div>

</div>

<?php

}

else

{

?>

<div style='position:absolute;left:17.6px;top:14px;bottom:-28px;'>

<div class="googleappsappsgoogle844444224474" style="position:absolute;z-index:888884;left:-4px;top:4px;">

<div class='inline'>

<img class='textavatar googleapps84744422224474' src="/gosearchimages8884/googleapps84747474.jpeg" style='width:34px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;border-radius:196px;border-style:solid;border-color:#f1f1f1;border-width:1px;' data-name='<?php echo "$googleappsappsappsappsapps844444444474"; ?>'></img>

</div>

</div>

</div>

<?php

}

?>

<?php

}

?>

<form action="" method="post" enctype="multipart/form-data" class="googledivdivappsappsappsappsappsapps84747474" style="">

<input type="text" name="userappsappsapps84747474" id="googleuserappsappsappsgoogleappsappsapps84747474" class="googleuserappsappsapps84747474444474" value="" autocomplete="off" placeholder="<?php echo "$googleapps84741274"; ?> <?php echo "$googleappsappsapps844444444474"; ?>?" style="padding:12px;font-size:17.6px;border:none;outline-style:none;z-index:888844;padding-left:58px;padding-top:34px;padding-bottom:34px;box-sizing:border-box;" onclick="$('#googlegooglegooglegoogleappsappsappsappsgoogleappsappsappsapps84444474').show();$('.google88884444444474444474').show();$('.googleappsapps84444444444474444474').show();$('.googleappsappsapps844444224474').css('z-index', 888844);$('.google84224422444474').css('z-index', 888844);$('.googleappsappsappsgooglegoogleappsappsapps84444474').css('z-index', '888844');"></input>

<input type="submit" value="post" style="border:none;background-color:<?php echo "$accountcolor4"; ?>;padding:12px;color:#ffffff;font-weight:bold;margin:12px;font-size:13.8px;display:none;"></input>

</form>

<div style="position:relative;left:0px;text-align:left;padding:12px;z-index:888844;background-color:#ffffff;" align="left;">

<div class="googleimageappapps847474744474" style="background-color:#f8f8f8;padding:12px;display:inline-block;border-radius:196px;">

<divappsapps844444444474 style="margin-left:4px;">

<i class="material-icons" style="font-size:14.6px;position:relative;top:2px;">insert_photo</i>

</divappsapps844444444474>

<divappsapps844444444474 style="cursor:pointer;font-size:12.8px;font-weight:bold;color:#888888;" onclick="document.getElementById('googleimageappsmobileappsappsappsapps84').click();">

<?php

echo "$googlegoogleappsappsapps84121274747474444474" . " Video";

?>

</divappsapps844444444474>

</div>

</div>

<div class="googleappsapps84444444444474444474" style="z-index:888844;position:relative;padding:12px;background-color:#ffffff;display:none;">

<div>

<div id="googlegooglegooglegoogleappsappsappsappsgoogleappsappsappsapps84444474" style="padding:10px;background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsapps84"; ?>;color:#ffffff;border-radius:4px;text-align:center;display:none;">

<?php echo "$google8474444444474"; ?>

</div>

</div>

</div>



</div>



</div>

<div class="google88884444444474444474" style="position:fixed;height:100%;width:100%;top:0px;left:0px;background:rgba(0, 0, 0, 0.4);display:none;z-index:8884;" onclick="$('#googlegooglegooglegoogleappsappsappsappsgoogleappsappsappsapps84444474').hide();$('.googleappsapps84444444444474444474').hide();$(this).hide();">
</div>

<?php

}

else

{

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../coworkersgoogle84747474.sh";

}

else

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../people/coworkersgoogle84747474.sh";

}

?>

<?php

$googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884 = file_get_contents($dataurlurlgoogleappsgooglegoogleappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884, $googleappsappsappsgoogleappsappsgooglegoogleappsapps84);
$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274 = $googleappsappsappsgoogleappsappsgooglegoogleappsapps84[2][0];

?>

<?php

if(preg_match("/business/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "business";

$google8474444444474 = "Update";

}

if(preg_match("/apps/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "Getit";

$google8474444444474 = "Post";

}

if(preg_match("/google/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "google";

$google8474444444474 = "Post";

}

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{
}

else

{

$googleappsappsapps84744474 = "business";

}

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$nameappsapps8884' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<div class="google84224422444474" style="z-index:888844;background-color:#ffffff;position:relative;" align="left">

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$googleappsgooglegooglegooglegoogleappsappsapps8884 = "../gosearchimages8884.sh";

}

else

{

$googleappsgooglegooglegooglegoogleappsappsapps8884 = "../gosearchimages8884/gosearchimages8884.sh";

}

?>

<?php

$googleappsgooglegooglegooglegoogleappsappsapps8884 = file_get_contents($googleappsgooglegooglegooglegoogleappsappsapps8884);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegooglegooglegoogleappsappsapps8884, $googleappsappsappsappsappsappsapps84);
$gosearchimagesgoogleappsappsappsappsappsappsapps84747474 = $googleappsappsappsappsappsappsapps84[2][0];

?>

<?php

if(preg_match("/[\W\w]/",$gosearchimagesgoogleappsappsappsappsappsappsapps84747474))

{

?>

<?php

preg_match_all("/<div class='$namegoogleappsgooglegooglegoogleappsgoogleappsappsgoogleapps84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps84742274 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

preg_match_all("/<div class='$namegoogleappsgooglegooglegoogleappsgoogleappsappsgoogleapps84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps847474 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorgoogleappsappsapps847474"))

{

$accountcolor1 = "$accountcolorgoogleappsappsapps847474";

$accountcolor2 = "$accountcolorgoogleappsappsapps847474";

$accountcolor4 = "$accountcolorgoogleappsappsapps847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<div id="div84747474" style="left:12px;top:24px;position:relative;"><img class="googleapps84744422224474" src="<?php echo $gosearchimagesgoogleappsappsappsappsappsappsapps84747474; ?>" width="34" height="34" style="border-color:<?php echo "$accountcolor4"; ?>;border-width:2px;box-shadow:0 2px 4px rgba(0,0,0,0.1);position:absolute;left:0px;z-index:888884;margin-top:4px;" onclick='myFunctiongoogleappsappsappsappsapps()'></img></div>

<?php

}

else

{

?>

<?php

$googleappsappsappsappsapps844444444474 = preg_replace("/(.*?) (.*?)/","$1",$googleappsappsapps844444444474);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsappsappsappsappsappsapps84 = "../googleappsapps84747474.sh";

}

else

{

$dataurluserappsappsappsappsappsappsapps84 = "../people/googleappsapps84747474.sh";

}

?>

<?php

$googleappsuserappsappsappsappsappsapps888474 = file_get_contents($dataurluserappsappsappsappsappsappsapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsappsappsapps888474, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/(^Male$|^male$)/","$gosearchimages84747674"))

{

?>

<div style='position:absolute;left:17.6px;top:14px;bottom:-28px;'>

<div class="googleappsappsgoogle844444224474" style="position:absolute;z-index:888884;left:-4px;top:4px;">

<div class='inline'>

<img class='textavatar googleapps84744422224474' src="/gosearchimages8884/googleapps84.jpg" style='width:34px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;border-radius:196px;border-style:solid;border-color:#f1f1f1;border-width:1px;' data-name='<?php echo "$googleappsappsappsappsapps844444444474"; ?>'></img>

</div>

</div>

</div>

<?php

}

else

{

?>

<div style='position:absolute;left:17.6px;top:14px;bottom:-28px;'>

<div class="googleappsappsgoogle844444224474" style="position:absolute;z-index:888884;left:-4px;top:4px;">

<div class='inline'>

<img class='textavatar googleapps84744422224474' src="/gosearchimages8884/googleapps84747474.jpeg" style='width:34px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;border-radius:196px;border-style:solid;border-color:#f1f1f1;border-width:1px;' data-name='<?php echo "$googleappsappsappsappsapps844444444474"; ?>'></img>

</div>

</div>

</div>

<?php

}

?>

<?php

}

?>

<div>

<div>

<form action="" method="post" enctype="multipart/form-data" class="googledivdivappsappsappsappsappsapps84747474" style="">

<input type="text" name="userappsappsapps84747474" id="googleuserappsappsappsgoogleappsappsapps84747474" class="googleuserappsappsapps84747474444474" value="" autocomplete="off" placeholder="<?php echo "$googleapps84741274"; ?> <?php echo "$googleappsappsapps844444444474"; ?>?" style="padding:12px;font-size:17.6px;border:none;outline-style:none;z-index:888844;padding-left:58px;padding-top:34px;padding-bottom:34px;" onclick="$('#googlegooglegooglegoogleappsappsappsappsgoogleappsappsappsapps84444474').show();$('.google88884444444474444474').show();$('.googleappsapps84444444444474444474').show();$('.googleappsappsapps844444224474').css('z-index', 888844);$('.google84224422444474').css('z-index', 888844);$('.googleappsappsappsgooglegoogleappsappsapps84444474').css('z-index', '888844');"></input>

<input type="submit" value="post" style="border:none;background-color:<?php echo "$accountcolor4"; ?>;padding:12px;color:#ffffff;font-weight:bold;margin:12px;font-size:13.8px;display:none;"></input>

</form>

<div style="position:relative;left:0px;text-align:left;padding:12px;z-index:888844;background-color:#ffffff;" align="left;">

<div class="googleimageappapps847474744474" style="background-color:#f8f8f8;padding:12px;display:inline-block;border-radius:196px;">

<divappsapps844444444474 style="margin-left:4px;">

<i class="material-icons" style="font-size:14.6px;position:relative;top:2px;">insert_photo</i>

</divappsapps844444444474>

<divappsapps844444444474 style="cursor:pointer;font-size:12.8px;font-weight:bold;color:#888888;" onclick="document.getElementById('googleimageappsmobileappsappsappsapps84').click();">

<?php

echo "$googlegoogleappsappsapps84121274747474444474" . " Video";

?>

</divappsapps844444444474>

</div>

</div>

<div class="googleappsapps84444444444474444474" style="z-index:888844;position:relative;padding:12px;background-color:#ffffff;display:none;">

<div>

<div id="googlegooglegooglegoogleappsappsappsappsgoogleappsappsappsapps84444474" style="padding:10px;background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsapps84"; ?>;color:#ffffff;border-radius:4px;text-align:center;display:none;">

<?php echo "$google8474444444474"; ?>

</div>

</div>

</div>

<div class="googleappsapps84444444444474444474" style="z-index:888844;position:relative;padding:12px;background-color:#ffffff;display:none;">

<div>

<div id="googlegooglegooglegoogleappsappsappsappsgoogleappsappsappsapps84444474" style="padding:10px;background-color:<?php echo "$googleappsappsappsappsappsgooglegoogleappsappsapps84"; ?>;color:#ffffff;border-radius:4px;text-align:center;display:none;">

<?php echo "$google8474444444474"; ?>

</div>

</div>

</div>



</div>

</div>



</div>

</div>

<div class="google88884444444474444474" style="position:fixed;height:100%;width:100%;top:0px;left:0px;background:rgba(0, 0, 0, 0.4);display:none;z-index:8884;" onclick="$('#googlegooglegooglegoogleappsappsappsappsgoogleappsappsappsapps84444474').hide();$('.googleappsapps84444444444474444474').hide();$(this).hide();">
</div>

<?php

}

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../coworkersgoogle84747474.sh";

}

else

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../people/coworkersgoogle84747474.sh";

}

?>

<?php

$googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884 = file_get_contents($dataurlurlgoogleappsgooglegoogleappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884, $googleappsappsappsgoogleappsappsgooglegoogleappsapps84);
$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274 = $googleappsappsappsgoogleappsappsgooglegoogleappsapps84[2][0];

?>

<?php

if(preg_match("/business/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "business";

$google8474444444474 = "Update";

}

if(preg_match("/apps/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "Getit";

$google8474444444474 = "Post";

}

if(preg_match("/google/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "google";

$google8474444444474 = "Post";

}

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{
}

else

{

$googleappsappsapps84744474 = "business";

}

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../coworkersgoogle84747474.sh";

}

else

{

$dataurlurlgoogleappsgooglegoogleappsapps84 = "../people/coworkersgoogle84747474.sh";

}

?>

<?php

$googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884 = file_get_contents($dataurlurlgoogleappsgooglegoogleappsapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegoogleappsgoogleappsappsappsgoogleapps8884, $googleappsappsappsgoogleappsappsgooglegoogleappsapps84);
$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274 = $googleappsappsappsgoogleappsappsgooglegoogleappsapps84[2][0];

?>

<?php

if(preg_match("/business/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "business";

$google8474444444474 = "Update";

}

if(preg_match("/apps/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "Getit";

$google8474444444474 = "Post";

}

if(preg_match("/google/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{

$googleappsappsapps84744474 = "google";

$google8474444444474 = "Post";

}

if(preg_match("/[\W\w]/","$accountcolorappsappsappsappsappsgooglegoogleappsapps84742274"))

{
}

else

{

$googleappsappsapps84744474 = "business";

}

?>

<div class="googleappsappsapps8474" id="googlegooglegoogleappsappsappsapps844444444474" style="display:none;">

<div>

<div style="position:absolute;">

<div class="googleappsappsappsgooglegoogleappsappsappsgoogleappsapps844444444474" align="center" style="display:none;">

<div class="googleappsapps84444444444474" style="box-shadow:0 2px 8px rgba(0,0,0,0.2);">

<?php

if(preg_match("/$_COOKIE[username]/","$googlegoogegoogleappsappsapps84747474"))

{

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

}

else

{

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

}

?>

</div>

</div>

</div>

</div>



<div class="google844444444474">

<div align="right">

<div>
</div>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../mainactivityapps84747474.sh";

}

else

{

$dataurl84 = "../people/mainactivityapps84747474.sh";

}

?>

<?php

$googleapps8884 = file_get_contents("");

?>

<?php

$googlegoogledivappsappsapps84747474 = $_GET['useremail'];

$passwordname8884 = "googleappsmobileapps888888884444";

$googlegoogledivappsappsapps84747474 = openssl_encrypt($googlegoogledivappsappsapps84747474,"AES-128-ECB",$passwordname8884);

$googlegoogledivappsappsapps84747474 = rawurlencode($googlegoogledivappsappsapps84747474);

?>

<?php

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='$googlegoogledivappsappsapps84747474' id='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/", $googleapps8884, $googleapps84);
$name = $googleapps84[0];

?>

<?php

$name = implode("<br>",$name);

$name = explode("<br>",$name);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurl84 = "../userregistrations.sh";

}

else

{

$dataurl84 = "../register/userregistrations.sh";

}

?>

<?php

$googleappsgoogleappsapps8884 = file_get_contents("$dataurl84");

?>

<?php

$googleappsgooglegooglegoogleappsappsapps8884 = file_get_contents($dataurl84);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsapps84 = "../thumbsupapps84747474.sh";

}

else

{

$dataurlappsapps84 = "thumbsupapps84747474.sh";

}

?>

<?php

$googleappsgooglegooglegooglegoogleapps8884 = file_get_contents("$dataurlappsapps84");

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$googleappsgooglegooglegooglegoogleappsappsapps8884 = "../gosearchimages8884.sh";

}

else

{

$googleappsgooglegooglegooglegoogleappsappsapps8884 = "../gosearchimages8884/gosearchimages8884.sh";

}

?>

<?php

$googleappsgooglegooglegooglegoogleappsappsapps8884 = file_get_contents($googleappsgooglegooglegooglegoogleappsappsapps8884);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$fileappsappsappsapps84 = "../userregistrations.sh";

}

else

{

$fileappsappsappsapps84 = "../register/userregistrations.sh";

}

?>

<?php

$fileappsappsappsapps84 = file_get_contents("$fileappsappsappsapps84");

?>

<?php

$googleapps84 = "0";

?>

<?php

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='$nameappsapps8884' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleapps8884,$googleappsappsappsappsapps844444444474);
$nameappsappsappsapps84747474 = $googleappsappsappsappsapps844444444474[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$nameappsappsappsapps84747474"))

{

?>

<?php

$googleappsgoogleappsappsapps84747474 = $_COOKIE['username'];

?>

<?php

$googleappsappsgoogleappsappsappsapps84 = "99999";

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84447422 = "../mainactivityapps84747474.sh";

}

else

{

$dataurlappsappsapps84447422 = "../people/mainactivityapps84747474.sh";

}

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsapps84447422 = "../mainactivityapps84747474.sh";

}

else

{

$dataurlappsappsapps84447422 = "../people/mainactivityapps84747474.sh";

}

?>

<?php

$googleappsappsappsapps84747444 = file_get_contents("");

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurlappsappsappsappsgooglegoogleappsgoogle84447422 = "../mainactivityapps84747474.sh";

}

else

{

$dataurlappsappsappsappsgooglegoogleappsgoogle84447422 = "../people/mainactivityapps84747474.sh";

}

?>

<?php

$googleappsappsappsappsappsgooglegoogleappsgoogle84747444 = file_get_contents("");

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsappsappsappsappsgooglegoogleappsgoogle84747444, $googleappsgooglegoogleappsappsgooglegoogleappsgooglegooglegoogle84);

$namegoogleappsgooglegooglegoogleappsgoogleappsappsgoogleappsgooglegooglegooglegooglegoogleapps84747474 = $googleappsgooglegoogleappsappsgooglegoogleappsgooglegooglegoogle84[6][0];

$namegoogleappsgooglegooglegoogleappsgoogleappsappsgoogleappsgooglegooglegooglegooglegoogleapps84747474 = $namegoogleappsgooglegooglegoogleappsgoogleappsappsgoogleappsgooglegooglegooglegooglegoogleapps84747474 - 1;

?>

<?php

foreach($name as $googleapps84)

{

?>

<?php

$googleappsappsgoogleapps84++;

$googleappsappsgoogleappsappsappsapps84++;

$namegoogleappsgooglegooglegoogleappsgoogleappsappsgoogleappsgooglegooglegooglegooglegoogleapps84747474++;

?>

<?php

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/", $googleapps84, $googleappsgoogleappsappsappsgoogleappsappsgoogleappsappsappsapps84);
$name84747474 = $googleappsgoogleappsappsappsgoogleappsappsgoogleappsappsappsapps84[1][0];

?>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $fileappsappsappsapps84, $googleappsappsapps84);
$namegooglegoogleappsappsappsapps84747474 = $googleappsappsapps84[2][0];

$password="googleappsmobileapps888888884444";

$namegooglegoogleappsappsappsapps84747474 = rawurldecode($namegooglegoogleappsappsappsapps84747474);

$namegooglegoogleappsappsappsapps84747474 = openssl_decrypt($namegooglegoogleappsappsappsapps84747474,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/", $googleapps84, $googleappsgoogleappsgooglegooglegoogleappsappsapps84);
$nameappsappsappsappsapps84444474 = $googleappsgoogleappsgooglegooglegoogleappsappsapps84[3][0];

?>

<script>

function googleappsappsappsgoogleapps<?php echo $googleappsappsgoogleapps84; ?>() {

$(document).ready(function() {

var googlemobileapps84444474 = $('#googleuserappsappsappsgoogleappsappsapps84747474').val();

var googlemobileappsgoogleappsappsgoogleapps84444474 = '<?php echo "$_COOKIE[username]"; ?>';

$.ajax({
    data: 'mainactivityapps84444474=<?php echo "$name84747474"; ?>&mainactivityapps84747474=<?php echo $nameappsappsappsappsapps84444474; ?>&mainactivityappsuserapps84747474=<?php echo "$googleappsgoogleappsappsapps84747474"; ?>',
    url: '/people/mainactivity84444474.php',
    method: 'GET',
    success: function(msg) {
    }
});

$.ajax({
    data: 'googleapps84747474=<?php echo "$name84747474"; ?>&googleapps1=<?php echo "$googleappsgoogleappsappsapps84747474"; ?>&googleapps4=' + googlemobileapps84444474 + '&googleappsapps1=googleapps84',
    url: '/emailappsapps84747474/useremailsappsapps84444474.php',
    method: 'GET',
    success: function(msg) {
    }
});

location.reload();

$('#myDropdown<?php echo $googleappsappsgoogleapps84; ?>').hide();



}

);

}

</script>

<div class="google84444444444474" style="height:100%;padding:12px;margin-top:12px;background-color:#ffffff;box-shadow:0 2px 4px rgba(0,0,0,0.2);position:relative;" align="left">

<div style="width:100%;">

<div style="margin-top:0px;position:absolute;right:0px;">

<div class="dropdown">
  <div onclick="myFunctiongoogleappsappsappsappsappsgoogleapps<?php echo "$googleappsappsgoogleapps84"; ?>();" class="dropbtn" style="font-size:12.4px;background:none;border:none;margin-right:12px;"><i class='material-icons googleappsgoogleappsappsapps84747474' id="googlegoogleappsappsapps84221874" style="color:#444444;font-size:19.4px;">more_vert</i></div>
  <div id="myDropdown<?php echo $googleappsappsgoogleapps84; ?>" class="dropdown-content" style="display:none;margin-left:-128.4px;">
    <div style="font-size:14px;background-color:#ffffff;">Report</div>
    <div style="font-size:14px;background-color:#ffffff;" onclick="$('#google<?php echo "$googleappsappsgoogleapps84"; ?>').show();"><?php echo "$google4"; ?></div>
    <div style="font-size:14px;background-color:#ffffff;">Show user</div>

<div style="font-size:14px;background-color:#ffffff;" onclick="googleappsappsappsgoogleapps<?php echo $googleappsappsgoogleapps84; ?>();"><?php echo "$google2"; ?></div>

</div>
</div>

<script>

function myFunctiongoogleappsappsappsappsappsgoogleapps<?php echo "$googleappsappsgoogleapps84"; ?>() {
    var x = document.getElementById('myDropdown<?php echo "$googleappsappsgoogleapps84"; ?>');
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

</script>

<style>

/* Dropdown Button */
.dropbtn {
cursor: pointer;
}

/* Dropdown button on hover & focus */
.dropbtn:hover, .dropbtn:focus {
    background-color: #2980B9;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
    position: relative;
    display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow: 0px 2px 4px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content div {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content div:hover {background-color:#ebebeb!important}

/* Show the dropdown menu (use JS to add this class to the .dropdown-content container when the user clicks on the dropdown button) */
.show {display:block;}

</style>

</div>

</div>

<div class="googleappsappsapps8474" id="google<?php echo "$googleappsappsgoogleapps84"; ?>" style="display:none;" onclick="$(this).hide();">

<div>

<div style="position:fixed;background-color:#bdbdbd;z-index:9884;height:100%;top:0px;width:100%;left:0px;background:rgba(0, 0, 0, 0.4);">

<div align="center" style="margin:12px;margin-top:62px;background-color:#f1f1f1;padding:12px;">

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsappsappsapps84747444, $googleappsgooglegoogleappsnamegoogleappsgooglegoogleappsappsapps84747474447484);

$namegoogleappsgooglegoogleappsappsapps847474744474 = $googleappsgooglegoogleappsnamegoogleappsgooglegoogleappsappsapps84747474447484[5][0];

$namegoogleappsgooglegoogleappsappsapps847474744474 = count($namegoogleappsgooglegoogleappsappsapps847474744474[0]);

$googleappsappsappsgoogleapps844444444474 = $googleappsappsgoogleappsappsappsapps84 - $namegoogleappsappsgoogleapps84747474;



?>

<?php

preg_match_all("/<div class='$name84747474'>\n<div class='(.*?)'>\n<div class='$namegoogleappsgooglegooglegoogleappsgoogleappsappsgoogleappsgooglegooglegooglegooglegoogleapps84747474'>(.*?)<\/div>\n<\/div>\n<\/div>/", $googleappsgooglegooglegooglegoogleapps8884, $googleappsgooglegoogleappsgooglegooglegooglegoogle84);

$namegoogleappsgooglegoogle84747474 = $googleappsgooglegoogleappsgooglegooglegooglegoogle84[0];

$namegoogleappsgooglegoogle84747474 = count($namegoogleappsgooglegoogle84747474);

?>

<?php

$namegoogleappsappsapps84747474 = "$name84747474";

$password="googleappsmobileapps888888884444";

$namegoogleappsappsapps84747474 = rawurldecode($namegoogleappsappsapps84747474);

$namegoogleappsappsapps84747474 = openssl_decrypt($namegoogleappsappsapps84747474,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps84742274 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps847474 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorgoogleappsappsapps847474"))

{

$accountcolor1 = "$accountcolorgoogleappsappsapps847474";

$accountcolor2 = "$accountcolorgoogleappsappsapps847474";

$accountcolor4 = "$accountcolorgoogleappsappsapps847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<div style="display:flex;">

<div style="font-weight:bold;">

<?php echo "$google1" . "'s"; ?>

</div>

<div style="background-color:<?php echo "$accountcolor4"; ?>;padding:4px;font-size:12.8px;color:#ffffff;margin-left:4px;">

<?php

echo "$namegoogleapps84747474";

?>

</div>

</div>

<div style="display:flex;">

<div style="font-weight:bold;">

User email

</div>

<div style="margin-left:4px;">

<?php

echo "$namegoogleappsappsapps84747474";

?>

</div>

</div>

</div>



</div>

</div>

</div>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegooglegooglegoogleappsappsapps8884, $googleappsappsappsappsappsappsapps84);
$gosearchimagesgoogleappsappsappsappsappsappsapps84747474 = $googleappsappsappsappsappsappsapps84[2][0];

?>

<?php

if(preg_match("/[\W\w]/",$gosearchimagesgoogleappsappsappsappsappsappsapps84747474))

{

?>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps84742274 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps847474 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorgoogleappsappsapps847474"))

{

$accountcolor1 = "$accountcolorgoogleappsappsapps847474";

$accountcolor2 = "$accountcolorgoogleappsappsapps847474";

$accountcolor4 = "$accountcolorgoogleappsappsapps847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<div id="div84747474" style="position:absolute;left:12px;top:24px;"><img src="<?php echo $gosearchimagesgoogleappsappsappsappsappsappsapps84747474; ?>" width="34" height="34" style="border-color:<?php echo "$accountcolor4"; ?>;border-width:2px;box-shadow:0 2px 4px rgba(0,0,0,0.1);" onclick='myFunctiongoogleappsappsappsappsapps()'></img></div>

<script>

function myFunctiongoogleappsappsappsappsapps() {
    var x = document.getElementById("googleappsappsapps84444474");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

</script>



<?php

}

else

{

?>

<style>

.googleapps84742274
{
display:inline-block!important;
}

</style>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/", $fileappsappsappsapps84, $googleappsappsappsappsapps84747474);
$nameappsappsappsapps84747474 = $googleappsappsappsappsapps84747474[2][0];

$password="googleappsmobileapps888888884444";

$nameappsappsappsapps84747474 = rawurldecode($nameappsappsappsapps84747474);

$nameappsappsappsapps84747474 = openssl_decrypt($nameappsappsappsapps84747474,"AES-128-ECB",$password);

$nameappsappsappsappsappsapps8884 = "$nameappsappsappsapps84747474";

?>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsappsappsapps84);
$accountcolorappsappsappsapps84742274 = $googleappsappsappsappsapps84[3][0];

?>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsappsappsappsapps84);
$accountcolorappsappsappsapps84747474 = $googleappsappsappsappsapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorappsappsappsapps84747474"))

{

$accountcolor1 = "$accountcolorappsappsappsapps84747474";

$accountcolor2 = "$accountcolorappsappsappsapps84747474";

$accountcolor4 = "$accountcolorappsappsappsapps84747474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674 $gosearchimagesappsappsappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

$googleappsappsappsappsapps844444444474 = preg_replace("/(.*?) (.*?)/","$1",$googleappsappsapps844444444474);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsappsappsappsappsappsapps84 = "../googleappsapps84747474.sh";

}

else

{

$dataurluserappsappsappsappsappsappsapps84 = "../people/googleappsapps84747474.sh";

}

?>

<?php

$googleappsuserappsappsappsappsappsapps888474 = file_get_contents($dataurluserappsappsappsappsappsappsapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsappsappsapps888474, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/(^Male$|^male$)/","$gosearchimages84747674"))

{

?>

<div style='position:absolute;left:12px;top:24px;cursor:pointer;'>

<div>

<div class='inline'>

<img class='textavatar' src="/gosearchimages8884/googleapps84.jpg" style='width:34px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;border-radius:196px;border-style:solid;border-color:#f1f1f1;border-width:1px;' data-name='<?php echo "$googleappsappsappsappsapps844444444474"; ?>'></img>

</div>

</div>

</div>

<?php

}

else

{

?>

<div style='position:absolute;left:12px;top:24px;cursor:pointer;'>

<div>

<div class='inline'>

<img class='textavatar' src="/gosearchimages8884/googleapps84747474.jpeg" style='width:34px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;border-radius:196px;border-style:solid;border-color:#f1f1f1;border-width:1px;' data-name='<?php echo "$googleappsappsappsappsapps844444444474"; ?>'></img>

</div>

</div>

</div>

<?php

}

?>

<?php

}

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsapps888474, $googleappsgoogleappsapps84);
$gosearchimagesappsapps84747674 = $googleappsgoogleappsapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsapps84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimagesappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsapps888474, $googleappsgoogle84);
$gosearchimagesappsappsappsapps84747674 = $googleappsgoogle84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimagesappsappsappsapps84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimagesappsappsappsapps84747674,"AES-128-ECB",$password);

?>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsapps888474, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

$gosearchimagesgooglegooglegoogleapps84747674 = "$name84747474";

$password = "googleappsmobileapps888888884444";

$gosearchimagesgooglegooglegoogleapps84747674 = rawurldecode($gosearchimagesgooglegooglegoogleapps84747674);

$gosearchimagesgooglegooglegoogleapps84747674 = openssl_decrypt($gosearchimagesgooglegooglegoogleapps84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsappsappsappsappsappsapps844444444474 = "<div class='textgoogleapps84747474' style='font-size:14.8px;margin-top:12px;'>$gosearchimagesappsapps84747674 $gosearchimagesappsappsappsapps84747674</div>";

?>

<?php

}

else

{

?>

<?php

$googleappsappsappsappsappsappsappsapps844444444474 = "<div class='textgoogleapps84747474'>$gosearchimages84747674</div>";

?>

<?php

}

?>

<div style="margin-left:44px;font-size:14.8px;word-wrap:break-word;margin-top:10px;font-weight:bold;cursor:pointer;" onclick="window.open('/people/usermail.php?useremail=<?php echo "$gosearchimagesgooglegooglegoogleapps84747674"; ?>','_self');">

<?php

echo "$googleappsappsappsappsappsappsappsapps844444444474";

?>

<?php

preg_match_all("/<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>\n<\/div>/", $googleapps84, $googleappsgoogleappsgooglegooglegoogleappsappsapps84);
$name84444474 = $googleappsgoogleappsgooglegooglegoogleappsappsapps84[3][0];

echo "<div style='font-size:14.8px;word-wrap:break-word;font-size:24px;margin-top:24px;margin-left:-44px;font-weight:normal!important;'>$name84444474</div><br>";

?>

</div>

<div style="position:absolute;right:12px;display:flex;bottom:12px;font-size:12.8px;color:#444444;">

<div style="padding-top:2.8px;">

<i class='material-icons' style="color:#ffffff;font-size:14.6px;background-color:<?php echo "$accountcolor4"; ?>;font-size:11px;padding:4px;border-radius:96px;padding-top:4px;margin-top:-1px;box-shadow:0 2px 4px rgba(0,0,0,0.2);">thumb_up</i>

</div>

<div style="padding:4px;font-size:12.4px;color:#444444;margin-left:4px;display:inline-block;">

<?php

echo "$namegoogleappsgooglegoogle84747474";

?>

</div>

</div>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>1<\/div>\n<\/div>\n<\/div>/", $googleappsappsappsapps84747444, $googleappsgooglegoogleapps84);

$namegoogleapps84747474 = $googleappsgooglegoogleapps84[1];

$namegoogleapps84747474 = count($namegoogleapps84747474);

?>

<script>

$(document).ready(function() {

$('#googleappsgoogleappsappsappsgoogleapps<?php echo "$googleappsappsgoogleapps84"; ?>').click(function(){

$.ajax({
    data: 'thumbsupapps84747474=1&userapps84747474=<?php echo "$_COOKIE[username]"; ?>&userappsappsapps84747474=<?php echo $googleappsappsgoogleappsappsappsapps84 - $namegoogleapps84747474; ?>',
    url: '/people/thumbsupapps84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

});

});

</script>

<div class="googleappsappsapps8474" id="googlegooglegoogleappsappsappsapps<?php echo "$googleappsappsgoogleapps84"; ?>" style="display:none;" onclick="$(this).hide();">

<div>

<div style="position:fixed;background-color:#bdbdbd;z-index:9884;height:100%;top:0px;width:100%;left:0px;background:rgba(0, 0, 0, 0.4);">

<div align="center" style="margin:12px;margin-top:62px;background-color:#f1f1f1;padding:12px;position:fixed;top:50%;left:50%;margin-top:-62px;margin-left:-62px;background:rgba(0, 0, 0, 0.4);">

<?php

if(preg_match("/Promote/","$google1"))

{

$googleappsapps1 = "Promoted";

}

if(preg_match("/Like/","$google1"))

{

$googleappsapps1 = "Liked";

}

if(preg_match("/1+/","$google1"))

{

$googleappsapps1 = "1+ed";

}

?>

<i class='material-icons' style="color:#ffffff;font-size:104px;">thumb_up</i>

</div>

</div>

</div>

</div>

<div class="googleappsappsapps8474" id="googlegooglegoogleappsappsappsappsgoogleappsapps<?php echo "$googleappsappsgoogleapps84"; ?>" style="display:none;">

<div>

<div style="position:fixed;background-color:#bdbdbd;z-index:9884;height:100%;top:0px;width:100%;left:0px;background:rgba(0, 0, 0, 0.4);">

<div align="center" style="margin:12px;margin-top:62px;background-color:#f1f1f1;padding:12px;">

<script>

function googleappsappsapps<?php echo $googleappsappsgoogleapps84; ?>() {

$(document).ready(function() {

var googlemobileapps844444444474 = $('#googledivdivdivappsappsapps84747474').val();

if(googlemobileapps844444444474 == "") {

$('#googlegooglegoogleappsappsappsappsgoogleappsapps<?php echo "$googleappsappsgoogleapps84"; ?>').hide();

}

else

{

var googlemobileappsgoogleappsapps84444474 = $('#googledivdivdivappsappsappsappsappsapps<?php echo $googleappsappsgoogleapps84; ?>').val();

$.ajax({
    data: 'useremail=' + googlemobileappsgoogleappsapps84444474 + '&emailtext=<?php echo $name84444474; ?>',
    url: '/people/writemail84747474.php',
    method: 'GET',
    success: function(msg) {
    }
});

$.ajax({
    data: 'googleapps84747474=' + googlemobileappsgoogleappsapps84444474 + '&googleapps1=<?php echo $_COOKIE[username]; ?>&googleapps4=<?php echo $name84444474; ?>&googleappsapps4=googleapps84',
    url: '/emailappsapps84747474/useremailsappsapps84444474.php',
    method: 'GET',
    success: function(msg) {
    }
});

$('#googlegooglegoogleappsappsappsappsgoogleappsapps<?php echo "$googleappsappsgoogleapps84"; ?>').hide();

}



}

);

}

</script>

<div id="pageviewsappsappsappsappsappsappsapps<?php echo $googleappsappsgoogleapps84; ?>" style="width:100%;position:absolute;margin-top:43.8px;z-index:44;"></div>

<script>

var timeout<?php echo $googleappsappsgoogleapps84; ?> = null;

function doDelayedSearchappsapps<?php echo $googleappsappsgoogleapps84; ?>(val) {
  if (timeout<?php echo $googleappsappsgoogleapps84; ?>) {  
    clearTimeout(timeout<?php echo $googleappsappsgoogleapps84; ?>);
  }
  timeout<?php echo $googleappsappsgoogleapps84; ?> = setTimeout(function() {

$('#pageviewsappsappsappsappsappsappsapps<?php echo $googleappsappsgoogleapps84; ?>').show();

$(document).ready(function(){

$("#pageviewsappsappsappsappsappsappsapps<?php echo $googleappsappsgoogleapps84; ?>").load('/people/useraccounts84442274.php?q=' + val + '&googleapps84747474=<?php echo $googleappsappsgoogleapps84; ?>');

}

);

}, 884);

}

</script>

<div>

<form action='/people/writemail84747474.php' class="input" method="get">

<input type="text" name="useremail" placeholder="To:" autocomplete="off" id="googledivdivdivappsappsappsappsappsapps<?php echo $googleappsappsgoogleapps84; ?>" style="width:100%;height:44px;padding-left:12px;box-sizing:border-box;margin-bottom:8px;border-style:solid;border-color:#dddddd;border-width:1px;outline-style:none;" onkeyup="doDelayedSearchappsapps<?php echo $googleappsappsgoogleapps84; ?>(this.value)" required></input>

<input type="text" name="emailtext" placeholder="" value="<?php echo $name84444474; ?>" autocomplete="off" style="width:100%;height:44px;padding-left:12px;box-sizing:border-box;border-style:solid;border-color:#dddddd;border-width:1px;outline-style:none;" required></input>

<button type="submit" name="action" style="margin-top:8px;background-color:<?php echo "$accountcolor1"; ?>;padding-top:8px;padding-bottom:8px;padding-left:18px;padding-right:18px;outline-style:none;border:none;color:#ffffff;border-radius:2px;font-size:12px;display:none;">send</button>

</form>

<div id="namemobileappsgoogledivapps84444474" style="border:none;padding:12px;background-color:#bdbdbd;text-align:left;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;margin-top:8px;" onclick="googleappsappsapps<?php echo $googleappsappsgoogleapps84; ?>();">

<?php echo "$google2"; ?>

</div>

</div>



</div>

</div>

</div>

</div>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsgoogledivapps84);
$accountcolor84742274 = $googleappsgoogledivapps84[3][0];

?>

<?php

preg_match_all("/<div class='$name84747474' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsgoogledivapps84);
$accountcolor847474 = $googleappsgoogledivapps84[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolor847474"))

{

$accountcolor1 = "$accountcolor847474";

$accountcolor2 = "$accountcolor847474";

$accountcolor4 = "$accountcolor847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<div style="display:flex;">

<div class="googlegoogleappsgoogleappsgooglegooglegooglegoogleapps84222274" id="googleappsgoogleappsappsappsgoogleapps<?php echo "$googleappsappsgoogleapps84"; ?>" style="font-size:12.8px;display:inline-block;cursor:pointer;width:100%;text-align:center;" onclick="$('#googlegooglegoogleappsappsappsapps<?php echo "$googleappsappsgoogleapps84"; ?>').show();">

<div style="display:flex;">

<div id="googleappsgoogleappsgooglegooglegooglegoogleapps844444444474" style="padding:12px;color:#444444;display:inline-block;font-weight:bold;text-align:center;">

<?php echo "$google1"; ?>

</div>

</div>

</div>

<script>

function myFunctiongoogleappsappsappsappsappsappsgooglegoogleapps<?php echo $googleappsappsgoogleapps84; ?>() {
    var x = document.getElementById('googleappsgoogleappsappsgoogleappsapps<?php echo $googleappsappsgoogleapps84; ?>');
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

</script>

<div class="googlegoogleappsgoogleappsgooglegooglegooglegoogleapps84222274" id="googleappsgoogleappsappsappsgoogleapps<?php echo "$googleappsappsgoogleapps84"; ?>" style="font-size:12.8px;display:inline-block;cursor:pointer;width:100%;text-align:center;" onclick="myFunctiongoogleappsappsappsappsappsappsgooglegoogleapps<?php echo $googleappsappsgoogleapps84; ?>();">

<div style="display:flex;">

<div id="googleappsgoogleappsgooglegooglegooglegoogleapps8444444444744474" style="padding:12px;color:#444444;display:inline-block;font-weight:bold;text-align:center;">

<?php echo "$googleappsappsappsappsapps84744444444474"; ?>

</div>

</div>



</div>

<div class="googlegoogleappsgoogleappsgooglegooglegooglegoogleapps84222274" id="googleappsgoogleappsappsappsgoogleapps<?php echo "$googleappsappsgoogleapps84"; ?>" style="font-size:12.8px;display:inline-block;cursor:pointer;width:100%;text-align:center;" onclick="$('#googlegooglegoogleappsappsappsappsgoogleappsapps<?php echo "$googleappsappsgoogleapps84"; ?>').show();">

<div style="display:flex;">

<div id="googleappsgoogleappsgooglegooglegooglegoogleapps844444444474" style="padding:12px;color:#444444;display:inline-block;font-weight:bold;text-align:center;">

<?php echo "$google2"; ?>

</div>

</div>



</div>

</div>

<script>

$(document).ready(function() {

$('#googleuser<?php echo "$googleappsappsgoogleapps84"; ?>').keypress(function(event) {

if (event.which == 13) {

var googlemobileappsgooglegoogleapps844444444474 = $('#googleuser<?php echo "$googleappsappsgoogleapps84"; ?>').val();

if(googlemobileappsgooglegoogleapps844444444474 == "") {

}

else

{

var googlemobileappsappsgoogleapps84444474 = $('#googleuser<?php echo "$googleappsappsgoogleapps84"; ?>').val();

$.ajax({
    data: 'mainactivityapps84444474=<?php echo "$nameappsapps8884"; ?>&mainactivityapps84747474=' + googlemobileappsappsgoogleapps84444474 + '&mainactivityappsuserapps84747474=<?php echo $_COOKIE[username]; ?>&googleappsapps84444474=<?php echo "$namegoogleappsgooglegooglegoogleappsgoogleappsappsgoogleappsgooglegooglegooglegooglegoogleapps84747474"; ?>',
    url: '/people/mainactivitywrite84444474.php',
    method: 'GET',
    success: function(msg) {
    }
});

location.reload();

}

}

});

});

</script>

<div class="googleappsgoogleappsappsgoogleappsapps<?php echo "$googleappsappsgoogleapps84"; ?>" id="googleappsgoogleappsappsgoogleappsapps<?php echo "$googleappsappsgoogleapps84"; ?>" style="display:none;width:100%;box-sizing:border-box;">



<div>

<div style="padding:12px;margin-top:24px;background-color:#ffffff;margin-left:-12px;margin-bottom:12px;">

<div style="display:flex;">

<div style="margin-top:2px;">

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../firstnameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/firstnameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsapps84747674);

$gosearchimagesappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../lastnameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/lastnameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimagesappsappsappsapps84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimagesappsappsappsapps84747674);

$gosearchimagesappsappsappsapps84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserapps84 = "../usernameapps84747474.sh";

}

else

{

$dataurluserapps84 = "../people/usernameapps84747474.sh";

}

?>

<?php

$googleappsuserapps888474 = file_get_contents($dataurluserapps84);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserapps888474, $googleapps84);
$gosearchimages84747674 = $googleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/[\W\w]/","$gosearchimagesappsapps84747674"))

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimagesappsapps84747674 $gosearchimagesappsappsappsapps84747674";

?>

<?php

}

else

{

?>

<?php

$googleappsappsapps844444444474 = "$gosearchimages84747674";

?>

<?php

}

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsgooglegooglegooglegoogleappsappsapps8884, $googleappsappsappsappsappsappsapps84);
$gosearchimagesgoogleappsappsappsappsappsappsapps84747474 = $googleappsappsappsappsappsappsapps84[2][0];

?>

<?php

if(preg_match("/[\W\w]/",$gosearchimagesgoogleappsappsappsappsappsappsapps84747474))

{

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps84742274 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'><div class='(.*?)'><div class='(.*?)'>(.*?)<\/div><\/div><\/div>/s", $googleappsgooglegoogleapps8884, $googleappsgoogleappsgoogleappsappsapps844444444474);
$accountcolorgoogleappsappsapps847474 = $googleappsgoogleappsgoogleappsappsapps844444444474[3][0];

?>

<?php

if(preg_match("/[\W\w]/","$accountcolorgoogleappsappsapps847474"))

{

$accountcolor1 = "$accountcolorgoogleappsappsapps847474";

$accountcolor2 = "$accountcolorgoogleappsappsapps847474";

$accountcolor4 = "$accountcolorgoogleappsappsapps847474";

}

else

{

$accountcolor1 = "#1565C0";

$accountcolor2 = "#1565C0";

$accountcolor4 = "#1565C0";

}

?>

<div id="div84747474" style="left:12px;top:24px;"><img src="<?php echo $gosearchimagesgoogleappsappsappsappsappsappsapps84747474; ?>" width="34" height="34" style="border-color:<?php echo "$accountcolor4"; ?>;border-width:2px;box-shadow:0 2px 4px rgba(0,0,0,0.1);" onclick='myFunctiongoogleappsappsappsappsapps()'></img></div>

<?php

}

else

{

?>

<?php

$googleappsappsappsappsapps844444444474 = preg_replace("/(.*?) (.*?)/","$1",$googleappsappsapps844444444474);

?>

<?php

if(preg_match("/[\W\w]/",$_SERVER['HTTP_HOST']))

{

$dataurluserappsappsappsappsappsappsapps84 = "../googleappsapps84747474.sh";

}

else

{

$dataurluserappsappsappsappsappsappsapps84 = "../people/googleappsapps84747474.sh";

}

?>

<?php

$googleappsuserappsappsappsappsappsapps888474 = file_get_contents($dataurluserappsappsappsappsappsappsapps84);

?>

<?php

$google84747474 = $_GET['useremail'];

$nameappsapps8884 = $google84747474;
$passwordname8884 = "googleappsmobileapps888888884444";

$nameappsapps8884 = openssl_encrypt($nameappsapps8884,"AES-128-ECB",$passwordname8884);

$nameappsapps8884 = rawurlencode($nameappsapps8884);

?>

<?php

preg_match_all("/<div class='$_COOKIE[username]' id='(.*?)'>\n<div class='(.*?)' id='(.*?)'>(.*?)<\/div>\n<\/div>/", $googleappsuserappsappsappsappsappsapps888474, $googleappsgoogleapps84);
$gosearchimages84747674 = $googleappsgoogleapps84[2][0];

?>

<?php

$password = "googleappsmobileapps888888884444";

$gosearchimages84747674 = rawurldecode($gosearchimages84747674);

$gosearchimages84747674 = openssl_decrypt($gosearchimages84747674,"AES-128-ECB",$password);

?>

<?php

if(preg_match("/(^Male$|^male$)/","$gosearchimages84747674"))

{

?>

<div style=''>

<div>

<div class='inline'>

<img class='textavatar' src="/gosearchimages8884/googleapps84.jpg" style='width:34px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;border-radius:196px;border-style:solid;border-color:#f1f1f1;border-width:1px;'></img>

</div>

</div>

</div>

<?php

}

else

{

?>

<div style=''>

<div>

<div class='inline'>

<img class='textavatar' src="/gosearchimages8884/googleapps84747474.jpeg" style='width:34px;background-color:<?php echo "$accountcolor4"; ?>;color:#ffffff;border-radius:196px;border-style:solid;border-color:#f1f1f1;border-width:1px;'></img>

</div>

</div>

</div>

<?php

}

?>

<?php

}

?>

</div>

<div style="width:100%;">

<div>

<input type="text" placeholder="<?php echo "$googleappsappsappsappsapps84744444444474"; ?>" value="" name="writeapps84747474" id="googleuser<?php echo "$googleappsappsgoogleapps84"; ?>" style="padding:12px;width:100%;box-sizing:border-box;border-radius:96px;border-style:solid;border-width:1px;border-color:#bdbdbd;outline-style:none;width:100%;margin-left:4px;" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="Write" value="<?php echo $_COOKIE[username]; ?>" name="writeappsuser84747474" autocomplete="off"  required autofocus></input>

</div>

<div>

<input type="hidden" placeholder="write" value="<?php echo "$_GET[useremail]"; ?>" name="useremail" autocomplete="off"  required></input>

</div>



</div>

</div>



</div>

</div>



<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) 