<?php

error_reporting(0);

?>

<?php

include "../dashboard/dashboardtop.php";

?>

<?php

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn = new mysqli($servername, $username, $password, $dbname);

$conn847474744474 = new mysqli($servername, $username, $password, $dbname);

?>

<?php

$countryapps8884 = $_COOKIE['country'];

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $isocode8884);

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<div style="margin-top:10px;margin:12px;">

<style>

@media screen and (min-width: 1884px)
{
html
{
zoom:1.4;
}
}

@media screen and (min-width: 2560px)
{
html
{
zoom:2;
}
}

</style>

<?php

$isSecure = false;
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
    $isSecure = true;
}
elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || !empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] == 'on') {
    $isSecure = true;
}
$googleprotocolapps8884 = $isSecure ? 'https' : 'http';

?>

<?php

$file84 = array();

$query = "SELECT * FROM mailapps84747474 WHERE email='$_COOKIE[username]' order by date desc limit $_GET[googleapps84],8";

$result = mysqli_query($conn847474744474,$query);

foreach($result as $row)

{

$file84[] = $row['email'];

}

?>

<?php

$googleappsapps847474747474744474 = "-1";

?>

<?php

$file844444444444744474 = array();

$query84747474744474 = "SELECT * FROM mailapps84747474 WHERE email='$_COOKIE[username]' order by date desc";

$result84747474744474 = mysqli_query($conn847474744474,$query84747474744474);

foreach($result84747474744474 as $row84747474744474)

{

$file844444444444744474[] = $row84747474744474['emailtext'];

}

?>

<?php

$emailtextgoogleapps84747474 = array();

$query84747474744474 = "SELECT * FROM mailapps84747474 WHERE email='$_COOKIE[username]' order by date desc";

$result84747474744474 = mysqli_query($conn847474744474,$query84747474744474);

foreach($result84747474744474 as $row84747474744474)

{

$emailtextgoogleapps84747474[] = $row84747474744474['date'];

}

?>

<?php

$emailtextgoogleapps847474744444444474 = array();

$query84747474744474 = "SELECT * FROM mailapps84747474 WHERE email='$_COOKIE[username]' order by date desc";

$result84747474744474 = mysqli_query($conn847474744474,$query84747474744474);

foreach($result84747474744474 as $row84747474744474)

{

$emailtextgoogleapps847474744444444474[] = $row84747474744474['toemail'];

}

?>

<style>

.googleappsapps847474747474744474:hover
{
box-shadow:0 2px 12px rgba(0,0,0,0.4);
}

</style>

<?php

foreach($file84 as $googleappsapps84747474)

{

$googleappsapps847474747474744474++;

?>

<?php

$stringtoencrypt = $emailtextgoogleapps847474744444444474[$googleappsapps847474747474744474];

$decryptedstring888474 = rawurldecode($stringtoencrypt);

$password = "googleappsmobileapps888888884444";

$decryptedstringemailtext84747474 = openssl_decrypt($decryptedstring888474,"AES-128-ECB",$password);

$stringtoencrypt84747474 = $file844444444444744474[$googleappsapps847474747474744474];

$decryptedstring88847484747474 = rawurldecode($stringtoencrypt84747474);

$password84747474 = "googleappsmobileapps888888884444";

$decryptedstringemailtext8474747484747474 = openssl_decrypt($decryptedstring88847484747474,"AES-128-ECB",$password84747474);

?>

<style>

.googleapps8474747474747474747474
{
background-color:#4285f4!important;
border-color:#4285f4!important;
}

.googleapps84747474747474747474744474
{
color:#ffffff;
}

</style>

<div class="googleappsapps847474747474744474" style="padding:12px;border-bottom-style:solid;border-width:1px;border-color:#bdbdbd;">

<div style="display:flex;">

<div style="margin-left:-12px;">

<div style="position:relative;">

<form action="/people/pagemail.php" method="get" class="google847474747444744474<?php echo "$googleappsapps847474747474744474"; ?>">

<div class="googleapps8474747474747474744474" style="position:absolute;left:19.8px;top:10px;">

<div style="position:relative;z-index:8884;border-style:solid;border-width:1px;border-radius:2px;border-color:#bdbdbd;padding:8px;position:relative;background-color:#ffffff;" onclick="$('.google8474747444744474447444744474<?php echo "$googleappsapps847474747474744474"; ?>').toggle();$('.googleappsapps8474747474747474747474').toggle();$(this).toggleClass('googleapps8474747474747474747474');$('.googleappsapps8474747474747474747474').toggleClass('googleapps84747474747474747474744474');">

<i class="material-icons googleappsapps8474747474747474747474" style="display:none;font-size:12px;position:absolute;top:2px;left:2px;">check</i>

</div>

</div>

<input type="hidden" name="mailappsapps847474744474447444744474" value="<?php echo $file844444444444744474[$googleappsapps847474747474744474]; ?>">

<input type="hidden" name="dateappsapps84747474" value="<?php echo $emailtextgoogleapps84747474[$googleappsapps847474747474744474]; ?>">

<input type="submit" class="googleappsappsappsappsapps847474744474447444444474<?php echo "$googleappsapps847474747474744474"; ?>" value="Submit" style="display:none;">

</form>

</div>

</div>

<div style="padding-left:62px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">

<?php

echo "<br>" . $decryptedstringemailtext84747474;

echo "<br>" . $decryptedstringemailtext8474747484747474;

$google84747474 = date("M d", strtotime($emailtextgoogleapps84747474[$googleappsapps847474747474744474]));

echo "<br>" . "$google84747474";

?>

</div>

</div>

<div class="google8474747444744474447444744474<?php echo "$googleappsapps847474747474744474"; ?> googleappsappsapps84747474747444744474" style="padding:12px;background-color:#ffffff;display:none;position:relative;position:relative;z-index:8884;">

<i class="material-icons googleapps84" onclick="googleapps84747474747444744474<?php echo "$googleappsapps847474747474744474"; ?>();" style="color:#444444;z-index:44;position:relative;cursor:pointer;position:relative;z-index:88888884;">delete</i>

<div class="googleappsappsappsapps84747474" style="background-color:#bdbdbd;position:absolute;left:12px;top:12px;padding:12px;border-radius:196px;left:8px;top:8px;padding:15.8px;border-radius:196px;display:none;cursor:pointer;relative;z-index:8884;">
</div>

</div>

</div>

<script>

function googleapps84747474747444744474<?php echo "$googleappsapps847474747474744474"; ?>() {

$(document).ready(function(){

$('.google847474747444744474<?php echo "$googleappsapps847474747474744474"; ?>').submit();

});

}

</script>

<?php

?>

<?php

}

?>

<?php

if(preg_match("/[\W\w]/",$_GET['mailappsapps847474744474447444744474']))

{

?>

<?php

$google84747474 = $_COOKIE['username'];

$google847474744474 = $_GET['mailappsapps847474744474447444744474'];

$google8474747444744444444444744474 = $_GET['dateappsapps84747474'];

?>

<?php

$query = "DELETE FROM mailapps84747474 WHERE email='$google84747474' and emailtext='$google847474744474' and date='$google8474747444744444444444744474'";

$result84747474 = mysqli_query($conn847474744474,$query);

echo "<div style='display:none;'>$result84747474</div>";

?>

<script>

location = "/people/pagemail.php?googleapps84=0&googleapps8474=8";

</script>

<?php

}

?>

<?php

include "../dashboard/dashboardbottom.php";

?>

<?php

$conn847474744474->close();

?>

