<div align="center" style="background-color:#f1f1f1;padding:12px;border-style:solid;border-top:none;border-left:none;border-right:none;border-width:2px;border-color:#bdbdbd;">
</div>

