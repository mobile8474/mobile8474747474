<?php

$countryapps8884 = $_COOKIE['country'];

$servername = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps84.sh"));
$username = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps1.sh"));
$password = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps2.sh"));
$dbname = preg_replace("/\s+/","",file_get_contents("../googleapps84/googleapps4.sh"));

$conn8444444444744444444474 = new mysqli($servername, $username, $password, $dbname);

?>

<?php

include 'getcountrygoogleapps8884.php';

$isocode8884 = array_search($countryapps8884, $countries);

?>

<?php

$googleappscountryapps8884 = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, "$isocode8884");

$googleappscountryapps8884 = reset($googleappscountryapps8884);

?>

<?php

date_default_timezone_set("$googleappscountryapps8884");

?>

<?php

include "../dashboard/dashboardtop.php";

?>

<div style="padding:12px;margin:12px;box-shadow:0 2px 12px rgba(0,0,0,0.4);background-color:#ffffff;">

<div>

<h3>

Copyright notice

</h3>

</div>

<div>

<h2>

This website and its content is copyright of Devcloudplatform - © Devcloudplatform <?php echo date("Y"); ?>. All rights reserved.

</h2>

</div>

<div>

Any redistribution or reproduction of part or all of the contents in any form is prohibited other than the following:

</div>

<br>

<div>

you may print or download to a local hard disk extracts for your personal and non-commercial use only

</div>

<br>

<div>

you may copy the content to individual third parties for their personal use, but only if you acknowledge the website as the source of the material

</div>

<br>

<div>

You may not, except with our express written permission, distribute or commercially exploit the content. Nor may you transmit it or store it in any other website or other form of electronic retrieval system.

</div>

</div>

<?php

include "../dashboard/dashboardbottom.php";

?>

<?php

$conn8444444444744444444474->close();

?>

